--[[
    ===========================================================================
    BarterHandIn.lua  (v1.3)
    ===========================================================================
    An ImGui-based MacroQuest (MQ) Lua script for EverQuest that automates
    finding and selling items into an NPC "Barter" merchant window.

    ---------------------------------------------------------------------------
    WHAT IT DOES
    ---------------------------------------------------------------------------
    With a target selected and an item chosen from your inventory dropdown,
    the script can:
      1. Move within CONFIG.MAX_DISTANCE of your current target (uses
         MQ2Nav if it's loaded to auto-path there; otherwise it just
         reports the distance and asks you to move closer yourself).
      2. Right-click your target to open their Barter window.
      3. Confirm the Barter window actually opened.
      4. Locate the selected item's row inside the Barter window's
         buy-line list (the list of items the NPC wants to buy).
      5. Read and display that row's quantity-wanted and price-per-item.
      6. Optionally sell/hand in a chosen quantity of the item, batching
         the hand-in into groups of CONFIG.MAX_PER_ATTEMPT (the game only
         allows handing in a limited number of items per attempt),
         re-locating the item's row before each batch since the list can
         shift or the row can disappear once fully sold.

    After every successful hand-in batch, the script also re-reads three
    values fresh from the game (never trusting pre-sale state): your
    current platinum, how much of the traded item you have left on hand,
    and how much of it the buyer still wants. These are logged after each
    batch and shown live in the main window as "Last hand-in refresh".

    It also has a "Load Barter Items Table" action that scans every row in
    the buyer's list and shows only the items you actually carry, with
    quantity wanted, price each, and how many you have on hand - so you
    don't have to check items one at a time.

    A "Debug Dump Selected" button is available next to "Refresh
    Inventory" for troubleshooting on-hand counts: it logs every raw
    inventory slot/sub-slot the selected item is found in, with each
    location's item ID and count, so a miscount can be tracked back to
    its exact source (see the "on-hand counts inflated" note under
    CONFIGURATION below).

    ---------------------------------------------------------------------------
    REQUIREMENTS
    ---------------------------------------------------------------------------
    - MacroQuest (MQ2/MQNext) with Lua scripting support (the `mq` and
      `ImGui` Lua modules).
    - MQ2Nav plugin (optional) - only needed for automatic movement toward
      the target; without it, the script will tell you to move manually.

    ---------------------------------------------------------------------------
    HOW TO RUN
    ---------------------------------------------------------------------------
    1. Place this file where MQ looks for Lua scripts (e.g. `lua/` folder)
       and launch it in-game with `/lua run <scriptname>`.
    2. Target the NPC/merchant you want to barter with.
    3. In the "Barter Hand-In" ImGui window that appears:
         - Click "Refresh Inventory" if your inventory changed after the
           script started (it auto-scans once on load). With an item
           selected in the dropdown, "Debug Dump Selected" appears next
           to it for troubleshooting on-hand counts (see CONFIGURATION).
         - Pick an item from the "Item" dropdown, then click "Locate Item"
           to run steps 1-5 above for just that item, OR click
           "Load Barter Items Table" to see every sellable-to-this-buyer
           item you're carrying at once.
         - From the results table, click "Sell" next to a row to open the
           quantity-picker popup, choose a quantity, and click
           "Confirm Sell" to run the hand-in (steps 1-6). After each
           hand-in batch, watch the log or the "Last hand-in refresh"
           line in the main window for your updated plat, on-hand count,
           and the buyer's remaining qty wanted.
    4. Click "Exit" (or close the window) to stop the script.

    ---------------------------------------------------------------------------
    CONFIGURATION (see the CONFIG table below)
    ---------------------------------------------------------------------------
    All tunable values live in one place at the top of the script:
      - BARTER_WND / BARTER_BUYLIST / BARTER_BUYLIST_INNER: names of the
        Barter window and its buy-line list control. BARTER_BUYLIST_INNER
        is a fallback used automatically if BARTER_BUYLIST isn't itself a
        usable list (see resolveBuyList()).
      - BARTER_COL_NAME / BARTER_COL_QTY / BARTER_COL_PRICE: 1-based
        column indices within the buy-line list for item name, quantity
        wanted, and price paid per item, respectively.
      - MAX_DISTANCE: how close (in EQ distance units) you must be to the
        target before the script will attempt to open the Barter window.
      - INV_SLOT_START / INV_SLOT_END: the inventory pack slot range that
        refreshInventory() scans (including sub-slots of bags in that
        range) to build the item dropdown - only stackable items are
        listed.
      - ACTION_DELAY_MS / WAIT_TIMEOUT_MS: pacing/timeout values used
        between in-game actions and while polling for UI state changes.
      - SELL_BUTTON / QUANTITY_WND / QUANTITY_SLIDER /
        QUANTITY_SLIDER_ALT / QUANTITY_ACCEPT: control names used to
        click "Sell" and, if a quantity-split prompt appears, set the
        quantity and accept it.
      - MAX_PER_ATTEMPT: the max quantity handed in per single Sell click,
        used to split larger sales into multiple batches.

    ON-HAND COUNTS LOOKING INFLATED (e.g. a clean multiple of the real
    amount, like 4x)? Some MQ builds/clients hand back a non-nil
    Inventory() result for a slot in the INV_SLOT_START..END range that
    isn't actually a distinct bag you own, aliasing back onto one already
    scanned - which silently re-sums that bag's contents once per alias.
    refreshInventory() guards against this by tracking each bag's and
    each item stack's unique in-game .ID() and skipping anything it's
    already counted (see the v1.3 changelog entry below). If a count
    still looks wrong after that fix, select the item in the dropdown
    and click "Debug Dump Selected" - it logs every raw slot/sub-slot
    location the item is found in (with each one's item ID and count) so
    you can see exactly what's being counted and where.

    !!! VERIFY THESE AGAINST YOUR CLIENT !!!
    Window/child names and column layout can vary between MQ/EQ builds.
    Values currently marked "confirmed" below were checked against this
    script's own "Load Barter Items Table" / row-dump output, but you
    should re-verify anything not explicitly marked confirmed before
    relying on it, especially the Sell/QuantityWnd controls:
      - CONFIG.BARTER_WND / BARTER_BUYLIST: confirmed against known Barter
        macros (BarterWnd / BTR_BuyLineList).
      - Column layout for BTRMERCH_BuyLineList is CONFIRMED via row-dump
        output: col 2 = item name, col 3 = qty the buyer wants, col 4 =
        price paid per item.
      - QuantityWnd control names come from other known-working EQ
        quantity-split prompts, but are NOT yet independently confirmed
        for this specific Sell button's prompt - watch the log the first
        time you sell a quantity that triggers it.
      - If MQ2Nav isn't loaded, movement (step 1) is skipped and you'll be
        told to move into range yourself.

    ---------------------------------------------------------------------------
    SCRIPT LAYOUT
    ---------------------------------------------------------------------------
      CONFIG              - all tunable settings (see above).
      STATE               - module-level variables tracking UI state, the
                             scanned inventory list, the currently loaded
                             barter rows, and the sell-quantity popup state.
      INVENTORY SCANNING   - refreshInventory() builds itemList from
                             CONFIG.INV_SLOT_START..END, merging stackable
                             items of the same name, and dedupes against
                             re-reading the same bag/stack twice via
                             unique .ID() tracking (see the on-hand-counts
                             note under CONFIGURATION). dumpRawSlotsForItem()
                             is a read-only diagnostic that logs every raw
                             slot/sub-slot location a given item is found
                             in, for troubleshooting on-hand counts.
      STEP HELPERS         - waitFor()/isWindowOpen() polling helpers,
                             moveWithinRange() (step 1),
                             openBarterWindowOnTarget() (steps 2-3),
                             resolveBuyList() (finds the buy-line list
                             control, with a fallback child name),
                             locateItemAndReadQty() (steps 4-5),
                             loadBarterItemsTable() (bulk row scan/filter
                             against inventory for the results table).
      MAIN ACTION           - parsePriceText()/formatCurrency() for
                             displaying prices, sellBatchViaButton() and
                             performSell() (drive the actual sell/hand-in,
                             batching by MAX_PER_ATTEMPT), plus
                             locateItemByName()/locateSelectedItem() and
                             the safeXxx() pcall wrappers used by the main
                             loop so a Lua error in one action doesn't
                             crash the script. refreshPostHandInState()
                             re-reads plat/on-hand/buyer-qty fresh after
                             each successful hand-in batch, called from
                             performSell().
      UI                    - DrawUIBody()/DrawUI() render the main
                             window (inventory dropdown, "Debug Dump
                             Selected" button, target info, "Last hand-in
                             refresh" line, action buttons, and results
                             table); DrawSellPopupBody()/DrawSellPopup()
                             render the quantity-picker/confirmation
                             popup.
      MAIN LOOP             - mq.imgui.init() registers the UI callback,
                             then the `while isOpen do ... end` loop
                             dispatches queued actions (pendingLocate,
                             pendingLoadTable, pendingLocateName,
                             pendingSellName) one at a time so blocking
                             calls like mq.delay() only ever run outside
                             the ImGui render callback.

    ---------------------------------------------------------------------------
    SAFETY NOTES
    ---------------------------------------------------------------------------
    - Selling is irreversible in-game; double-check the item, quantity,
      and expected plat total shown in the Sell popup before confirming.
    - If a sell action errors out mid-batch, the script logs a warning if
      an item is still sitting on your cursor so you can check your
      character before doing anything else.

    ---------------------------------------------------------------------------
    CHANGELOG
    ---------------------------------------------------------------------------
    v1.4 - Clicking "Exit" (or closing the window with the X) now also
           closes the NPC's Barter window if it's still open, instead of
           leaving it up on screen after the script stops. See
           closeBarterWindowIfOpen(), called once on the way out after
           the main loop ends.
    v1.3 - Fixed reported on-hand item counts being inflated (consistently
           by a fixed multiple, e.g. 4x actual) for some MQ builds/clients.
           refreshInventory() now tracks each bag's and each item stack's
           unique in-game .ID() and skips re-counting one it's already
           seen, instead of assuming every slot 23-34 it can query is a
           distinct, real bag - some builds hand back a non-nil result
           for a slot that isn't a real distinct bag, aliasing back onto
           one already scanned, which silently multiplied every count
           inside it. Also added a "Debug Dump Selected" button (calls
           new dumpRawSlotsForItem()) that logs every raw slot/sub-slot
           location an item is found in, for diagnosing this kind of
           issue directly from the log if it recurs.
    v1.2 - After every successful hand-in batch, the script now re-reads
           three values fresh from the game rather than trusting
           pre-sale state: your current platinum (Me.Platinum()), how
           much of the traded item you have left on hand, and how much
           of it the buyer still wants (re-scanned from their buy-line
           row). See refreshPostHandInState(), called from performSell()
           after each batch. These are logged after every hand-in and
           also shown live in the main window as "Last hand-in refresh".
    v1.1 - Version bump (window title now reads "Barter Hand-In (v1.1)").
           Removed the per-row "row N: buyer wants ..." log line printed
           while scanning the buy-line list in loadBarterItemsTable(), to
           cut down on notification/log spam during "Load Barter Items
           Table".
           Moved the "Locate Item" button so it sits on the same line as
           the "Item" selection dropdown, instead of down with the other
           action buttons.
    v1.0 - Initial documented release: locate/read item rows (steps 1-5),
           bulk "Load Barter Items Table" scan, and batched sell/hand-in
           (step 6) with a quantity-picker confirmation popup.
--]]

local mq = require('mq')
local ImGui = require('ImGui')

-- ============================================================
-- CONFIG
-- ============================================================
local CONFIG = {
    BARTER_WND       = "BarterMerchantWnd",
    BARTER_BUYLIST       = "BTRMERCH_BuyLineList", -- direct child of BARTER_WND
    BARTER_BUYLIST_INNER = "BuyLineList",          -- fallback guess if the above isn't a real list
    BARTER_COL_NAME  = 2,
    BARTER_COL_QTY   = 3,   -- confirmed via row dump
    BARTER_COL_PRICE = 4,   -- confirmed via row dump (price per item)

    MAX_DISTANCE     = 10,  -- "10 paces" - paces roughly line up with EQ distance units

    INV_SLOT_START   = 23,
    INV_SLOT_END     = 34,

    ACTION_DELAY_MS  = 400,
    WAIT_TIMEOUT_MS  = 5000,

    -- Selling controls. SELL_BUTTON is confirmed. QuantityWnd names
    -- come from known-working EQ quantity-split prompts elsewhere in
    -- the client; not yet independently confirmed for this specific
    -- Sell button's prompt - watch the log on your first real test.
    SELL_BUTTON      = "BTRMERCH_SellButton",
    QUANTITY_WND     = "QuantityWnd",
    QUANTITY_SLIDER      = "QTYW_slider",      -- per MQ's own /notify docs: "newvalue" applies here
    QUANTITY_SLIDER_ALT  = "QTYW_SliderInput", -- fallback in case this build names it differently
    QUANTITY_ACCEPT  = "QTYW_Accept_Button",

    MAX_PER_ATTEMPT  = 20, -- the game only allows handing in 20 at a time; larger sells are batched
}

-- ============================================================
-- STATE
-- ============================================================
local itemList = {}
local selectedIndex = nil
local isOpen = true
local shouldDraw = true
local busy = false
local pendingLocate = false
local pendingLoadTable = false
local pendingLocateName = nil -- set when a per-row "Select" button is clicked
local pendingSellName = nil   -- set when "Confirm Sell" is clicked
local pendingSellQty = 0
local lastFoundQty = nil
local barterRows = {} -- { {name=, qty=, price=}, ... } - populated from the barter window for display

-- Post hand-in refresh state - re-read fresh after every successful
-- hand-in batch (see refreshPostHandInState()) so nothing downstream
-- ever relies on pre-sale (stale) plat/inventory/buyer-qty values.
local lastPlatinum = nil       -- fresh Me.Platinum() read after the most recent hand-in
local lastHandInItemName = nil -- item name the three values below apply to
local lastHandInOnHand = nil   -- fresh on-hand count of that item after the most recent hand-in
local lastHandInBuyerQty = nil -- fresh "qty wanted" from the buyer's row after the most recent hand-in

-- Sell popup state
local sellPopupOpen = false
local sellPopupItemName = nil
local sellPopupMaxQty = 0
local sellPopupQty = 0
local sellPopupPricePerItem = nil -- numeric price per unit, or nil if it couldn't be parsed
local sellPopupPriceUnit = nil    -- any trailing unit text from the price column, e.g. "pp"

local function log(msg)
    -- \at = teal, \ay = yellow, \ax = reset to default - standard EQ/MQ
    -- inline chat color codes, rendered by the MQ console.
    print(string.format("\at[BarterHandIn]\ax \ay%s\ax", tostring(msg)))
end

-- ============================================================
-- INVENTORY SCANNING
-- ============================================================
-- Dedupe guards: some MQ builds/clients will hand back a non-nil
-- Inventory() result for a slot index that doesn't correspond to a
-- distinct bag the character actually has (e.g. an out-of-range or
-- unpopulated general-inventory slot aliases back onto a bag we
-- already scanned at a different slot number, instead of returning
-- nil). Left unguarded, that silently re-sums the same physical bag's
-- (or the same physical item stack's) contents once per alias, which
-- is exactly what a consistent Nx-inflated on-hand count looks like.
-- Every bag and every item stack has its own unique in-game item ID
-- (two genuinely separate stacks of the same item name still get
-- different IDs), so tracking IDs we've already counted and skipping
-- repeats fixes this without needing to know why the alias happens,
-- and is a no-op (no behavior change) if this MQ build doesn't expose
-- .ID() the way we expect.
local function refreshInventory()
    itemList = {}
    local byName = {}
    local skippedNonStackable = 0
    local skippedDuplicate = 0
    local seenBagIDs = {}
    local seenItemIDs = {}

    local function addCount(name, count)
        byName[name] = byName[name] or { name = name, total = 0 }
        byName[name].total = byName[name].total + count
    end

    -- Returns true if `tlo` has a usable, not-yet-seen .ID() (and marks
    -- it seen), false if it has a usable ID that's already been seen
    -- (a duplicate - caller should skip it), or nil if no usable ID
    -- was available at all (caller should treat it as never-duplicate,
    -- since we have no reliable way to tell).
    local function markSeen(tlo, seenSet)
        local idOk, id = pcall(function() return tlo.ID() end)
        if not idOk or not id then return nil end
        if seenSet[id] then return false end
        seenSet[id] = true
        return true
    end

    for slot = CONFIG.INV_SLOT_START, CONFIG.INV_SLOT_END do
        local invItem = mq.TLO.Me.Inventory(slot)
        if invItem() then
            local containerSlots = invItem.Container()
            if containerSlots and containerSlots > 0 then
                local bagSeen = markSeen(invItem, seenBagIDs)
                if bagSeen == false then
                    skippedDuplicate = skippedDuplicate + 1
                else
                    for sub = 1, containerSlots do
                        local subItem = invItem.Item(sub)
                        if subItem() and subItem.Name() then
                            local stackOk, stackable = pcall(function() return subItem.Stackable() end)
                            if stackOk and stackable then
                                local itemSeen = markSeen(subItem, seenItemIDs)
                                if itemSeen == false then
                                    skippedDuplicate = skippedDuplicate + 1
                                else
                                    local name = subItem.Name()
                                    local count = subItem.StackCount() or 1
                                    if count < 1 then count = 1 end
                                    addCount(name, count)
                                end
                            else
                                skippedNonStackable = skippedNonStackable + 1
                            end
                        end
                    end
                end
            else
                local name = invItem.Name()
                if name then
                    local stackOk, stackable = pcall(function() return invItem.Stackable() end)
                    if stackOk and stackable then
                        local itemSeen = markSeen(invItem, seenItemIDs)
                        if itemSeen == false then
                            skippedDuplicate = skippedDuplicate + 1
                        else
                            local count = invItem.StackCount() or 1
                            if count < 1 then count = 1 end
                            addCount(name, count)
                        end
                    else
                        skippedNonStackable = skippedNonStackable + 1
                    end
                end
            end
        end
    end

    for _, entry in pairs(byName) do
        table.insert(itemList, entry)
    end
    table.sort(itemList, function(a, b) return a.name < b.name end)

    if skippedDuplicate > 0 then
        log(string.format(
            "NOTE: skipped %d duplicate slot/item read(s) that pointed at a bag or stack already counted (this is what was causing inflated on-hand counts).",
            skippedDuplicate))
    end

    if selectedIndex and selectedIndex > #itemList then
        selectedIndex = nil
    end

    log(string.format("Inventory refreshed: %d distinct stackable item(s) (%d non-stackable item(s) skipped).",
        #itemList, skippedNonStackable))
end

-- Diagnostic only - does not affect itemList. Walks the exact same
-- slot range as refreshInventory() and logs every single (slot, sub)
-- location that matches `itemName`, with its item ID and count, plus a
-- running total. Use this if the on-hand count still looks wrong after
-- the dedupe fix in refreshInventory() - the output shows exactly
-- which physical slots are contributing, which pins down whether a
-- bag/slot is genuinely being read more than once (and if so, whether
-- .ID() came back nil for it, which would explain why the dedupe guard
-- couldn't catch it on this MQ build).
local function dumpRawSlotsForItem(itemName)
    if not itemName or itemName == "" then
        log("DEBUG DUMP: no item name given.")
        return
    end

    log(string.format("=== DEBUG DUMP: raw scan for '%s' across slots %d-%d ===",
        itemName, CONFIG.INV_SLOT_START, CONFIG.INV_SLOT_END))

    local runningTotal = 0
    for slot = CONFIG.INV_SLOT_START, CONFIG.INV_SLOT_END do
        local invItem = mq.TLO.Me.Inventory(slot)
        local exists = invItem() ~= nil
        if exists then
            local bagIdOk, bagId = pcall(function() return invItem.ID() end)
            local containerSlots = invItem.Container()
            log(string.format("slot %d: bagName=%s bagID=%s container=%s",
                slot, tostring(invItem.Name()), tostring(bagIdOk and bagId or "?"), tostring(containerSlots)))

            if containerSlots and containerSlots > 0 then
                for sub = 1, containerSlots do
                    local subItem = invItem.Item(sub)
                    if subItem() and subItem.Name() and subItem.Name():lower() == itemName:lower() then
                        local idOk, id = pcall(function() return subItem.ID() end)
                        local cntOk, count = pcall(function() return subItem.StackCount() end)
                        count = (cntOk and count) or 1
                        if count < 1 then count = 1 end
                        runningTotal = runningTotal + count
                        log(string.format("  -> slot %d sub %d: '%s' id=%s count=%d (running total=%d)",
                            slot, sub, subItem.Name(), tostring(idOk and id or "?"), count, runningTotal))
                    end
                end
            elseif invItem.Name() and invItem.Name():lower() == itemName:lower() then
                local idOk, id = pcall(function() return invItem.ID() end)
                local cntOk, count = pcall(function() return invItem.StackCount() end)
                count = (cntOk and count) or 1
                if count < 1 then count = 1 end
                runningTotal = runningTotal + count
                log(string.format("  -> slot %d (direct, no bag): '%s' id=%s count=%d (running total=%d)",
                    slot, invItem.Name(), tostring(idOk and id or "?"), count, runningTotal))
            end
        end
    end

    log(string.format("=== DEBUG DUMP DONE: raw (non-deduped) total for '%s' = %d - compare this to what refreshInventory() reports and to your actual in-game count ===",
        itemName, runningTotal))
end

-- ============================================================
-- STEP HELPERS
-- ============================================================
local function waitFor(condFn, timeoutMs)
    local waited = 0
    local step = 100
    while not condFn() and waited < timeoutMs do
        mq.delay(step)
        waited = waited + step
    end
    return condFn()
end

-- Robust "is this window open" check.
local function isWindowOpen(name)
    local w = mq.TLO.Window(name)
    if not w() then return false end
    return w.Open() and true or false
end

-- Closes the NPC's Barter window if it's currently open. Called on the
-- way out (Exit button or window X) so the script doesn't leave the
-- merchant window sitting open on screen after it stops. Tries the
-- window's own DoClose first, falling back to /windowstate, and is a
-- no-op if the window isn't open.
local function closeBarterWindowIfOpen()
    if not isWindowOpen(CONFIG.BARTER_WND) then return end

    log("Closing the Barter window on the way out...")

    local ok = pcall(function() mq.TLO.Window(CONFIG.BARTER_WND).DoClose() end)
    if not ok then
        mq.cmdf("/windowstate %s close", CONFIG.BARTER_WND)
    end

    mq.delay(CONFIG.ACTION_DELAY_MS)

    if isWindowOpen(CONFIG.BARTER_WND) then
        -- DoClose didn't take (or isn't supported on this build) - try
        -- the command form as a second attempt before giving up.
        mq.cmdf("/windowstate %s close", CONFIG.BARTER_WND)
        mq.delay(CONFIG.ACTION_DELAY_MS)
    end

    if isWindowOpen(CONFIG.BARTER_WND) then
        log("NOTE: the Barter window still reports as open - close it manually if it's still up.")
    end
end

-- Step 1: move within CONFIG.MAX_DISTANCE of the target.
local function moveWithinRange()
    if not mq.TLO.Target() then
        log("STEP 1 FAILED: no target selected.")
        return false
    end

    local dist = mq.TLO.Target.Distance3D()
    log(string.format("STEP 1: distance to target is %.1f (need <= %d).", dist or -1, CONFIG.MAX_DISTANCE))

    if dist and dist <= CONFIG.MAX_DISTANCE then
        log("STEP 1: already within range.")
        return true
    end

    local navLoaded = mq.TLO.Plugin("MQ2Nav")() ~= nil
    if not navLoaded then
        log("STEP 1 FAILED: not within range, and MQ2Nav is not loaded to auto-path there. Move closer manually and try again.")
        return false
    end

    log(string.format("STEP 1: navigating to within %d of target via MQ2Nav...", CONFIG.MAX_DISTANCE))
    mq.cmdf("/nav target distance=%d", CONFIG.MAX_DISTANCE)
    mq.delay(300)

    local arrived = waitFor(function()
        if not mq.TLO.Target() then return true end -- target lost, stop waiting
        local d = mq.TLO.Target.Distance3D()
        local navActive = mq.TLO.Navigation.Active()
        return (d and d <= CONFIG.MAX_DISTANCE) or not navActive
    end, CONFIG.WAIT_TIMEOUT_MS)

    mq.cmdf("/nav stop")

    local finalDist = mq.TLO.Target() and mq.TLO.Target.Distance3D() or nil
    if finalDist and finalDist <= CONFIG.MAX_DISTANCE then
        log(string.format("STEP 1: arrived, distance now %.1f.", finalDist))
        return true
    end

    log(string.format("STEP 1 FAILED: still %.1f away after navigation attempt.", finalDist or -1))
    return false
end

-- Step 2 + 3: right-click target, confirm BarterWnd opens.
local function openBarterWindowOnTarget()
    -- Diagnostic: show exactly what the TLO reports right now, before
    -- we do anything, so we can see if the window is already found at
    -- all (vs. found-but-closed, vs. not-found).
    local wnd0 = mq.TLO.Window(CONFIG.BARTER_WND)
    local existsNow = wnd0() ~= nil
    local openVal0 = existsNow and wnd0.Open()
    log(string.format("STEP 2 (pre-check): Window[%s] exists=%s .Open=%s",
        CONFIG.BARTER_WND, tostring(existsNow), tostring(openVal0)))

    if isWindowOpen(CONFIG.BARTER_WND) then
        log("STEP 2/3: Barter window was already open.")
        return true
    end

    log("STEP 2: right-clicking target...")
    mq.cmdf("/click right target")

    local opened = waitFor(function()
        return isWindowOpen(CONFIG.BARTER_WND)
    end, CONFIG.WAIT_TIMEOUT_MS)

    if not opened then
        local wnd = mq.TLO.Window(CONFIG.BARTER_WND)
        local existsFinal = wnd() ~= nil
        local openFinal = existsFinal and wnd.Open()
        log(string.format("STEP 3 FAILED: exists=%s .Open=%s",
            tostring(existsFinal), tostring(openFinal)))
        if not existsFinal then
            log("The window name itself is likely wrong for your client - CONFIG.BARTER_WND needs to change.")
        end
        return false
    end

    mq.delay(CONFIG.ACTION_DELAY_MS)
    log("STEP 3: Barter window confirmed open.")
    return true
end

-- Resolves the buy-line list control (trying the direct child first,
-- then drilling into BARTER_BUYLIST_INNER if needed) and returns
-- (list, rows, notifyWnd, notifyChild) or (nil) with a logged reason.
local function resolveBuyList()
    if not isWindowOpen(CONFIG.BARTER_WND) then
        log("Barter window is not open.")
        return nil
    end

    local wnd = mq.TLO.Window(CONFIG.BARTER_WND)
    local list = wnd.Child(CONFIG.BARTER_BUYLIST)
    if not list() then
        log(string.format("Could not find child '%s' on %s.", CONFIG.BARTER_BUYLIST, CONFIG.BARTER_WND))
        return nil
    end

    local itemsOk, rows = pcall(function() return list.Items() end)
    local usedInner = false
    if not itemsOk or type(rows) ~= "number" then
        log(string.format("'%s' isn't a list directly, trying inner child '%s'...",
            CONFIG.BARTER_BUYLIST, CONFIG.BARTER_BUYLIST_INNER))
        local inner = list.Child(CONFIG.BARTER_BUYLIST_INNER)
        if inner() then
            list = inner
            usedInner = true
            itemsOk, rows = pcall(function() return list.Items() end)
        end
    end

    if not itemsOk or type(rows) ~= "number" then
        log(string.format("Neither '%s' nor '%s' behaves like a list (.Items call failed: %s).",
            CONFIG.BARTER_BUYLIST, CONFIG.BARTER_BUYLIST_INNER, tostring(rows)))
        return nil
    end

    local notifyWnd = usedInner and CONFIG.BARTER_BUYLIST or CONFIG.BARTER_WND
    local notifyChild = usedInner and CONFIG.BARTER_BUYLIST_INNER or CONFIG.BARTER_BUYLIST
    log(string.format("Resolved list: %d row(s) in %s (used inner child: %s)",
        rows, usedInner and CONFIG.BARTER_BUYLIST_INNER or CONFIG.BARTER_BUYLIST, tostring(usedInner)))

    return list, rows, notifyWnd, notifyChild
end

-- Reads the buy-line list into a clean structured table for display:
-- { {name=, qty=, price=}, ... }
local function trim(s)
    if not s then return s end
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

-- Returns (exactName, total) for the given item name from the current
-- itemList (case-insensitive), or (nil, 0) if not carried.
local function getInventoryInfo(itemName)
    for _, it in ipairs(itemList) do
        if it.name:lower() == itemName:lower() then
            return it.name, it.total
        end
    end
    return nil, 0
end

local function loadBarterItemsTable()
    if not moveWithinRange() then return end
    if not openBarterWindowOnTarget() then return end

    local list, rows = resolveBuyList()
    if not list then
        log("Could not load items - list not resolved (see reason above).")
        return
    end

    -- Make sure we're filtering against current inventory, not a stale
    -- scan from earlier in the session.
    refreshInventory()
    log(string.format("Filtering against %d distinct inventory item name(s).", #itemList))

    local newRows = {}
    local skipped = 0
    for row = 1, rows do
        local nameOk, rawName = pcall(function() return list.List(row, CONFIG.BARTER_COL_NAME)() end)
        local qtyOk, qty = pcall(function() return list.List(row, CONFIG.BARTER_COL_QTY)() end)
        local priceOk, price = pcall(function() return list.List(row, CONFIG.BARTER_COL_PRICE)() end)

        if nameOk and rawName and rawName ~= "" then
            local name = trim(rawName)
            local exactName, onHand = getInventoryInfo(name)
            if exactName then
                table.insert(newRows, {
                    name = exactName, -- use our own inventory's exact casing/spelling
                    qty = qtyOk and tostring(qty) or "?",
                    price = priceOk and tostring(price) or "?",
                    onHand = onHand,
                })
            else
                skipped = skipped + 1
            end
        end
    end

    table.sort(newRows, function(a, b) return a.name:lower() < b.name:lower() end)

    barterRows = newRows
    log(string.format("Loaded %d item(s) this buyer wants that you also have (%d other wanted item(s) skipped - not in your inventory).",
        #barterRows, skipped))
end

-- Step 4 + 5: find the item's row in the buy-line list, dump all its
-- columns, and pull out the configured quantity column.
local function locateItemAndReadQty(itemName)
    local list, rows, notifyWnd, notifyChild = resolveBuyList()
    if not list then
        log("STEP 4 FAILED: list not resolved (see reason above).")
        return nil
    end
    log(string.format("STEP 4: scanning %d row(s) for '%s'...", rows, itemName))

    for row = 1, rows do
        local cellOk, nameCell = pcall(function() return list.List(row, CONFIG.BARTER_COL_NAME)() end)
        if cellOk and nameCell and nameCell ~= "" and nameCell:lower() == itemName:lower() then
            local qtyOk, qtyCell = pcall(function() return list.List(row, CONFIG.BARTER_COL_QTY)() end)
            local priceOk, priceCell = pcall(function() return list.List(row, CONFIG.BARTER_COL_PRICE)() end)

            log(string.format("STEP 4: found '%s' on row %d - qty wanted: %s, price each: %s. Selecting it...",
                itemName, row,
                qtyOk and tostring(qtyCell) or "ERR",
                priceOk and tostring(priceCell) or "ERR"))

            mq.cmdf("/notify %s %s listselect %d", notifyWnd, notifyChild, row)
            mq.delay(CONFIG.ACTION_DELAY_MS)

            local exactName, onHand = getInventoryInfo(nameCell)
            return {
                name = exactName or nameCell,
                qty = qtyOk and tostring(qtyCell) or "?",
                price = priceOk and tostring(priceCell) or "?",
                onHand = onHand,
            }
        end
    end

    log(string.format("STEP 4 FAILED: '%s' was not found in this buyer's list.", itemName))
    return nil
end

-- ============================================================
-- MAIN ACTION (steps 1-5 only, no give logic)
-- ============================================================
-- Pulls a leading number (and any trailing unit text, e.g. "pp") out
-- of a price/qty string from the barter list, which may or may not be
-- purely numeric depending on how the client formats it.
local function parsePriceText(text)
    if not text then return nil, nil end
    local cleaned = tostring(text):gsub(",", "")
    local num = cleaned:match("%-?%d+%.?%d*")
    if not num then return nil, nil end
    local unit = cleaned:match("%d+%.?%d*%s*(.*)$")
    if unit and unit == "" then unit = nil end
    return tonumber(num), unit
end

-- Formats a plat amount as simple currency text with thousands
-- separators and a "pp" (platinum pieces) suffix, e.g. 1234.5 -> "1,234.5 pp".
local function formatCurrency(amount)
    if not amount then return "?" end

    local isWhole = (amount == math.floor(amount))
    local numText = isWhole and string.format("%d", amount) or string.format("%.2f", amount)

    local sign = ""
    if numText:sub(1, 1) == "-" then
        sign = "-"
        numText = numText:sub(2)
    end

    local intPart, fracPart = numText:match("^(%d+)(.-)$")
    local formattedInt = intPart:reverse():gsub("(%d%d%d)", "%1,"):reverse():gsub("^,", "")

    return sign .. formattedInt .. fracPart .. " pp"
end

-- Computes how many of an item can actually be sold: the smaller of
-- (what's in your inventory right now) and (what the buyer's row said
-- they want), and opens the sell popup pre-filled with that max.
local function openSellPopup(itemName, buyerQtyText, priceText)
    local invTotal = 0
    for _, it in ipairs(itemList) do
        if it.name:lower() == itemName:lower() then
            invTotal = it.total
            break
        end
    end

    local buyerQty = tonumber(buyerQtyText)
    local maxQty
    if buyerQty then
        maxQty = math.min(invTotal, buyerQty)
    else
        maxQty = invTotal
    end
    if maxQty < 0 then maxQty = 0 end

    sellPopupItemName = itemName
    sellPopupMaxQty = maxQty
    sellPopupQty = maxQty -- default the slider to the max sellable amount
    sellPopupPricePerItem, sellPopupPriceUnit = parsePriceText(priceText)
    sellPopupOpen = true

    log(string.format("Sell popup: '%s' - your inventory: %d, buyer wants: %s -> max sellable: %d, price each: %s",
        itemName, invTotal, tostring(buyerQtyText), maxQty, tostring(priceText)))
end

-- Tries to set the QuantityWnd's slider to `qty`, trying the
-- documented child name first and falling back to the alternate name
-- if that child isn't found. Logs the slider's value before and after
-- so we can actually verify the set took effect.
local function setQuantityWindowValue(qty)
    local candidates = { CONFIG.QUANTITY_SLIDER, CONFIG.QUANTITY_SLIDER_ALT }
    for _, childName in ipairs(candidates) do
        local child = mq.TLO.Window(CONFIG.QUANTITY_WND).Child(childName)
        if child() then
            local beforeOk, before = pcall(function() return child.Value() or child.Text() end)
            mq.cmdf("/notify %s %s newvalue %d", CONFIG.QUANTITY_WND, childName, qty)
            mq.delay(CONFIG.ACTION_DELAY_MS)
            local afterOk, after = pcall(function() return child.Value() or child.Text() end)
            log(string.format("Set quantity via '%s': before=%s, requested=%d, after=%s",
                childName,
                beforeOk and tostring(before) or "?",
                qty,
                afterOk and tostring(after) or "?"))
            return true
        end
    end
    log(string.format("Could not find a quantity slider child (tried '%s', '%s') to set the value on.",
        CONFIG.QUANTITY_SLIDER, CONFIG.QUANTITY_SLIDER_ALT))
    return false
end

-- Clicks the in-window Sell button, wanting `batch` of the currently
-- selected buy line. Handles EQ's native quantity prompt (QuantityWnd)
-- if one appears after clicking Sell, since the row's full "qty
-- wanted" is likely more than a single MAX_PER_ATTEMPT batch.
-- Returns true if the sell click (and any quantity prompt) went
-- through without an obvious failure.
local function sellBatchViaButton(batch)
    local sellWnd = mq.TLO.Window(CONFIG.BARTER_WND)
    local sellBtn = sellWnd.Child(CONFIG.SELL_BUTTON)
    if not sellBtn() then
        log(string.format("Could not find Sell button '%s' on %s - aborting.", CONFIG.SELL_BUTTON, CONFIG.BARTER_WND))
        return false
    end

    log(string.format("Clicking %s for a batch of %d...", CONFIG.SELL_BUTTON, batch))
    mq.cmdf("/notify %s %s leftmouseup", CONFIG.BARTER_WND, CONFIG.SELL_BUTTON)
    mq.delay(CONFIG.ACTION_DELAY_MS)

    local gotQty = waitFor(function() return mq.TLO.Window(CONFIG.QUANTITY_WND).Open() end, CONFIG.WAIT_TIMEOUT_MS)
    if gotQty then
        log(string.format("Quantity prompt appeared after clicking Sell - setting it to %d.", batch))
        setQuantityWindowValue(batch)
        mq.cmdf("/notify %s %s leftmouseup", CONFIG.QUANTITY_WND, CONFIG.QUANTITY_ACCEPT)
        mq.delay(CONFIG.ACTION_DELAY_MS)
    else
        log("No quantity prompt appeared after clicking Sell - the sale may have completed instantly, or nothing happened. Verify against your inventory/log.")
    end

    return true
end

-- Re-reads platinum, this item's on-hand count, and the buyer's
-- remaining "qty wanted" for this item straight from the game - called
-- right after every successful hand-in so nothing downstream (the next
-- batch decision, the UI, the log) ever relies on pre-sale values that
-- the hand-in just made stale. Returns the freshly located buyer row
-- (or nil if the item is no longer listed at all, e.g. fully sold or
-- you're now out of it).
local function refreshPostHandInState(itemName)
    local platOk, curPlat = pcall(function() return mq.TLO.Me.Platinum() end)
    lastPlatinum = platOk and curPlat or nil

    refreshInventory()
    local _, onHandNow = getInventoryInfo(itemName)
    lastHandInItemName = itemName
    lastHandInOnHand = onHandNow or 0

    local freshRow = locateItemAndReadQty(itemName)
    lastHandInBuyerQty = freshRow and freshRow.qty or "0"

    log(string.format(
        "Post hand-in refresh -> platinum: %s | '%s' on hand: %d | buyer still wants: %s",
        lastPlatinum and formatCurrency(lastPlatinum) or "?",
        itemName, lastHandInOnHand, tostring(lastHandInBuyerQty)))

    return freshRow
end

-- Sells up to `totalQty` of itemName, batching in groups of at most
-- CONFIG.MAX_PER_ATTEMPT since the game only allows that many per
-- hand-in attempt. Re-selects the item's row before each batch, since
-- the list may shift or the row may disappear once fully sold.
local function performSell(itemName, totalQty)
    if not totalQty or totalQty <= 0 then
        log("Nothing to sell (quantity is 0).")
        return
    end

    if not moveWithinRange() then return end
    if not openBarterWindowOnTarget() then return end

    local remaining = totalQty
    local given = 0
    local found = locateItemAndReadQty(itemName)

    while remaining > 0 do
        if not found then
            log("Item no longer found in this buyer's list - stopping (it may already be fully sold, or the row shifted).")
            break
        end

        local batch = math.min(remaining, CONFIG.MAX_PER_ATTEMPT)
        log(string.format("=== Selling batch of %d (given so far: %d, remaining after this: %d) ===",
            batch, given, remaining - batch))

        local ok = sellBatchViaButton(batch)
        if not ok then
            log("Sell batch failed - stopping here.")
            break
        end

        given = given + batch
        remaining = remaining - batch

        -- Every successful hand-in immediately changes our plat, our
        -- on-hand count of this item, and the buyer's remaining qty
        -- wanted - re-read all three fresh right now (not assumed from
        -- pre-sale values), and reuse the fresh row lookup to decide
        -- whether there's anything left to sell on the next iteration.
        found = refreshPostHandInState(itemName)

        -- Refresh the on-screen table after *every* successful batch,
        -- not just once at the very end - the window shouldn't sit
        -- stale while a multi-batch sale is still in progress.
        loadBarterItemsTable()
    end

    log(string.format("=== Sell finished: attempted to hand in %d of %d requested '%s' - verify against your inventory ===",
        given, totalQty, itemName))
end

local function locateItemByName(itemName)
    lastFoundQty = nil
    barterRows = {} -- clear any previously loaded/located rows

    log(string.format("=== Locating '%s' on the current target's barter ===", itemName))

    if not moveWithinRange() then return end
    if not openBarterWindowOnTarget() then return end

    local found = locateItemAndReadQty(itemName)
    if found then
        lastFoundQty = found.qty
        barterRows = { found } -- same structure as Load Items Table, filtered to just this one
        log(string.format("=== DONE: '%s' qty=%s price=%s ===", found.name, found.qty, found.price))
    else
        log("=== DONE: item not located, see log above for the failing step ===")
    end
end

local function locateSelectedItem()
    if not selectedIndex or not itemList[selectedIndex] then
        log("No item selected from the dropdown.")
        return
    end
    locateItemByName(itemList[selectedIndex].name)
end

local function safeLocate()
    local ok, err = pcall(locateSelectedItem)
    if not ok then
        log("ERROR: " .. tostring(err))
    end
    busy = false
end

local function safeLocateByName(itemName)
    local ok, err = pcall(locateItemByName, itemName)
    if not ok then
        log("ERROR: " .. tostring(err))
    end
    busy = false
end

local function safeLoadTable()
    local ok, err = pcall(loadBarterItemsTable)
    if not ok then
        log("ERROR: " .. tostring(err))
    end
    busy = false
end

local function safeSell(itemName, qty)
    local ok, err = pcall(performSell, itemName, qty)
    if not ok then
        log("ERROR: " .. tostring(err))
        if mq.TLO.Cursor() and mq.TLO.Cursor.Name() then
            log(string.format("WARNING: '%s' is still on your cursor - check your character before doing anything else.",
                mq.TLO.Cursor.Name()))
        end
    end
    busy = false
end

-- ============================================================
-- UI
-- ============================================================
local function DrawUIBody()
    if ImGui.Button("Refresh Inventory") then
        refreshInventory()
    end
    ImGui.SameLine()
    ImGui.Text(string.format("(%d items)", #itemList))

    if selectedIndex and itemList[selectedIndex] then
        ImGui.SameLine()
        if ImGui.Button("Debug Dump Selected") then
            local ok, err = pcall(dumpRawSlotsForItem, itemList[selectedIndex].name)
            if not ok then
                log("DEBUG DUMP ERROR: " .. tostring(err))
            end
        end
    end

    ImGui.Separator()

    local previewLabel = "Select and item from inventory..."
    if selectedIndex and itemList[selectedIndex] then
        previewLabel = string.format("%s (%d)", itemList[selectedIndex].name, itemList[selectedIndex].total)
    end

    if ImGui.BeginCombo("Item", previewLabel) then
        for i, entry in ipairs(itemList) do
            local isSelected = (selectedIndex == i)
            local label = string.format("%s (%d)", entry.name, entry.total)
            if ImGui.Selectable(label, isSelected) then
                selectedIndex = i
            end
            if isSelected then
                ImGui.SetItemDefaultFocus()
            end
        end
        ImGui.EndCombo()
    end
    ImGui.SameLine()
    if busy then
        ImGui.TextDisabled("Locate Item")
    else
        if ImGui.Button("Locate Item") then
            if selectedIndex and itemList[selectedIndex] then
                busy = true
                pendingLocate = true
            end
        end
    end

    ImGui.Separator()
    local targetName = mq.TLO.Target() and mq.TLO.Target.Name() or "(none)"
    local targetDist = mq.TLO.Target() and mq.TLO.Target.Distance3D() or nil
    ImGui.TextColored(1, 1, 0, 1, "Target:")
    ImGui.SameLine()
    ImGui.TextColored(0.15, 0.85, 0.8, 1, string.format("%s  (dist: %s)", targetName, targetDist and string.format("%.1f", targetDist) or "n/a"))

    if lastHandInItemName then
        ImGui.TextColored(1, 1, 0, 1, "Last hand-in refresh:")
        ImGui.SameLine()
        ImGui.TextColored(0.15, 0.85, 0.8, 1, string.format("plat: %s | '%s' on hand: %s | buyer wants: %s",
            lastPlatinum and formatCurrency(lastPlatinum) or "?",
            tostring(lastHandInItemName),
            tostring(lastHandInOnHand),
            tostring(lastHandInBuyerQty)))
    end

    if busy then
        ImGui.TextDisabled("Working...")
        if ImGui.Button("Force Reset") then
            pendingLocate = false
            pendingLoadTable = false
            pendingLocateName = nil
            pendingSellName = nil
            pendingSellQty = 0
            busy = false
        end
    else
        if ImGui.Button("Load Barter Items Table") then
            busy = true
            pendingLoadTable = true
        end
		ImGui.SameLine()
		ImGui.PushStyleColor(ImGuiCol.Button, 0.7, 0.1, 0.1, 1.0)
		ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.85, 0.15, 0.15, 1.0)
		ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0.6, 0.05, 0.05, 1.0)
		if ImGui.Button("Exit", 100, 25) then
			-- Don't call mq.exit() here: this runs inside the ImGui render
			-- callback, where blocking calls aren't safe. Drop out of the
			-- main loop instead, which closes the Barter window (if it's
			-- still open) before the script ends.
			isOpen = false
		end
		ImGui.PopStyleColor(3)
    end

	ImGui.Separator()

    if #barterRows > 0 then
        ImGui.Separator()
        ImGui.TextColored(1, 1, 0, 1, "Items this buyer wants, that you have:")
        ImGui.SameLine()
        ImGui.TextColored(0.15, 0.85, 0.8, 1, string.format("(%d)", #barterRows))

        -- Default table sizing stretches columns to fill the window
        -- width, which leaves huge gaps with only 6 short columns.
        -- SizingFixedFit auto-sizes columns to content; Borders/RowBg
        -- add grid lines and alternating row shading so each entry
        -- stands out. Looked up individually via pcall since we can't
        -- be 100% sure every flag name is exposed the same way on
        -- every MQ build - missing ones just contribute 0.
        local function getTableFlag(name)
            local ok, val = pcall(function() return ImGuiTableFlags[name] end)
            if ok and type(val) == "number" then return val end
            return 0
        end
        local tableFlags = getTableFlag("SizingFixedFit") + getTableFlag("Borders") + getTableFlag("RowBg")

        local tableOk = ImGui.BeginTable("BarterItemsTable", 6, tableFlags)
        if tableOk then
            ImGui.TableSetupColumn("Item")
            ImGui.TableSetupColumn("Qty Wanted")
            ImGui.TableSetupColumn("On Hand")
            ImGui.TableSetupColumn("Price Each")
            ImGui.TableSetupColumn("")
            ImGui.TableSetupColumn("")
            ImGui.TableHeadersRow()

            for idx, r in ipairs(barterRows) do
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.Text(r.name)
                ImGui.TableNextColumn()
                ImGui.Text(r.qty)
                ImGui.TableNextColumn()
                ImGui.Text(tostring(r.onHand or "?"))
                ImGui.TableNextColumn()
                ImGui.Text(r.price)

                ImGui.TableNextColumn()
                ImGui.PushID(idx)
                if busy then
                    ImGui.TextDisabled("Select")
                else
                    if ImGui.SmallButton("Select") then
                        busy = true
                        pendingLocateName = r.name
                    end
                end
                ImGui.PopID()

                ImGui.TableNextColumn()
                ImGui.PushID(idx + 1000000) -- distinct ID space from the Select button above
                if busy then
                    ImGui.TextDisabled("Sell")
                else
                    if ImGui.SmallButton("Sell") then
                        openSellPopup(r.name, r.qty, r.price)
                    end
                end
                ImGui.PopID()
            end
            ImGui.EndTable()
        end
    end
end

-- ============================================================
-- SELL POPUP (quantity picker) - "Confirm Sell" queues an actual
-- pickup/give sequence, run from the main loop so it can mq.delay().
-- ============================================================
local function DrawSellPopupBody()
    ImGui.TextColored(1, 1, 0, 1, "Item:")
    ImGui.SameLine()
    ImGui.TextColored(0.15, 0.85, 0.8, 1, tostring(sellPopupItemName))
    ImGui.TextColored(1, 1, 0, 1, "Max sellable right now:")
    ImGui.SameLine()
    ImGui.TextColored(0.15, 0.85, 0.8, 1, tostring(sellPopupMaxQty))
    ImGui.TextDisabled("(the lower of what you have and what the buyer wants)")
    ImGui.TextDisabled(string.format("(sold in batches of up to %d per attempt)", CONFIG.MAX_PER_ATTEMPT))

    ImGui.Separator()

    if sellPopupMaxQty > 0 then
        local a, b = ImGui.SliderInt("Quantity", sellPopupQty, 0, sellPopupMaxQty)
        -- Different ImGui Lua bindings return (changed, value) or
        -- (value, changed) - figure out which is which rather than
        -- assuming, so we never assign a boolean into sellPopupQty.
        local newVal, changed
        if type(a) == "number" then
            newVal, changed = a, b
        elseif type(b) == "number" then
            newVal, changed = b, a
        end
        if changed and type(newVal) == "number" then
            sellPopupQty = newVal
        end
    else
        sellPopupQty = 0
        ImGui.TextDisabled("Nothing sellable - you have none, or the buyer wants none.")
    end

    ImGui.Separator()

    if sellPopupPricePerItem then
        local total = sellPopupPricePerItem * (sellPopupQty or 0)

        local unitSuffix = sellPopupPriceUnit and (" " .. sellPopupPriceUnit) or ""
        ImGui.TextColored(1, 1, 0, 1, "You will receive:")
        ImGui.SameLine()
        ImGui.TextColored(0.15, 0.85, 0.8, 1, formatCurrency(total))
        ImGui.SameLine()
        ImGui.TextColored(1, 1, 1, 1, string.format("(%s%s per item x %d)",
            tostring(sellPopupPricePerItem), unitSuffix, sellPopupQty or 0))

        local platOk, curPlat = pcall(function() return mq.TLO.Me.Platinum() end)
        if platOk and type(curPlat) == "number" then
            ImGui.TextColored(1, 1, 0, 1, "Current plat:")
            ImGui.SameLine()
            ImGui.TextColored(0.15, 0.85, 0.8, 1, formatCurrency(curPlat))
            ImGui.SameLine()
            ImGui.TextColored(1, 1, 0, 1, "| Plat after sale:")
            ImGui.SameLine()
            ImGui.TextColored(0.15, 0.85, 0.8, 1, formatCurrency(curPlat + total))
        else
            ImGui.TextDisabled("Current plat: ? | Plat after sale: ?")
        end
    else
        ImGui.TextDisabled("Price per item could not be read - total unavailable.")
    end

    ImGui.Separator()

    if busy then
        ImGui.TextDisabled("Working...")
    else
        if ImGui.Button("Cancel") then
            sellPopupOpen = false
        end
        ImGui.SameLine()
        if type(sellPopupQty) ~= "number" then
            sellPopupQty = 0
        end
        local confirmLabel = string.format("Confirm Sell (%d)", sellPopupQty)
        if sellPopupQty > 0 then
            if ImGui.Button(confirmLabel) then
                busy = true
                pendingSellName = sellPopupItemName
                pendingSellQty = sellPopupQty
                sellPopupOpen = false
            end
        else
            ImGui.TextDisabled(confirmLabel)
        end
    end
end

local function DrawSellPopup()
    if not sellPopupOpen then return end

    local stillOpen, shouldDrawPopup = ImGui.Begin("Sell Item##BarterHandInSellPopup", true)
    if shouldDrawPopup then
        local ok, err = pcall(DrawSellPopupBody)
        if not ok then
            ImGui.TextColored(1, 0, 0, 1, "UI ERROR: " .. tostring(err))
        end
    end
    ImGui.End()

    if not stillOpen then
        sellPopupOpen = false
    end
end

local function DrawUI()
    isOpen, shouldDraw = ImGui.Begin("Barter Hand-In (v1.3)", isOpen)
    if shouldDraw then
        local ok, err = pcall(DrawUIBody)
        if not ok then
            ImGui.TextColored(1, 0, 0, 1, "UI ERROR: " .. tostring(err))
        end
    end
    ImGui.End()

    DrawSellPopup()
end

mq.imgui.init("BarterHandIn", DrawUI)

-- ============================================================
-- MAIN LOOP
-- ============================================================
refreshInventory()
log("Ready. Select an item, target the barter NPC, and click 'Locate Item'.")

while isOpen do
    if pendingLocate then
        pendingLocate = false
        safeLocate()
    elseif pendingLoadTable then
        pendingLoadTable = false
        safeLoadTable()
    elseif pendingLocateName then
        local name = pendingLocateName
        pendingLocateName = nil
        safeLocateByName(name)
    elseif pendingSellName then
        local name, qty = pendingSellName, pendingSellQty
        pendingSellName = nil
        pendingSellQty = 0
        safeSell(name, qty)
    end
    mq.delay(200)
end

-- Leaving the merchant's Barter window open after the script stops is
-- just clutter on screen, so close it if it's still up (covers both the
-- Exit button and closing the window with the X).
local closeOk, closeErr = pcall(closeBarterWindowIfOpen)
if not closeOk then
    log("ERROR while closing the Barter window: " .. tostring(closeErr))
end

log("BarterHandIn.lua exiting.")
