--[[
    Fishing - By wired420 @ redguides

    Conversion of the fishing mac I previously rewrote to lua
]]
--
local Fish_Version = '1.06'
local mq = require("mq")
require("ImGui")

-- Start up/Exit Stuff
local _initialized = false
local terminate = false

-- Make every mq.delay in this script interruptible: if Exit was pressed, the
-- delay ends immediately and the script shuts down instead of waiting it out.
local function shutdown()
    if mq.TLO.Navigation.Active() then
        mq.cmd('/nav stop')
    end
    pcall(mq.unbind, '/fish')
    mq.exit()
end
local _mq_delay = mq.delay
mq.delay = function(t, cond)
    if terminate then shutdown() end
    local user_cond = cond
    _mq_delay(t, function()
        if terminate then return true end
        -- MQ requires a real boolean back; TLO calls can return nil, so coerce.
        if type(user_cond) == 'function' then return user_cond() and true or false end
        if type(user_cond) == 'string' then return mq.parse(user_cond) == 'TRUE' end
        return false
    end)
    if terminate then shutdown() end
end

-- UI Stuff
local Open, ShowUI = true, true

-- Adjustable Default Settings
local Fish_Active = false
local Fish_Buy_Bait = 1000
local Fish_Buy_Poles = 5
local Fish_Drink_Beer = false
local Fish_Drink_Beer_Number = 1
local Fish_Go_Shopping = true
local Fish_Make_Bait = false
local Fish_Make_Bait_Number = 50
local Fish_Status
local Fish_Skill_Cap = 200
local Fish_Summon_Beer = 20

-- Internal Stuff
local making_bait = false
local current_zone
local current_location
local current_heading
-- Fishing vendors by zone short name. Each entry says who to buy from, where
-- they stand, and what the pole/bait are called on their merchant list.
-- If we are in one of these zones we buy from THAT zone's vendor (no travel);
-- anywhere else we travel to default_vendor_zone.
-- 'loc' is optional; with no loc we navigate straight to the NPC by name.
local fishing_vendors = {
    poknowledge = {
        label = 'Plane of Knowledge',
        name  = 'Daeld Atand',
        loc   = '23.38, 1434.09, -124.24',
        pole  = { name = 'Fishing Pole', id = 13100, stack = 1 },
        bait  = { name = 'Fishing Bait', id = 13101, stack = 100 },
    },
    potranquility = {
        label = 'Plane of Tranquility',
        name  = 'Rataga Stoneskipper',
        loc   = '-491.60, -1406.15, -906.24',
        pole  = { name = 'Fishing Pole', id = 13100, stack = 1 },
        bait  = { name = 'Fishing Bait', id = 13101, stack = 100 },
    },
}
local default_vendor_zone = 'poknowledge'

-- Where to stand and fish in each zone (Y, X, Z - same order as /nav locyxz).
-- Once we have a pole and bait we walk here. Optional 'heading' (degrees) to face afterwards.
local fishing_spots = {
    poknowledge   = { loc = '20.54, 1440.83, -120.24' },
    potranquility = { loc = '-561.04, -1287.07, -935.70' },
}
-- Shard hunting zone: The Qeynos Hills: Hardcore. We never shop here; we just
-- walk to the spot and fish. Matched on the zone's full name (and the short
-- name as a fallback) since the short name is not known for certain.
-- Location is Y, X, Z (the order /loc prints and /nav locyxz expects).
local shard_zone = {
    loc = '4160.82, 952.92, -21.37',
}
local function is_shard_zone()
    local name = (mq.TLO.Zone.Name() or ''):lower()
    local short = (mq.TLO.Zone.ShortName() or ''):lower()
    if name:find('qeynos hills', 1, true) and name:find('hardcore', 1, true) then
        return true
    end
    return short:find('qeytoqrg', 1, true) ~= nil and short:find('hc', 1, true) ~= nil
end
local function get_fishing_spot()
    if is_shard_zone() then
        return shard_zone
    end
    return fishing_spots[(mq.TLO.Zone.ShortName() or ''):lower()]
end
local go_to_spot_pending = false -- set when we start fishing or change zones
local last_zone_seen = nil
local was_active = false
local caught = 0
local fish_kept = 0
local lucky_catches = 0
local trash_caught = 0
local spilled_beers = 0
local fishing_skill = mq.TLO.Me.Skill('Fishing')() or 0

-- Shard of a Broken Reality tracking
local SHARD_ID = 150763
local SHARD_NAME = 'Shard of a Broken Reality'
local function count_shards()
    return mq.TLO.FindItemCount(SHARD_ID)() or 0
end
-- Set by check_catch() when a Shard lands while we are fishing in the shard zone.
local shard_found = false

-- The real maximum fishing skill for this character right now (level/class
-- dependent). Falls back to Fish_Skill_Cap if the TLO gives nothing useful.
local function get_skill_cap()
    local cap = mq.TLO.Me.SkillCap('Fishing')() or 0
    if cap <= 0 then
        cap = Fish_Skill_Cap
    end
    return cap
end
local function skill_is_capped()
    return fishing_skill >= get_skill_cap()
end
local cap_announced = false

local function logz(s, ...)
    if not Open then
        print('\ar[\atFishing\ar]\aw ' .. string.format(s, ...))
    end
end

local function update_status(s, ...)
    Fish_Status = string.format(s, ...)
end

update_status('Stopped')
logz('\ar[\awVersion\a-w:\aw %s \aw- By\a-w:\aw wired420\ar]\aw', Fish_Version)

local function pack_open(i)
    if mq.TLO.Me.Inventory(i).Open() == 1 then
        return true
    end
    return false
end

local function get_pack_name(i)
    local pack = {
        [23] = 'pack1',
        [24] = 'pack2',
        [25] = 'pack3',
        [26] = 'pack4',
        [27] = 'pack5',
        [28] = 'pack6',
        [29] = 'pack7',
        [30] = 'pack8',
        [31] = 'pack9',
        [32] = 'pack10',
        [33] = 'pack11',
        [34] = 'pack12'
    }
    return pack[i]
end

-- Pick the vendor zone: use the vendor for the zone we are in if there is one
-- (poknowledge -> Daeld Atand, potranquility -> Rataga Stoneskipper),
-- otherwise travel to the default vendor zone.
local function pick_vendor_zone()
    local zone = (mq.TLO.Zone.ShortName() or ''):lower()
    if fishing_vendors[zone] then
        return zone, false
    end
    -- Fallback in case the zone short name differs: is a known vendor standing here?
    for key, vendor in pairs(fishing_vendors) do
        if (mq.TLO.Spawn('npc ' .. vendor.name).ID() or 0) > 0 then
            return key, false
        end
    end
    return default_vendor_zone, true
end

-- Walk to this zone's fishing spot (if it has one). Unless force is set, we
-- skip the walk when we are already standing there. Returns true if a spot exists.
local function go_to_fishing_spot(force)
    local spot = get_fishing_spot()
    go_to_spot_pending = false
    if not spot then
        return false
    end
    if not force then
        local y, x, z = spot.loc:match('^%s*(-?[%d%.]+)%s*,%s*(-?[%d%.]+)%s*,%s*(-?[%d%.]+)')
        local my_y, my_x = mq.TLO.Me.Y(), mq.TLO.Me.X()
        if y and my_y and my_x then
            local dist = math.sqrt((my_y - tonumber(y)) ^ 2 + (my_x - tonumber(x)) ^ 2)
            if dist <= 10 then
                return true
            end
        end
    end
    update_status('Navigating to fishing spot')
    logz('Heading to the fishing spot: %s', spot.loc)
    mq.cmdf('/nav locyxz %s', spot.loc)
    mq.delay(500)
    while mq.TLO.Navigation.Active() do
        mq.delay(1000)
    end
    if spot.heading then
        mq.cmdf('/face heading %s', spot.heading)
    end
    update_status('Fishing')
    return true
end

local function travel_to_vendor_zone(vendor_zone, need_travel)
    local vendor = fishing_vendors[vendor_zone]
    if need_travel then
        update_status('Traveling to %s', vendor.label)
        mq.cmdf('/travelto %s', vendor_zone)
        while mq.TLO.Zone.ShortName() ~= vendor_zone do
            mq.delay(1000)
        end
        logz('Now in %s. Navigating to vendor.', vendor.label)
    else
        logz('Already in %s. Navigating to vendor.', vendor.label)
    end
    update_status('Navigating to fishing vendors')
    if vendor.loc then
        mq.cmdf('/nav locyxz %s', vendor.loc)
    else
        mq.cmdf('/nav spawn npc %s | dist=15', vendor.name)
    end
    while mq.TLO.Navigation.Active() do
        mq.delay(1000)
    end
    mq.cmdf('/target npc %s', vendor.name)
    mq.delay(3000, function() return mq.TLO.Target.CleanName() == vendor.name end)
    if mq.TLO.Target.CleanName() ~= vendor.name then
        logz('Could not target %s.', vendor.name)
        return false
    end
    for _ = 1, 5 do
        mq.cmd('/click right target')
        mq.delay(3000, function() return mq.TLO.Merchant.Open() end)
        if mq.TLO.Merchant.Open() then
            mq.delay(5000, function() return mq.TLO.Merchant.ItemsReceived() end)
            return true
        end
    end
    logz('Could not open the merchant window for %s.', vendor.name)
    return false
end

local function return_from_vendor(need_travel)
    if need_travel then
        update_status('Returning to %s', current_zone)
        mq.cmdf('/travelto %s', current_zone)
        while mq.TLO.Zone.ShortName() ~= current_zone do
            mq.delay(1000)
        end
        logz('We have returned to %s', current_zone)
    end
    -- Zones with a set fishing spot: go there instead of our old position.
    if go_to_fishing_spot(true) then
        logz('Returning to fishing!')
        return
    end
    update_status('Navigating to fishing spot')
    logz('Attempting to return to location: %s', current_location)
    mq.cmdf('/nav locyxz %s', current_location)
    while mq.TLO.Navigation.Active() do
        mq.delay(1000)
    end
    logz('Attempting to face original direction')
    update_status('Facing fishing spot')
    mq.cmdf('/face heading %s', current_heading)
    logz('Returning to fishing!')
    update_status('Fishing')
end

-- How many buyable fishing poles / bait we are carrying.
local function count_poles()
    return mq.TLO.FindItemCount(13100)() or 0
end

local function count_bait()
    return (mq.TLO.FindItemCount(13101)() or 0) + (mq.TLO.FindItemCount('=Homemade Bait')() or 0)
end

-- Buy an item from the open merchant window until count_fn() reaches `target`.
local function buy_item(item, target, count_fn)
    local item_id, item_name, stack = item.id, item.name, item.stack
    local have = count_fn()
    if have >= target then
        return
    end
    local tries = 0
    while mq.TLO.Merchant.SelectedItem.ID() ~= item_id and tries < 50 do
        mq.TLO.Merchant.SelectItem(item_name)()
        mq.delay(100)
        tries = tries + 1
    end
    local stalls = 0
    while have < target and stalls < 5 do
        mq.TLO.Merchant.Buy(math.max(1, math.min(stack, target - have)))()
        mq.delay(500)
        local now = count_fn()
        if now <= have then
            stalls = stalls + 1
        else
            stalls = 0
        end
        have = now
    end
    if have < target then
        logz('Could only buy up to %d of %s (wanted %d). Out of money or bag space?', have, item_name, target)
    end
end

-- One shopping trip that buys BOTH fishing poles and bait.
local function go_buy_supplies()
    if is_shard_zone() then
        return
    end
    local vendor_zone, need_travel = pick_vendor_zone()
    local vendor = fishing_vendors[vendor_zone]
    logz('Buying fishing poles and bait from %s in %s.', vendor.name, vendor.label)
    current_zone = mq.TLO.Zone.ShortName()
    current_location = mq.TLO.Me.LocYXZ()
    current_heading = mq.TLO.Me.Heading.DegreesCCW()
    if travel_to_vendor_zone(vendor_zone, need_travel) then
        local poles_needed = math.max(0, Fish_Buy_Poles - count_poles())
        local bait_needed = math.max(0, Fish_Buy_Bait - count_bait())
        update_status('Buying %d fishing poles from %s', poles_needed, vendor.name)
        buy_item(vendor.pole, Fish_Buy_Poles, count_poles)
        update_status('Buying %d bait from %s', bait_needed, vendor.name)
        buy_item(vendor.bait, Fish_Buy_Bait, count_bait)
    end
    if mq.TLO.Merchant.Open() then
        mq.TLO.Window('MerchantWnd').DoClose()
        mq.delay(3000, function() return not mq.TLO.Merchant.Open() end)
    end
    logz('Finished shopping. Attempting to return to previous location.')
    return_from_vendor(need_travel)
end

local fishing_poles = {
    'The Bone Rod',
    'Blessed Fishing Rod',
    'Collapsible Fishing Pole',
    'Ancient Fishing Pole',
    "Brell's Fishin' Pole",
    "Uliorn's Fishing Pole",
    "KT's Magic Fishing Pole",
    "Hintol's Fishing Pole",
    'Grey Wood Fishing Pole',
    "Aglthin's Fishing Pole",
    'Kerran Fishing Pole',
    'Fishing Pole',
}

local function find_best_pole()
    for _, itemname in ipairs(fishing_poles) do
        if mq.TLO.FindItem(itemname)() == itemname then
            return itemname, mq.TLO.FindItem(itemname).ID()
        end
    end
    return nil, nil
end

local function have_pole()
    if find_best_pole() then
        return true
    end
    return mq.TLO.FindItem("Fisherman's Companion")() ~= nil
end

local function have_bait()
    return (mq.TLO.FindItemCount(13101)() or 0) > 0
        or (mq.TLO.FindItemCount('=Homemade Bait')() or 0) > 0
end

local check_supplies -- defined below (needs lets_make_bait)
local restock_supplies -- defined below

local function equip_pole(polename, poleid)
    update_status('Equipping Best Rod')
    local found_pole_inv  = mq.TLO.FindItem(poleid).ItemSlot()
    local found_pole_slot = mq.TLO.FindItem(poleid).ItemSlot2() + 1
    if not pack_open(found_pole_inv) then
        mq.cmdf('/itemnotify %s rightmouseup', found_pole_inv)
        while not pack_open(found_pole_inv) do
            mq.delay(100)
        end
    end
    local mainid = mq.TLO.Me.Inventory(13).ID()
    mq.cmdf('/itemnotify in %s %s leftmouseup', get_pack_name(found_pole_inv), found_pole_slot)
    while mq.TLO.Cursor.ID() ~= poleid do
        mq.delay(100)
    end
    mq.cmd('/itemnotify mainhand leftmouseup')
    while mq.TLO.Cursor.ID() ~= mainid do
        mq.delay(100)
    end
    -- Only put the old mainhand item back if there was one (a freshly bought
    -- pole goes into an empty hand, so there is nothing to swap back).
    if mainid then
        mq.cmdf('/itemnotify in %s %s leftmouseup', get_pack_name(found_pole_inv), found_pole_slot)
        while mq.TLO.Cursor.ID() == mainid do
            mq.delay(100)
        end
    end
    logz(string.format('\ay%s \a-r(\awID: \ar%s\a-r)\aw equipped in \ammainhand\aw.', polename, poleid))
    update_status('Fishing')
end

-- Called when the game says our pole is missing/unequipped.
local function event_select_pole()
    update_status("Checking for Fishermans's Companion")
    local fishermans_companion = mq.TLO.FindItem("Fisherman's Companion")()
    if fishermans_companion ~= nil then
        update_status("Checking for Brell's Fishin' Pole")
        if mq.TLO.FindItemCount("Brell's Fishin' Pole")() < 1 then
            update_status("Summoning Brell's Fishin' Pole")
            mq.cmdf('/useitem %s', fishermans_companion)
            while mq.TLO.Me.Casting.ID() ~= nil do
                mq.delay(100)
            end
        end
    end
    local polename, poleid = find_best_pole()
    if polename and poleid then
        equip_pole(polename, poleid)
    else
        check_supplies()
    end
end

local function lets_make_bait()
    update_status('Making Bait')
    making_bait = true
    mq.cmd('/cleanup')
    mq.delay(2000)
    local bait_maker_found = mq.TLO.FindItemCount("Anizok's Bait Dispenser")()
    if bait_maker_found > 0 then
        local bait_maker_slot = mq.TLO.FindItem("Anizok's Bait Dispenser").ItemSlot()
        local bait_fish_pack, bait_fish_slot
        if bait_maker_slot > 22 and bait_maker_slot < 35 then
            if not pack_open(bait_maker_slot) then
                mq.cmdf('/itemnotify %s rightmouseup', bait_maker_slot)
                while not pack_open(bait_maker_slot) do
                    mq.delay(100)
                end
                local bait_fish = {
                    [1] = 'Fresh Fish',
                    [2] = 'Spirit Pollock',
                    [3] = 'Strident Croaker',
                    [4] = 'Small Jinx Sturgeon',
                    [5] = 'Krup Guppy',
                    [6] = 'Danak Grouper',
                    [7] = 'Despair Chub',
                    [8] = 'Ikfish',
                    [9] = 'Stonefish',
                    [10] = 'Boar Carp',
                    [11] = 'Cauldron Trout',
                    [12] = 'Thunder Salmon',
                    [13] = 'Thullian Mudskipper',
                    [14] = 'Rujarkian Chub',
                    [15] = 'Kerra Catfish',
                    [16] = 'Rathe Muskie',
                    [17] = 'Koada Cichlid',
                    [18] = 'Hatch Dace',
                    [19] = 'Greengill Salmon',
                    [20] = '10lb Fetid Bass',
                    [21] = '11lb Fetid Bass',
                    [22] = '12lb Fetid Bass',
                    [23] = '13lb Fetid Bass',
                    [24] = '14lb Fetid Bass',
                    [25] = '15lb Fetid Bass',
                    [26] = '16lb Fetid Bass',
                    [27] = '17lb Fetid Bass',
                    [28] = '2lb Fetid Bass',
                    [29] = '3lb Fetid Bass',
                    [30] = '4lb Fetid Bass',
                    [31] = '5lb Fetid Bass',
                    [32] = '6lb Fetid Bass',
                    [33] = '7lb Fetid Bass',
                    [34] = '8lb Fetid Bass',
                    [35] = '9lb Fetid Bass',
                    [36] = 'Giant Fetid Bass',
                    [37] = 'Tiny Fetid Bass',
                    [38] = 'Large Fetid Bass',
                    [39] = 'Large Fetid Bass',
                    [40] = 'Large Fetid Bass',
                    [41] = 'Large Fetid Bass',
                    [42] = 'Fogwater Trout',
                    [43] = 'Timorous Tuna',
                    [44] = 'Evergreen Salmon',
                    [45] = 'Kunzar Koi',
                    [46] = 'Dragon Bay Snapper',
                    [47] = 'Cobalt Cod',
                    [48] = 'Iceclad Cutlassfish',
                    [49] = 'Giant Halibut',
                    [50] = 'Giant Snapper',
                    [51] = 'Quellian Koi',
                    [52] = 'Storm Salmon',
                    [53] = 'Vallorian Discus',
                    [54] = 'Nightmare Cichlid',
                    [55] = 'Muckskipper Fish',
                    [56] = '1 lb. Saltwater Tuna',
                    [57] = 'Albino Crawfish',
                    [58] = 'Cave Catfish',
                    [59] = 'Gravestone Loach',
                    [60] = 'Tiny Blind Cave Fish',
                    [61] = 'Hound Pike',
                    [62] = 'Barren Flounder',
                    [63] = 'Highland Pike',
                    [64] = 'Gunthak Mackerel',
                    [65] = 'Pine Cichlid',
                    [66] = 'Salty Whitefish',
                    [67] = 'Frosty Cave Trout',
                    [68] = 'Gigantic Fetid Bass',
                    [69] = 'Humongous Fetid Bass',
                    [70] = 'Blood Tainted Cod',
                    [71] = 'Malevolent Haddock',
                    [72] = 'Miniature Bloodgill Swordfish',
                    [73] = 'Takish Catfish',
                    [74] = 'Takish Smelt',
                    [75] = 'Scup Porgy',
                    [76] = 'Spectral Grouper',
                    [77] = 'Blind Catfish',
                    [78] = 'Absonant Char',
                    [79] = 'Barren Croaker',
                    [80] = 'Grunion',
                    [81] = 'Kelpfish',
                    [82] = 'Seaperch',
                    [83] = 'Wayunder Perch',
                    [84] = 'Barren Moray Eel',
                    [85] = 'Lamprey',
                    [86] = 'Decorative Carp',
                    [87] = 'Sprat',
                    [88] = 'Herring'
                }
                for _, bait_fish_name in pairs(bait_fish) do
                    if mq.TLO.FindItemCount('=' .. bait_fish_name)() > 1 then
                        bait_fish_pack = mq.TLO.FindItem('=' .. bait_fish_name).ItemSlot()
                        bait_fish_slot = mq.TLO.FindItem('=' .. bait_fish_name).ItemSlot2() + 1
                        while mq.TLO.FindItemCount('=' .. 'Homemade Bait')() < Fish_Make_Bait_Number do
                            mq.cmdf('/ctrlkey /itemnotify in %s %s leftmouseup', get_pack_name(bait_fish_pack),
                                bait_fish_slot)
                            mq.delay(1000)
                            mq.cmdf('/itemnotify in %s %s leftmouseup', get_pack_name(bait_maker_slot), '1')
                            while mq.TLO.Me.Inventory(bait_maker_slot).Items() > 0 do
                                mq.cmd('/notify ContainerWindow Container_Combine leftmouseup')
                                mq.delay(1000)
                            end
                            while mq.TLO.Cursor.ID() ~= nil do
                                mq.cmd('/autoinventory')
                                mq.delay(1000)
                            end
                        end
                        making_bait = false
                    end
                end
            else
                logz("\ayAnizok's Bait Dispenser\ar not found in a \amtop level\ar inventory slot.")
                logz("\arTurning off \amMake bait\aw.")
                Fish_Make_Bait = false
            end
        end
        mq.cmd('/cleanup')
    end
    making_bait = false
    update_status('Fishing')
end

-- Make sure we have a pole AND bait. If either is missing, make bait if enabled,
-- then do a single shopping trip that buys both. Returns true when OK to fish.
-- One shopping trip for poles and bait, then equip the best pole.
restock_supplies = function()
    go_buy_supplies()
    local polename, poleid = find_best_pole()
    if polename and poleid and mq.TLO.Me.Inventory(13).ID() ~= poleid then
        equip_pole(polename, poleid)
    end
end

check_supplies = function()
    local need_pole = not have_pole()
    local need_bait = not have_bait()
    if not need_pole and not need_bait then
        return true
    end
    if need_bait and Fish_Make_Bait then
        lets_make_bait()
        need_bait = not have_bait()
    end
    if not need_pole and not need_bait then
        return true
    end
    if is_shard_zone() then
        Fish_Active = false
        update_status('Stopped - out of supplies (no shopping in this zone)')
        logz('Out of poles/bait in the shard zone. Not shopping here. Stopping.')
        return false
    end
    if not Fish_Go_Shopping then
        local missing = {}
        if need_pole then missing[#missing + 1] = 'fishing pole' end
        if need_bait then missing[#missing + 1] = 'bait' end
        logz('Missing %s. Not set to go shopping. Goodbye!', table.concat(missing, ' and '))
        terminate = true
        return false
    end
    update_status('Out of supplies - restocking')
    logz('Out of %s. Going to rebuy.',
        (need_pole and need_bait) and 'poles and bait' or (need_pole and 'poles' or 'bait'))
    restock_supplies()
    if have_pole() and have_bait() then
        return true
    end
    -- Rebuy failed (no money, no bag space, vendor missing...). Stop instead of
    -- running back to the vendor over and over.
    Fish_Active = false
    update_status('Stopped - could not buy supplies')
    logz('Could not rebuy poles/bait. Stopping.')
    return false
end

-- When we start fishing: if we carry fewer poles/bait than the settings, shop for the difference.
local function restock_on_start()
    if is_shard_zone() then
        return
    end
    if count_poles() >= Fish_Buy_Poles and count_bait() >= Fish_Buy_Bait then
        return
    end
    if not Fish_Go_Shopping then
        logz('Below the set pole/bait amounts, but Go Shopping is off. Not restocking.')
        return
    end
    logz('Have %d/%d poles and %d/%d bait. Buying the difference.',
        count_poles(), Fish_Buy_Poles, count_bait(), Fish_Buy_Bait)
    restock_supplies()
end

local function event_no_bait()
    check_supplies()
end

local function event_no_water()
end

local function event_leaving()
end

local function check_catch()
    update_status('Checking Catch')
    if mq.TLO.Cursor.ID() then
        local auto_destroy_names = {
            ['Fish Scales'] = true,
            ['Rusty Dagger'] = true,
            ['Tattered Cloth Sandal'] = true,
			['Worn Turban'] = true
        }
        local cursor_name = mq.TLO.Cursor.Name()
        if cursor_name and auto_destroy_names[cursor_name] then
            local cursor_id = mq.TLO.Cursor.ID()
            update_status('Destroying %s', cursor_name)
            logz(Fish_Status)
            mq.cmd('/destroy')
            local waited = 0
            while mq.TLO.Cursor.ID() == cursor_id and waited < 3000 do
                mq.delay(100)
                waited = waited + 100
            end
            caught = caught + 1
            trash_caught = trash_caught + 1
            update_status('Fishing')
            return
        end
        -- Alert the first time a Shard lands after we had none on us.
        -- (FindItemCount doesn't include the cursor, so this is the count before this catch.)
        local is_shard = mq.TLO.Cursor.ID() == SHARD_ID
        if is_shard and count_shards() == 0 then
            print(string.format('\ar[\atFishing\ar]\ag *** You caught your first %s! ***', SHARD_NAME))
            mq.cmd(string.format('/popup You caught a %s!', SHARD_NAME))
            mq.cmd('/beep')
        end
        update_status('Keeping %s', mq.TLO.Cursor.Name())
        logz(Fish_Status)
        mq.cmd('/autoinventory')
        caught = caught + 1
        fish_kept = fish_kept + 1
        mq.delay(1000)
        -- In the shard zone, a Shard is the goal: remember it so the main loop stops.
        if is_shard and is_shard_zone() then
            shard_found = true
        end
    end
    update_status('Fishing')
end

local function event_party_foul()
    update_status('Spilling your beer')
    spilled_beers = spilled_beers + 1
    update_status('Fishing')
end

local function event_lucky_catch()
    update_status('Lucky Catch!')
    lucky_catches = lucky_catches + 1
    update_status('Fishing')
end

local function event_skill_up()
    fishing_skill = mq.TLO.Me.Skill('Fishing')() or fishing_skill
end

--[[ Events ]]
--
mq.event('BrokenPole', 'You need to put your fishing pole in your primary hand.', event_select_pole)
mq.event('NoPole', "#*#You can't fish without a fishing pole, go buy one.#*#", event_select_pole)
mq.event('NoBait', "#*#You can't fish without fishing bait, go buy some.#*#", event_no_bait)
mq.event('NoWater', '#*#Trying to catch land sharks perhaps?#*#', event_no_water)
mq.event('Leaving', '#*#You stop fishing and go on your way.#*#', event_leaving)
mq.event('PartyFoul', '#*#You spill your beer while bringing in your line#*#', event_party_foul)
mq.event('LuckyCatch', '#*#You luckily caught#*#', event_lucky_catch)
mq.event('SkillUp', '#*#You have become better at Fishing#*#', event_skill_up)

local function show_help_marker(s)
    ImGui.SameLine()
    ImGui.TextDisabled('(?)')
    if ImGui.IsItemHovered(ImGuiHoveredFlags.None) then
        ImGui.BeginTooltip()
        ImGui.PushTextWrapPos(ImGui.GetFontSize() * 35.0)
        ImGui.TextUnformatted(s)
        ImGui.PopTextWrapPos()
        ImGui.EndTooltip()
    end
end

-- Info tab colors (r, g, b, a)
local LABEL_COLOR = { 1.0, 1.0, 1.0, 1.0 } -- white text
local VALUE_COLOR = { 0.0, 1.0, 0.0, 1.0 } -- green values

local function info_pair(label, value)
    ImGui.TextColored(LABEL_COLOR[1], LABEL_COLOR[2], LABEL_COLOR[3], LABEL_COLOR[4], label)
    ImGui.SameLine(0, 4)
    ImGui.TextColored(VALUE_COLOR[1], VALUE_COLOR[2], VALUE_COLOR[3], VALUE_COLOR[4], tostring(value))
end

local function render_fish_ui()
    if Open then
        local WindowFlags = bit32.bor(ImGuiWindowFlags.NoResize, ImGuiWindowFlags.AlwaysAutoResize)
        Open, ShowUI = ImGui.Begin('Fishing', Open, WindowFlags)
        if ShowUI then
            if ImGui.BeginTabBar('FishTabs', ImGuiTabBarFlags.None) then
                if ImGui.BeginTabItem('Info') then
                    ImGui.Spacing()
                    info_pair('Status:', Fish_Status)
                    ImGui.Spacing()
                    if ImGui.Button('Start', ImVec2(40, 25)) then
                        Fish_Active = true
                    end
                    ImGui.SameLine()
                    ImGui.PushStyleColor(ImGuiCol.Button, 1.0, 1.0, 0.0, 1.0)
                    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 1.0, 1.0, 0.4, 1.0)
                    ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0.8, 0.8, 0.0, 1.0)
                    ImGui.PushStyleColor(ImGuiCol.Text, 0.0, 0.0, 0.0, 1.0)
                    if ImGui.Button('Stop', ImVec2(40, 25)) then
                        Fish_Active = false
                        update_status('Stopped')
                    end
                    ImGui.PopStyleColor(4)
                    ImGui.SameLine(0, 110)
                    ImGui.PushStyleColor(ImGuiCol.Button, 1.0, 0.0, 0.0, 1.0)
                    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 1.0, 0.4, 0.4, 1.0)
                    ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0.8, 0.0, 0.0, 1.0)
                    ImGui.PushStyleColor(ImGuiCol.Text, 0.0, 0.0, 0.0, 1.0)
                    if ImGui.Button('Exit', ImVec2(40, 25)) then
                        terminate = true
                    end
                    ImGui.PopStyleColor(4)
                    ImGui.Spacing()
                    ImGui.Separator()
                    ImGui.Spacing()
                    info_pair('Catches:', caught)
                    ImGui.SameLine()
                    info_pair('Kept:', fish_kept)
                    ImGui.SameLine()
                    info_pair('Destroyed:', trash_caught)
                    ImGui.Spacing()
                    info_pair('Beers Spilt:', spilled_beers)
                    ImGui.SameLine()
                    info_pair('Lucky Catches:', lucky_catches)
                    ImGui.Spacing()
                    ImGui.Separator()
                    ImGui.Spacing()
                    info_pair('Fishing Skill:', fishing_skill)
                    ImGui.Spacing()
                    ImGui.Separator()
                    ImGui.Spacing()
                    info_pair(SHARD_NAME .. ':', count_shards())
                    ImGui.EndTabItem()
                end
                if ImGui.BeginTabItem('Settings') then
                    -- Begin Fishing Settings Section
                    ImGui.Spacing()
                    ImGui.Text('Fishing Settings:')
                    ImGui.Spacing()

                    -- Turn fishing on or off
                    Fish_Active, _ = ImGui.Checkbox('Start Fishing', Fish_Active)
                    show_help_marker('Turn fishing on or off. Do this last! READ THE INSTRUCTIONS!')
                    ImGui.SameLine(0, 25)
                    local running
                    if Fish_Active then
                        running = 'Running'
                    else
                        running = 'Stopped'
                    end
                    ImGui.Text('Status: %s', running)

                    -- BEER! IT'S THE BEER SECTION!
                    ImGui.Spacing()
                    ImGui.Separator()
                    ImGui.Spacing()
                    ImGui.Text('Alcoholism:')
                    ImGui.Spacing()

                    -- Do we want to... DO WE WANT TO DRINK BEER? What kind of question is that?
                    Fish_Drink_Beer, _ = ImGui.Checkbox('Drink Beer', Fish_Drink_Beer)
                    show_help_marker(
                        "*** Breaks Invis ***\n Will only work if you have a Fisherman's Companion or Brell's Fishin' Pole in your inventory.")
                    ImGui.SameLine(0, 41)
                    local drinking
                    if Fish_Drink_Beer then
                        drinking = 'Running'
                    else
                        drinking = 'Stopped'
                    end
                    ImGui.Text('Status: %s', drinking)

                    -- How much wonderful beer do we want to summon?
                    ImGui.Text('Summon Beers:    ')
                    show_help_marker('Number of beers to summon before fishing again. Ctrl+Click bar to type amount.')
                    ImGui.SameLine(0, 9)
                    Fish_Summon_Beer, _ = ImGui.SliderInt('##SliderSummonBeers', Fish_Summon_Beer, 2, 999, '%d')

                    -- How many beers to drink before we cast our line each time
                    ImGui.Text('Drinks Per Round:')
                    show_help_marker('Number of beers to drink before fishing again. Ctrl+Click bar to type amount.')
                    ImGui.SameLine()
                    Fish_Drink_Beer_Number, _ = ImGui.SliderInt('##SliderDrinksPerRound', Fish_Drink_Beer_Number, 1, 20,
                        '%d')


                    -- Begin Making Bait Section
                    ImGui.Spacing()
                    ImGui.Separator()
                    ImGui.Spacing()
                    ImGui.Text('Making Bait:')
                    ImGui.Spacing()

                    -- Let's cut up some fish! Ewwww Fish Guts!
                    Fish_Make_Bait, _ = ImGui.Checkbox('Make Bait', Fish_Make_Bait)
                    show_help_marker(
                        "If we have an Anizok's Bait Dispenser, and it is in a top level inventory slot, we can make our own bait forever.")
                    ImGui.SameLine(0, 43)
                    local baiting
                    if Fish_Make_Bait then
                        baiting = 'Running'
                    else
                        baiting = 'Stopped'
                    end
                    ImGui.Text('Status: %s', baiting)

                    -- Let's make this much bait!
                    ImGui.Text('Bait Amount:  ')
                    show_help_marker(
                        'How much bait to make? We can use multiple devices. Will pick best first. CTRL+Click bar to type amount.')
                    ImGui.SameLine(0, 32)
                    Fish_Make_Bait_Number, _ = ImGui.SliderInt('##SliderMakeBaitNumber', Fish_Make_Bait_Number, 1, 999,
                        '%d')

                    -- Begin Shopping Section
                    ImGui.Spacing()
                    ImGui.Separator()
                    ImGui.Spacing()
                    ImGui.Text('Shopping:')
                    ImGui.Spacing()

                    -- Let us go to the store?
                    Fish_Go_Shopping, _ = ImGui.Checkbox('Go Shopping', Fish_Go_Shopping)
                    show_help_marker(
                        '*** Breaks Invis *** Allow us to buy bait or poles from the vendor in this zone (Plane of Knowledge or Plane of Tranquility), or travel to Plane of Knowledge if there is not one. Then return to our current spot and start right back up.')
                    ImGui.SameLine(0, 25)
                    local shopping
                    if Fish_Go_Shopping then
                        shopping = 'Running'
                    else
                        shopping = 'Stopped'
                    end
                    ImGui.Text('Status: %s', shopping)

                    -- How Many Poles to buy
                    ImGui.Text('Buy Poles: ')
                    show_help_marker('How many fishing poles to buy if we do not have one or break them all.')
                    ImGui.SameLine(0, 53)
                    Fish_Buy_Poles, _ = ImGui.SliderInt('##SliderBuyPoles', Fish_Buy_Poles, 1, 10)

                    -- How much bait to buy
                    ImGui.Text('Buy Bait:    ')
                    show_help_marker('How much bait to buy if we do not have any and can make none.')
                    ImGui.SameLine(0, 53)
                    Fish_Buy_Bait, _ = ImGui.SliderInt('##SliderBuyBait', Fish_Buy_Bait, 1, 2000)

                    -- End the Tab
                    ImGui.EndTabItem()
                end
                -- End the Tab Holder
                ImGui.EndTabBar()
            end
        end
        -- End the entire UI
        ImGui.End()
    end
end

local function FishHUD()
    if Open then
        Open = false
    else
        Open = true
    end
end

mq.imgui.init('fishhud', render_fish_ui)
mq.bind('/fish', FishHUD)

while not terminate
do
    if not _initialized then
        ShowUI = true
        _initialized = true
    end
    -- Stop rules:
    --  * In Qeynos Hills (shard zone): stop as soon as we have obtained a Shard.
    --    The skill cap does not matter there.
    --  * Anywhere else: never stop for skill. Fish up to the cap, and once capped
    --    just keep fishing to catch items.
    if Fish_Active and shard_found then
        Fish_Active = false
        update_status('Stopped - %s obtained', SHARD_NAME)
        print(string.format('\ar[\atFishing\ar]\ag %s obtained. Stopping.', SHARD_NAME))
    end
    if Fish_Active and not is_shard_zone() then
        if skill_is_capped() then
            if not cap_announced then
                cap_announced = true
                print(string.format('\ar[\atFishing\ar]\aw Fishing skill capped (%d). Fishing for items.',
                    get_skill_cap()))
            end
        else
            cap_announced = false
        end
    end
    -- Walk to the fishing spot when we start fishing or enter a new zone.
    local zone_now = mq.TLO.Zone.ShortName()
    if zone_now ~= last_zone_seen then
        last_zone_seen = zone_now
        go_to_spot_pending = true
    end
    local just_started = Fish_Active and not was_active
    if just_started then
        go_to_spot_pending = true
        shard_found = false
    end
    was_active = Fish_Active
    if just_started and not making_bait then
        restock_on_start()
    end
    if Fish_Active then
        if not making_bait then
            -- Deal with stuff we find on cursor. Trash some. Inventory others.
            while mq.TLO.Cursor.ID() do
                check_catch()
            end

            if mq.TLO.Me.AbilityReady('Fishing')() then
                -- If we have the magic pole and summon beer is on, summon more when we need it.
                if mq.TLO.Me.Inventory(13).Name() == "Brell's Fishin' Pole" then
                    if Fish_Drink_Beer then
                        if mq.TLO.FindItemCount(8991)() < Fish_Drink_Beer_Number then
                            update_status('Summoning Beer')
                            logz('Out of beer! Time to summon more!')
                            while mq.TLO.FindItemCount(8991)() < Fish_Summon_Beer do
                                mq.cmd('/useitem "Brell\'s Fishin\' Pole"')
                                mq.delay(2500)
                                if mq.TLO.Cursor.ID() ~= 8991 then
                                    check_catch()
                                else
                                    mq.cmd('/autoinventory')
                                    mq.delay(500)
                                end
                            end
                        end
                    end
                    -- Drink beer if we have the magic rod and drink beer is on.
                    if Fish_Drink_Beer then
                        update_status('Drinking Beer')
                        local beer_count = mq.TLO.FindItemCount(8991)() - Fish_Drink_Beer_Number
                        while beer_count < mq.TLO.FindItemCount(8991)() do
                            mq.cmd('/useitem "Summoned: Ale"')
                            mq.delay(500)
                        end
                    end
                end

                -- Make sure we have a pole and bait before casting. If either is
                -- missing, buy both in a single trip.
                local supplies_ok = check_supplies()

                -- Have pole and bait: walk to this zone's fishing spot (once per start / zone change).
                if supplies_ok and not terminate and go_to_spot_pending then
                    go_to_fishing_spot()
                end

                -- Actually do the fishing
                if supplies_ok and not terminate and not mq.TLO.Cursor.ID() then
                    mq.cmd('/squelch /doability Fishing')
                    update_status('Fishing')
                    mq.delay(1000)
                end
            end
        end
    end
    mq.doevents()
    mq.delay(1)
end
shutdown()
