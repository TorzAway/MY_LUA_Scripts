local mq = require('mq')
local ImGui = require('ImGui')

-- Window visibility state - controls the background loop survival
local openGUI = true
local shouldDrawGUI = false

-- Helper function to format numbers with commas
local function format_with_commas(amount)
    local formatted = tostring(amount)
    while true do  
        local k
        formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
        if k == 0 then break end
    end
    return formatted
end

-- Helper function to automatically lookup Diamond Coin value natively using MQ TLO
local function get_merchant_sale_price()
    local item = mq.TLO.FindItem("=Diamond Coin")
    
    if item and item() then
        local raw_value = item.Value() or 0
        -- Game engine merchant values are stored in copper. Divide by 1000 to convert to Platinum pieces.
        if raw_value > 0 then
            return math.floor(raw_value / 1000)
        end
    end
    
    -- Fallback default price if your character is not holding a Diamond Coin to scan
    return 100 
end

-- Helper function to fetch data locally or over DanNet
local function get_member_aa(name)
    if name == mq.TLO.Me.Name() then
        return mq.TLO.Me.AAPoints() or 0
    end

    if mq.TLO.Plugin('mq2dannet')() then
        local query_string = "Me.AAPoints"
        local result = mq.TLO.DanNet(name).Observe(query_string)()
        
        if result and result ~= "NULL" and result ~= "" then
            return tonumber(result) or 0
        end
    end
    return 0
end

-- Main ImGui render function
local function draw_gui()
    if not openGUI then return end

    -- Set default window size (adjusted height slightly for the new button)
    ImGui.SetNextWindowSize(ImVec2(480, 310), ImGuiCond.FirstUseEver)
    
    openGUI, shouldDrawGUI = ImGui.Begin("Unspent AA Conversion Table", openGUI, ImGuiWindowFlags.None)
    
    if shouldDrawGUI then
        if not ImGui.IsWindowCollapsed() then
            
            -- Fetch the current true item value dynamically every frame
            local current_rate = get_merchant_sale_price()
            
            -- Display the automatically scanned merchant rate at the top
            ImGui.AlignTextToFramePadding()
            ImGui.Text("Scanned Merchant Rate:")
            ImGui.SameLine()
            ImGui.TextColored(ImVec4(1.0, 0.84, 0.0, 1), string.format("%s pp per Diamond Coin", format_with_commas(current_rate)))
            
            ImGui.Spacing()

            local flags = ImGuiTableFlags.Borders + ImGuiTableFlags.RowBg + ImGuiTableFlags.Resizable
            
            local total_aa_points = 0
            local total_diamond_coins = 0
            local total_platinum = 0

            -- 1. MAIN DATA TABLE
            if ImGui.BeginTable("GroupAATable", 4, flags) then
                ImGui.TableSetupColumn("Name")
                ImGui.TableSetupColumn("Unspent AA")
                ImGui.TableSetupColumn("Diamond Coin")
                ImGui.TableSetupColumn("Platinum")
                ImGui.TableHeadersRow()

                local group_size = mq.TLO.Group.GroupSize() or 0
                if group_size > 0 then
                    for i = 0, group_size - 1 do
                        local member = mq.TLO.Group.Member(i)
                        
                        if member and member.Name() then
                            ImGui.TableNextRow()
                            
                            -- Column 1: Name
                            ImGui.TableSetColumnIndex(0)
                            ImGui.Text(member.Name())
                            
                            -- Column 2: Unspent AAs
                            ImGui.TableSetColumnIndex(1)
                            local unspent_aa = get_member_aa(member.Name())
                            local aa_str = format_with_commas(unspent_aa)
                            
                            if unspent_aa >= 100 then
                                ImGui.TextColored(ImVec4(0, 1, 0, 1), aa_str)
                            elseif unspent_aa > 0 then
                                ImGui.TextColored(ImVec4(1, 1, 0, 1), aa_str)
                            else
                                ImGui.TextColored(ImVec4(1, 0, 0, 1), "0")
                            end
                            total_aa_points = total_aa_points + unspent_aa

                            -- Column 3: Diamond Coin
                            ImGui.TableSetColumnIndex(2)
                            local diamond_coins = unspent_aa * 3
                            ImGui.Text(format_with_commas(diamond_coins))
                            total_diamond_coins = total_diamond_coins + diamond_coins

                            -- Column 4: Platinum
                            ImGui.TableSetColumnIndex(3)
                            local platinum_val = diamond_coins * current_rate
                            ImGui.TextColored(ImVec4(0.9, 0.9, 0.9, 1), string.format("%s pp", format_with_commas(platinum_val)))
                            total_platinum = total_platinum + platinum_val
                        end
                    end
                else
                    -- Fallback row if solo
                    total_aa_points = mq.TLO.Me.AAPoints() or 0
                    total_diamond_coins = total_aa_points * 3
                    total_platinum = total_diamond_coins * current_rate
                    
                    ImGui.TableNextRow()
                    ImGui.TableSetColumnIndex(0)
                    ImGui.Text(mq.TLO.Me.Name())
                    ImGui.TableSetColumnIndex(1)
                    ImGui.Text(format_with_commas(total_aa_points))
                    ImGui.TableSetColumnIndex(2)
                    ImGui.Text(format_with_commas(total_diamond_coins))
                    ImGui.TableSetColumnIndex(3)
                    ImGui.TextColored(ImVec4(0.9, 0.9, 0.9, 1), string.format("%s pp", format_with_commas(total_platinum)))
                end
                
                ImGui.EndTable()
            end

            -- 2. VISUAL SEPARATOR
            ImGui.Spacing()
            ImGui.Separator()
            ImGui.Spacing()

            -- 3. TOTALS DISPLAY ROW
            if ImGui.BeginTable("TotalsTable", 4, flags) then
                ImGui.TableSetupColumn("TotalsLabel")
                ImGui.TableSetupColumn("TotalAA")
                ImGui.TableSetupColumn("TotalDC")
                ImGui.TableSetupColumn("TotalPlat")
                
                ImGui.TableNextRow()
                
                -- Column 1 Label
                ImGui.TableSetColumnIndex(0)
                ImGui.Text("Group Totals:")
                
                -- Column 2 Total AA
                ImGui.TableSetColumnIndex(1)
                ImGui.TextColored(ImVec4(1.0, 1.0, 1.0, 1), format_with_commas(total_aa_points))
                
                -- Column 3 Diamond Coin Sum Total
                ImGui.TableSetColumnIndex(2)
                ImGui.TextColored(ImVec4(0.3, 0.8, 1.0, 1), format_with_commas(total_diamond_coins))
                
                -- Column 4 Platinum Sum Total
                ImGui.TableSetColumnIndex(3)
                ImGui.TextColored(ImVec4(1.0, 0.84, 0.0, 1), string.format("%s pp", format_with_commas(total_platinum)))
                
                ImGui.EndTable()
            end

            -- 4. ADDED: EXIT SCRIPT BUTTON
            ImGui.Spacing()
            ImGui.Separator()
            ImGui.Spacing()
            
            -- Pushes a red accent style onto the exit button text for clear visual feedback
            ImGui.PushStyleColor(ImGuiCol.Text, ImVec4(1.0, 0.3, 0.3, 1.0))
            if ImGui.Button("Exit Script", ImVec2(-1, 24)) then
                openGUI = false -- Triggers immediate loop termination below
            end
            ImGui.PopStyleColor()
        end
    end
    ImGui.End()
end

-- Initialize the ImGui window callback with MacroQuest
mq.imgui.init('UnspentAAConversionTableUI', draw_gui)

-- Main execution loop: Survives as long as openGUI is true
while openGUI do
    mq.delay(100)
end
