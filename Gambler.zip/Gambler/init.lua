--[[
    gamber.lua

    MacroQuest Lua script that repeatedly takes ONE "King's Court Token" out of
    your inventory and hands it to the NPC "Vuri Pandar", over and over, until
    you have no tokens left.

    Safety behavior:
      - Before grabbing a new token, it checks the cursor for up to 0.5
        seconds; if anything is there, it runs /autoinventory once,
        immediately, and waits for it to clear.
      - It will NOT attempt to grab another token until it has confirmed the
        cursor is empty.
    Hand-in flow for each token:
      1) Pick up one token from inventory (via /ctrlkey so only 1 comes off
         a stack).
      2) Hand the token to Vuri (click the target).
      3) Confirm there is nothing on the cursor after handing it over - if
         the token didn't actually leave your hand, stop for safety.
      4) Click the Give button to finish the turn-in.
      5) Wait a flat 0.5 seconds, THEN check the cursor once. If something's
         there, that's logged as a WIN ("WE WON: <item name>", shown in
         yellow, with a stack count if more than one came back).
      6) Auto-inventory whatever's on the cursor (win or not) so the cursor
         is clear and the next token attempt can begin - UNLESS the won
         item is listed under [Destroy] in Gamber_Config.ini, or it's a
         Lore item you already have one of, in which case it's destroyed
         instead. Every win is also appended to Gamber_Wins.txt in the
         MQ config directory.

    Won-item config (Gamber_Config.ini, in the MQ config directory):
      - [Destroy] section: won items here are destroyed immediately via
        /destroy as soon as they land on the cursor.
      - There is no [Keep] section - anything not in [Destroy] is simply
        auto-inventoried by default, which is the safe choice.
      - Lore duplicates: in practice, a duplicate Lore item is rejected by
        the server before it ever lands on your cursor, so there's nothing
        to destroy - instead, the script listens for the server's chat
        message ("You already have a lore <item> ... in your inventory.")
        and logs it in red, so it doesn't pass by silently. If a Lore
        duplicate ever DOES land on the cursor some other way, the script
        still destroys it on sight as a safety net - this would override
        everything else, including the always-keep items below.
      - "Gold Ticket" and "King's Court Token" are special cases: they are
        ALWAYS auto-inventoried, no matter what the config file says, and
        cannot be toggled to Destroy from the GUI either (except when the
        Lore-duplicate rule above applies).
      - Winning the Gold Ticket is the grand prize: after it's kept, an
        ALL CAPS gold message is logged ("WE WON THE GRAND PRIZE - A GOLD
        TICKET!") and the script stops itself (scriptState = "stopped")
        without exiting, so it doesn't keep grinding tokens past the win.
        Press Start again to resume.
      - Created automatically (blank) on first run if it doesn't exist.
      - Can be reloaded without restarting the script via the "Reload
        Config" button in the GUI.

    "Perform *TURBOSELL* on STOP" checkbox (on by default):
      - If checked, this same sell sequence triggers in two places:
        1) clicking Stop, and 2) automatically when free inventory slots
        drop to FREE_SLOT_THRESHOLD or fewer (instead of just pausing).
        Either way it walks to the nearest merchant (spawn search
        "merchant", 500 range), runs "/squelch /mac turboloot sell" once
        in range, waits for that macro to finish (Macro.Name() goes
        nil/empty), then walks back to Vuri Pandar and auto-resumes
        hand-ins if any tokens remain (otherwise stays stopped). This all
        happens via a "selling" scriptState driven from the main loop,
        not the button click itself, since MQ Lua ImGui callbacks can't
        use mq.delay().
      - If unchecked: Stop just stops hand-ins in place, and bags getting
        almost full just pauses (make room manually, then hit Resume) -
        the original behavior in both cases.

    Usage:
      /lua run gamber

    Notes / things to double check before you trust it:
      - The item name and NPC name below must match EXACTLY (case matters for
        the item name in /itemnotify).
      - One-at-a-time pickup is done with
        "/nomodkey /ctrlkey /itemnotify ... leftmouseup". /nomodkey clears any
        modifier key you might physically be holding, and /ctrlkey then
        simulates a clean Ctrl+click, which in EQ pulls exactly 1 item off a
        stack instead of grabbing the whole stack. As a safety net, the script
        also checks the cursor's stack count after picking up and will abort
        (putting the item(s) back via /autoinventory) if it ever sees more
        than 1 land on the cursor.
      - Clicking the NPC with an item on cursor opens the "GiveWnd" window
        with the token sitting in it; the script then clicks its "Give"
        button (GVW_Give_Button) to actually complete the turn-in. If your
        UI uses different control names, update GIVE_WINDOW / GIVE_BUTTON
        at the top of this file.
      - If you're farther than HANDIN_RANGE (default 20 units) from Vuri
        Pandar, the script runs "/nav target" (MQ2Nav) to walk over before
        attempting the hand-in. This requires the MQ2Nav plugin to be loaded
        and a navmesh for the zone; if either is missing, it logs a warning
        and stops rather than trying to hand in from out of range.
      - Before every token attempt, it checks your free inventory slots
        (Me.FreeInventory). If you're at or below FREE_SLOT_THRESHOLD
        (default 3) free slots, it pauses itself and posts a "bags are
        almost full" warning instead of risking a failed pickup/win with
        nowhere to put items. Make room and hit Resume to continue.
--]]

local mq = require('mq')
local ImGui = require('ImGui')

----------------------------------------------------------------------
-- Config
----------------------------------------------------------------------
local TOKEN_NAME        = "King's Court Token"
local NPC_NAME          = "Vuri Pandar"
local GIVE_WINDOW       = "GiveWnd"          -- the window that pops up when you click an NPC with an item on cursor
local GIVE_BUTTON       = "GVW_Give_Button"  -- the "Give" button inside that window
local CURSOR_WAIT_MS    = 500   -- max time to check for an item on cursor
local CLEAR_WAIT_MS     = 1000  -- max time to wait for autoinventory to clear cursor
local CYCLE_PAUSE_MS    = 400   -- small pause between turn-ins so we don't spam the server
local HANDIN_RANGE      = 20    -- distance (game units) considered close enough to hand in
local NAV_TIMEOUT_MS    = 30000 -- give up on navigation after this long
local NAV_POLL_MS       = 200   -- how often to check navigation progress
local FREE_SLOT_THRESHOLD = 3   -- pause and warn when free inventory slots drop to this or fewer
local WIN_LOG_FILENAME  = "Gamber_Wins.txt" -- written to mq.configDir, one line per win
local CONFIG_FILENAME   = "Gamber_Config.ini" -- written to mq.configDir, controls keep vs destroy
local MERCHANT_SEARCH   = "merchant radius 500" -- spawn search used to find a merchant to sell to
local MERCHANT_RANGE    = 15    -- distance considered close enough to interact with a merchant
local SELL_MACRO_NAME   = "turboloot"
local MACRO_START_WAIT_MS = 3000  -- time to give the macro to actually start running
local MACRO_POLL_MS       = 250   -- how often to check whether the macro has finished
local MACRO_TIMEOUT_MS    = 300000 -- give up waiting on the macro after this long (5 min) and continue anyway

----------------------------------------------------------------------
-- State
----------------------------------------------------------------------
local scriptState     = "stopped" -- "stopped" | "running" | "paused"
local statusText      = "Idle. Press Start."
local tokensTurnedIn  = 0
local logLines        = {}
local lastLogCount    = 0
local destroyItemCount = 0
local logWinsToFile   = true -- controlled by the "Log Wins to File" checkbox
local performSellOnStop = true -- controlled by the "Perform *TURBOSELL* on STOP" checkbox

----------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------
-- Turns a plain string or a list of segments into a single plain string
-- (used for the status text and the console /print line).
local function segmentsToPlainText(msgOrSegments)
    if type(msgOrSegments) ~= "table" then
        return msgOrSegments
    end
    local parts = {}
    for _, seg in ipairs(msgOrSegments) do
        table.insert(parts, seg.text)
    end
    return table.concat(parts)
end

-- log() accepts either a plain string, OR a list of segments like:
--   { { text = "Picked up " }, { text = "5", isStack = true }, { text = " tokens" } }
-- Any segment with isStack = true is rendered in the GUI as a red number
-- wrapped in cyan [ ] brackets, instead of the normal log text color.
-- kind colors the whole line: "win" yellow, "destroy" red, "keep" green,
-- "grand" gold. Omit kind (nil) for the normal log text color.
local function log(msgOrSegments, kind)
    local segments
    if type(msgOrSegments) == "table" then
        segments = msgOrSegments
    else
        segments = { { text = msgOrSegments } }
    end

    local lineSegments = { { text = string.format("[%s] ", os.date("%H:%M:%S")) } }
    for _, seg in ipairs(segments) do
        table.insert(lineSegments, seg)
    end

    table.insert(logLines, { segments = lineSegments, kind = kind })
    if #logLines > 200 then table.remove(logLines, 1) end
    print(string.format("\ay[Gamber]\ax %s", segmentsToPlainText(segments)))
end

local function setStatus(msgOrSegments, kind)
    statusText = segmentsToPlainText(msgOrSegments)
    log(msgOrSegments, kind)
end

-- Appends one line per win to Gamber_Wins.txt in the MQ config directory -
-- just the item name, no timestamp or "WE WON:" text. This is a permanent
-- record on disk, separate from the in-GUI log (which only keeps the most
-- recent 200 lines and resets when the script ends).
local function logWinToFile(prizeName, prizeStack)
    local path = mq.configDir .. "/" .. WIN_LOG_FILENAME
    local file, err = io.open(path, "a")
    if not file then
        log(string.format("Could not write win to %s: %s", WIN_LOG_FILENAME, tostring(err)))
        return
    end

    file:write(prizeName .. "\n")
    file:close()
end

----------------------------------------------------------------------
-- Won-item config (Gamber_Config.ini)
--
-- Controls what happens to a won item once it lands on your cursor:
--   - if it's listed under [Destroy], it gets destroyed
--   - otherwise, it gets auto-inventoried (kept)
-- There is no [Keep] section - keeping is just the default for anything
-- not in the Destroy list. One item name per line under [Destroy]; "="
-- and anything after it is optional and ignored, so "Item Name" and
-- "Item Name=1" both work. Lines starting with ; or # are comments.
-- Matching is case-insensitive.
--
-- "Gold Ticket" and "King's Court Token" can never be in the Destroy
-- list - they're always auto-inventoried, no matter what.
--
-- Loaded items are kept in wonItemEntries, an array of
-- { name = "Original Case Name", mode = "keep" | "destroy" }. The locked
-- always-keep items (Gold Ticket, King's Court Token) always sort first,
-- followed by everything else alphabetically, so the GUI list has a
-- stable order. wonItemIndex maps a lowercased name to its entry for fast
-- lookups. Toggling an entry's mode in the GUI updates it in memory
-- immediately AND rewrites Gamber_Config.ini so the change survives a
-- script restart.
----------------------------------------------------------------------
local CONFIG_HEADER_COMMENT = [[
; Gamber_Config.ini
;
; Controls what happens to a won item when it lands on your cursor.
; List one item name per line under [Destroy] below to have that item
; destroyed when won. Anything not listed here is auto-inventoried
; (kept) by default. Lines starting with ; or # are comments and are
; ignored. Item name matching is case-insensitive.
;
; "Gold Ticket" and "King's Court Token" are always kept (auto-inventoried)
; no matter what - they cannot be set to Destroy, even if listed under
; [Destroy] here.
;
; This file is rewritten automatically whenever an item is toggled
; between Keep and Destroy from the in-game window.

]]

local DEFAULT_CONFIG_CONTENT = CONFIG_HEADER_COMMENT .. "[Destroy]\n"

-- Items in this list can never be set to Destroy, in the config file or
-- via the GUI - they're always auto-inventoried. Keyed by lowercase name,
-- valued with the canonical display name.
local GOLD_TICKET_NAME = "Gold Ticket" -- the grand prize: always kept, and triggers a special win message + auto-stop

local ALWAYS_KEEP_ITEMS = {
    [GOLD_TICKET_NAME:lower()] = GOLD_TICKET_NAME,
    [TOKEN_NAME:lower()] = TOKEN_NAME,
}

local wonItemEntries = {} -- array of { name = "Original Case", mode = "keep"|"destroy", locked = true|nil }, locked items first, then alphabetical
local wonItemIndex   = {} -- lowercase name -> entry (same tables as in wonItemEntries)

local function trim(s)
    return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function isAlwaysKeepItem(name)
    return name ~= nil and ALWAYS_KEEP_ITEMS[trim(name):lower()] ~= nil
end

-- Recomputes destroyItemCount from the current entries.
local function recountWonItems()
    destroyItemCount = 0
    for _, entry in ipairs(wonItemEntries) do
        if entry.mode == "destroy" then
            destroyItemCount = destroyItemCount + 1
        end
    end
end

-- Rewrites Gamber_Config.ini from the current in-memory entries. Only the
-- [Destroy] list is persisted - "keep" is just the absence of an entry, so
-- nothing needs to be written for it. Any comments or formatting in the
-- user's original file beyond the standard header are not preserved -
-- this is a fully managed/generated file once any toggling happens.
local function saveWonItemConfig()
    local path = mq.configDir .. "/" .. CONFIG_FILENAME
    local file, err = io.open(path, "w")
    if not file then
        log(string.format("Could not save %s: %s", CONFIG_FILENAME, tostring(err)))
        return
    end

    file:write(CONFIG_HEADER_COMMENT)
    file:write("[Destroy]\n")
    for _, entry in ipairs(wonItemEntries) do
        if entry.mode == "destroy" and not entry.locked then
            file:write(entry.name .. "\n")
        end
    end
    file:close()
end

-- Reads Gamber_Config.ini from the MQ config directory, creating it with a
-- blank template on first run. Populates wonItemEntries / wonItemIndex.
-- Only lines under [Destroy] are read; any other section (including a
-- leftover [Keep] section from an older version of this file) is ignored.
local function loadWonItemConfig()
    local path = mq.configDir .. "/" .. CONFIG_FILENAME

    local file = io.open(path, "r")
    if not file then
        local newFile, err = io.open(path, "w")
        if not newFile then
            log(string.format("Could not create %s: %s", CONFIG_FILENAME, tostring(err)))
            return
        end
        newFile:write(DEFAULT_CONFIG_CONTENT)
        newFile:close()
        log(string.format("Created default %s in the config folder. Edit it to set destroy items.", CONFIG_FILENAME))
        file = io.open(path, "r")
        if not file then return end
    end

    local newEntries, newIndex = {}, {}
    local section = nil

    for rawLine in file:lines() do
        local line = trim(rawLine)
        if line == "" or line:sub(1, 1) == ";" or line:sub(1, 1) == "#" then
            -- comment or blank line, skip
        elseif line:sub(1, 1) == "[" then
            local sectionName = line:match("^%[(.-)%]$")
            section = sectionName and trim(sectionName):lower() or nil
        elseif section == "destroy" then
            local itemName = trim(line:match("^([^=]+)") or line)
            local key = itemName:lower()
            if key ~= "" then
                local entry = { name = itemName, mode = "destroy" }
                newIndex[key] = entry
                table.insert(newEntries, entry)
            end
        end
    end
    file:close()

    -- Gold Ticket, King's Court Token (and anything else in ALWAYS_KEEP_ITEMS) can never be
    -- Destroy, even if the file says otherwise - correct it and lock it.
    for _, entry in ipairs(newEntries) do
        local canonical = ALWAYS_KEEP_ITEMS[entry.name:lower()]
        if canonical then
            entry.name = canonical
            entry.mode = "keep"
            entry.locked = true
        end
    end

    -- Make sure every always-keep item shows up in the list even if it
    -- wasn't mentioned in the file at all.
    for lowerName, canonicalName in pairs(ALWAYS_KEEP_ITEMS) do
        if not newIndex[lowerName] then
            local entry = { name = canonicalName, mode = "keep", locked = true }
            newIndex[lowerName] = entry
            table.insert(newEntries, entry)
        end
    end

    -- Locked (always-keep) items always come first, then everything else
    -- alphabetically.
    table.sort(newEntries, function(a, b)
        if (a.locked == true) ~= (b.locked == true) then
            return a.locked == true
        end
        return a.name:lower() < b.name:lower()
    end)

    wonItemEntries, wonItemIndex = newEntries, newIndex
    recountWonItems()

    log(string.format("Loaded %s: %d destroy item%s.",
        CONFIG_FILENAME, destroyItemCount, destroyItemCount == 1 and "" or "s"))
end

-- Flips an entry between keep and destroy, then persists the change to
-- Gamber_Config.ini. Locked entries (ALWAYS_KEEP_ITEMS) can't be toggled.
local function toggleWonItemMode(entry)
    if entry.locked then
        log(string.format("'%s' is always kept and can't be toggled.", entry.name))
        return
    end
    entry.mode = (entry.mode == "keep") and "destroy" or "keep"
    recountWonItems()
    log(string.format("Set '%s' to %s.", entry.name, entry.mode == "keep" and "Keep" or "Destroy"))
    saveWonItemConfig()
end

local function isDestroyItem(name)
    if name == nil then return false end
    local entry = wonItemIndex[trim(name):lower()]
    return entry ~= nil and entry.mode == "destroy"
end

local function getTokenCount()
    return mq.TLO.FindItemCount(TOKEN_NAME)() or 0
end

local function getFreeInventorySlots()
    return mq.TLO.Me.FreeInventory() or 0
end

local function cursorHasItem()
    return mq.TLO.Cursor.ID() ~= nil
end

-- Returns how many of the item are in the stack currently on the cursor.
-- Non-stackable items (or an empty cursor) are treated as a count of 1/0.
local function getCursorStackCount()
    if not cursorHasItem() then return 0 end
    local stack = mq.TLO.Cursor.Stack()
    if stack == nil or stack <= 0 then return 1 end
    return stack
end

-- True if the item on the cursor is flagged Lore AND you already have at
-- least one elsewhere in your inventory - meaning auto-inventorying it
-- would just fail (the server won't let you hold two of the same Lore
-- item), so it needs to be destroyed instead of kept.
local function isCursorLoreDuplicate()
    if not cursorHasItem() then return false end
    if mq.TLO.Cursor.Lore() ~= true then return false end
    local name = mq.TLO.Cursor.Name()
    if name == nil then return false end
    return (mq.TLO.FindItemCount(name)() or 0) > 0
end

-- Checks the cursor for up to CURSOR_WAIT_MS. If something is there, runs
-- /autoinventory immediately (just once) and waits up to CLEAR_WAIT_MS for
-- it to clear. Returns true if the cursor ends up empty.
local function ensureCursorClear()
    mq.delay(CURSOR_WAIT_MS, function() return cursorHasItem() end)

    if not cursorHasItem() then
        return true
    end

    setStatus("Item detected on cursor, running /autoinventory...")
    mq.cmd('/autoinventory')
    mq.delay(CLEAR_WAIT_MS, function() return not cursorHasItem() end)

    return not cursorHasItem()
end

local function isTargetCorrectNPC()
    local t = mq.TLO.Target
    if t.ID() == nil then return false end
    if t.Type() ~= "NPC" then return false end
    local name = t.CleanName() or t.Name() or ""
    return name == NPC_NAME
end

local function targetNPC()
    if isTargetCorrectNPC() then return true end
    mq.cmdf('/target npc "%s"', NPC_NAME)
    mq.delay(1000, function() return isTargetCorrectNPC() end)
    return isTargetCorrectNPC()
end

local function giveWindowOpen()
    local w = mq.TLO.Window(GIVE_WINDOW)
    return w.Open() == true
end

local function clickGiveButton()
    mq.cmdf('/notify %s %s leftmouseup', GIVE_WINDOW, GIVE_BUTTON)
end

local function navPluginLoaded()
    return mq.TLO.Plugin("MQ2Nav").IsLoaded() == true
end

local function isInRangeOfTarget(range)
    local dist = mq.TLO.Target.Distance3D()
    if dist == nil then return false end
    return dist <= (range or HANDIN_RANGE)
end

-- Navigates to the current target using MQ2Nav, for as long as scriptState
-- still equals expectedState (aborts immediately if it changes out from
-- under it, e.g. user hits Stop or Exit mid-navigation). targetLabel is
-- only used for the status message. Returns true if navigation completed
-- within `range` of the target.
local function navigateToTarget(expectedState, targetLabel, range)
    if not navPluginLoaded() then
        log("MQ2Nav isn't loaded, can't auto-navigate to the NPC. Move closer manually.")
        return false
    end

    setStatus(string.format("Out of range of %s, navigating closer...", targetLabel))
    mq.cmd('/nav target')
    mq.delay(500, function() return mq.TLO.Navigation.Active() == true end)

    local waited = 0
    while mq.TLO.Navigation.Active() == true and waited < NAV_TIMEOUT_MS do
        if scriptState ~= expectedState then
            mq.cmd('/nav stop')
            return false
        end
        mq.delay(NAV_POLL_MS)
        waited = waited + NAV_POLL_MS
    end

    if mq.TLO.Navigation.Active() == true then
        log("Navigation timed out, stopping it.")
        mq.cmd('/nav stop')
    end

    return isInRangeOfTarget(range)
end

----------------------------------------------------------------------
-- Main work cycle: hand in exactly one token
----------------------------------------------------------------------
local function processOneToken()
    local freeSlots = getFreeInventorySlots()
    if freeSlots <= FREE_SLOT_THRESHOLD then
        if performSellOnStop then
            setStatus(string.format(
                "Bags are almost full (%d free slot%s left). Stopping hand-ins to sell...",
                freeSlots, freeSlots == 1 and "" or "s"))
            scriptState = "selling"
        else
            scriptState = "paused"
            setStatus(string.format(
                "Bags are almost full (%d free slot%s left). Pausing - make room, then hit Resume.",
                freeSlots, freeSlots == 1 and "" or "s"))
        end
        return
    end

    local count = getTokenCount()
    if count <= 0 then
        setStatus("No more King's Court Tokens. Stopping.")
        scriptState = "stopped"
        return
    end

    setStatus(string.format("Tokens remaining: %d. Targeting %s...", count, NPC_NAME))
    if not targetNPC() then
        setStatus(string.format("Could not target NPC '%s'. Is it nearby? Stopping.", NPC_NAME))
        scriptState = "stopped"
        return
    end

    if not isInRangeOfTarget() then
        if not navigateToTarget("running", NPC_NAME) then
            if scriptState == "running" then
                setStatus(string.format("Could not get in range of %s. Stopping.", NPC_NAME))
                scriptState = "stopped"
            end
            return
        end
        setStatus(string.format("In range of %s.", NPC_NAME))
    end

    -- never grab another token until we're sure the cursor is empty
    if not ensureCursorClear() then
        setStatus("Could not clear cursor. Stopping for safety.")
        scriptState = "stopped"
        return
    end

    -- 1) pick up exactly ONE token onto the cursor.
    -- /nomodkey clears any modifier key you might actually be holding down,
    -- then /ctrlkey simulates a clean Ctrl+click for the itemnotify call,
    -- which in EQ pulls a single item off a stack instead of the whole stack.
    mq.cmdf('/nomodkey /ctrlkey /itemnotify "%s" leftmouseup', TOKEN_NAME)
    mq.delay(CURSOR_WAIT_MS, function() return cursorHasItem() end)

    if not cursorHasItem() then
        setStatus(string.format("Tried to pick up '%s' but nothing landed on cursor. Stopping.", TOKEN_NAME))
        scriptState = "stopped"
        return
    end

    local stackCount = getCursorStackCount()
    if stackCount > 1 then
        setStatus({
            { text = "Picked up " },
            { text = tostring(stackCount), isStack = true },
            { text = " tokens instead of 1 (ctrlkey pickup didn't behave as expected). Putting them back and stopping for safety." }
        })
        mq.cmd('/autoinventory')
        mq.delay(CLEAR_WAIT_MS, function() return not cursorHasItem() end)
        scriptState = "stopped"
        return
    end

    -- 2) hand the token to Vuri: clicking with an item on cursor should
    -- immediately move the token off your cursor and into the "Give" window
    mq.cmd('/click left target')

    -- 3) confirm there is nothing on the cursor after handing it to Vuri
    mq.delay(CURSOR_WAIT_MS, function() return not cursorHasItem() end)

    if cursorHasItem() then
        setStatus("Token did not leave cursor after handing it to Vuri. Stopping for safety.")
        scriptState = "stopped"
        return
    end

    -- 4) click the Give button to finish the turn-in
    mq.delay(CURSOR_WAIT_MS, function() return giveWindowOpen() end)

    if giveWindowOpen() then
        clickGiveButton()
    else
        log("Give window didn't open; the turn-in may have completed directly.")
    end

    -- 5) wait a flat 0.5s after clicking Give, THEN check once for a win
    mq.delay(CURSOR_WAIT_MS)

    local wonPrizeName = nil

    if cursorHasItem() then
        wonPrizeName = mq.TLO.Cursor.Name() or "an unknown item"
        local prizeStack = getCursorStackCount()
        if prizeStack > 1 then
            setStatus({
                { text = string.format("WE WON: %s x", wonPrizeName) },
                { text = tostring(prizeStack), isStack = true }
            }, "win")
        else
            setStatus(string.format("WE WON: %s", wonPrizeName), "win")
        end
        if logWinsToFile then
            logWinToFile(wonPrizeName, prizeStack)
        end
    end

    -- 6) decide what to do with whatever's on the cursor so we're clear to
    -- hand in the next token.
    --   1) If it's Lore and you already have one, destroy it - the server
    --      won't let you keep a second one anyway, so trying to
    --      auto-inventory it would just fail and leave it stuck on cursor.
    --   2) "Gold Ticket", "King's Court Token" (and anything else in
    --      ALWAYS_KEEP_ITEMS) is always auto-inventoried, no matter what
    --      the config says. Winning the Gold Ticket specifically is the
    --      grand prize: it gets a special ALL CAPS gold message, and the
    --      script stops itself (but does not exit) so it doesn't keep
    --      grinding tokens past the big win.
    --   3) Otherwise, items on the Destroy list (Gamber_Config.ini) get
    --      destroyed; everything else (including anything not listed)
    --      gets auto-inventoried, which is the safe default.
    if cursorHasItem() then
        if isCursorLoreDuplicate() then
            setStatus(string.format("'%s' is Lore and you already have one - destroying the duplicate.", wonPrizeName), "destroy")
            mq.cmd('/destroy')
            mq.delay(CLEAR_WAIT_MS, function() return not cursorHasItem() end)
            if cursorHasItem() then
                log(string.format("Couldn't destroy Lore duplicate '%s' on cursor. Check it manually.", wonPrizeName))
            else
                log(string.format("Destroyed '%s' (Lore item, already had one).", wonPrizeName), "destroy")
            end
        elseif isAlwaysKeepItem(wonPrizeName) then
            mq.cmd('/autoinventory')
            mq.delay(CLEAR_WAIT_MS, function() return not cursorHasItem() end)
            if cursorHasItem() then
                log("Couldn't auto-inventory the item on cursor. Check it manually.")
            else
                log(string.format("Kept '%s'.", wonPrizeName), "keep")
                if trim(wonPrizeName):lower() == GOLD_TICKET_NAME:lower() then
                    setStatus("WE WON THE GRAND PRIZE - A GOLD TICKET!", "grand")
                    scriptState = "stopped"
                end
            end
        elseif isDestroyItem(wonPrizeName) then
            setStatus(string.format("Destroying '%s' per %s.", wonPrizeName, CONFIG_FILENAME), "destroy")
            mq.cmd('/destroy')
            mq.delay(CLEAR_WAIT_MS, function() return not cursorHasItem() end)
            if cursorHasItem() then
                log("Couldn't destroy the item on cursor. Check it manually.")
            else
                log(string.format("Destroyed '%s'.", wonPrizeName), "destroy")
            end
        else
            mq.cmd('/autoinventory')
            mq.delay(CLEAR_WAIT_MS, function() return not cursorHasItem() end)
            if cursorHasItem() then
                log("Couldn't auto-inventory the item on cursor. Check it manually.")
            else
                log(string.format("Kept '%s'.", wonPrizeName), "keep")
            end
        end
    end

    tokensTurnedIn = tokensTurnedIn + 1
    if scriptState == "running" then
        setStatus(string.format("Handed in token #%d. %d remaining.", tokensTurnedIn, getTokenCount()))
    end

    mq.delay(CYCLE_PAUSE_MS)
end

----------------------------------------------------------------------
-- Sell sequence: walk to the nearest merchant, run turboloot sell, walk
-- back to Vuri Pandar, and resume hand-ins if any tokens are left.
-- Triggered by the Stop button when "Perform *TURBOSELL* on STOP" is checked.
-- Runs from the main loop (not a GUI callback) so it's free to use
-- mq.delay() for navigation and for waiting on the macro to finish.
----------------------------------------------------------------------
local function performSellSequence()
    mq.cmd('/nav stop')
    setStatus("Stopped hand-ins. Looking for the nearest merchant...")

    local merchant = mq.TLO.NearestSpawn(MERCHANT_SEARCH)
    local merchantID = merchant.ID()
    if merchantID == nil then
        log("No merchant found nearby. Staying stopped.")
        scriptState = "stopped"
        return
    end
    local merchantName = merchant.CleanName() or merchant.Name() or "the merchant"

    mq.cmdf('/target id %d', merchantID)
    mq.delay(1000, function() return mq.TLO.Target.ID() == merchantID end)
    if mq.TLO.Target.ID() ~= merchantID then
        log(string.format("Could not target merchant '%s'. Staying stopped.", merchantName))
        scriptState = "stopped"
        return
    end

    if not isInRangeOfTarget(MERCHANT_RANGE) then
        if not navigateToTarget("selling", merchantName, MERCHANT_RANGE) then
            if scriptState == "selling" then
                log(string.format("Could not reach merchant '%s'. Staying stopped.", merchantName))
                scriptState = "stopped"
            end
            return
        end
    end

    if scriptState ~= "selling" then return end

    setStatus(string.format("At '%s'. Running turboloot sell...", merchantName))
    mq.cmd('/squelch /mac turboloot sell')

    -- give the macro a moment to actually start before polling for it to end
    mq.delay(MACRO_START_WAIT_MS, function() return mq.TLO.Macro.Name() ~= nil end)

    local waited = 0
    while mq.TLO.Macro.Name() ~= nil and waited < MACRO_TIMEOUT_MS do
        if scriptState ~= "selling" then return end
        mq.delay(MACRO_POLL_MS)
        waited = waited + MACRO_POLL_MS
    end

    if mq.TLO.Macro.Name() ~= nil then
        log(string.format("%s didn't finish within the timeout, continuing anyway.", SELL_MACRO_NAME))
    else
        log("Selling complete.")
    end

    if scriptState ~= "selling" then return end

    setStatus(string.format("Heading back to %s...", NPC_NAME))
    if not targetNPC() then
        log(string.format("Could not target '%s' to resume hand-ins. Staying stopped.", NPC_NAME))
        scriptState = "stopped"
        return
    end

    if not isInRangeOfTarget() then
        if not navigateToTarget("selling", NPC_NAME) then
            if scriptState == "selling" then
                log(string.format("Could not get back to %s. Staying stopped.", NPC_NAME))
                scriptState = "stopped"
            end
            return
        end
    end

    if scriptState ~= "selling" then return end

    if getTokenCount() > 0 then
        scriptState = "running"
        setStatus(string.format("Back at %s. Resuming hand-ins.", NPC_NAME))
    else
        scriptState = "stopped"
        setStatus(string.format("Back at %s. No tokens left, staying stopped.", NPC_NAME))
    end
end

----------------------------------------------------------------------
-- ImGui
----------------------------------------------------------------------
local function GamberGUI()
    local shouldDraw = ImGui.Begin('Gamber - Token Turn-In')
    if shouldDraw then
        ImGui.Text("NPC:  " .. NPC_NAME)
        ImGui.Text("Item: " .. TOKEN_NAME)
        ImGui.Separator()
        ImGui.Text(string.format("Tokens in inventory: %d", getTokenCount()))
        ImGui.Text(string.format("Tokens turned in this session: %d", tokensTurnedIn))
        ImGui.Text(string.format("Free inventory slots: %d", getFreeInventorySlots()))
        ImGui.Text(string.format("%s: %d destroy item%s", CONFIG_FILENAME, destroyItemCount, destroyItemCount == 1 and "" or "s"))
        ImGui.SameLine()
        if ImGui.Button("Reload Config") then
            loadWonItemConfig()
        end
        logWinsToFile = ImGui.Checkbox(string.format("Log Wins to %s", WIN_LOG_FILENAME), logWinsToFile)
        performSellOnStop = ImGui.Checkbox("Perform *TURBOSELL* on STOP", performSellOnStop)

        if ImGui.CollapsingHeader(string.format("Won Item List Configuration: (%d)", #wonItemEntries)) then
            if #wonItemEntries == 0 then
                ImGui.TextDisabled(string.format("No items yet. Add some under [Destroy] in %s.", CONFIG_FILENAME))
            else
                ImGui.BeginChild("WonItemList", 0, 150, true)
                for _, entry in ipairs(wonItemEntries) do
                    local isKeep = entry.mode == "keep"
                    ImGui.Text(entry.name)
                    ImGui.SameLine(220)
                    if entry.locked then
                        ImGui.TextColored(ImVec4(0.15, 0.55, 0.15, 1.0), "KEEP (locked)")
                    else
                        if isKeep then
                            ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(0.15, 0.55, 0.15, 1.0))
                            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.20, 0.70, 0.20, 1.0))
                            ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.10, 0.40, 0.10, 1.0))
                        else
                            ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(0.65, 0.12, 0.12, 1.0))
                            ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.80, 0.18, 0.18, 1.0))
                            ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.50, 0.08, 0.08, 1.0))
                        end
                        if ImGui.Button(string.format("%s##%s", isKeep and "KEEP" or "DESTROY", entry.name)) then
                            toggleWonItemMode(entry)
                        end
                        ImGui.PopStyleColor(3)
                    end
                end
                ImGui.EndChild()
            end
        end

        ImGui.Separator()
        ImGui.TextWrapped("State: " .. scriptState)
        ImGui.TextWrapped("Status: " .. statusText)
        ImGui.Separator()

        if scriptState == "running" then
            if ImGui.Button("Pause") then
                scriptState = "paused"
                setStatus("Paused by user.")
            end
            ImGui.SameLine()
            if ImGui.Button("Stop") then
                mq.cmd('/nav stop')
                if performSellOnStop then
                    scriptState = "selling"
                else
                    scriptState = "stopped"
                    setStatus("Stopped by user.")
                end
            end
        elseif scriptState == "paused" then
            if ImGui.Button("Resume") then
                scriptState = "running"
                setStatus("Resumed.")
            end
            ImGui.SameLine()
            if ImGui.Button("Stop") then
                mq.cmd('/nav stop')
                if performSellOnStop then
                    scriptState = "selling"
                else
                    scriptState = "stopped"
                    setStatus("Stopped by user.")
                end
            end
        elseif scriptState == "selling" then
            ImGui.TextDisabled("Selling in progress...")
        else -- stopped
            if ImGui.Button("Start") then
                if getTokenCount() <= 0 then
                    setStatus("No tokens in inventory, nothing to do.")
                else
                    scriptState = "running"
                    setStatus("Started.")
                end
            end
        end

        ImGui.SameLine()
        ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(0.75, 0.10, 0.10, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.90, 0.15, 0.15, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.60, 0.05, 0.05, 1.0))
        if ImGui.Button("Exit") then
            -- no confirmation, ends the script immediately
            mq.cmd('/nav stop')
            mq.exit()
        end
        ImGui.PopStyleColor(3)

        ImGui.Separator()
        ImGui.Text("Log:")
        ImGui.BeginChild("GamberLog", 0, 188, true)
        local stackBracketColor = ImVec4(0.0, 1.0, 1.0, 1.0) -- cyan
        local stackNumberColor  = ImVec4(1.0, 0.0, 0.0, 1.0) -- red
        local kindColors = {
            win     = ImVec4(1.0, 0.85, 0.0, 1.0), -- yellow
            destroy = ImVec4(1.0, 0.25, 0.25, 1.0), -- red
            keep    = ImVec4(0.25, 0.85, 0.25, 1.0), -- green
            grand   = ImVec4(1.0, 0.84, 0.0, 1.0), -- gold
        }
        for _, entry in ipairs(logLines) do
            local lineColor = entry.kind and kindColors[entry.kind]
            for i, seg in ipairs(entry.segments) do
                if i > 1 then ImGui.SameLine(0, 0) end
                if seg.isStack then
                    ImGui.TextColored(stackBracketColor, "[")
                    ImGui.SameLine(0, 0)
                    ImGui.TextColored(stackNumberColor, seg.text)
                    ImGui.SameLine(0, 0)
                    ImGui.TextColored(stackBracketColor, "]")
                elseif lineColor then
                    ImGui.TextColored(lineColor, seg.text)
                else
                    ImGui.Text(seg.text)
                end
            end
        end
        if #logLines ~= lastLogCount then
            ImGui.SetScrollHereY(1.0)
            lastLogCount = #logLines
        end
        ImGui.EndChild()
    end
    ImGui.End()
end

mq.imgui.init('GamberGUI', GamberGUI)

----------------------------------------------------------------------
-- Duplicate-Lore detection
--
-- When a won item is Lore and you already have one, the server never
-- actually puts it on your cursor at all - it's silently rejected before
-- it reaches you, so there's nothing for the script to see or destroy via
-- the cursor. Instead, the server prints a chat message like:
--   "You already have a lore <ItemLink> (<ItemID>) in your inventory."
-- This event catches that message and logs it, since it's otherwise
-- completely invisible to the script.
----------------------------------------------------------------------

-- Strips EQ item-link encoding (raw bytes delimited by \18) down to just
-- the readable item name, so logged text doesn't contain link control
-- characters.
local function delinkify(text)
    return (text:gsub("\18(.-)\18", function(link)
        return link:match("([%a%s'%-]+)$") or link
    end))
end

mq.event("GamberLoreDuplicate", "You already have a lore #1# in your inventory.", function(_, linkedItem)
    local itemInfo = delinkify(linkedItem)
    log(string.format("Duplicate Lore item rejected by the server: %s (you already have one - it never landed on cursor).", itemInfo), "destroy")
end)

----------------------------------------------------------------------
-- Main loop
----------------------------------------------------------------------
log("Gamber loaded. Open the window and press Start to begin turning in tokens.")
loadWonItemConfig()

while true do
    mq.doevents()

    if scriptState == "running" then
        processOneToken()
    elseif scriptState == "selling" then
        performSellSequence()
    end

    mq.delay(100)
end
