--[==[
================================================================================
 Clue  -  Helper for the "Mischief Plane" murder-mystery / Clue task (EverQuest)
 Version 1.1
================================================================================

OVERVIEW
    A MacroQuest Lua script that opens a small ImGui window ("Clue v1.1") and
    walks you through the Mischief Plane murder-mystery task. It does three jobs:

      1. Gets you from wherever you are to the task and into the instance,
         using context-sensitive buttons that depend on your current zone.
      2. Inside the instance (zone 'frozenshadow') it listens to chat and NPC
         emotes to work out the three answers - WHO did it, WHERE it happened
         and WHAT weapon was used - and shows your progress.
      3. Provides one-click navigation / dialogue buttons for every floor,
         NPC, ground spawn and puzzle so you rarely have to type anything.

    The script never makes the final accusation for you. It finds and walks you
    to ground spawns, and it picks them up (the nav "click" does that), but you
    still talk to Tranquility and answer the Who / Where / What questions.

    VERSIONS
      1.0  Base script: everything described below except the "Cursor Item
           Refresh" section.
      1.1  Adds the cursor item refresh: after a ground spawn is picked up, the
           item is autoinventoried, grabbed back out of your inventory onto the
           cursor, and autoinventoried again, which fixes clue item detection.

REQUIREMENTS
    * MacroQuest (Lua + ImGui support).
    * MQ2Nav loaded, with a navmesh for the zones used (all /nav commands).
    * Standard MQ commands used: /itemtarget, /popcustom, /multiline, /timed,
      /mqt, /squelch and /keypress (1.0), plus /itemnotify and /autoinventory
      (added in 1.1 for the cursor item refresh).

USAGE
    Start it with:   /lua run <name of the folder containing this init.lua>
    Stop it by closing the Clue window (the main loop ends when it is closed).

    The window contents change with your zone:

      mischiefplane   "Nav to Clue" walks you to the Clue NPC. Once you are
                      within 30 units it becomes "Get Task" which targets the
                      Clue NPC and says "clue" then "ready" to start the task.

      poknowledge /   "Nav to Valium" (Knowledge / Nexus). Within 75 units it
      nexus           becomes "Say mischiefplane" to get ported.

      freeporttemple  Same as above but using the NPC Klonopin.

      frozenshadow    The instance itself. First you must press "Hail Elias
                      before proceeding" (targets Elias, hails twice and says
                      "where"). After that the full tracker is shown (below).

THE TRACKER WINDOW (frozenshadow)
    Who / Where / What
        Shows the three answers. Red "Unknown" until found, green once known.

    Suspects / Location Clue NPCs
        Two columns listing every suspect and every location-clue NPC. Names
        turn green once that NPC has spoken to you, so you can see who is left.

    Current Floor
        Drop-down showing where the script thinks you are. It is updated
        automatically when you tell Elias where to go, but you can correct it
        by hand if it ever gets out of sync. Choosing "Entry" hides the
        per-floor buttons.

    Per-floor buttons (hidden while on the Entry floor)
        Nav To Elias         Walks to the Elias NPC for the current floor.
        Talk to / Nav To     The floor's suspect (Librarian, Angry Chef, etc).
                             Navigates until you are within 125 units, then
                             becomes a "Talk to" button that hails and says
                             "what", "where" and "who".
        Location NPC button  Same idea for the floor's clue NPC (see the table
                             below). It is suppressed on the Maze, where the
                             NPC (Antediluvian) is only navigated to.
        Say Truth / Red or   Penthouse only, while the Red Drake is up. Says
        Blue Drake           "truth" to the Red Drake, then once the drake riddle
                             has been solved, says the name of the correct drake.
        Say <riddle answer>  Dragon Terrace only, once the Black Drake riddle
                             has been identified and the Secret Passage is not
                             yet open. Says the answer, then clears it.
        Nav To Groundspawn   Targets the nearest ground item and runs
                             "/nav item click", which walks to it and clicks it
                             up onto your cursor.
        Nav To Secret Passage  Dining Hall only, once the passage has spawned.

    Floor buttons (Library ... Penthouse)
        "Click next to Elias to go to:" - each button navigates to Elias if you
        are more than 100 units away, otherwise targets him and says that floor
        name to travel there. A floor turns GREEN when a ground spawn has been
        reported there and you are not already on it (the recommended floor).

    Spawns
        Lists floors that still have an unclaimed clue ground spawn, plus the
        floor of the weapon-carrying mob once it has been seen.

FLOORS AND THEIR NPCs
    Floor            Suspect                   Location-clue NPC
    ---------------  ------------------------  ---------------------------
    Library          The Librarian             Liriel Mooncrest
    Dining Hall      Angry Chef                Thaddeus Ironspoon
    Maze             Ahhotep                   Antediluvian
    Wedding Hall     Daman The Bride           Alira Duskveil
    Dragon Terrace   Disordered Spirit         Black Drake
    Penthouse        Svartmane The Advisor     Commander Roland Grimblade
    Entry            (none)                    Elias the Ghost Hunter

HOW THE CLUES ARE DETECTED  (all via mq.event chat triggers)
    WHO     The suspect "tell" emotes (e.g. "The Librarian glances around
            anxiously...") and Antediluvian's line "the murderer is <name>".
            Only the first WHO clue is kept.
    WHERE   Antediluvian's line "the crime took place in the <place>", or
            picking up one of the location items: Broken Staff, Burned Diary,
            Crushed Amulet or Torn Robe (sets Where to your current floor).
    WHAT    Antediluvian's line "the weapon used was the <weapon>", picking up
            a weapon item, or looting one. Weapons: Candlestick, Dagger,
            Crossbow, Flaming Mace, Rope, Battle Axe.
    Ground   When any NPC says a floor name in chat, the script runs
    spawns   /itemtarget. If an item is on the ground the floor is recorded as
            having a clue spawn and a popup is shown. Elias and Tranquility are
            ignored, since they mention floor names as part of normal dialogue.
    Drakes   Red/Blue Drake riddle lines identify which drake is truthful
            (shown by popup). Black Drake riddle lines identify the answer
            word: map, echo, fire, needle, breath, silence, darkness or piano.
    Weapon   The mob carrying the weapon is found by checking for any of the
    mob      spawns Cloaked Confidante (Dining Hall), Elusive Henchman (Wedding
            Hall), Dark Associate (Dragon Terrace) or Sinister Conspirator
            (Library).
    Visited  Any NPC saying anything to you marks that NPC visited.
    Location You saying a floor name (e.g. to Elias) updates the current floor.

CURSOR ITEM REFRESH  (added in 1.1; not present in 1.0)
    In 1.0, a picked-up ground spawn was left sitting on the cursor. In 1.1,
    whenever an item is on your cursor the script runs refreshCursorItem() to
    work around a bug where a freshly picked up clue item is not detected
    correctly until it has been put into inventory and taken out again. The
    routine grabs the ground spawn back out of inventory and re-autoinventories
    it:
        1. /autoinventory, wait up to 5s for the cursor to clear
        2. wait 1 second
        3. find the item in inventory by name and pick it back up from its
           slot (or bag slot) onto the cursor with /itemnotify
        4. wait 1 second
        5. /autoinventory a final time
    The Who / Where / What checks and the removal of the claimed ground spawn
    from the Spawns list still happen first, before the refresh runs.
    If the first autoinventory fails (e.g. bags full) the routine gives up and
    leaves the item on your cursor. It blocks the script for roughly 2-3
    seconds while it runs, so the window and chat events pause briefly.

SCRIPT LAYOUT
    1. Data tables       Lookup tables for floors, NPCs, weapons and clue items.
    2. State variables   clues, groundspawns, weaponNPC, currentLocation,
                         recommendedWhere, openedPassage, drake clue state.
    3. Event handlers    mq.event registrations that fill in the state.
    4. draw()            The ImGui window, rebuilt every frame.
    5. refreshCursorItem() Cursor workaround described above (1.1).
    6. Main loop         Runs every 500ms: processes chat events, checks the
                         cursor for clue items, clears claimed ground spawns,
                         runs the cursor item refresh (1.1),
                         detects the weapon mob and the Secret Passage, and
                         works out the next recommended floor.

    Once WHO, WHERE and WHAT are all known, the recommended floor is set to the
    Dragon Terrace (to open the secret passage) and then to the Dining Hall
    (to go through it).

KNOWN QUIRKS
    * The "A clue spawned in %s" popup is passed an extra argument, so the item
      name is never actually displayed.
    * Daman The Bride and Svartmane are stored under shorter / differently
      capitalised names in the Who answer than in the suspect list, so the
      Who display and the suspect list use slightly different spellings.
    * Window layout assumes a 600x400 starting size.

VERSION HISTORY
    1.1   Added the cursor item refresh (refreshCursorItem): grabs the picked-up
          ground spawn back out of inventory and re-autoinventories it
          (autoinventory -> pick up from inventory -> autoinventory) to fix
          clue item detection. Version number shown in the window title.
    1.0   Base script: zone-aware navigation, WHO / WHERE / WHAT clue
          detection from chat events, ground spawn tracking, drake riddle
          helpers, floor travel via Elias, and weapon mob / Secret Passage
          detection.
================================================================================
]==]

local mq = require 'mq'

local VERSION = '1.1'

--[[
Sample chat lines the script reacts to (for reference):
[Sun Sep 29 12:47:58 2024] Elias in the Penthouse says 'Where would you like to visit next?: Library, Dining Hall, Maze, Wedding Hall, Dragon Terrace, and Penthouse. We can go to any of these places if you wish. We are currently in the Penthouse. At any time we can come back here as well.'
[Sun Sep 29 13:06:32 2024] Tranquility says 'Who do you think the killer is? The Librarian, Disordered Spirit, Svartmane The Advisor, Ahhotep, Angry Chef, Daman The Bride'
[Sun Sep 29 13:06:37 2024] Tranquility says 'Where did the murder happen? Library, Dining Hall, Maze, Wedding Hall, Dragon Terrace, Penthouse'
[Sun Sep 29 13:06:40 2024] Tranquility says 'What weapon was used? Candlestick, Dagger, Crossbow, Flaming Mace, Rope, Battle Axe'
]]
local visitedLocationNPCs = {
    ['Commander Roland Grimblade'] = false,
    ['Alira Duskveil'] = false,
    ['Liriel Mooncrest'] = false,
    ['Thaddeus Ironspoon'] = false,
}
local visitedSuspects = {
    ['The Librarian'] = false,
    ['Angry Chef'] = false,
    ['Ahhotep'] = false,
    ['Daman The Bride'] = false,
    ['Disordered Spirit'] = false,
    ['Svartmane The Advisor'] = false,
}
local weapons = {['Candlestick']=true, ['Dagger']=true, ['Crossbow']=true, ['Flaming Mace']=true, ['Rope']=true, ['Battle Axe']=true}
local locations = {[7]='Entry',['Entry']=7,[1]='Library',['Library']=1,[2]='Dining Hall',['Dining Hall']=2,[3]='Maze',['Maze']=3,[4]='Wedding Hall',['Wedding Hall']=4,[5]='Dragon Terrace',['Dragon Terrace']=5,[6]='Penthouse',['Penthouse']=6}
local locationClues = {['Broken Staff']=true,['Burned Diary']=true,['Crushed Amulet']=true,['Torn Robe']=true}
local eliasSpawns = {['Entry']='Elias the Ghost Hunter',['Library']='Elias in the Library',['Dining Hall']='Elias in the Dining Hall',['Maze']='Elias in the Maze',['Wedding Hall']='Elias in the Wedding Hall',['Dragon Terrace']='Elias in the Dragon Terrace',['Penthouse']='Elias in the Penthouse',}
local suspectsByLoc = {['Library']='The Librarian',['Dining Hall']='Angry Chef',['Maze']='Ahhotep',['Wedding Hall']='Daman The Bride',['Dragon Terrace']='Disordered Spirit',['Penthouse']='Svartmane The Advisor'}
local locNPCsByLoc = {['Library']='Liriel Mooncrest',['Dining Hall']='Thaddeus Ironspoon',['Maze']='Antediluvian',['Wedding Hall']='Alira Duskveil',['Dragon Terrace']='Black Drake',['Penthouse']='Commander Roland Grimblade'}
local clues = {What = 'Unknown',Where = 'Unknown',Who = 'Unknown'}
local groundspawns = {}
local weaponNPC = nil
local isOpen, shouldDraw = true, true
local currentLocation = 'Entry'
local recommendedWhere = nil
local openedPassage = false
local blackDrakeClue = nil
local redBlueDrakeClue = nil
local hailedElias = false

local function reportClue(where, who)
    if who:find('Elias') or who:find('Tranquility') then return end
    mq.cmd('/itemtarget')
    if mq.TLO.ItemTarget() then
        mq.cmdf('/popcustom 5 A clue spawned in %s', where, mq.TLO.ItemTarget.Name())
        table.insert(groundspawns, where)
        if currentLocation ~= where then recommendedWhere = where end
    end
end

mq.event('libraryclue', '#1# says \'#*#Library#*#', function(line, who) reportClue('Library', who) end)
mq.event('dininghallclue', '#1# says \'#*#Dining Hall#*#', function(line, who) reportClue('Dining Hall', who) end)
mq.event('mazeclue', '#1# says \'#*#Maze#*#', function(line, who) reportClue('Maze', who) end)
mq.event('weddinghallclue', '#1# says \'#*#Wedding Hall#*#', function(line, who) reportClue('Wedding Hall', who) end)
mq.event('dragonterraceclue', '#1# says \'#*#Dragon Terrace#*#', function(line, who) reportClue('Dragon Terrace', who) end)
mq.event('penthouseclue', '#1# says \'#*#Penthouse#*#', function(line, who) reportClue('Penthouse', who) end)

local function reportWhoClue(who)
    if clues.Who == 'Unknown' then
        mq.cmdf('/popcustom 5 The killer is %s', who)
        clues.Who = who
    end
end

mq.event('librarianclue', '#*#The Librarian glances around anxiously, hands fidgeting.#*#', function(line) reportWhoClue('The Librarian') end)
mq.event('angrychefclue', '#*#Angry Chef slams a fist on the table, eyes narrowing with irritation rather than remorse.#*#', function(line) reportWhoClue('Angry Chef') end)
mq.event('ahhotepclue', '#*#Ahhotep smirks slightly, his eyes gleaming with a hint of something... unsettling.#*#', function(line) reportWhoClue('Ahhotep') end)
mq.event('damanclue', '#*#Daman The Bride glares with a manic intensity, her eyes blazing with fury.#*#', function(line) reportWhoClue('Daman the Bride') end)
mq.event('disorderedclue', '#*#Disordered Spirit says \'No... it wasn#*#t me... was it? I don’t... remember. Shadows... they hide so much...\'#*#', function(line) reportWhoClue('Disordered Spirit') end)
mq.event('svartmaneclue', '#*#Svartmane The Advisor smiles slightly, his eyes calculating and calm.#*#', function(line) reportWhoClue('Svartmane') end)

mq.event('bluedrake1', '#*#If you ask the Red Drake, he would say I lie#*#', function() mq.cmdf('/popcustom 5 Blue Drake') redBlueDrakeClue = 'Blue Drake' end)
mq.event('reddrake1', '#*#If you ask the Blue Drake, he would say I lie#*#', function() mq.cmdf('/popcustom 5 Red Drake') redBlueDrakeClue = 'Red Drake' end)
mq.event('bluedrake2', '#*#If you ask the Red Drake, he would say I tell the truth#*#', function() mq.cmdf('/popcustom 5 Red Drake') redBlueDrakeClue = 'Red Drake' end)
mq.event('reddrake2', '#*#If you ask the Blue Drake, he would say I tell the truth#*#', function() mq.cmdf('/popcustom 5 Blue Drake') redBlueDrakeClue = 'Blue Drake' end)

mq.event('blackdrake1', '#*#cities, but no houses#*#', function() mq.cmdf('/popcustom 5 Map') blackDrakeClue = 'map' end)
mq.event('blackdrake2', '#*#speak without a mouth#*#', function() mq.cmdf('/popcustom 5 Echo') blackDrakeClue = 'echo' end)
mq.event('blackdrake3', '#*#not alive, yet I can grow#*#', function() mq.cmdf('/popcustom 5 Fire') blackDrakeClue = 'fire' end)
mq.event('blackdrake4', '#*#What has one eye#*#', function() mq.cmdf('/popcustom 5 Needle') blackDrakeClue = 'needle' end)
mq.event('blackdrake5', '#*#light as a feather#*#', function() mq.cmdf('/popcustom 5 Breath') blackDrakeClue = 'breath' end)
mq.event('blackdrake6', '#*#disappear as soon as you say my name#*#', function() mq.cmdf('/popcustom 5 Silence') blackDrakeClue = 'silence' end)
mq.event('blackdrake7', '#*#the less you see#*#', function() mq.cmdf('/popcustom 5 Darkness') blackDrakeClue = 'darkness' end)
mq.event('blackdrake8', '#*#What has keys#*#', function() mq.cmdf('/popcustom 5 Piano') blackDrakeClue = 'piano' end)

mq.event('antediluvianWho', '#*#The flames whisper... the murderer is #1#.', function(line, who) reportWhoClue(who) end)
mq.event('antediluvianWhere', '#*#The flames show... the crime took place in the #1#.', function(line, where) clues.Where = where mq.cmdf('/popcustom 5 The crime took place in the %s', where) end)
mq.event('antediluvianWhat', '#*#The flames reveal... the weapon used was the #1#.', function(line, what) clues.What = what mq.cmdf('/popcustom 5 The weapon used was the %s', what) end)

local function updateLocation(line, where)
    if locations[where] then
        currentLocation = where
    end
end
mq.event('location', 'You say, \'#1#\'', updateLocation)

local function looted(line, item)
    if weapons[item] then
        clues.What = item
    end
end
mq.event('looted', '#*#You have looted a #1#.--#*#', looted)

local function reportVisited(line, who)
    if visitedLocationNPCs[who] ~= nil then visitedLocationNPCs[who] = true end
    if visitedSuspects[who] ~= nil then visitedSuspects[who] = true end
end
mq.event('visitedNPC', '#1# says \'#*#', reportVisited)

local function draw()
    if not isOpen then return end
    ImGui.SetNextWindowSize(600, 400)
    isOpen, shouldDraw = ImGui.Begin(('Clue v%s###Clue'):format(VERSION), isOpen)
    if shouldDraw then
        local zone = mq.TLO.Zone.ShortName()
        if zone == 'mischiefplane' then
            if (mq.TLO.Spawn('Clue').Distance3D() or 100) < 30 then
                if ImGui.Button('Get Task') then
                    mq.cmdf('/multiline ; /nav spawn clue ; /timed 10 /mqt clue ; /timed 13 /say clue ; /timed 20 /say ready')
                end
            else
                if ImGui.Button('Nav to Clue') then
                    mq.cmd('/nav spawn clue')
                end
            end
        elseif zone == 'frozenshadow' and not hailedElias then
            if ImGui.Button('Hail Elias before proceeding') then
                hailedElias = true
                mq.cmd('/multiline ; /mqt elias ; /timed 2 /keypress HAIL ; /timed 3 /keypress HAIL ; /timed 4 /say where')
            end
        elseif zone == 'poknowledge' or zone == 'nexus' then
            if (mq.TLO.Spawn('Valium').Distance3D() or 100) > 75 then
                if ImGui.Button('Nav to Valium') then
                    mq.cmdf('/nav spawn Valium')
                end
            else
                if ImGui.Button('Say mischiefplane') then
                    mq.cmdf('/multiline ; /mqt Valium ; /timed 2 /say mischiefplane')
                end
            end
        elseif zone == 'freeporttemple' then
            if (mq.TLO.Spawn('Klonopin').Distance3D() or 100) > 75 then
                if ImGui.Button('Nav to Klonopin') then
                    mq.cmdf('/nav spawn Klonopin')
                end
            else
                if ImGui.Button('Say mischiefplane') then
                    mq.cmdf('/multiline ; /mqt Klonopin ; /timed 2 /say mischiefplane')
                end
            end
        elseif zone == 'frozenshadow' then
            ImGui.Text('Who: ') ImGui.SameLine()
            if clues.Who == 'Unknown' then ImGui.TextColored(1,0,0,1,'%s',clues.Who) else ImGui.TextColored(0,1,0,1,'%s',clues.Who) end ImGui.SameLine()
            ImGui.Text('Where: ') ImGui.SameLine()
            if clues.Where == 'Unknown' then ImGui.TextColored(1,0,0,1,'%s',clues.Where) else ImGui.TextColored(0,1,0,1,'%s',clues.Where) end ImGui.SameLine()
            ImGui.Text('What: ') ImGui.SameLine()
            if clues.What == 'Unknown' then ImGui.TextColored(1,0,0,1,'%s',clues.What) else ImGui.TextColored(0,1,0,1,'%s',clues.What) end
            ImGui.Separator()
            ImGui.Columns(2)
            ImGui.Text('Suspects:')
            ImGui.NextColumn()
            ImGui.Text('Location Clue NPCs:')
            ImGui.NextColumn()
            ImGui.Separator()
            for name,visited in pairs(visitedSuspects) do
                if not visited then ImGui.TextColored(1,0,0,1,'%s',name) else ImGui.TextColored(0,1,0,1,'%s',name) end
            end
            ImGui.NextColumn()
            for name,visited in pairs(visitedLocationNPCs) do
                if not visited then ImGui.TextColored(1,0,0,1,'%s',name) else ImGui.TextColored(0,1,0,1,'%s',name) end
            end
            ImGui.Columns(1)
            if currentLocation ~= 'Entry' then
                ImGui.Separator()
                ImGui.PushItemWidth(100)
                ---@diagnostic disable-next-line: param-type-mismatch, cast-local-type
                currentLocation = locations[ImGui.Combo('Current Floor', locations[currentLocation], 'Library\0Dining Hall\0Maze\0Wedding Hall\0Dragon Terrace\0Penthouse\0Entry\0')]
                ImGui.PopItemWidth()
                if ImGui.Button('Nav To Elias') then
                    mq.cmdf('/nav spawn %s', eliasSpawns[currentLocation])
                end
                ImGui.SameLine()
                if (mq.TLO.Spawn(suspectsByLoc[currentLocation]).Distance3D() or 100) < 125 then
                    if ImGui.Button(('Talk to %s'):format(suspectsByLoc[currentLocation])) then
                        mq.cmdf('/multiline ; /mqt %s ; /timed 2 /keypress HAIL ; /timed 3 /say what ; /timed 5 /say where ; /timed 7 /say who', suspectsByLoc[currentLocation])
                    end
                else
                    if ImGui.Button(('Nav To %s'):format(suspectsByLoc[currentLocation])) then
                        mq.cmdf('/nav spawn %s', suspectsByLoc[currentLocation])
                    end
                end
                ImGui.SameLine()
                if currentLocation == 'Penthouse' and mq.TLO.Spawn('Red Drake')() then
                    if (mq.TLO.Spawn('Red Drake').Distance3D() or 100) < 125 then
                        if not redBlueDrakeClue then
                            if ImGui.Button('Say Truth') then
                                mq.cmd('/multiline ; /mqt red drake ; /timed 2 /say truth')
                            end
                        else
                            if ImGui.Button('Say '..redBlueDrakeClue) then
                                mq.cmdf('/multiline ; /mqt drake ; /say %s', redBlueDrakeClue)
                            end
                        end
                    else
                        if ImGui.Button('Nav To Red Drake') then
                            mq.cmd('/nav spawn red drake | dist=15')
                        end
                    end
                else
                    if (mq.TLO.Spawn(locNPCsByLoc[currentLocation]).Distance3D() or 100) < 125 then
                        if currentLocation == 'Dragon Terrace' and blackDrakeClue and not mq.TLO.Spawn('Secret Passage')() then
                            if ImGui.Button('Say '..blackDrakeClue) then
                                mq.cmdf('/multiline ; /mqt black drake ; /timed 2 /say %s', blackDrakeClue)
                                blackDrakeClue = nil
                            end
                        elseif currentLocation ~= 'Maze' then
                            if ImGui.Button(('Talk to %s'):format(locNPCsByLoc[currentLocation])) then
                                mq.cmdf('/multiline ; /mqt %s ; /timed 2 /keypress HAIL', locNPCsByLoc[currentLocation])
                            end
                        end
                    else
                        if ImGui.Button(('Nav To %s'):format(locNPCsByLoc[currentLocation])) then
                            mq.cmdf('/nav spawn %s', locNPCsByLoc[currentLocation])
                        end
                    end
                end
                if ImGui.Button('Nav To Groundspawn') then
                    mq.cmd('/itemtar')
                    if mq.TLO.ItemTarget() then
                        mq.cmd('/squelch /nav item click')
                    end
                end
                if currentLocation == 'Dining Hall' and mq.TLO.Spawn('Secret Passage')() then
                    ImGui.SameLine()
                    if ImGui.Button('Nav To Secret Passage') then
                        mq.cmd('/nav spawn secret passage')
                    end
                end
            end
            ImGui.Separator()
            ImGui.Text('Click next to Elias to go to:')
            for i,location in ipairs(locations) do
                if location == 'Entry' then break end
                local shouldPopColor = false
                if recommendedWhere == location then ImGui.PushStyleColor(ImGuiCol.Button, 0,1,0,1) shouldPopColor = true end
                if ImGui.Button(location) then
                    if (mq.TLO.Spawn(eliasSpawns[currentLocation]).Distance3D() or 200) > 100 then
                        mq.cmdf('/nav spawn %s', eliasSpawns[currentLocation])
                    else
                        mq.cmd('/tar npc elias')
                        mq.cmdf('/timed 5 /say %s', location)
                        if recommendedWhere == location then recommendedWhere = nil end
                    end
                end
                if shouldPopColor then ImGui.PopStyleColor() shouldPopColor = false end
                if i ~= 6 then ImGui.SameLine() end
            end
            ImGui.Separator()
            ImGui.Text('Spawns:')
            for _,groundspawn in ipairs(groundspawns) do
                ImGui.Text('Ground Spawn in: %s', groundspawn)
            end
            if weaponNPC then
                ImGui.Text('Weapon Mob Spawned: %s', weaponNPC)
            end
        end
    end
    ImGui.End()
end

-- Workaround: freshly grabbed clue items aren't flagged properly until they've
-- been pulled back out of inventory. Autoinventory -> wait -> pick back up -> wait -> autoinventory.
local function refreshCursorItem()
    local name = mq.TLO.Cursor.Name()
    if not name then return end

    mq.cmd('/autoinventory')
    mq.delay(5000, function() return not mq.TLO.Cursor() end)
    if mq.TLO.Cursor() then return end -- couldn't stash it (bags full?), bail
    mq.delay(1000)

    local item = mq.TLO.FindItem('=' .. name)
    if not item() then return end
    local slot, slot2 = item.ItemSlot(), item.ItemSlot2()
    if slot2 and slot2 >= 0 then
        mq.cmdf('/itemnotify in pack%d %d leftmouseup', slot - 22, slot2 + 1)
    else
        mq.cmdf('/itemnotify %d leftmouseup', slot)
    end
    mq.delay(2000, function() return mq.TLO.Cursor() ~= nil end)
    mq.delay(1000)

    mq.cmd('/autoinventory')
    mq.delay(5000, function() return not mq.TLO.Cursor() end)
end

mq.imgui.init('Clue', draw)

while isOpen do
    mq.doevents()
    if clues.Where == 'Unknown' and mq.TLO.Cursor() then
        for item,_ in pairs(locationClues) do
            if mq.TLO.Cursor.Name() and mq.TLO.Cursor.Name():find(item) then
                mq.cmdf('/popcustom 5 Found strong location evidence Tserrina\'s %s', item)
                clues.Where = currentLocation
            end
        end
    end
    if clues.What == 'Unknown' and mq.TLO.Cursor() and weapons[mq.TLO.Cursor()] then
        mq.cmdf('/popcustom 5 Found weapon %s', mq.TLO.Cursor())
        clues.What = mq.TLO.Cursor()
    end
    if mq.TLO.Cursor() then
        for i,loc in ipairs(groundspawns) do if loc == currentLocation then table.remove(groundspawns,i) break end end
        refreshCursorItem()
    end
    if not weaponNPC then
        if mq.TLO.Spawn('Cloaked Confidante')() then
            weaponNPC = 'Cloaked Confidante in the Dining Hall'
        elseif mq.TLO.Spawn('Elusive Henchman')() then
            weaponNPC = 'Elusive Henchman in the Wedding Hall'
        elseif mq.TLO.Spawn('Dark Associate')() then
            weaponNPC = 'Dark Associate in the Dragon Terrace'
        elseif mq.TLO.Spawn('Sinister Conspirator')() then
            weaponNPC = 'Sinister Conspirator in the Library'
        end
    end
    if not openedPassage and mq.TLO.Spawn('Secret Passage')() then
        openedPassage = true
    end
    if clues.Who ~= 'Unknown' and clues.Where ~= 'Unknown' and clues.What ~= 'Unknown' then
        if not openedPassage and currentLocation ~= 'Dragon Terrace' then
            recommendedWhere = 'Dragon Terrace'
        elseif openedPassage and currentLocation ~= 'Dining Hall' then
            recommendedWhere = 'Dining Hall'
        elseif not openedPassage and currentLocation == 'Dragon Terrace' then
            recommendedWhere = nil
        elseif openedPassage and currentLocation == 'Dining Hall' then
            recommendedWhere = nil
        end
    end
    mq.delay(500)
end