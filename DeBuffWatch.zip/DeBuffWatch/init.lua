--[[
    DebuffWatch.lua
    ============================================================
    A MacroQuest ImGui script that watches your active buff slots
    (both regular buffs and short-duration/song slots) and displays
    beneficial and/or detrimental effects in a sortable table.

    ------------------------------------------------------------
    INSTALLATION
    ------------------------------------------------------------
    1. Place this file in your MacroQuest lua folder, either directly
       as DebuffWatch.lua, or in a subfolder as DebuffWatch/init.lua.
    2. (Optional) Place a 40x40 PNG named DeBuffWatch_Image.png in the
       SAME folder as this script. It's used as the minimized-state
       icon. If it's missing, a small fallback "DW" button is used
       instead -- the script still works fine without it.
    3. Start with:  /lua run DebuffWatch
       Stop  with:  /lua stop DebuffWatch

    ------------------------------------------------------------
    WHAT IT DOES
    ------------------------------------------------------------
    Every ~0.2 seconds, the script scans:
      - Regular buff slots  (Me.Buff(1..42))
      - Short duration / song slots  (Me.Song(1..15))

    For each active effect it records name, source (Buff/Song), slot
    number, caster, remaining duration, and hit counters (for
    count-based effects like curses/DoTs that don't tick a timer).

    Two independent checkboxes/radio-style toggles in the window let
    you choose what's DISPLAYED in the table:
      - "Detrimental" -- shows harmful effects (ON by default)
      - "Beneficial"  -- shows helpful effects (OFF by default)
    Both, either, or neither can be active at the same time; toggling
    one never affects the other.

    Regardless of what's currently displayed, every NEWLY-ARRIVED
    detrimental effect is always logged to a per-character log file
    (see LOGGING below) the moment it's first detected -- logging is
    independent of the display filter.

    ------------------------------------------------------------
    THE WINDOW
    ------------------------------------------------------------
    The main window shows, top to bottom:
      - A "Minimize to icon" button
      - The full path of the log file currently being written to
      - The Detrimental / Beneficial display toggles
      - A running count of what's currently shown
      - A sortable, resizable table of the matching effects, with
        columns: Type, Resist, Source, Slot, Name, Caster, Duration,
        Counters. "Resist" is the underlying spell's resist type
        (Poison, Disease, Magic, Fire, Cold, Corruption, Chromatic,
        Prismatic, Physical, etc) -- mainly meaningful for detrimental
        effects; shows '-' if unavailable. Rows for effects with <= 6
        seconds remaining are highlighted amber as an early-warning cue.

    Closing the window via its [x] button stops the script entirely.

    ------------------------------------------------------------
    MINIMIZE TO ICON
    ------------------------------------------------------------
    Clicking "Minimize to icon" (or running /debuffwatch_min) hides
    the main window and shows a small, borderless, draggable icon
    instead (DeBuffWatch_Image.png if present, otherwise a "DW"
    fallback button). Drag the icon to reposition it; click it
    (a press+release with no drag) to restore the main window.

    The window's native title-bar collapse chevron is ALSO wired up to
    minimize: clicking it swaps straight to the icon view, exactly like
    the "Minimize to icon" button or running /debuffwatch_min.

    ------------------------------------------------------------
    COMMANDS
    ------------------------------------------------------------
    /debuffwatch       Failsafe: unconditionally restores/shows the
                       main window, no matter what state it's in
                       (minimized, collapsed, etc). This is NOT a
                       toggle -- it only ever shows the window.

    /debuffwatch_min   Unconditionally minimizes to the icon view.

    ------------------------------------------------------------
    LOGGING
    ------------------------------------------------------------
    Every newly-detected detrimental effect is appended, timestamped,
    to a per-character log file at:

        <MQ config dir>/DebuffWatch_<YourCharacterName>.log

    The full path is also shown live in the window itself. Log entries
    are only written once per arrival (not on every scan tick) by
    tracking which detrimental effects are currently active.

    ------------------------------------------------------------
    STARTUP BEHAVIOR / FAILSAFES
    ------------------------------------------------------------
    - The script ALWAYS starts (or restarts after /lua run again)
      with the full window showing, never minimized, regardless of
      any prior session state.
    - Any error while rendering the window is caught, printed to the
      console as a RENDER ERROR, and the script automatically falls
      back to showing the main window rather than getting stuck on a
      broken render path.
    - Any error while scanning buffs/songs is caught, printed to the
      console as a SCAN ERROR, and the script keeps running rather
      than crashing outright.
]]

local mq = require('mq')
local ImGui = require('ImGui')

----------------------------------------------------------------------
-- Config
----------------------------------------------------------------------

local RENDER_HZ_THROTTLE = 0.2  -- seconds between full data refreshes (rendering itself is every frame)
local MAX_BUFF_SLOTS = 42       -- generous upper bound, GetMaxBuffSlots() covers most cases anyway
local MAX_SONG_SLOTS = 15       -- short duration / song slots

----------------------------------------------------------------------
-- State
----------------------------------------------------------------------

local openGUI = true
local shouldDrawGUI = true
local terminate = false

local showDetrimental = true   -- initializes enabled per spec
local showBeneficial = false

local effects = {}       -- refreshed table of currently displayed effects (per filter selection)
local lastScan = 0

local activeDebuffKeys = {}   -- tracks currently-active detrimental effects to detect new arrivals
local LOG_FILE = string.format('%s/DebuffWatch_%s.log', mq.configDir, mq.TLO.Me.Name() or 'Unknown')

local APP_NAME = 'Debuff Watch'

-- Minimise-to-icon state (same pattern as menu_bar.lua).
local minimized   = false  -- true -> show the icon instead of the window
local forceExpand = false  -- one-shot: un-collapse the window when restoring,
                           -- clearing the collapsed flag ImGui set on the
                           -- chevron click (else it would re-minimise).

----------------------------------------------------------------------
-- Minimise-to-icon constants
----------------------------------------------------------------------

-- Image shown while minimised.  Looked for as DeBuffWatch_Image.png in THIS
-- script's own directory, resolved from debug.getinfo so it works no matter
-- where the script is placed (lua root or a subfolder).  Mirrors
-- menu_bar.lua's proven-working SCRIPT_DIR resolution exactly.
local SCRIPT_DIR = (debug.getinfo(1, 'S').short_src or ''):match('^(.*[/\\])')
                   or ((mq.luaDir or '.') .. '/')
local ICON_PATH  = SCRIPT_DIR .. 'DeBuffWatch_Image.png'
local ICON_W     = 40   -- drawn image width  (pixels)
local ICON_H     = 40   -- drawn image height (pixels)
local ICON_PAD   = 0    -- window padding around the minimised image

-- Load the icon texture once.  Confirm the file exists first, since
-- mq.CreateTexture can return a non-nil but blank texture for a missing
-- path.  If the file is absent (or the build lacks mq.CreateTexture),
-- iconImg stays nil and the minimised view falls back to a small button.
local iconImg    = nil
local iconLoaded = false
do
    local f = io.open(ICON_PATH, 'rb')
    if f then
        f:close()
        local ok, tex = pcall(mq.CreateTexture, ICON_PATH)
        if ok and tex then
            iconImg    = tex
            iconLoaded = true
        end
    end
end

----------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------

--- Scan a slot range using the given TLO accessor function.
--- Collects EVERY active effect (beneficial and detrimental alike); filtering
--- for display happens separately based on the radio button selections.
local function scanSlots(getSlot, maxSlots, sourceLabel, results)
    for i = 1, maxSlots do
        local buff = getSlot(i)
        if buff() and buff.ID() and buff.ID() > 0 then
            local isBeneficial = buff.Beneficial() and true or false
            local name = buff.Name() or "Unknown"
            local caster = buff.Caster() or "Unknown"

            -- NOTE: buff.Duration() returns a plain number (ticks), not an
            -- object -- so chain off buff.Duration (no parens) to reach the
            -- Ticks TLO's members like TimeHMS()/TotalSeconds().
            local duration = "N/A"
            local remainingSec = -1
            pcall(function()
                duration = buff.Duration.TimeHMS() or "N/A"
            end)
            pcall(function()
                remainingSec = buff.Duration.TotalSeconds() or -1
            end)

            local counters = 0
            -- some effects track counters/hits instead of duration
            pcall(function()
                counters = buff.Counters() or 0
            end)

            -- Resist type (Poison/Disease/Magic/Fire/Cold/Corruption/
            -- Chromatic/Prismatic/Physical/etc), pulled from the
            -- underlying spell. Mainly meaningful for detrimental
            -- effects; shown as '-' if unavailable.
            local resistType = "-"
            pcall(function()
                resistType = buff.Spell.ResistType() or "-"
            end)

            table.insert(results, {
                source = sourceLabel,
                slot = i,
                name = name,
                caster = caster,
                duration = duration,
                remainingSec = remainingSec,
                counters = counters,
                resistType = resistType,
                id = buff.ID(),
                beneficial = isBeneficial,
            })
        end
    end
end

--- Append a line to the log file, creating it if needed.
local function logToFile(line)
    local f = io.open(LOG_FILE, 'a')
    if f then
        f:write(string.format('[%s] %s\n', os.date('%Y-%m-%d %H:%M:%S'), line))
        f:close()
    end
end

--- Refresh the effects table from current game state, filtered by the
--- currently selected radio button(s). Also logs any NEW detrimental
--- effect (one not already tracked as active) to LOG_FILE, regardless
--- of whether the Detrimental filter is currently displayed.
local function refreshDebuffs()
    local allEffects = {}

    -- Regular buff slots
    scanSlots(function(i) return mq.TLO.Me.Buff(i) end, MAX_BUFF_SLOTS, "Buff", allEffects)

    -- Short duration / song slots
    scanSlots(function(i) return mq.TLO.Me.Song(i) end, MAX_SONG_SLOTS, "Song", allEffects)

    -- Detect and log newly-arrived detrimental effects
    local currentKeys = {}
    for _, e in ipairs(allEffects) do
        if not e.beneficial then
            local key = string.format('%s:%d:%d', e.source, e.slot, e.id)
            currentKeys[key] = true
            if not activeDebuffKeys[key] then
                logToFile(string.format(
                    'DETRIMENTAL landed -- Name=%s Resist=%s Source=%s Slot=%d Caster=%s Duration=%s',
                    e.name, e.resistType, e.source, e.slot, e.caster, e.duration
                ))
            end
        end
    end
    activeDebuffKeys = currentKeys

    local filtered = {}
    for _, e in ipairs(allEffects) do
        if (e.beneficial and showBeneficial) or (not e.beneficial and showDetrimental) then
            table.insert(filtered, e)
        end
    end

    effects = filtered
end

----------------------------------------------------------------------
-- ImGui rendering
----------------------------------------------------------------------

-- Minimised view: a small borderless, auto-sized window whose only
-- content is the icon drawn as a plain image (same approach as
-- menu_bar.lua's minimise-to-icon). Uses its own window id so it is
-- independent of the main window.
local MIN_FLAGS = bit32.bor(ImGuiWindowFlags.AlwaysAutoResize,
                            ImGuiWindowFlags.NoResize,
                            ImGuiWindowFlags.NoScrollbar,
                            ImGuiWindowFlags.NoTitleBar,
                            (ImGuiWindowFlags.NoBackground or 0))

local iconPressed = false  -- mouse button is down having pressed on the icon
local iconDragged = false  -- that press has moved -> treat as a window drag,
                           -- not a click, so it moves instead of restoring.

local function renderIcon()
    -- Spawn near the top-left on first appearance only; after that the
    -- user's own drag position is left alone (drag-to-move works normally).
    ImGui.SetNextWindowPos(100, 100, ImGuiCond.FirstUseEver)

    ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, ICON_PAD, ICON_PAD)

    local visible
    openGUI, visible = ImGui.Begin(APP_NAME .. ' Icon###DebuffWatchMini', openGUI, MIN_FLAGS)
    if visible then
        local restore = false

        if iconImg then
            -- Draw the icon as a plain image (not a button). A plain image is
            -- non-interactive, so ImGui lets the borderless window be dragged
            -- by it -- giving "drag the image to move" for free. Restoring is
            -- handled below by detecting a click (press + release, no drag).
            local ok = pcall(function()
                ImGui.Image(iconImg:GetTextureID(), ImVec2(ICON_W, ICON_H))
            end)

            if ok then
                local hovered = ImGui.IsItemHovered()
                if hovered and not iconPressed then
                    ImGui.SetTooltip(APP_NAME .. ' — drag to move, click to restore')
                end

                -- Press started on the icon -> begin tracking a potential click.
                if hovered and ImGui.IsMouseClicked(0) then
                    iconPressed = true
                    iconDragged = false
                end
                -- Any movement while held turns it into a drag (window move),
                -- which must NOT restore.
                if iconPressed and ImGui.IsMouseDragging(0) then
                    iconDragged = true
                end
                -- Release: a press that never became a drag is a click -> restore.
                if ImGui.IsMouseReleased(0) then
                    if iconPressed and not iconDragged then
                        restore = true
                    end
                    iconPressed = false
                    iconDragged = false
                end
            else
                iconImg = nil
            end
        end

        if not iconImg then
            if ImGui.Button('DW##restore') then restore = true end
        end

        if restore then
            minimized   = false
            forceExpand = true   -- un-collapse the main window next frame
        end
    end

    ImGui.End()
    ImGui.PopStyleVar()
end

local function renderMainWindow()
    if forceExpand then
        ImGui.SetNextWindowCollapsed(false, ImGuiCond.Always)
        forceExpand = false
    end

    ImGui.SetNextWindowSize(520, 300, ImGuiCond.FirstUseEver)
    local show
    -- NOTE: MQ's Lua ImGui.Begin returns (open, shouldDraw) -- the open/
    -- closed p_open flag comes FIRST, not second like the generic ImGui
    -- Lua bindings. Getting this order backwards means the [x] button's
    -- close never gets picked up, so the script won't terminate.
    openGUI, show = ImGui.Begin('Debuff Watch', openGUI)

    -- Title-bar collapse chevron: clicking it collapses the window, which
    -- we treat exactly like /debuffwatch_min -- swap straight to the icon
    -- view instead of leaving a collapsed title bar sitting around.
    if ImGui.IsWindowCollapsed() then
        ImGui.End()
        minimized   = true
        forceExpand = true  -- so it's un-collapsed next time it's restored
        return
    end

    if show then
        if ImGui.Button('Minimize to icon##minBtn') then
            minimized = true
        end
        ImGui.Separator()

        ImGui.Text(string.format('Logging detrimental effects to: %s', LOG_FILE))
        ImGui.Separator()

        -- Independent (non-exclusive) radio-style toggles. Clicking one does
        -- NOT clear the other -- both, either, or neither may be active.
        if ImGui.RadioButton('Detrimental', showDetrimental) then
            showDetrimental = not showDetrimental
        end
        ImGui.SameLine()
        if ImGui.RadioButton('Beneficial', showBeneficial) then
            showBeneficial = not showBeneficial
        end

        ImGui.Separator()

        local label
        if showDetrimental and showBeneficial then
            label = 'All effects active'
        elseif showDetrimental then
            label = 'Detrimental effects active'
        elseif showBeneficial then
            label = 'Beneficial effects active'
        else
            label = 'No filters selected'
        end
        ImGui.Text(string.format('%s: %d', label, #effects))
        ImGui.Separator()

        local flags = ImGuiTableFlags.Borders + ImGuiTableFlags.RowBg
            + ImGuiTableFlags.Resizable + ImGuiTableFlags.Sortable

        if ImGui.BeginTable('DebuffTable', 8, flags) then
            ImGui.TableSetupColumn('Type', ImGuiTableColumnFlags.WidthFixed, 75)
            ImGui.TableSetupColumn('Resist', ImGuiTableColumnFlags.WidthFixed, 80)
            ImGui.TableSetupColumn('Source', ImGuiTableColumnFlags.WidthFixed, 60)
            ImGui.TableSetupColumn('Slot', ImGuiTableColumnFlags.WidthFixed, 40)
            ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthStretch)
            ImGui.TableSetupColumn('Caster', ImGuiTableColumnFlags.WidthFixed, 100)
            ImGui.TableSetupColumn('Duration', ImGuiTableColumnFlags.WidthFixed, 90)
            ImGui.TableSetupColumn('Counters', ImGuiTableColumnFlags.WidthFixed, 70)
            ImGui.TableHeadersRow()

            for _, d in ipairs(effects) do
                ImGui.TableNextRow()

                ImGui.TableNextColumn()
                if d.beneficial then
                    ImGui.TextColored(0.4, 1.0, 0.4, 1.0, 'Beneficial')
                else
                    ImGui.TextColored(1.0, 0.4, 0.4, 1.0, 'Detrimental')
                end

                ImGui.TableNextColumn()
                ImGui.Text(d.resistType)

                ImGui.TableNextColumn()
                ImGui.Text(d.source)

                ImGui.TableNextColumn()
                ImGui.Text(tostring(d.slot))

                ImGui.TableNextColumn()
                -- extra flag for very-low-remaining effects, regardless of type
                if d.remainingSec >= 0 and d.remainingSec <= 6 then
                    ImGui.TextColored(1.0, 0.8, 0.2, 1.0, d.name)
                else
                    ImGui.Text(d.name)
                end

                ImGui.TableNextColumn()
                ImGui.Text(d.caster)

                ImGui.TableNextColumn()
                ImGui.Text(d.duration)

                ImGui.TableNextColumn()
                ImGui.Text(d.counters > 0 and tostring(d.counters) or '-')
            end

            ImGui.EndTable()
        end
    end

    ImGui.End()

    if not openGUI then
        -- window was closed via the [x] button; stop the script
        terminate = true
    end
end

local function renderGUI()
    if not openGUI then return end

    local ok, err = pcall(function()
        if minimized then
            renderIcon()
        else
            renderMainWindow()
        end
    end)

    if not ok then
        print(string.format('\ar[Debuff Watch] RENDER ERROR:\ax %s', tostring(err)))
        -- Fail safe: drop back to the main window rather than staying stuck
        -- on a render path that's erroring out every frame.
        minimized = false
    end
end

----------------------------------------------------------------------
-- Bind to toggle window
----------------------------------------------------------------------

-- FAILSAFE: always shows/restores the main window, regardless of current
-- state. This is intentionally NOT a toggle -- if the icon is invisible,
-- stuck, or the window is collapsed/minimised for any reason, this command
-- unconditionally brings the full window back.
mq.bind('/debuffwatch', function()
    minimized   = false
    forceExpand = true
    openGUI     = true
end)

-- Explicit minimise command, for testing/using the icon view without
-- having to find and click the title-bar chevron.
mq.bind('/debuffwatch_min', function()
    minimized = true
end)

----------------------------------------------------------------------
-- Register with MQ's ImGui pipeline
----------------------------------------------------------------------

mq.imgui.init('DebuffWatch', renderGUI)

-- FAILSAFE: always start (or /lua run again after a stop) with the full
-- window showing, never minimised to the icon, regardless of any prior
-- session state.
minimized   = false
forceExpand = false
openGUI     = true

print(string.format('\ay[Debuff Watch]\ax Restore the window anytime with: \ag/debuffwatch\ax'))
print(string.format('\ay[Debuff Watch]\ax Minimise to icon (testing) with: \ag/debuffwatch_min\ax'))
if iconLoaded then
    print(string.format('\ay[Debuff Watch]\ax Minimise icon loaded: \ag%s\ax', ICON_PATH))
else
    print(string.format('\ay[Debuff Watch]\ax \arNo minimise icon found\ax at %s -- using fallback button while minimised.', ICON_PATH))
end

----------------------------------------------------------------------
-- Main loop
----------------------------------------------------------------------

while not terminate do
    if os.clock() - lastScan >= RENDER_HZ_THROTTLE then
        local ok, err = pcall(refreshDebuffs)
        if not ok then
            print(string.format('\ar[Debuff Watch] SCAN ERROR:\ax %s', tostring(err)))
        end
        lastScan = os.clock()
    end
    mq.delay(50) -- ms
end
