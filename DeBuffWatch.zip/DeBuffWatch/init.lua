--[[
    DebuffWatch.lua
    ============================================================
    A MacroQuest ImGui script that watches your active buff slots
    (both regular buffs and short-duration/song slots) and displays
    beneficial and/or detrimental effects in a sortable table. When
    minimised to its icon, the icon itself flips between a normal and an
    "alert" image (with a pulsing red border) depending on whether you
    currently have a detrimental effect active.

    ------------------------------------------------------------
    INSTALLATION
    ------------------------------------------------------------
    1. Place this file in your MacroQuest lua folder, either directly
       as DebuffWatch.lua, or in a subfolder as DebuffWatch/init.lua.
    2. (Optional) Place two 75x75 PNGs in the SAME folder as this script:
         - DeBuffWatch_Image_NoBadEffect.png  (shown while minimised and
           NO detrimental effect is currently active)
         - DeBuffWatch_Image_HasBadEffect.png (shown while minimised and
           AT LEAST ONE detrimental effect is currently active)
       These are used as the minimized-state icon, and which one is drawn
       updates dynamically as debuffs land/expire. Either image may be
       omitted independently; if the image for the current state is
       missing, the script falls back to the other one, and if neither
       is present, a small fallback "DW" button is used instead -- the
       script still works fine without them. (The expected image size is
       controlled by ICON_W/ICON_H near the top of the script -- see
       TUNING below if you use different image dimensions.)
    3. Start with:  /lua run DebuffWatch
       Stop  with:  /lua stop DebuffWatch

    ------------------------------------------------------------
    WHAT IT DOES
    ------------------------------------------------------------
    Every ~0.2 seconds, the script scans:
      - Regular buff slots  (Me.Buff(1..42))
      - Short duration / song slots  (Me.Song(1..15))

    For each active effect it records name, source (Buff/Song), slot
    number, caster, remaining duration, and hit counters (for
    count-based effects like curses/DoTs that don't tick a timer).

    Two independent checkboxes/radio-style toggles in the window let
    you choose what's DISPLAYED in the table:
      - "Detrimental" -- shows harmful effects (ON by default)
      - "Beneficial"  -- shows helpful effects (OFF by default)
    Both, either, or neither can be active at the same time; toggling
    one never affects the other.

    Regardless of what's currently displayed, every NEWLY-ARRIVED
    detrimental effect is always logged to a per-character log file
    (see LOGGING below) the moment it's first detected -- logging is
    independent of the display filter.

    ------------------------------------------------------------
    THE WINDOW
    ------------------------------------------------------------
    The main window shows, top to bottom:
      - A "Minimize to icon" button and a "Simulate Bad Effect" button
        (the latter is a debug/testing aid -- it forces the minimised
        icon into its "has bad effect" state, flashing border included,
        without needing an actual detrimental effect on you; click it
        again, now labeled "Stop Simulating Bad Effect", to turn it
        off. It's purely cosmetic and never touches scanning, logging,
        or the table filters below.)
      - The full path of the log file currently being written to
      - The Detrimental / Beneficial display toggles
      - A running count of what's currently shown
      - A sortable, resizable table of the matching effects, with
        columns: Type, Resist, Source, Slot, Name, Caster, Duration,
        Counters. "Resist" is the underlying spell's resist type
        (Poison, Disease, Magic, Fire, Cold, Corruption, Chromatic,
        Prismatic, Physical, etc) -- mainly meaningful for detrimental
        effects; shows '-' if unavailable. Rows for effects with <= 6
        seconds remaining are highlighted amber as an early-warning cue.

    Closing the window via its [x] button stops the script entirely.

    ------------------------------------------------------------
    MINIMIZE TO ICON
    ------------------------------------------------------------
    Clicking "Minimize to icon" (or running /debuffwatch_min) hides
    the main window and shows a small, borderless, draggable icon
    instead. The icon image is DYNAMIC: it shows
    DeBuffWatch_Image_HasBadEffect.png whenever at least one detrimental
    effect is currently active, or DeBuffWatch_Image_NoBadEffect.png
    otherwise (falling back to a "DW" button if neither image is
    present) -- so you can tell at a glance, even while minimised,
    whether you're currently debuffed. While a detrimental effect is
    active, the icon also gets a pulsing red flashing border to draw
    the eye; the border is absent whenever no detrimental effect is
    active. Drag the icon to reposition it; click it (a press+release
    with no drag) to restore the main window.

    The window's native title-bar collapse chevron is ALSO wired up to
    minimize: clicking it swaps straight to the icon view, exactly like
    the "Minimize to icon" button or running /debuffwatch_min.

    ------------------------------------------------------------
    TUNING THE ICON / BORDER
    ------------------------------------------------------------
    A handful of constants near the top of the script control the
    minimised icon's look, in case the defaults don't suit your
    resolution/UI scale or the "Simulate Bad Effect" flashing border
    doesn't look right:
      - ICON_W / ICON_H       -- drawn image size in pixels (default 75x75;
                                  match this to your actual PNG dimensions)
      - ICON_PAD              -- gap between the image edge and the window/
                                  border edge
      - BORDER_THICKNESS      -- thickness of the flashing red border
      - WIN_SIZE_SCALE        -- compensates for a quirk in some MacroQuest
                                  ImGui builds where window-size requests
                                  render at ~2x the size actually asked
                                  for (while ImGui.Image() draws are NOT
                                  affected). Defaulted here to 0.5 to
                                  correct for that; if your build doesn't
                                  have the quirk, or has a different
                                  magnitude of it, adjust this (1.0 = no
                                  correction) until the border hugs the
                                  image.

    ------------------------------------------------------------
    COMMANDS
    ------------------------------------------------------------
    /debuffwatch       Failsafe: unconditionally restores/shows the
                       main window, no matter what state it's in
                       (minimized, collapsed, etc). This is NOT a
                       toggle -- it only ever shows the window.

    /debuffwatch_min   Unconditionally minimizes to the icon view.

    ------------------------------------------------------------
    LOGGING
    ------------------------------------------------------------
    Every newly-detected detrimental effect is appended, timestamped,
    to a per-character log file at:

        <MQ config dir>/DebuffWatch_<YourCharacterName>.log

    The full path is also shown live in the window itself. Log entries
    are only written once per arrival (not on every scan tick) by
    tracking which detrimental effects are currently active.

    ------------------------------------------------------------
    STARTUP BEHAVIOR / FAILSAFES
    ------------------------------------------------------------
    - The script ALWAYS starts (or restarts after /lua run again)
      with the full window showing, never minimized, regardless of
      any prior session state.
    - Any error while rendering the window is caught, printed to the
      console as a RENDER ERROR, and the script automatically falls
      back to showing the main window rather than getting stuck on a
      broken render path.
    - Any error while scanning buffs/songs is caught, printed to the
      console as a SCAN ERROR, and the script keeps running rather
      than crashing outright.
]]

local mq = require('mq')
local ImGui = require('ImGui')

----------------------------------------------------------------------
-- Config
----------------------------------------------------------------------

local RENDER_HZ_THROTTLE = 0.2  -- seconds between full data refreshes (rendering itself is every frame)
local MAX_BUFF_SLOTS = 42       -- generous upper bound, GetMaxBuffSlots() covers most cases anyway
local MAX_SONG_SLOTS = 15       -- short duration / song slots

----------------------------------------------------------------------
-- State
----------------------------------------------------------------------

local openGUI = true
local shouldDrawGUI = true
local terminate = false

local showDetrimental = true   -- initializes enabled per spec
local showBeneficial = false

local effects = {}       -- refreshed table of currently displayed effects (per filter selection)
local lastScan = 0

local activeDebuffKeys = {}   -- tracks currently-active detrimental effects to detect new arrivals
local LOG_FILE = string.format('%s/DebuffWatch_%s.log', mq.configDir, mq.TLO.Me.Name() or 'Unknown')

local APP_NAME = 'Debuff Watch'

-- Minimise-to-icon state (same pattern as menu_bar.lua).
local minimized   = false  -- true -> show the icon instead of the window
local forceExpand = false  -- one-shot: un-collapse the window when restoring,
                           -- clearing the collapsed flag ImGui set on the
                           -- chevron click (else it would re-minimise).

----------------------------------------------------------------------
-- Minimise-to-icon constants
----------------------------------------------------------------------

-- Image shown while minimised.  Looked for as DeBuffWatch_Image_NoBadEffect.png
-- / DeBuffWatch_Image_HasBadEffect.png in THIS script's own directory,
-- resolved from debug.getinfo so it works no matter where the script is
-- placed (lua root or a subfolder).  Mirrors menu_bar.lua's proven-working
-- SCRIPT_DIR resolution exactly.
--
-- Which of the two images is drawn is DYNAMIC: it reflects whether any
-- detrimental effect is currently active (see hasBadEffect below), so the
-- minimised icon itself tells you at a glance whether you're debuffed --
-- independent of the Detrimental/Beneficial display filters.
local SCRIPT_DIR = (debug.getinfo(1, 'S').short_src or ''):match('^(.*[/\\])')
                   or ((mq.luaDir or '.') .. '/')
local ICON_PATH_NO_BAD  = SCRIPT_DIR .. 'DeBuffWatch_Image_NoBadEffect.png'
local ICON_PATH_HAS_BAD = SCRIPT_DIR .. 'DeBuffWatch_Image_HasBadEffect.png'
local ICON_W     = 75   -- drawn image width  (pixels)
local ICON_H     = 75   -- drawn image height (pixels)
local ICON_PAD   = 2    -- window padding around the minimised image; this is
                         -- also the visible gap between the image edge and
                         -- the flashing border, since the border is drawn as
                         -- the window's own edge (see renderIcon). Tune this
                         -- down further (even 0) if the gap still looks too
                         -- wide for your taste/UI scale.
local BORDER_THICKNESS = 4  -- flashing border line thickness (px). Tune this
                             -- to taste too -- how "thick" 1 unit renders
                             -- as can vary with UI/display scale.

-- Confirmed (twice, with different implementations) that this binding
-- applies an exact 2x multiplier to ImGui.SetNextWindowSize() requests
-- specifically -- NOT to ImGui.Image() draw sizes, which is why the image
-- itself renders correctly at ICON_W x ICON_H while the window (and thus
-- its border) comes out exactly double. This scales down what we ASK for
-- so what actually renders matches ICON_W/ICON_H. If your border still
-- doesn't hug the image, try other values here (e.g. 0.667 for a 1.5x
-- mismatch instead of 2x, or 1.0 if there's no mismatch at all).
local WIN_SIZE_SCALE = 0.5

-- Tracks whether at least one detrimental effect is currently active
-- (updated every scan in refreshDebuffs, regardless of display filters).
-- Drives which of the two minimised-icon images is shown.
local hasBadEffect = false

-- Debug/testing aid: when true, forces the icon into the "has bad effect"
-- state (image + flashing border) regardless of real game state, so the
-- flashing border can be previewed outside of combat. Purely cosmetic --
-- does not affect scanning, logging, or the table filters. Toggled via the
-- "Simulate Bad Effect" button in the main window.
local simulateBadEffect = false

--- Combines the real detection with the debug simulation toggle. Everything
--- that decides icon/border appearance should read this instead of
--- hasBadEffect directly.
local function effectiveHasBadEffect()
    return hasBadEffect or simulateBadEffect
end

--- Load a single icon texture. Confirms the file exists first, since
--- mq.CreateTexture can return a non-nil but blank texture for a missing
--- path. Returns (texture-or-nil, loaded-boolean).
local function loadIcon(path)
    local f = io.open(path, 'rb')
    if f then
        f:close()
        local ok, tex = pcall(mq.CreateTexture, path)
        if ok and tex then
            return tex, true
        end
    end
    return nil, false
end

-- Load both icon textures once. If either is missing (or the build lacks
-- mq.CreateTexture), its slot stays nil and the minimised view falls back
-- to a small button whenever the currently-selected image isn't available.
local iconImgNoBad,  iconLoadedNoBad  = loadIcon(ICON_PATH_NO_BAD)
local iconImgHasBad, iconLoadedHasBad = loadIcon(ICON_PATH_HAS_BAD)
local iconLoaded = iconLoadedNoBad or iconLoadedHasBad

--- Returns the texture that should currently be drawn for the minimised
--- icon, based on hasBadEffect, falling back to whichever image IS loaded
--- if the preferred one for the current state is missing.
local function currentIconTexture()
    if effectiveHasBadEffect() then
        return iconImgHasBad or iconImgNoBad
    else
        return iconImgNoBad or iconImgHasBad
    end
end

----------------------------------------------------------------------
-- Helpers
----------------------------------------------------------------------

--- Scan a slot range using the given TLO accessor function.
--- Collects EVERY active effect (beneficial and detrimental alike); filtering
--- for display happens separately based on the radio button selections.
local function scanSlots(getSlot, maxSlots, sourceLabel, results)
    for i = 1, maxSlots do
        local buff = getSlot(i)
        if buff() and buff.ID() and buff.ID() > 0 then
            local isBeneficial = buff.Beneficial() and true or false
            local name = buff.Name() or "Unknown"
            local caster = buff.Caster() or "Unknown"

            -- NOTE: buff.Duration() returns a plain number (ticks), not an
            -- object -- so chain off buff.Duration (no parens) to reach the
            -- Ticks TLO's members like TimeHMS()/TotalSeconds().
            local duration = "N/A"
            local remainingSec = -1
            pcall(function()
                duration = buff.Duration.TimeHMS() or "N/A"
            end)
            pcall(function()
                remainingSec = buff.Duration.TotalSeconds() or -1
            end)

            local counters = 0
            -- some effects track counters/hits instead of duration
            pcall(function()
                counters = buff.Counters() or 0
            end)

            -- Resist type (Poison/Disease/Magic/Fire/Cold/Corruption/
            -- Chromatic/Prismatic/Physical/etc), pulled from the
            -- underlying spell. Mainly meaningful for detrimental
            -- effects; shown as '-' if unavailable.
            local resistType = "-"
            pcall(function()
                resistType = buff.Spell.ResistType() or "-"
            end)

            table.insert(results, {
                source = sourceLabel,
                slot = i,
                name = name,
                caster = caster,
                duration = duration,
                remainingSec = remainingSec,
                counters = counters,
                resistType = resistType,
                id = buff.ID(),
                beneficial = isBeneficial,
            })
        end
    end
end

--- Append a line to the log file, creating it if needed.
local function logToFile(line)
    local f = io.open(LOG_FILE, 'a')
    if f then
        f:write(string.format('[%s] %s\n', os.date('%Y-%m-%d %H:%M:%S'), line))
        f:close()
    end
end

--- Refresh the effects table from current game state, filtered by the
--- currently selected radio button(s). Also logs any NEW detrimental
--- effect (one not already tracked as active) to LOG_FILE, regardless
--- of whether the Detrimental filter is currently displayed.
local function refreshDebuffs()
    local allEffects = {}

    -- Regular buff slots
    scanSlots(function(i) return mq.TLO.Me.Buff(i) end, MAX_BUFF_SLOTS, "Buff", allEffects)

    -- Short duration / song slots
    scanSlots(function(i) return mq.TLO.Me.Song(i) end, MAX_SONG_SLOTS, "Song", allEffects)

    -- Detect and log newly-arrived detrimental effects
    local currentKeys = {}
    for _, e in ipairs(allEffects) do
        if not e.beneficial then
            local key = string.format('%s:%d:%d', e.source, e.slot, e.id)
            currentKeys[key] = true
            if not activeDebuffKeys[key] then
                logToFile(string.format(
                    'DETRIMENTAL landed -- Name=%s Resist=%s Source=%s Slot=%d Caster=%s Duration=%s',
                    e.name, e.resistType, e.source, e.slot, e.caster, e.duration
                ))
            end
        end
    end
    activeDebuffKeys = currentKeys

    -- Drives the minimised-icon image: true as soon as ANY detrimental
    -- effect is active, regardless of what the display filters show.
    hasBadEffect = false
    for _, e in ipairs(allEffects) do
        if not e.beneficial then
            hasBadEffect = true
            break
        end
    end

    local filtered = {}
    for _, e in ipairs(allEffects) do
        if (e.beneficial and showBeneficial) or (not e.beneficial and showDetrimental) then
            table.insert(filtered, e)
        end
    end

    effects = filtered
end

----------------------------------------------------------------------
-- ImGui rendering
----------------------------------------------------------------------

-- Minimised view: a small window, explicitly sized every frame (see
-- renderIcon), whose only content is the icon drawn as a plain image (same
-- approach as menu_bar.lua's minimise-to-icon). Uses its own window id so
-- it is independent of the main window.
--
-- NOTE: deliberately NOT using ImGuiWindowFlags.AlwaysAutoResize. That flag
-- makes ImGui recompute (and override) the window size from its content
-- EVERY frame -- which meant it was fighting with, and winning over, our
-- own explicit ImGui.SetNextWindowSize() call in renderIcon, silently
-- reverting the size back to whatever (apparently oversized) result its
-- own auto-computation produced. Since we now size the window ourselves
-- every frame from known constants, auto-resize is unnecessary and was
-- actively working against the fix.
--
-- Also deliberately NOT using ImGuiWindowFlags.NoBackground. In real Dear
-- ImGui, a window's border is only rendered when NoBackground is absent --
-- so as long as that flag was set, NO style-based border approach could
-- ever have worked, regardless of color/size values. Instead, the
-- background is made invisible via a WindowBg style color with alpha 0
-- (pushed below), which achieves the same "see-through" look while still
-- letting ImGui draw its own native border for us.
local MIN_FLAGS = bit32.bor(ImGuiWindowFlags.NoResize,
                            ImGuiWindowFlags.NoScrollbar,
                            ImGuiWindowFlags.NoTitleBar)

local iconPressed = false  -- mouse button is down having pressed on the icon
local iconDragged = false  -- that press has moved -> treat as a window drag,
                           -- not a click, so it moves instead of restoring.

local function renderIcon()
    -- Spawn near the top-left on first appearance only; after that the
    -- user's own drag position is left alone (drag-to-move works normally).
    ImGui.SetNextWindowPos(100, 100, ImGuiCond.FirstUseEver)
    -- Force the exact window size EVERY frame instead of trusting
    -- AlwaysAutoResize, scaled by WIN_SIZE_SCALE to compensate for the
    -- confirmed 2x window-size mismatch (see WIN_SIZE_SCALE comment above).
    ImGui.SetNextWindowSize(
        (ICON_W + ICON_PAD * 2) * WIN_SIZE_SCALE,
        (ICON_H + ICON_PAD * 2) * WIN_SIZE_SCALE,
        ImGuiCond.Always
    )
    -- Also keep WindowMinSize overridden low, in case a min-size floor is
    -- compounding the issue at these small scaled-down request values.
    ImGui.PushStyleVar(ImGuiStyleVar.WindowMinSize, ImVec2(1, 1))

    -- Invisible background (replaces the NoBackground flag -- see MIN_FLAGS
    -- comment above for why) plus a native window border whose size/color
    -- depend on whether a detrimental effect is active. WindowBorderSize is
    -- ALWAYS pushed explicitly (0 when inactive, thick+colored when
    -- active) rather than only pushed in the active case -- the default
    -- theme apparently has a nonzero border size, and since removing
    -- NoBackground stopped suppressing it outright, leaving it unpushed in
    -- the inactive case let that default border show around the
    -- NoBadEffect image too. Both are popped right after Begin(): that's
    -- when the window's border/background are baked from the current style
    -- stack, so popping immediately keeps these from leaking into anything
    -- created later in this scope (e.g. the SetTooltip() call below, which
    -- opens its own separate ImGui window).
    local borderActive = effectiveHasBadEffect()
    local varCount, colorCount = 3, 1  -- WindowPadding + WindowMinSize + WindowBorderSize, WindowBg
    ImGui.PushStyleColor(ImGuiCol.WindowBg, 0, 0, 0, 0)
    ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, ICON_PAD, ICON_PAD)
    if borderActive then
        local pulse = (math.sin(os.clock() * 6) + 1) / 2  -- 0..1
        local alpha = 0.35 + pulse * 0.65                  -- 0.35..1.0
        ImGui.PushStyleColor(ImGuiCol.Border, 1.0, 0.15, 0.15, alpha)
        ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, BORDER_THICKNESS)
        colorCount = colorCount + 1
    else
        -- Explicitly force no border, overriding whatever the theme's
        -- default WindowBorderSize is.
        ImGui.PushStyleVar(ImGuiStyleVar.WindowBorderSize, 0)
    end

    local visible
    openGUI, visible = ImGui.Begin(APP_NAME .. ' Icon###DebuffWatchMini', openGUI, MIN_FLAGS)

    -- Pop immediately: the window's background/border are baked from the
    -- style stack at Begin() time, so they're already applied to THIS
    -- window. Popping now (rather than after End()) keeps them from
    -- leaking into the SetTooltip() call below, which opens its own
    -- separate ImGui window later in this same scope.
    for _ = 1, varCount do
        ImGui.PopStyleVar()
    end
    for _ = 1, colorCount do
        ImGui.PopStyleColor()
    end

    if visible then
        local restore = false

        -- Pick the texture fresh every frame so the icon flips the instant
        -- hasBadEffect changes (e.g. a debuff lands while minimised).
        local iconImg = currentIconTexture()

        if iconImg then
            -- Draw the icon as a plain image (not a button). A plain image is
            -- non-interactive, so ImGui lets the borderless window be dragged
            -- by it -- giving "drag the image to move" for free. Restoring is
            -- handled below by detecting a click (press + release, no drag).
            local ok = pcall(function()
                ImGui.Image(iconImg:GetTextureID(), ImVec2(ICON_W, ICON_H))
            end)

            if ok then
                local hovered = ImGui.IsItemHovered()
                if hovered and not iconPressed then
                    ImGui.SetTooltip(APP_NAME .. ' — drag to move, click to restore')
                end

                -- Press started on the icon -> begin tracking a potential click.
                if hovered and ImGui.IsMouseClicked(0) then
                    iconPressed = true
                    iconDragged = false
                end
                -- Any movement while held turns it into a drag (window move),
                -- which must NOT restore.
                if iconPressed and ImGui.IsMouseDragging(0) then
                    iconDragged = true
                end
                -- Release: a press that never became a drag is a click -> restore.
                if ImGui.IsMouseReleased(0) then
                    if iconPressed and not iconDragged then
                        restore = true
                    end
                    iconPressed = false
                    iconDragged = false
                end
            else
                iconImg = nil
            end
        end

        if not iconImg then
            if ImGui.Button('DW##restore') then restore = true end
        end

        if restore then
            minimized   = false
            forceExpand = true   -- un-collapse the main window next frame
        end
    end

    ImGui.End()
end

local function renderMainWindow()
    if forceExpand then
        ImGui.SetNextWindowCollapsed(false, ImGuiCond.Always)
        forceExpand = false
    end

    ImGui.SetNextWindowSize(520, 300, ImGuiCond.FirstUseEver)
    local show
    -- NOTE: MQ's Lua ImGui.Begin returns (open, shouldDraw) -- the open/
    -- closed p_open flag comes FIRST, not second like the generic ImGui
    -- Lua bindings. Getting this order backwards means the [x] button's
    -- close never gets picked up, so the script won't terminate.
    openGUI, show = ImGui.Begin('Debuff Watch', openGUI)

    -- Title-bar collapse chevron: clicking it collapses the window, which
    -- we treat exactly like /debuffwatch_min -- swap straight to the icon
    -- view instead of leaving a collapsed title bar sitting around.
    if ImGui.IsWindowCollapsed() then
        ImGui.End()
        minimized   = true
        forceExpand = true  -- so it's un-collapsed next time it's restored
        return
    end

    if show then
        if ImGui.Button('Minimize to icon##minBtn') then
            minimized = true
        end
        --[[ Simulate Bad Effect button -- disabled (commented out) for now.
        Everything it relies on (simulateBadEffect, effectiveHasBadEffect())
        is left fully intact above; only this display of the button itself
        is disabled. Uncomment this block to bring the button back.
        ImGui.SameLine()
        -- Debug/testing aid: lets you preview the flashing "has bad effect"
        -- icon/border without needing an actual detrimental effect on you.
        -- Purely cosmetic -- does not touch scanning, logging, or filters.
        if simulateBadEffect then
            if ImGui.Button('Stop Simulating Bad Effect##simBtn') then
                simulateBadEffect = false
            end
        else
            if ImGui.Button('Simulate Bad Effect##simBtn') then
                simulateBadEffect = true
            end
        end
        if simulateBadEffect then
            ImGui.SameLine()
            ImGui.TextColored(1.0, 0.4, 0.4, 1.0, '(simulating -- minimize to preview)')
        end
        --]]
        ImGui.Separator()

        ImGui.Text(string.format('Logging detrimental effects to: %s', LOG_FILE))
        ImGui.Separator()

        -- Independent (non-exclusive) radio-style toggles. Clicking one does
        -- NOT clear the other -- both, either, or neither may be active.
        if ImGui.RadioButton('Detrimental', showDetrimental) then
            showDetrimental = not showDetrimental
        end
        ImGui.SameLine()
        if ImGui.RadioButton('Beneficial', showBeneficial) then
            showBeneficial = not showBeneficial
        end

        ImGui.Separator()

        local label
        if showDetrimental and showBeneficial then
            label = 'All effects active'
        elseif showDetrimental then
            label = 'Detrimental effects active'
        elseif showBeneficial then
            label = 'Beneficial effects active'
        else
            label = 'No filters selected'
        end
        ImGui.Text(string.format('%s: %d', label, #effects))
        ImGui.Separator()

        local flags = ImGuiTableFlags.Borders + ImGuiTableFlags.RowBg
            + ImGuiTableFlags.Resizable + ImGuiTableFlags.Sortable

        if ImGui.BeginTable('DebuffTable', 8, flags) then
            ImGui.TableSetupColumn('Type', ImGuiTableColumnFlags.WidthFixed, 75)
            ImGui.TableSetupColumn('Resist', ImGuiTableColumnFlags.WidthFixed, 80)
            ImGui.TableSetupColumn('Source', ImGuiTableColumnFlags.WidthFixed, 60)
            ImGui.TableSetupColumn('Slot', ImGuiTableColumnFlags.WidthFixed, 40)
            ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthStretch)
            ImGui.TableSetupColumn('Caster', ImGuiTableColumnFlags.WidthFixed, 100)
            ImGui.TableSetupColumn('Duration', ImGuiTableColumnFlags.WidthFixed, 90)
            ImGui.TableSetupColumn('Counters', ImGuiTableColumnFlags.WidthFixed, 70)
            ImGui.TableHeadersRow()

            for _, d in ipairs(effects) do
                ImGui.TableNextRow()

                ImGui.TableNextColumn()
                if d.beneficial then
                    ImGui.TextColored(0.4, 1.0, 0.4, 1.0, 'Beneficial')
                else
                    ImGui.TextColored(1.0, 0.4, 0.4, 1.0, 'Detrimental')
                end

                ImGui.TableNextColumn()
                ImGui.Text(d.resistType)

                ImGui.TableNextColumn()
                ImGui.Text(d.source)

                ImGui.TableNextColumn()
                ImGui.Text(tostring(d.slot))

                ImGui.TableNextColumn()
                -- extra flag for very-low-remaining effects, regardless of type
                if d.remainingSec >= 0 and d.remainingSec <= 6 then
                    ImGui.TextColored(1.0, 0.8, 0.2, 1.0, d.name)
                else
                    ImGui.Text(d.name)
                end

                ImGui.TableNextColumn()
                ImGui.Text(d.caster)

                ImGui.TableNextColumn()
                ImGui.Text(d.duration)

                ImGui.TableNextColumn()
                ImGui.Text(d.counters > 0 and tostring(d.counters) or '-')
            end

            ImGui.EndTable()
        end
    end

    ImGui.End()

    if not openGUI then
        -- window was closed via the [x] button; stop the script
        terminate = true
    end
end

local function renderGUI()
    if not openGUI then return end

    local ok, err = pcall(function()
        if minimized then
            renderIcon()
        else
            renderMainWindow()
        end
    end)

    if not ok then
        print(string.format('\ar[Debuff Watch] RENDER ERROR:\ax %s', tostring(err)))
        -- Fail safe: drop back to the main window rather than staying stuck
        -- on a render path that's erroring out every frame.
        minimized = false
    end
end

----------------------------------------------------------------------
-- Bind to toggle window
----------------------------------------------------------------------

-- FAILSAFE: always shows/restores the main window, regardless of current
-- state. This is intentionally NOT a toggle -- if the icon is invisible,
-- stuck, or the window is collapsed/minimised for any reason, this command
-- unconditionally brings the full window back.
mq.bind('/debuffwatch', function()
    minimized   = false
    forceExpand = true
    openGUI     = true
end)

-- Explicit minimise command, for testing/using the icon view without
-- having to find and click the title-bar chevron.
mq.bind('/debuffwatch_min', function()
    minimized = true
end)

----------------------------------------------------------------------
-- Register with MQ's ImGui pipeline
----------------------------------------------------------------------

mq.imgui.init('DebuffWatch', renderGUI)

-- FAILSAFE: always start (or /lua run again after a stop) with the full
-- window showing, never minimised to the icon, regardless of any prior
-- session state.
minimized   = false
forceExpand = false
openGUI     = true

print(string.format('\ay[Debuff Watch]\ax Restore the window anytime with: \ag/debuffwatch\ax'))
print(string.format('\ay[Debuff Watch]\ax Minimise to icon (testing) with: \ag/debuffwatch_min\ax'))
if iconLoadedNoBad then
    print(string.format('\ay[Debuff Watch]\ax No-effect icon loaded: \ag%s\ax', ICON_PATH_NO_BAD))
else
    print(string.format('\ay[Debuff Watch]\ax \arNo-effect icon not found\ax at %s', ICON_PATH_NO_BAD))
end
if iconLoadedHasBad then
    print(string.format('\ay[Debuff Watch]\ax Bad-effect icon loaded: \ag%s\ax', ICON_PATH_HAS_BAD))
else
    print(string.format('\ay[Debuff Watch]\ax \arBad-effect icon not found\ax at %s', ICON_PATH_HAS_BAD))
end
if not iconLoaded then
    print(string.format('\ay[Debuff Watch]\ax \arNo minimise icons found\ax -- using fallback button while minimised.'))
end

----------------------------------------------------------------------
-- Main loop
----------------------------------------------------------------------

while not terminate do
    if os.clock() - lastScan >= RENDER_HZ_THROTTLE then
        local ok, err = pcall(refreshDebuffs)
        if not ok then
            print(string.format('\ar[Debuff Watch] SCAN ERROR:\ax %s', tostring(err)))
        end
        lastScan = os.clock()
    end
    mq.delay(50) -- ms
end
