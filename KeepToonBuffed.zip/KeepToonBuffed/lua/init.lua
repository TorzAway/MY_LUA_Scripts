--[[
    KeepToonBuffed.lua
    MacroQuest Lua Script

    Features:
      - All configuration loaded from buffhealer.ini (no hardcoded values)
      - Single target list drives both buff monitoring AND heal monitoring
      - Recasts buffs on each target when they expire or fall below a tick threshold
      - Heals each target when their HP drops below a configured threshold
      - Heals always fire before buff maintenance each loop
      - Watches a designated tank's current NPC target and casts debuffs on the mob
        when the mob's HP falls at or below each debuff's configured trigger percentage
      - Each debuff is cast once per mob and not repeated until a new mob is engaged
      - Skips buff casting while in combat (configurable)
      - Skips all casting when mana is below a minimum threshold
      - ImGui window with Pause/Resume and Stop buttons for in-game control

    Requirements:
      - MacroQuest with Lua support (mq.TLO, mq.cmd)
      - buffhealer.ini must be in the MacroQuest config directory (mq.configDir, e.g. MacroQuest/config/)
      - All spells must be memorized in the gem slots defined in the INI

    Usage:
      /lua run KeepToonBuffed
--]]

local mq    = require('mq')
local imgui = require('ImGui')
local bit   = require('bit')

-- ============================================================
--  INI PARSER
-- ============================================================

--- mq.configDir is a string property built into the MacroQuest Lua runtime.
--- It resolves to the absolute path of the MQ config folder at runtime
--- (e.g. C:\\MacroQuest\\config) and is the correct way to locate INI files.
--- Build the INI filename dynamically using the logged-in character's name,
--- following the MacroQuest convention of per-character config files.
--- e.g. MacroQuest/config/KeepToonBuffed_LUA_Charname.ini
-- mq.TLO.Me is not available until the first game frame has been processed.
-- Yield one frame with mq.delay(0) so the engine populates the Me TLO,
-- then resolve the character name before anything else runs.
mq.delay(0)
local CHAR_NAME = mq.TLO.Me.Name() or 'Unknown'
local INI_PATH  = mq.configDir .. '/KeepToonBuffed_LUA_' .. CHAR_NAME .. '.ini'

--- Parse a simple INI file into a nested table: result[section][key] = value.
--- Lines beginning with ; or # are treated as comments and ignored.
---@param path string
---@return table
local function parse_ini(path)
    local result  = {}
    local section = "default"

    local fh, err = io.open(path, "r")
    if not fh then
        error("[BuffHealer] Cannot open INI file: " .. path .. "\n" .. (err or ""))
    end

    for line in fh:lines() do
        -- Strip leading/trailing whitespace
        line = line:match("^%s*(.-)%s*$")

        -- Skip blank lines and comment lines
        if line == "" or line:sub(1, 1) == ";" or line:sub(1, 1) == "#" then
            -- nothing

        -- Section header  [SectionName]
        elseif line:match("^%[.+%]$") then
            section = line:match("^%[(.+)%]$")
            if not result[section] then result[section] = {} end

        -- Key=Value pair
        elseif line:find("=") then
            local k, v = line:match("^([^=]+)=(.*)$")
            if k and v then
                k = k:match("^%s*(.-)%s*$")
                v = v:match("^%s*(.-)%s*$")
                if not result[section] then result[section] = {} end
                result[section][k] = v
            end
        end
    end

    fh:close()
    return result
end

--- Extract all ordered list entries (Prefix1, Prefix2, …) from an INI section.
--- Returns them as an array of raw value strings, in numeric order.
---@param section table   A section sub-table from parse_ini()
---@param prefix  string  Key prefix for this section, e.g. "Target", "Buff"
---@return string[]
local function get_list(section, prefix)
    if not section then return {} end
    local items = {}
    local i = 1
    while true do
        local v = section[prefix .. i]
        if not v then break end
        items[#items + 1] = v
        i = i + 1
    end
    return items
end

--- Split a pipe-delimited string and trim each field.
---@param s string
---@return string[]
local function split_pipe(s)
    local parts = {}
    for part in s:gmatch("([^|]+)") do
        parts[#parts + 1] = part:match("^%s*(.-)%s*$")
    end
    return parts
end

--- Convert a string to a boolean (case-insensitive "true"/"1" → true).
---@param s string
---@return boolean
local function to_bool(s)
    if type(s) ~= "string" then return false end
    s = s:lower()
    return s == "true" or s == "1" or s == "yes" or s == "on"
end

-- ============================================================
--  LOAD CONFIGURATION FROM INI
-- ============================================================

local function load_config(path)
    local ini = parse_ini(path)

    local cfg = {}

    -- [Settings] -----------------------------------------------
    local s = ini["Settings"] or {}
    cfg.loop_interval        = tonumber(s["LoopInterval"])        or 0
    cfg.min_mana_pct         = tonumber(s["MinManaPct"])          or 20
    cfg.pause_buffs_in_combat = to_bool(s["PauseBuffsInCombat"]  or "true")
    cfg.debuff_tank          = s["DebuffTank"] or ""
    cfg.auto_follow          = to_bool(s["AutoFollow"] or "false")
    cfg.announce             = to_bool(s["Announce"]   or "false")
    cfg.debuff_mobs          = to_bool(s["DebuffMobs"] or "true")

    -- Self-healing (separate from the [Targets] list, always checked first)
    cfg.self_heal_enabled    = to_bool(s["SelfHealEnabled"] or "false")
    cfg.self_heal_pct        = tonumber(s["SelfHealPct"])        or 70
    cfg.self_heal_spell      = s["SelfHealSpell"] or ""
    cfg.self_heal_gem        = tonumber(s["SelfHealGem"])        or 1
    cfg.self_heal_cast       = tonumber(s["SelfHealCastMs"])     or 2500

    -- Follow distance in feet — stay within this range of the DebuffTank
    cfg.follow_distance      = tonumber(s["FollowDistance"])     or 20

    -- [Targets] ------------------------------------------------
    -- Format: Name | HealPct | HealSpell | HealGem | HealCastMs
    cfg.targets = {}
    for _, raw in ipairs(get_list(ini["Targets"], "Target")) do
        local f = split_pipe(raw)
        if #f >= 5 then
            cfg.targets[#cfg.targets + 1] = {
                name       = f[1],
                heal_pct   = tonumber(f[2]) or 70,
                heal_spell = f[3],
                heal_gem   = tonumber(f[4]) or 1,
                heal_cast  = tonumber(f[5]) or 2500,
            }
        else
            mq.cmd("/echo \\at[BuffHealer]\\ay WARNING: Malformed [Targets] entry: \\ag" .. raw .. "\\ay")
        end
    end

    -- [Buffs] --------------------------------------------------
    -- Format: Name | MinTicks | Gem | CastTimeMs
    cfg.buffs = {}
    for _, raw in ipairs(get_list(ini["Buffs"], "Buff")) do
        local f = split_pipe(raw)
        if #f >= 4 then
            cfg.buffs[#cfg.buffs + 1] = {
                name      = f[1],
                min_ticks = tonumber(f[2]) or 0,
                gem       = tonumber(f[3]) or 1,
                cast_time = tonumber(f[4]) or 2000,
            }
        else
            mq.cmd("/echo \\at[BuffHealer]\\ay WARNING: Malformed [Buffs] entry: \\ag" .. raw .. "\\ay")
        end
    end

    -- [SelfBuffs] ----------------------------------------------
    -- Format: Name | MinTicks | Gem | CastTimeMs
    cfg.self_buffs = {}
    for _, raw in ipairs(get_list(ini["SelfBuffs"], "SelfBuff")) do
        local f = split_pipe(raw)
        if #f >= 4 then
            cfg.self_buffs[#cfg.self_buffs + 1] = {
                name      = f[1],
                min_ticks = tonumber(f[2]) or 0,
                gem       = tonumber(f[3]) or 1,
                cast_time = tonumber(f[4]) or 2000,
            }
        else
            mq.cmd("/echo \\at[BuffHealer]\\ay WARNING: Malformed [SelfBuffs] entry: \\ag" .. raw .. "\\ay")
        end
    end

    -- [Debuffs] ------------------------------------------------
    -- Format: Name | TriggerPct | Gem | CastTimeMs
    cfg.debuffs = {}
    for _, raw in ipairs(get_list(ini["Debuffs"], "Debuff")) do
        local f = split_pipe(raw)
        if #f >= 4 then
            cfg.debuffs[#cfg.debuffs + 1] = {
                name        = f[1],
                trigger_pct = tonumber(f[2]) or 100,
                gem         = tonumber(f[3]) or 1,
                cast_time   = tonumber(f[4]) or 2000,
            }
        else
            mq.cmd("/echo \\at[BuffHealer]\\ay WARNING: Malformed [Debuffs] entry: \\ag" .. raw .. "\\ay")
        end
    end

    return cfg
end

-- Load once at startup; reload by restarting the script.
local CONFIG = load_config(INI_PATH)

-- ============================================================
--  UTILITY FUNCTIONS
-- ============================================================

--- Print a labelled message to the MQ console.
---@param msg string
local function info(msg)
    mq.cmd('/echo \\at[BuffHealer]\\ay ' .. tostring(msg))
end

--- Return remaining ticks on a buff for a named spawn, or 0 if absent.
---@param spawn_name string  Player name, or "self"
---@param buff_name  string
---@return number
local function get_buff_ticks(spawn_name, buff_name)
    local b
    if spawn_name == "self" then
        b = mq.TLO.Me.Buff(buff_name)
    else
        local spawn = mq.TLO.Spawn(spawn_name)
        if spawn and spawn() then
            b = spawn.Buff(buff_name)
        end
    end
    if b and b.Duration() then
        -- Duration() is in ms; 6 000 ms = 1 EQ tick
        return math.floor(b.Duration() / 6000)
    end
    return 0
end

--- Return HP percentage for a named character, or 0 if not found/visible.
---@param name string
---@return number
local function get_hp_pct(name)
    local spawn = mq.TLO.Spawn(name)
    if spawn and spawn() then
        return spawn.PctHPs() or 0
    end
    return 0
end

--- Return true while a spell is being cast.
---@return boolean
local function is_casting()
    return mq.TLO.Me.Casting() ~= nil
end

--- Block until casting finishes or timeout_ms elapses.
---@param timeout_ms number
local function wait_for_cast(timeout_ms)
    local elapsed, poll = 0, 100
    while elapsed < timeout_ms do
        if not is_casting() then return end
        mq.delay(poll)
        elapsed = elapsed + poll
    end
end

--- Target a named character.  Returns true when the target window confirms the name.
---@param name string  Player name, or "self"
---@return boolean
local function target_spawn(name)
    local actual = (name == 'self') and CHAR_NAME or name
    mq.cmd('/target ' .. actual)
    mq.delay(300)
    -- Access Target members directly; mq.TLO.Target.Name() not mq.TLO.Target().Name()
    local tname = mq.TLO.Target.Name()
    return tname ~= nil and tname == actual
end

--- Cast the spell in gem slot `gem` and wait for completion.
---@param gem       number  Gem slot (1-12)
---@param cast_time number  Expected cast duration in ms
local function cast_gem(gem, cast_time)
    mq.cmd('/cast ' .. gem)
    mq.delay(500)
    wait_for_cast(cast_time + 2000)   -- +2 s safety margin
    mq.delay(500)
end

-- ============================================================
--  GUI STATE (forward-declared here so earlier passes, e.g.
--  manage_debuffs, can read toggle state; populated below)
-- ============================================================

local gui = {
    open     = true,   -- window visibility (closing hides but does not stop)
    paused   = true,   -- when true the logic passes are skipped each loop
    exit     = false,  -- set to true to break the main loop and exit
    follow   = CONFIG.auto_follow and CONFIG.debuff_tank ~= '',  -- initial state driven by AutoFollow in the INI (requires a DebuffTank)
    debuff   = CONFIG.debuff_mobs,  -- initial state driven by DebuffMobs in the INI
    announce = CONFIG.announce and CONFIG.debuff_tank ~= '',     -- initial state driven by Announce in the INI (requires a DebuffTank)
}

--- Send a /tell notification to the DebuffTank, if Announce is toggled on
--- and a DebuffTank is configured.
---@param msg string
local function announce(msg)
    if not gui.announce then return end
    if CONFIG.debuff_tank == "" then return end
    mq.cmdf('/tell %s %s', CONFIG.debuff_tank, msg)
end

-- ============================================================
--  HEAL PASS  (runs first — highest priority)
-- ============================================================

local function manage_heals()
    if (mq.TLO.Me.PctMana() or 0) < CONFIG.min_mana_pct then
        info(string.format("Mana low (\\ag%d%%\\ay), skipping heals.", mq.TLO.Me.PctMana()))
        return
    end

    -- Self-heal always checked first, ahead of the [Targets] list.
    if CONFIG.self_heal_enabled then
        local my_hp = mq.TLO.Me.PctHPs() or 100
        if my_hp <= CONFIG.self_heal_pct then
            info(string.format("Self-healing at \\ag%d%%\\ay HP with [\\ag%s\\ay]", my_hp, CONFIG.self_heal_spell))
            -- No /target needed for self-cast heals; just fire the gem.
            cast_gem(CONFIG.self_heal_gem, CONFIG.self_heal_cast)
            info("Self-heal complete.")
            announce(string.format('Self-healed with %s (%d%% HP)', CONFIG.self_heal_spell, my_hp))
        end
    end

    for _, t in ipairs(CONFIG.targets) do
        local hp = get_hp_pct(t.name)
        if hp == 0 then
            -- Target not visible / out of range — skip silently
        elseif hp <= t.heal_pct then
            info(string.format("Healing [\\ag%s\\ay] at \\ag%d%%\\ay HP with [\\ag%s\\ay]", t.name, hp, t.heal_spell))
            if target_spawn(t.name) then
                cast_gem(t.heal_gem, t.heal_cast)
                info(string.format("Heal complete -> [\\ag%s\\ay]", t.name))
                announce(string.format('Healed %s with %s', t.name, t.heal_spell))
            else
                info(string.format("WARNING: Could not target [\\ag%s\\ay] for healing", t.name))
            end
        end
    end
end

-- ============================================================
--  DEBUFF PASS  (runs second)
-- ============================================================

-- Tracks which debuffs have already landed on the current mob.
-- Reset automatically whenever the tank acquires a new NPC target.
local debuff_state = {
    mob_id   = nil,
    cast_map = {},
}

--- Assist the DebuffTank so our own Target becomes whatever mob they're
--- fighting. This avoids the TargetOfTarget TLO entirely — on some servers
--- (especially emulated ones) that TLO's underlying data is never populated
--- even though the "target of target" UI element shows correctly, since the
--- UI can source that info differently than the network data MQ's TLO reads.
--- `/assist` is a native EQ client command, not a TLO, so it works the same
--- as pressing the in-game Assist button and is far more reliable here.
---@return number|nil spawn_id  ID of the mob now targeted, or nil if none
local function get_tank_target_id()
    if CONFIG.debuff_tank == "" then return nil end

    mq.cmdf('/assist %s', CONFIG.debuff_tank)
    mq.delay(400)

    local id  = mq.TLO.Target.ID()
    local typ = mq.TLO.Target.Type() or ""

    if id and id > 0 and typ ~= "PC" and typ ~= "Corpse" then
        return id
    end
    return nil
end

--- Cast configured debuffs on the tank's mob target as HP thresholds are met.
local function manage_debuffs()
    if not gui.debuff then
        -- Toggled off — drop any tracked mob so a fresh mob is seen cleanly
        -- if/when the toggle is switched back on.
        if debuff_state.mob_id ~= nil then
            debuff_state.mob_id   = nil
            debuff_state.cast_map = {}
        end
        return
    end
    if #CONFIG.debuffs == 0 then return end
    if (mq.TLO.Me.PctMana() or 0) < CONFIG.min_mana_pct then return end

    local mob_id = get_tank_target_id()

    if not mob_id then
        if debuff_state.mob_id ~= nil then
            info("Tank has no NPC target — resetting debuff state.")
            debuff_state.mob_id   = nil
            debuff_state.cast_map = {}
        end
        return
    end

    -- New mob: reset cast history
    if mob_id ~= debuff_state.mob_id then
        info(string.format("New mob detected (ID: \\ag%d\\ay) — resetting debuff cast history.", mob_id))
        debuff_state.mob_id   = mob_id
        debuff_state.cast_map = {}
    end

    -- Nothing left to check for this mob — skip the HP read entirely.
    local pending = false
    for _, debuff in ipairs(CONFIG.debuffs) do
        if not debuff_state.cast_map[debuff.name] then
            pending = true
            break
        end
    end
    if not pending then return end

    -- We are already targeting the mob directly via /assist above, so
    -- PctHPs() here is a real, live reading.
    local mob_hp = mq.TLO.Target.PctHPs() or 0

    for _, debuff in ipairs(CONFIG.debuffs) do
        if not debuff_state.cast_map[debuff.name] and mob_hp <= debuff.trigger_pct then
            info(string.format("Casting debuff [\\ag%s\\ay] on mob (ID: \\ag%d\\ay, HP: \\ag%d%%\\ay <= trigger: \\ag%d%%\\ay)",
                debuff.name, mob_id, mob_hp, debuff.trigger_pct
            ))
            -- Re-confirm target hasn't changed mid-loop before casting.
            if mq.TLO.Target.ID() == mob_id then
                cast_gem(debuff.gem, debuff.cast_time)
                debuff_state.cast_map[debuff.name] = true
                info(string.format("Debuff [\\ag%s\\ay] applied to mob ID \\ag%d\\ay.", debuff.name, mob_id))
                announce(string.format('Debuffed mob ID %d with %s (HP: %d%%)', mob_id, debuff.name, mob_hp))
            else
                info(string.format("WARNING: Lost target on mob ID \\ag%d\\ay for debuff [\\ag%s\\ay]", mob_id, debuff.name
                ))
            end
        end
    end
end

-- ============================================================
--  BUFF PASS  (runs last — lowest priority)
-- ============================================================

--- Apply a single buff to a character if needed.
---@param char_name string
---@param buff      table
local function apply_buff_to(char_name, buff)
    local ticks = get_buff_ticks(char_name, buff.name)
    if ticks <= buff.min_ticks then
        info(string.format("Recasting [\\ag%s\\ay] on [\\ag%s\\ay] (ticks left: \\ag%d\\ay / threshold: \\ag%d\\ay)",
            buff.name, char_name, ticks, buff.min_ticks
        ))
        if target_spawn(char_name) then
            cast_gem(buff.gem, buff.cast_time)
            info(string.format("Buff cast complete: [\\ag%s\\ay] -> [\\ag%s\\ay]", buff.name, char_name))
            announce(string.format('Cast %s on %s', buff.name, char_name))
        else
            info(string.format("WARNING: Could not target [\\ag%s\\ay] for [\\ag%s\\ay]", char_name, buff.name))
        end
    end
end

local function manage_buffs()
    if CONFIG.pause_buffs_in_combat and mq.TLO.Me.CombatState() == "COMBAT" then
        return
    end

    if (mq.TLO.Me.PctMana() or 0) < CONFIG.min_mana_pct then
        info(string.format("Mana low (\\ag%d%%\\ay), skipping buffs.", mq.TLO.Me.PctMana()))
        return
    end

    -- Self-only buffs
    for _, buff in ipairs(CONFIG.self_buffs) do
        apply_buff_to("self", buff)
    end

    -- Shared buffs applied to every monitored target
    for _, t in ipairs(CONFIG.targets) do
        local spawn = mq.TLO.Spawn(t.name)
        if spawn and spawn() then
            for _, buff in ipairs(CONFIG.buffs) do
                apply_buff_to(t.name, buff)
            end
        else
            info(string.format("Target [\\ag%s\\ay] not visible — skipping buffs", t.name))
        end
    end
end

-- ============================================================
--  FOLLOW
-- ============================================================

--- Return the 2D distance to a named spawn, or nil if not found.
---@param name string
---@return number|nil
local function distance_to(name)
    local spawn = mq.TLO.Spawn(name)
    if spawn and spawn() then
        return spawn.Distance()
    end
    return nil
end

--- Maintain a CONFIG.follow_distance-foot follow distance behind the
--- debuff tank using MQ2Nav (set via FollowDistance in the INI).
---
--- Logic:
---   - If farther than CONFIG.follow_distance and not already navigating,
---     issue /nav spawn <tank> |distance=<follow_distance> to close the gap.
---   - If within CONFIG.follow_distance and nav is active, stop nav so we
---     don't slide right up to the tank's feet.
---   - If follow is toggled off, stop any active navigation immediately.
local function manage_follow()
    if CONFIG.debuff_tank == '' then return end

    if not gui.follow then
        if mq.TLO.Navigation.Active() then
            mq.cmd('/nav stop')
        end
        return
    end

    local dist = distance_to(CONFIG.debuff_tank)
    if not dist then return end  -- tank not visible

    if dist > CONFIG.follow_distance then
        -- Too far away — navigate toward the tank, stopping the configured distance out
        if not mq.TLO.Navigation.Active() then
            mq.cmdf('/nav spawn %s |distance=%d', CONFIG.debuff_tank, CONFIG.follow_distance)
        end
    else
        -- Within range — stop nav so we don't overshoot
        if mq.TLO.Navigation.Active() then
            mq.cmd('/nav stop')
        end
    end
end

-- ============================================================
--  IMGUI WINDOW
-- ============================================================

--- Draw the KeepToonBuffed control window.
--- Called every frame by mq.imgui.init(); must not yield or sleep.
---
--- ImGuiWindowFlags raw integer values (no global enum table in MQ Lua):
---   NoResize         = 1 << 1  =  2
---   AlwaysAutoResize = 1 << 6  = 64
---   NoCollapse       = 1 << 5  = 32
--- LuaJIT 2.1 (Lua 5.1) has no | operator; use bit.bor() instead.
local WIN_FLAGS = bit.bor(2, 64, 32)  -- NoResize | AlwaysAutoResize | NoCollapse

-- Forward declaration: defined further down, but the GUI's "Show Settings"
-- button (in draw_gui, below) needs to call it.
local announce_config

--- ImGuiCol integer constants used with PushStyleColor:
---   Button        = 21
---   ButtonHovered = 22
---   ButtonActive  = 23
local COL_BUTTON         = 21
local COL_BUTTON_HOVERED = 22
local COL_BUTTON_ACTIVE  = 23
local COL_TEXT           = 0

local function draw_gui()
    if not gui.open then return end

    gui.open = imgui.Begin('KeepToonBuffed', gui.open, WIN_FLAGS)

    -- Status indicator — TextColored takes four separate r,g,b,a floats in MQ Lua
    if gui.paused then
        imgui.TextColored(1.0, 0.6, 0.0, 1.0, 'Status: PAUSED')    -- orange
    else
        imgui.TextColored(0.0, 0.9, 0.0, 1.0, 'Status: RUNNING')   -- green
    end

    imgui.Separator()

    -- Character & mana info
    imgui.Text('Char : ' .. CHAR_NAME)
    imgui.Text(string.format('Mana : %d%%', mq.TLO.Me.PctMana() or 0))

    imgui.Separator()

    -- Debuff tank being monitored for NPC-target debuffing
    local debuff_tank_label = CONFIG.debuff_tank ~= '' and CONFIG.debuff_tank or 'None set'
    imgui.Text('Debuff Tank : ' .. debuff_tank_label)

    -- Self-heal status
    if CONFIG.self_heal_enabled then
        imgui.Text(string.format('Self-Heal : ON  (<=%d%% -> %s)', CONFIG.self_heal_pct, CONFIG.self_heal_spell))
    else
        imgui.Text('Self-Heal : OFF')
    end

    imgui.Separator()

    -- Pause / Resume toggle — label and behaviour swap each frame
    if gui.paused then
        if imgui.Button('Resume##ktb', 120, 0) then
            gui.paused = false
            info('Resumed by GUI.')
        end
    else
        if imgui.Button('Pause##ktb', 120, 0) then
            gui.paused = true
            info('Paused by GUI.')
        end
    end

    imgui.SameLine()

    -- Exit button styled red; PushStyleColor takes (col_index, r, g, b, a)
    imgui.PushStyleColor(COL_BUTTON,         0.7, 0.1, 0.1, 1.0)
    imgui.PushStyleColor(COL_BUTTON_HOVERED, 0.9, 0.2, 0.2, 1.0)
    imgui.PushStyleColor(COL_BUTTON_ACTIVE,  1.0, 0.0, 0.0, 1.0)
    if imgui.Button('Exit##ktb', 80, 0) then
        gui.exit = true
        info('Exited by GUI.')
    end
    imgui.PopStyleColor(3)

    imgui.Separator()

    -- Follow toggle — green when active, grey when off
    local tank_label = CONFIG.debuff_tank ~= '' and CONFIG.debuff_tank or 'No tank set'
    if gui.follow then
        imgui.PushStyleColor(COL_BUTTON,         0.0, 0.6, 0.0, 1.0)
        imgui.PushStyleColor(COL_BUTTON_HOVERED, 0.0, 0.8, 0.0, 1.0)
        imgui.PushStyleColor(COL_BUTTON_ACTIVE,  0.0, 1.0, 0.0, 1.0)
        if imgui.Button('Following: ' .. tank_label .. '##follow', -1, 0) then
            gui.follow = false
            mq.cmd('/nav stop')
            info('Follow stopped by GUI.')
        end
        imgui.PopStyleColor(3)
    else
        if imgui.Button('Follow: ' .. tank_label .. '##follow', -1, 0) then
            if CONFIG.debuff_tank ~= '' then
                gui.follow = true
                info('Follow started by GUI: \\ag' .. CONFIG.debuff_tank .. '\\ay')
            else
                info('Cannot follow: DebuffTank not set in INI.')
            end
        end
    end

    imgui.Separator()

    -- Debuff toggle — green when active, grey when off
    if gui.debuff then
        imgui.PushStyleColor(COL_BUTTON,         0.0, 0.6, 0.0, 1.0)
        imgui.PushStyleColor(COL_BUTTON_HOVERED, 0.0, 0.8, 0.0, 1.0)
        imgui.PushStyleColor(COL_BUTTON_ACTIVE,  0.0, 1.0, 0.0, 1.0)
        if imgui.Button('Debuffs: ON##debuff', -1, 0) then
            gui.debuff = false
            info('Debuff monitoring disabled by GUI.')
        end
        imgui.PopStyleColor(3)
    else
        if imgui.Button('Debuffs: OFF##debuff', -1, 0) then
            gui.debuff = true
            info('Debuff monitoring enabled by GUI.')
        end
    end

    -- Announce toggle — green when active, grey when off
    if gui.announce then
        imgui.PushStyleColor(COL_BUTTON,         0.0, 0.6, 0.0, 1.0)
        imgui.PushStyleColor(COL_BUTTON_HOVERED, 0.0, 0.8, 0.0, 1.0)
        imgui.PushStyleColor(COL_BUTTON_ACTIVE,  0.0, 1.0, 0.0, 1.0)
        if imgui.Button('Announce: ON##announce', -1, 0) then
            gui.announce = false
            info('Announce disabled by GUI.')
        end
        imgui.PopStyleColor(3)
    else
        if imgui.Button('Announce: OFF##announce', -1, 0) then
            if CONFIG.debuff_tank ~= '' then
                gui.announce = true
                info('Announce enabled by GUI — will /tell \\ag' .. CONFIG.debuff_tank .. '\\ay on heal/buff/debuff casts.')
            else
                info('Cannot enable Announce: DebuffTank not set in INI.')
            end
        end
    end

    imgui.Separator()

    -- Show Settings — yellow background, black text; dumps full config to console
    imgui.PushStyleColor(COL_BUTTON,         1.0, 1.0, 0.0, 1.0)
    imgui.PushStyleColor(COL_BUTTON_HOVERED, 1.0, 0.95, 0.3, 1.0)
    imgui.PushStyleColor(COL_BUTTON_ACTIVE,  0.9, 0.85, 0.0, 1.0)
    imgui.PushStyleColor(COL_TEXT,           0.0, 0.0, 0.0, 1.0)
    if imgui.Button('Show Settings##showsettings', -1, 0) then
        announce_config()
    end
    imgui.PopStyleColor(4)

    imgui.End()
end

-- Register the ImGui callback — runs every rendered frame
mq.imgui.init('KeepToonBuffed', draw_gui)

-- ============================================================
--  MAIN LOOP
-- ============================================================

--- Echo a detailed breakdown of the loaded configuration to the chat window:
--- every target, buff, self-buff, debuff, and heal spell, one line each.
function announce_config()
    info("\aw========================================\ay")
    info(string.format("Config loaded from: \\ag%s\\ay", INI_PATH))

    info(string.format("LoopInterval: \\ag%ds\\ay   MinManaPct: \\ag%d%%\\ay   PauseBuffsInCombat: \\ag%s\\ay",
        CONFIG.loop_interval, CONFIG.min_mana_pct, tostring(CONFIG.pause_buffs_in_combat)
    ))

    if CONFIG.debuff_tank ~= "" then
        info(string.format("Debuff Tank: [\\ag%s\\ay]", CONFIG.debuff_tank))
    else
        info("Debuff Tank: none configured")
    end
    info(string.format("AutoFollow: \\ag%s\\ay   FollowDistance: \\ag%d\\ayft   Announce: \\ag%s\\ay   DebuffMobs: \\ag%s\\ay",
        tostring(CONFIG.auto_follow), CONFIG.follow_distance, tostring(CONFIG.announce), tostring(CONFIG.debuff_mobs)
    ))

    if CONFIG.self_heal_enabled then
        info(string.format("Self-Heal: \\ag%s\\ay  HealAt: \\ag%d%%\\ay  Gem: \\ag%d\\ay  CastTime: \\ag%d\\ayms",
            CONFIG.self_heal_spell, CONFIG.self_heal_pct, CONFIG.self_heal_gem, CONFIG.self_heal_cast
        ))
    else
        info("Self-Heal: disabled")
    end

    info("\aw========================================\ay")

    -- Targets — also doubles as the list of heal spells in use
    if #CONFIG.targets == 0 then
        info("Targets: none configured")
    else
        for i, t in ipairs(CONFIG.targets) do
            info(string.format("Target \\ag%d\\ay: [\\ag%s\\ay]  HealAt: \\ag%d%%\\ay  HealSpell: [\\ag%s\\ay]  Gem: \\ag%d\\ay  CastTime: \\ag%d\\ayms",
                i, t.name, t.heal_pct, t.heal_spell, t.heal_gem, t.heal_cast
            ))
        end
    end

    -- Shared buffs
    if #CONFIG.buffs == 0 then
        info("Buffs: none configured")
    else
        for i, b in ipairs(CONFIG.buffs) do
            info(string.format("Buff \\ag%d\\ay: [\\ag%s\\ay]  MinTicks: \\ag%d\\ay  Gem: \\ag%d\\ay  CastTime: \\ag%d\\ayms",
                i, b.name, b.min_ticks, b.gem, b.cast_time
            ))
        end
    end

    -- Self buffs
    if #CONFIG.self_buffs == 0 then
        info("Self Buffs: none configured")
    else
        for i, b in ipairs(CONFIG.self_buffs) do
            info(string.format("Self Buff \\ag%d\\ay: [\\ag%s\\ay]  MinTicks: \\ag%d\\ay  Gem: \\ag%d\\ay  CastTime: \\ag%d\\ayms",
                i, b.name, b.min_ticks, b.gem, b.cast_time
            ))
        end
    end

    -- Debuffs
    if #CONFIG.debuffs == 0 then
        info("Debuffs: none configured")
    else
        for i, d in ipairs(CONFIG.debuffs) do
            info(string.format("Debuff \\ag%d\\ay: [\\ag%s\\ay]  TriggerHP: \\ag%d%%\\ay  Gem: \\ag%d\\ay  CastTime: \\ag%d\\ayms",
                i, d.name, d.trigger_pct, d.gem, d.cast_time
            ))
        end
    end

    info("\aw========================================\ay")
end

announce_config()

while not gui.exit do
    mq.doevents()

    if not gui.open then
        -- Re-show the window if the user closed it with the X;
        -- closing should not stop the script, only hide the window.
        gui.open = true
    end

    if mq.TLO.Me.Zoning() then
        mq.delay(2000)
    else
        manage_follow()   -- 0. Follow     — always runs regardless of pause state
        if not gui.paused then
            manage_heals()    -- 1. Healing    — highest priority
            manage_debuffs()  -- 2. Debuffs    — once per mob at HP thresholds
            manage_buffs()    -- 3. Buffs      — lowest priority
        end
    end

    mq.delay(CONFIG.loop_interval * 1000)
end

info("KeepToonBuffed stopped.")
