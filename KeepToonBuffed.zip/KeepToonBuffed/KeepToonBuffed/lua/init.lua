--[[
    KeepToonBuffed.lua
    MacroQuest Lua Script

    Features:
      - All configuration loaded from buffhealer.ini (no hardcoded values)
      - Single target list drives both buff monitoring AND heal monitoring
      - Recasts buffs on each target when they expire or fall below a tick threshold
      - Heals each target when their HP drops below a configured threshold
      - Heals always fire before buff maintenance each loop
      - Watches a designated tank's current NPC target and casts debuffs on the mob
        when the mob's HP falls at or below each debuff's configured trigger percentage
      - Each debuff is cast once per mob and not repeated until a new mob is engaged
      - Skips buff casting while in combat (configurable)
      - Skips all casting when mana is below a minimum threshold
      - ImGui window with Pause/Resume and Stop buttons for in-game control

    Requirements:
      - MacroQuest with Lua support (mq.TLO, mq.cmd)
      - buffhealer.ini must be in the MacroQuest config directory (mq.configDir, e.g. MacroQuest/config/)
      - All spells must be memorized in the gem slots defined in the INI

    Usage:
      /lua run KeepToonBuffed
--]]

local mq    = require('mq')
local imgui = require('ImGui')
local bit   = require('bit')

-- ============================================================
--  INI PARSER
-- ============================================================

--- mq.configDir is a string property built into the MacroQuest Lua runtime.
--- It resolves to the absolute path of the MQ config folder at runtime
--- (e.g. C:\\MacroQuest\\config) and is the correct way to locate INI files.
--- Build the INI filename dynamically using the logged-in character's name,
--- following the MacroQuest convention of per-character config files.
--- e.g. MacroQuest/config/KeepToonBuffed_Charname.ini
-- mq.TLO.Me is not available until the first game frame has been processed.
-- Yield one frame with mq.delay(0) so the engine populates the Me TLO,
-- then resolve the character name before anything else runs.
mq.delay(0)
local CHAR_NAME = mq.TLO.Me.Name() or 'Unknown'
local INI_PATH  = mq.configDir .. '/KeepToonBuffed_' .. CHAR_NAME .. '.ini'

--- Parse a simple INI file into a nested table: result[section][key] = value.
--- Lines beginning with ; or # are treated as comments and ignored.
---@param path string
---@return table
local function parse_ini(path)
    local result  = {}
    local section = "default"

    local fh, err = io.open(path, "r")
    if not fh then
        error("[BuffHealer] Cannot open INI file: " .. path .. "\n" .. (err or ""))
    end

    for line in fh:lines() do
        -- Strip leading/trailing whitespace
        line = line:match("^%s*(.-)%s*$")

        -- Skip blank lines and comment lines
        if line == "" or line:sub(1, 1) == ";" or line:sub(1, 1) == "#" then
            -- nothing

        -- Section header  [SectionName]
        elseif line:match("^%[.+%]$") then
            section = line:match("^%[(.+)%]$")
            if not result[section] then result[section] = {} end

        -- Key=Value pair
        elseif line:find("=") then
            local k, v = line:match("^([^=]+)=(.*)$")
            if k and v then
                k = k:match("^%s*(.-)%s*$")
                v = v:match("^%s*(.-)%s*$")
                if not result[section] then result[section] = {} end
                result[section][k] = v
            end
        end
    end

    fh:close()
    return result
end

--- Extract all ordered list entries (Key1, Key2, …) from an INI section.
--- Returns them as an array of raw value strings, in numeric order.
---@param section table   A section sub-table from parse_ini()
---@return string[]
local function get_list(section)
    if not section then return {} end
    local items = {}
    local i = 1
    while true do
        local v = section["Key" .. i]
        if not v then break end
        items[#items + 1] = v
        i = i + 1
    end
    return items
end

--- Split a pipe-delimited string and trim each field.
---@param s string
---@return string[]
local function split_pipe(s)
    local parts = {}
    for part in s:gmatch("([^|]+)") do
        parts[#parts + 1] = part:match("^%s*(.-)%s*$")
    end
    return parts
end

--- Convert a string to a boolean (case-insensitive "true"/"1" → true).
---@param s string
---@return boolean
local function to_bool(s)
    return s == "true" or s == "1" or s == "yes"
end

-- ============================================================
--  LOAD CONFIGURATION FROM INI
-- ============================================================

local function load_config(path)
    local ini = parse_ini(path)

    local cfg = {}

    -- [Settings] -----------------------------------------------
    local s = ini["Settings"] or {}
    cfg.loop_interval        = tonumber(s["LoopInterval"])        or 3
    cfg.min_mana_pct         = tonumber(s["MinManaPct"])          or 20
    cfg.pause_buffs_in_combat = to_bool(s["PauseBuffsInCombat"]  or "true")
    cfg.debuff_tank          = s["DebuffTank"] or ""

    -- [Targets] ------------------------------------------------
    -- Format: Name | HealPct | HealSpell | HealGem | HealCastMs
    cfg.targets = {}
    for _, raw in ipairs(get_list(ini["Targets"])) do
        local f = split_pipe(raw)
        if #f >= 5 then
            cfg.targets[#cfg.targets + 1] = {
                name       = f[1],
                heal_pct   = tonumber(f[2]) or 70,
                heal_spell = f[3],
                heal_gem   = tonumber(f[4]) or 1,
                heal_cast  = tonumber(f[5]) or 2500,
            }
        else
            mq.cmd("/echo [BuffHealer] WARNING: Malformed [Targets] entry: " .. raw)
        end
    end

    -- [Buffs] --------------------------------------------------
    -- Format: Name | MinTicks | Gem | CastTimeMs
    cfg.buffs = {}
    for _, raw in ipairs(get_list(ini["Buffs"])) do
        local f = split_pipe(raw)
        if #f >= 4 then
            cfg.buffs[#cfg.buffs + 1] = {
                name      = f[1],
                min_ticks = tonumber(f[2]) or 0,
                gem       = tonumber(f[3]) or 1,
                cast_time = tonumber(f[4]) or 2000,
            }
        else
            mq.cmd("/echo [BuffHealer] WARNING: Malformed [Buffs] entry: " .. raw)
        end
    end

    -- [SelfBuffs] ----------------------------------------------
    -- Format: Name | MinTicks | Gem | CastTimeMs
    cfg.self_buffs = {}
    for _, raw in ipairs(get_list(ini["SelfBuffs"])) do
        local f = split_pipe(raw)
        if #f >= 4 then
            cfg.self_buffs[#cfg.self_buffs + 1] = {
                name      = f[1],
                min_ticks = tonumber(f[2]) or 0,
                gem       = tonumber(f[3]) or 1,
                cast_time = tonumber(f[4]) or 2000,
            }
        else
            mq.cmd("/echo [BuffHealer] WARNING: Malformed [SelfBuffs] entry: " .. raw)
        end
    end

    -- [Debuffs] ------------------------------------------------
    -- Format: Name | TriggerPct | Gem | CastTimeMs
    cfg.debuffs = {}
    for _, raw in ipairs(get_list(ini["Debuffs"])) do
        local f = split_pipe(raw)
        if #f >= 4 then
            cfg.debuffs[#cfg.debuffs + 1] = {
                name        = f[1],
                trigger_pct = tonumber(f[2]) or 100,
                gem         = tonumber(f[3]) or 1,
                cast_time   = tonumber(f[4]) or 2000,
            }
        else
            mq.cmd("/echo [BuffHealer] WARNING: Malformed [Debuffs] entry: " .. raw)
        end
    end

    return cfg
end

-- Load once at startup; reload by restarting the script.
local CONFIG = load_config(INI_PATH)

-- ============================================================
--  UTILITY FUNCTIONS
-- ============================================================

--- Print a labelled message to the MQ console.
---@param msg string
local function info(msg)
    mq.cmd('/echo [BuffHealer] ' .. tostring(msg))
end

--- Return remaining ticks on a buff for a named spawn, or 0 if absent.
---@param spawn_name string  Player name, or "self"
---@param buff_name  string
---@return number
local function get_buff_ticks(spawn_name, buff_name)
    local b
    if spawn_name == "self" then
        b = mq.TLO.Me.Buff(buff_name)
    else
        local spawn = mq.TLO.Spawn(spawn_name)
        if spawn and spawn() then
            b = spawn.Buff(buff_name)
        end
    end
    if b and b.Duration() then
        -- Duration() is in ms; 6 000 ms = 1 EQ tick
        return math.floor(b.Duration() / 6000)
    end
    return 0
end

--- Return HP percentage for a named character, or 0 if not found/visible.
---@param name string
---@return number
local function get_hp_pct(name)
    local spawn = mq.TLO.Spawn(name)
    if spawn and spawn() then
        return spawn.PctHPs() or 0
    end
    return 0
end

--- Return true while a spell is being cast.
---@return boolean
local function is_casting()
    return mq.TLO.Me.Casting() ~= nil
end

--- Block until casting finishes or timeout_ms elapses.
---@param timeout_ms number
local function wait_for_cast(timeout_ms)
    local elapsed, poll = 0, 100
    while elapsed < timeout_ms do
        if not is_casting() then return end
        mq.delay(poll)
        elapsed = elapsed + poll
    end
end

--- Target a named character.  Returns true when the target window confirms the name.
---@param name string  Player name, or "self"
---@return boolean
local function target_spawn(name)
    local actual = (name == 'self') and CHAR_NAME or name
    mq.cmd('/target ' .. actual)
    mq.delay(300)
    -- Access Target members directly; mq.TLO.Target.Name() not mq.TLO.Target().Name()
    local tname = mq.TLO.Target.Name()
    return tname ~= nil and tname == actual
end

--- Cast the spell in gem slot `gem` and wait for completion.
---@param gem       number  Gem slot (1-12)
---@param cast_time number  Expected cast duration in ms
local function cast_gem(gem, cast_time)
    mq.cmd('/cast ' .. gem)
    mq.delay(500)
    wait_for_cast(cast_time + 2000)   -- +2 s safety margin
    mq.delay(500)
end

-- ============================================================
--  HEAL PASS  (runs first — highest priority)
-- ============================================================

local function manage_heals()
    if (mq.TLO.Me.PctMana() or 0) < CONFIG.min_mana_pct then
        info(string.format("Mana low (%d%%), skipping heals.", mq.TLO.Me.PctMana()))
        return
    end

    for _, t in ipairs(CONFIG.targets) do
        local hp = get_hp_pct(t.name)
        if hp == 0 then
            -- Target not visible / out of range — skip silently
        elseif hp <= t.heal_pct then
            info(string.format("Healing [%s] at %d%% HP with [%s]", t.name, hp, t.heal_spell))
            if target_spawn(t.name) then
                cast_gem(t.heal_gem, t.heal_cast)
                info(string.format("Heal complete -> [%s]", t.name))
            else
                info(string.format("WARNING: Could not target [%s] for healing", t.name))
            end
        end
    end
end

-- ============================================================
--  DEBUFF PASS  (runs second)
-- ============================================================

-- Tracks which debuffs have already landed on the current mob.
-- Reset automatically whenever the tank acquires a new NPC target.
local debuff_state = {
    mob_id   = nil,
    cast_map = {},
}

--- Return SpawnID and HP% of the tank's current NPC target, or nil if unavailable.
---@return number|nil spawn_id
---@return number     hp_pct
local function get_tank_target_info()
    if CONFIG.debuff_tank == "" then return nil, 0 end

    local tot = mq.TLO.Spawn(CONFIG.debuff_tank).TargetOfTarget
    if tot and tot() then
        local id  = tot.ID()
        local hp  = tot.PctHPs() or 0
        local typ = tot.Type() or ""
        if id and id > 0 and typ ~= "PC" and typ ~= "Corpse" then
            return id, hp
        end
    end
    return nil, 0
end

--- Cast configured debuffs on the tank's mob target as HP thresholds are met.
local function manage_debuffs()
    if #CONFIG.debuffs == 0 then return end
    if (mq.TLO.Me.PctMana() or 0) < CONFIG.min_mana_pct then return end

    local mob_id, mob_hp = get_tank_target_info()

    if not mob_id then
        if debuff_state.mob_id ~= nil then
            info("Tank has no NPC target — resetting debuff state.")
            debuff_state.mob_id   = nil
            debuff_state.cast_map = {}
        end
        return
    end

    -- New mob: reset cast history
    if mob_id ~= debuff_state.mob_id then
        info(string.format("New mob detected (ID: %d) — resetting debuff cast history.", mob_id))
        debuff_state.mob_id   = mob_id
        debuff_state.cast_map = {}
    end

    for _, debuff in ipairs(CONFIG.debuffs) do
        if not debuff_state.cast_map[debuff.name] and mob_hp <= debuff.trigger_pct then
            info(string.format(
                "Casting debuff [%s] on mob (ID: %d, HP: %d%% <= trigger: %d%%)",
                debuff.name, mob_id, mob_hp, debuff.trigger_pct
            ))
            mq.cmd('/target id ' .. mob_id)
            mq.delay(400)
            -- Access Target members directly on the TLO, not via ()
            local tid = mq.TLO.Target.ID()
            if tid and tid == mob_id then
                cast_gem(debuff.gem, debuff.cast_time)
                debuff_state.cast_map[debuff.name] = true
                info(string.format("Debuff [%s] applied to mob ID %d.", debuff.name, mob_id))
            else
                info(string.format(
                    "WARNING: Could not target mob ID %d for debuff [%s]", mob_id, debuff.name
                ))
            end
        end
    end
end

-- ============================================================
--  BUFF PASS  (runs last — lowest priority)
-- ============================================================

--- Apply a single buff to a character if needed.
---@param char_name string
---@param buff      table
local function apply_buff_to(char_name, buff)
    local ticks = get_buff_ticks(char_name, buff.name)
    if ticks <= buff.min_ticks then
        info(string.format(
            "Recasting [%s] on [%s] (ticks left: %d / threshold: %d)",
            buff.name, char_name, ticks, buff.min_ticks
        ))
        if target_spawn(char_name) then
            cast_gem(buff.gem, buff.cast_time)
            info(string.format("Buff cast complete: [%s] -> [%s]", buff.name, char_name))
        else
            info(string.format("WARNING: Could not target [%s] for [%s]", char_name, buff.name))
        end
    end
end

local function manage_buffs()
    if CONFIG.pause_buffs_in_combat and mq.TLO.Me.CombatState() == "COMBAT" then
        return
    end

    if (mq.TLO.Me.PctMana() or 0) < CONFIG.min_mana_pct then
        info(string.format("Mana low (%d%%), skipping buffs.", mq.TLO.Me.PctMana()))
        return
    end

    -- Self-only buffs
    for _, buff in ipairs(CONFIG.self_buffs) do
        apply_buff_to("self", buff)
    end

    -- Shared buffs applied to every monitored target
    for _, t in ipairs(CONFIG.targets) do
        local spawn = mq.TLO.Spawn(t.name)
        if spawn and spawn() then
            for _, buff in ipairs(CONFIG.buffs) do
                apply_buff_to(t.name, buff)
            end
        else
            info(string.format("Target [%s] not visible — skipping buffs", t.name))
        end
    end
end

-- ============================================================
--  GUI STATE
-- ============================================================

local gui = {
    open    = true,   -- window visibility (closing hides but does not stop)
    paused  = true,   -- when true the logic passes are skipped each loop
    exit    = false,  -- set to true to break the main loop and exit
    follow  = false,  -- when true the script issues /nav follow on the debuff tank
}

-- ============================================================
--  FOLLOW
-- ============================================================

--- Follow distance in feet — stay within this range of the tank.
local FOLLOW_DISTANCE = 30

--- Return the 2D distance to a named spawn, or nil if not found.
---@param name string
---@return number|nil
local function distance_to(name)
    local spawn = mq.TLO.Spawn(name)
    if spawn and spawn() then
        return spawn.Distance()
    end
    return nil
end

--- Maintain a ~30-foot follow distance behind the debuff tank using MQ2Nav.
---
--- Logic:
---   - If farther than FOLLOW_DISTANCE and not already navigating, issue
---     /nav spawn <tank> |distance=30 to close the gap.
---   - If within FOLLOW_DISTANCE and nav is active, stop nav so we don't
---     slide right up to the tank's feet.
---   - If follow is toggled off, stop any active navigation immediately.
local function manage_follow()
    if CONFIG.debuff_tank == '' then return end

    if not gui.follow then
        if mq.TLO.Navigation.Active() then
            mq.cmd('/nav stop')
        end
        return
    end

    local dist = distance_to(CONFIG.debuff_tank)
    if not dist then return end  -- tank not visible

    if dist > FOLLOW_DISTANCE then
        -- Too far away — navigate toward the tank, stopping 30 ft out
        if not mq.TLO.Navigation.Active() then
            mq.cmdf('/nav spawn %s |distance=%d', CONFIG.debuff_tank, FOLLOW_DISTANCE)
        end
    else
        -- Within range — stop nav so we don't overshoot
        if mq.TLO.Navigation.Active() then
            mq.cmd('/nav stop')
        end
    end
end

-- ============================================================
--  IMGUI WINDOW
-- ============================================================

--- Draw the KeepToonBuffed control window.
--- Called every frame by mq.imgui.init(); must not yield or sleep.
---
--- ImGuiWindowFlags raw integer values (no global enum table in MQ Lua):
---   NoResize         = 1 << 1  =  2
---   AlwaysAutoResize = 1 << 6  = 64
---   NoCollapse       = 1 << 5  = 32
--- LuaJIT 2.1 (Lua 5.1) has no | operator; use bit.bor() instead.
local WIN_FLAGS = bit.bor(2, 64, 32)  -- NoResize | AlwaysAutoResize | NoCollapse

--- ImGuiCol integer constants used with PushStyleColor:
---   Button        = 21
---   ButtonHovered = 22
---   ButtonActive  = 23
local COL_BUTTON         = 21
local COL_BUTTON_HOVERED = 22
local COL_BUTTON_ACTIVE  = 23

local function draw_gui()
    if not gui.open then return end

    gui.open = imgui.Begin('KeepToonBuffed', gui.open, WIN_FLAGS)

    -- Status indicator — TextColored takes four separate r,g,b,a floats in MQ Lua
    if gui.paused then
        imgui.TextColored(1.0, 0.6, 0.0, 1.0, 'Status: PAUSED')    -- orange
    else
        imgui.TextColored(0.0, 0.9, 0.0, 1.0, 'Status: RUNNING')   -- green
    end

    imgui.Separator()

    -- Character & mana info
    imgui.Text('Char : ' .. CHAR_NAME)
    imgui.Text(string.format('Mana : %d%%', mq.TLO.Me.PctMana() or 0))

    imgui.Separator()

    -- Pause / Resume toggle — label and behaviour swap each frame
    if gui.paused then
        if imgui.Button('Resume##ktb', 120, 0) then
            gui.paused = false
            info('Resumed by GUI.')
        end
    else
        if imgui.Button('Pause##ktb', 120, 0) then
            gui.paused = true
            info('Paused by GUI.')
        end
    end

    imgui.SameLine()

    -- Exit button styled red; PushStyleColor takes (col_index, r, g, b, a)
    imgui.PushStyleColor(COL_BUTTON,         0.7, 0.1, 0.1, 1.0)
    imgui.PushStyleColor(COL_BUTTON_HOVERED, 0.9, 0.2, 0.2, 1.0)
    imgui.PushStyleColor(COL_BUTTON_ACTIVE,  1.0, 0.0, 0.0, 1.0)
    if imgui.Button('Exit##ktb', 80, 0) then
        gui.exit = true
        info('Exited by GUI.')
    end
    imgui.PopStyleColor(3)

    imgui.Separator()

    -- Follow toggle — green when active, grey when off
    local tank_label = CONFIG.debuff_tank ~= '' and CONFIG.debuff_tank or 'No tank set'
    if gui.follow then
        imgui.PushStyleColor(COL_BUTTON,         0.0, 0.6, 0.0, 1.0)
        imgui.PushStyleColor(COL_BUTTON_HOVERED, 0.0, 0.8, 0.0, 1.0)
        imgui.PushStyleColor(COL_BUTTON_ACTIVE,  0.0, 1.0, 0.0, 1.0)
        if imgui.Button('Following: ' .. tank_label .. '##follow', -1, 0) then
            gui.follow = false
            mq.cmd('/nav stop')
            info('Follow stopped by GUI.')
        end
        imgui.PopStyleColor(3)
    else
        if imgui.Button('Follow: ' .. tank_label .. '##follow', -1, 0) then
            if CONFIG.debuff_tank ~= '' then
                gui.follow = true
                info('Follow started by GUI: ' .. CONFIG.debuff_tank)
            else
                info('Cannot follow: DebuffTank not set in INI.')
            end
        end
    end

    imgui.End()
end

-- Register the ImGui callback — runs every rendered frame
mq.imgui.init('KeepToonBuffed', draw_gui)

-- ============================================================
--  MAIN LOOP
-- ============================================================

info("KeepToonBuffed started — config loaded from: " .. INI_PATH)
info(string.format(
    "Targets: %d  |  Buffs/target: %d  |  Self buffs: %d  |  Debuffs: %d  |  Loop: %ds",
    #CONFIG.targets, #CONFIG.buffs, #CONFIG.self_buffs,
    #CONFIG.debuffs, CONFIG.loop_interval
))
if CONFIG.debuff_tank ~= "" then
    info(string.format("Debuff tank: [%s]", CONFIG.debuff_tank))
end

while not gui.exit do
    mq.doevents()

    if not gui.open then
        -- Re-show the window if the user closed it with the X;
        -- closing should not stop the script, only hide the window.
        gui.open = true
    end

    if mq.TLO.Me.Zoning() then
        mq.delay(2000)
    else
        manage_follow()   -- 0. Follow     — always runs regardless of pause state
        if not gui.paused then
            manage_heals()    -- 1. Healing    — highest priority
            manage_debuffs()  -- 2. Debuffs    — once per mob at HP thresholds
            manage_buffs()    -- 3. Buffs      — lowest priority
        end
    end

    mq.delay(CONFIG.loop_interval * 1000)
end

info("KeepToonBuffed stopped.")
