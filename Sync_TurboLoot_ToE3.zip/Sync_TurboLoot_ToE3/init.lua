--[[
    sync_loot_settings.lua
    ============================================================

    PURPOSE
    -------
    A MacroQuest ImGui tool that migrates/syncs looting decisions from a
    TurboLoot-style ini file (turboloot.ini) into an e3-style
    "Loot Settings.ini" file.

    The goal is that every item listed in turboloot.ini's [ItemLimits]
    section ends up represented in Loot Settings.ini with an equivalent
    status:
        - If the item does NOT already exist anywhere in Loot Settings.ini,
          it is ADDED under the correct alphabetical [LETTER]/[DIGIT]
          section and the correct status block (Keep/Sell/Skip/Destroy).
        - If the item ALREADY exists in Loot Settings.ini but is filed
          under a different status than turboloot.ini says it should be,
          it is UPDATED (moved) to the status block dictated by
          turboloot.ini. It is not duplicated.
        - If the item already exists with the same status, nothing
          happens (reported as "already in sync").

    Matching between the two files is done by item name only
    (case-insensitive), regardless of which letter section the item is
    currently filed under in Loot Settings.ini.

    INPUT FILE FORMATS
    -------------------
    turboloot.ini:
        Standard Windows-style ini with a [ItemLimits] section of
        "ItemName=VALUE" lines. VALUE is one of:
            ALL, KEEP, SELL, BANK, DESTROY, IGNORE, TRIBUTE, or a plain
            number (meaning "keep until you have this many").
        Only the [ItemLimits] section is read for loot entries. Anything
        BEFORE the [ItemLimits] header (e.g. [Settings], [Wildcards]) is
        ignored, and reading stops entirely once the [GiveList] section
        header is reached - everything from [GiveList] onward (GiveList
        itself, its prefix patterns, and [GiveExclude]) is ignored, since
        those lines are give-away rules, not loot decisions, and would
        otherwise be misread as item entries.

    Loot Settings.ini:
        Organized into [A]..[Z] / [0]..[9] sections. Within each section,
        items are listed as "ItemName=Status" where Status is one of
        Keep, Sell, Skip, Destroy (or any other custom status string
        already present in the file - those are preserved and written
        back out, just sorted after the four known statuses).

    MAPPING (turboloot.ini VALUE -> Loot Settings.ini Status)
    -----------------------------------------------------------
        SELL    -> Sell
        KEEP    -> Keep
        IGNORE  -> Skip
        ALL     -> Keep
        BANK    -> Keep
        DESTROY -> Destroy
        TRIBUTE -> Keep

    UNHANDLED VALUES
    -----------------
    Plain numeric values (e.g. "5", "1000", meaning "loot until you have
    this many") have no Keep/Sell/Skip/Destroy equivalent and are
    intentionally left untouched - they are NOT written to
    Loot Settings.ini. Instead, every such entry is collected and
    surfaced in the "Preview Changes" review panel under a
    "Not Migrated - numeric value" section (and counted in the plan
    summary/log) so the user can see exactly which items were excluded
    and decide whether to handle them manually. This list is sorted
    alphabetically by item name, same as the New Items and Status
    Changes lists. Any turboloot.ini value that is neither a recognized
    keyword above nor a plain number is silently ignored (not added,
    not reported).

    WORKFLOW / SAFETY
    -------------------
    1. Set/browse to the turboloot.ini source and Loot Settings.ini
       target paths in the GUI.
    2. Click "Preview Changes" (planSync) - this is READ-ONLY. It parses
       both files and computes a diff (adds / status changes / already
       in sync / not-migrated numeric entries) without writing anything.
    3. Review the New Items, Status Changes, and Not Migrated lists.
       Each add/change has a checkbox (default checked) so individual
       entries can be excluded from the commit.
    4. Click "Commit Selected" (commitSync) to apply only the checked
       adds/changes. Before writing, the existing Loot Settings.ini is
       backed up to a new numbered file alongside it, e.g.
       "Loot Settings_1.ini", then "Loot Settings_2.ini", and so on -
       starting at 1 and incrementing until an unused number is found,
       so every commit gets its own backup snapshot instead of
       overwriting a single backup file. The file is then rewritten
       with items grouped by [LETTER] section and, within each section,
       ordered Keep/Sell/Skip/Destroy (then any other custom statuses
       alphabetically), with items alphabetized within each status
       block. A BOM is preserved if the original file had one.

    A separate, unrelated maintenance action, "Resort Loot Settings
    ALPHA" (resortAlpha), rewrites Loot Settings.ini so each [LETTER]
    section is one flat alphabetically-sorted list of ItemName=Status
    (ignoring the Keep/Sell/Skip grouping). This also makes a backup
    first, but uses the older single-file "Loot Settings.ini.bak" name
    (overwritten each time) rather than the numbered backups described
    above, since it's a separate action from Commit Selected. It does
    not read or involve turboloot.ini.

    DISPLAY / COLOR CODING
    -------------------------
    The preview lists (New Items, Status Changes, Not Migrated), the plan
    summary line, the section headers' item counts, and the Log panel all
    color VARIABLE data (item names, statuses, counts, paths, section
    keys) differently from the STATIC label text around it, so the two
    are easy to tell apart at a glance without changing the label's own
    color:
        - Item names are light blue.
        - A status being applied (new/target status) is green; a status
          being replaced (old status) is soft red.
        - Secondary static labels (brackets, section, arrows) are gray.
        - "Not migrated" warnings are orange.
        - The plan summary's labels are gold; its counts are bright
          white.
        - Each review section header (e.g. "New Items") keeps its normal
          header color; the "(N)" count next to it is bright white.
        - "Preview Changes" (read-only) has a yellow background with
          black text; "Commit Selected" (writes to disk) has a red
          background with black text, so the two are visually distinct
          by risk level at a glance.
        - Log lines are colored by their leading keyword (ERROR = red,
          ADDED/CHANGED/Committed/Backup = green, source/target/summary
          lines = gold, numeric-value warnings = orange, everything else
          = light gray) - within that colored line, log() automatically
          highlights each substituted value (the ... args passed to a
          %s/%d/etc placeholder) in bright white by walking the format
          string's own specifiers, so e.g. in "Turbo source : %s" the
          label stays the line's category color and the path itself is
          highlighted; in "ADDED [%s] %s = %s" the section key, item
          name, and status are each highlighted individually.
    See the COLOR_* constants near the top of the script to adjust the
    palette.

    FILE BROWSER
    -------------
    The "Browse" popups (for both turboloot.ini and Loot Settings.ini)
    let the user navigate folders and pick a file. The ".. (Up)" button
    is hidden whenever the current folder is already a drive root (e.g.
    "C:" or "C:\"), since there is nothing further up to navigate to -
    this prevents the user from getting stuck at a root with no way back
    into the drive's own folders. Folder listing (listDir) normalizes
    away any trailing slash before building its `dir` command, so a
    drive root passed in as either "C:" or "C:\" lists correctly either
    way (a naively-appended trailing slash would otherwise produce a
    double backslash that the underlying `dir` command can't resolve).

    Requires MacroQuest's Lua + ImGui bindings (mq / ImGui globals).
--]]

local mq    = require('mq')
local ImGui = require('ImGui')

-- join path segments with a single backslash, regardless of whether the
-- preceding segment already ends in one - fixes double-backslash paths
-- (e.g. "C:\" + "\turboloot.ini" -> "C:\\turboloot.ini") that would
-- otherwise occur whenever a base directory already ends in a slash,
-- such as a drive root ("C:\") or a path returned by mq.TLO with a
-- trailing separator already included.
local function joinPath(base, ...)
    local result = (base or ''):gsub('[\\/]+$', '')
    for _, seg in ipairs({ ... }) do
        result = result .. '\\' .. seg
    end
    return result
end

----------------------------------------------------------------------
-- state
----------------------------------------------------------------------

local openGUI        = true
local shouldDrawGUI   = true

local defaultDir      = mq.TLO.MacroQuest.Path('config')() or '.'
local turboPath       = joinPath(defaultDir, 'turboloot.ini')
local lootPath        = joinPath(defaultDir, 'e3 Macro Inis', 'Loot Settings.ini')

local turboBrowseDir   = defaultDir
local lootBrowseDir    = joinPath(defaultDir, 'e3 Macro Inis')
local turboDirs, turboFiles = {}, {}
local lootDirs, lootFiles   = {}, {}

local logLines        = {}
local statusOrder     = { 'Keep', 'Sell', 'Skip', 'Destroy' } -- preferred block order on write
local mappedStatus     = { SELL = 'Sell', KEEP = 'Keep', IGNORE = 'Skip', DESTROY = 'Destroy', ALL = 'Keep', BANK = 'Keep', TRIBUTE = 'Keep' }

----------------------------------------------------------------------
-- color scheme for preview / report display
-- All colors are {r, g, b, a} floats (0-1) passed to ImGui.TextColored.
-- The intent is a consistent, low-glare palette where STATIC labels stay
-- plain white/gray and VARIABLE data (item names, statuses, counts,
-- log categories) is colored so it's easy to scan at a glance.
----------------------------------------------------------------------
local COLOR_ITEM_NAME   = { 0.55, 0.80, 1.00, 1 } -- light blue  - item names
local COLOR_MUTED        = { 0.65, 0.65, 0.65, 1 } -- gray        - static/secondary labels (section, brackets, arrows)
local COLOR_STATUS_KEEP  = { 0.55, 1.00, 0.55, 1 } -- green       - a status being applied / Keep
local COLOR_STATUS_OLD   = { 1.00, 0.55, 0.55, 1 } -- soft red    - a status being replaced
local COLOR_WARN         = { 1.00, 0.70, 0.30, 1 } -- orange      - not-migrated / warning entries
local COLOR_HEADING      = { 1.00, 0.85, 0.35, 1 } -- gold        - plan summary / section heading text
local COLOR_SUCCESS      = { 0.55, 1.00, 0.55, 1 } -- green       - log: ADDED / CHANGED / Committed / Backup
local COLOR_ERROR        = { 1.00, 0.40, 0.40, 1 } -- red         - log: ERROR
local COLOR_DEFAULT      = { 0.85, 0.85, 0.85, 1 } -- light gray  - log: everything else
local COLOR_VAR          = { 1.00, 1.00, 1.00, 1 } -- bright white - variable/substituted data embedded in a line
                                                     -- (counts, item names, paths, etc.), so it stands out from
                                                     -- the static wording around it

-- action-button colors: yellow "Preview Changes" (safe/read-only) vs
-- red "Commit Selected" (writes to disk), both with black text for
-- contrast/legibility against their bright backgrounds
local COLOR_BTN_PREVIEW_BG        = { 0.95, 0.85, 0.10, 1 }
local COLOR_BTN_PREVIEW_BG_HOVER  = { 1.00, 0.92, 0.25, 1 }
local COLOR_BTN_PREVIEW_BG_ACTIVE = { 0.85, 0.75, 0.05, 1 }
local COLOR_BTN_COMMIT_BG         = { 0.80, 0.15, 0.15, 1 }
local COLOR_BTN_COMMIT_BG_HOVER   = { 0.90, 0.25, 0.25, 1 }
local COLOR_BTN_COMMIT_BG_ACTIVE  = { 0.65, 0.10, 0.10, 1 }
local COLOR_BTN_TEXT_BLACK        = { 0.00, 0.00, 0.00, 1 }

-- render an ImGui.Button with custom background (normal/hovered/active)
-- and text colors, restoring the previous style afterward. Assumes
-- MacroQuest's Lua ImGui binding exposes ImGuiCol as a global enum table
-- (the standard convention in mq lua ImGui scripts); if a given build
-- instead requires ImGuiCol via the ImGui module (e.g. ImGui.ImGuiCol),
-- adjust the ImGuiCol.* references below accordingly.
local function coloredButton(label, bg, bgHover, bgActive, textColor)
    ImGui.PushStyleColor(ImGuiCol.Button, bg[1], bg[2], bg[3], bg[4])
    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, bgHover[1], bgHover[2], bgHover[3], bgHover[4])
    ImGui.PushStyleColor(ImGuiCol.ButtonActive, bgActive[1], bgActive[2], bgActive[3], bgActive[4])
    ImGui.PushStyleColor(ImGuiCol.Text, textColor[1], textColor[2], textColor[3], textColor[4])
    local clicked = ImGui.Button(label)
    ImGui.PopStyleColor(4)
    return clicked
end

-- shorthand: render `text` in `color` (a {r,g,b,a} table)
local function ctext(color, text)
    ImGui.TextColored(color[1], color[2], color[3], color[4], text)
end

-- pick a log-line color based on its leading keyword
local function logLineColor(line)
    if line:match('^ERROR') then return COLOR_ERROR end
    if line:match('^ADDED') or line:match('^CHANGED') or line:match('^Committed') or line:match('^Backup') then return COLOR_SUCCESS end
    if line:match('^New items:') or line:match('^Turbo source') or line:match('^Loot target') then return COLOR_HEADING end
    if line:match('numeric value') then return COLOR_WARN end
    return COLOR_DEFAULT
end

-- render one log entry, coloring its static wording in `baseColor` and any
-- of its substituted printf-style arguments (numbers, names, paths) in
-- COLOR_VAR so the variable data visually stands out from the fixed label
-- text around it, without changing the label text's own color. Segments
-- were precomputed by log() from the format string's own specifiers, so
-- this never has to guess/search - it just plays them back.
local function drawLogLine(entry)
    local baseColor = logLineColor(entry.text)
    local first = true
    for _, seg in ipairs(entry.segments) do
        if seg.text ~= '' then
            if not first then ImGui.SameLine(0, 0) end
            ctext(seg.isVar and COLOR_VAR or baseColor, seg.text)
            first = false
        end
    end
end

-- review state (populated by planSync, consumed by commitSync)
local plan            = nil   -- { sections=, lookup=, hadBOM= } snapshot to mutate on commit
local pendingAdds     = {}    -- array of { name, status, key(=letter), include }
local pendingChanges  = {}    -- array of { name, section, oldStatus, newStatus, include }
local pendingSkippedNumeric = {} -- array of { name, value } - turboloot entries with a plain-number value, not migrated
local hasPlan         = false
local planSummary     = ''
local planCounts      = { adds = 0, changes = 0, unchanged = 0, skippedNumeric = 0 } -- for the on-screen colored summary line

----------------------------------------------------------------------
-- helpers
----------------------------------------------------------------------

-- log(fmt, ...) both renders the final string (for logLines' plain text /
-- category-color lookup) AND splits it into segments by walking `fmt`'s
-- own %-specifiers (%s, %d, %%, etc.) so each substituted argument becomes
-- its own segment. This is done against the FORMAT STRING rather than by
-- searching for the argument's text inside the finished string, because a
-- short/common substituted value (e.g. a single-letter section key "A")
-- could otherwise false-match inside unrelated literal text (e.g. the "A"
-- in the literal word "ADDED"), garbling the coloring.
local FMT_SPEC_PATTERN = '%%[%-%+ #0]*%d*%.?%d*[diouxXeEfgGqscp%%]'

local function log(fmt, ...)
    local args = { ... }
    local segments = {}
    local argIndex = 0
    local pos = 1
    while true do
        local s, e = fmt:find(FMT_SPEC_PATTERN, pos)
        if not s then
            table.insert(segments, { text = fmt:sub(pos), isVar = false })
            break
        end
        if s > pos then
            table.insert(segments, { text = fmt:sub(pos, s - 1), isVar = false })
        end
        local specifier = fmt:sub(s, e)
        if specifier == '%%' then
            table.insert(segments, { text = '%', isVar = false })
        else
            argIndex = argIndex + 1
            table.insert(segments, { text = string.format(specifier, args[argIndex]), isVar = true })
        end
        pos = e + 1
    end

    local parts = {}
    for _, seg in ipairs(segments) do table.insert(parts, seg.text) end

    table.insert(logLines, { text = table.concat(parts), segments = segments })
end

local function trim(s)
    return (s:gsub('^%s+', ''):gsub('%s+$', ''))
end

-- pull the directory portion out of a full file path (Windows or /-style)
local function dirOf(path)
    local d = path:match('^(.*)[\\/][^\\/]-$')
    return d or '.'
end

-- split a full file path into directory, base filename (no extension),
-- and extension (no dot). e.g. "C:\foo\Loot Settings.ini" ->
-- "C:\foo", "Loot Settings", "ini"
local function splitPath(path)
    local dir  = dirOf(path)
    local file = path:match('[^\\/]+$') or path
    local base, ext = file:match('^(.*)%.([^.]+)$')
    if not base then
        base, ext = file, ''
    end
    return dir, base, ext
end

-- true if a file exists at path (readable)
local function fileExists(path)
    local f = io.open(path, 'rb')
    if f then f:close() return true end
    return false
end

-- find the next available numbered backup path alongside `path`, in the
-- form "<dir>\<base>_<N>.<ext>" starting at N=1 and incrementing until a
-- name that doesn't already exist is found. Used so every Commit keeps
-- its own backup instead of overwriting a single ".bak" file.
local function nextBackupPath(path)
    local dir, base, ext = splitPath(path)
    local n = 1
    while true do
        local filename
        if ext ~= '' then
            filename = base .. '_' .. n .. '.' .. ext
        else
            filename = base .. '_' .. n
        end
        local candidate = joinPath(dir, filename)
        if not fileExists(candidate) then
            return candidate
        end
        n = n + 1
    end
end

-- list subdirectories and *.ini files in a directory
local function listDir(dir)
    local dirs, files = {}, {}

    -- strip any trailing slash first so appending '\*' below never produces
    -- a double-backslash path (e.g. "C:\" + "\*" -> "C:\\*", which the
    -- dir command fails to resolve) - this matters for drive roots like
    -- "C:\" as well as any other directory passed in with a trailing slash
    local base = dir:gsub('[\\/]+$', '')

    local dh = io.popen('dir "' .. base .. '\\*" /b /ad 2>nul')
    if dh then
        for line in dh:lines() do
            local name = trim(line)
            if name ~= '' then table.insert(dirs, name) end
        end
        dh:close()
    end

    local fh = io.popen('dir "' .. base .. '\\*.ini" /b /a-d 2>nul')
    if fh then
        for line in fh:lines() do
            local name = trim(line)
            if name ~= '' then table.insert(files, name) end
        end
        fh:close()
    end

    table.sort(dirs, function(a, b) return a:lower() < b:lower() end)
    table.sort(files, function(a, b) return a:lower() < b:lower() end)
    return dirs, files
end

-- go up one directory level (handles trailing slash / drive roots)
local function parentDir(dir)
    dir = dir:gsub('[\\/]+$', '')
    local parent = dir:match('^(.*)[\\/][^\\/]+$')
    if not parent or parent == '' then
        -- already at (or one level from) a drive root, e.g. "C:"
        local drive = dir:match('^(%a:)')
        return drive and (drive .. '\\') or dir
    end
    -- normalize a bare drive letter (e.g. "D:") to "D:\" so it's
    -- consistently recognized as a root by isDriveRoot()
    if parent:match('^%a:$') then
        parent = parent .. '\\'
    end
    return parent
end

-- true if dir is already a drive root (e.g. "C:" or "C:\") with nothing
-- further up to navigate to - used to hide the ".. (Up)" browse button
-- so the user can't get stuck unable to get back into the drive's folders
local function isDriveRoot(dir)
    local stripped = dir:gsub('[\\/]+$', '')
    return stripped:match('^%a:$') ~= nil
end

-- returns the letter/digit this item name should be filed under
local function sectionKeyFor(name)
    local c = name:sub(1, 1):upper()
    if c:match('%a') or c:match('%d') then
        return c
    end
    -- fall back: first alphanumeric char anywhere in the name, else '0'
    local alnum = name:match('%w')
    return alnum and alnum:upper() or '0'
end

-- read whole file as raw bytes, detect+strip BOM, return body + hadBOM flag
local function readFile(path)
    local f = io.open(path, 'rb')
    if not f then return nil, false end
    local data = f:read('*a')
    f:close()
    local hadBOM = false
    if data:sub(1, 3) == '\239\187\191' then
        hadBOM = true
        data = data:sub(4)
    end
    return data, hadBOM
end

local function splitLines(data)
    local lines = {}
    for line in (data .. '\n'):gmatch('([^\r\n]*)\r?\n') do
        table.insert(lines, line)
    end
    return lines
end

----------------------------------------------------------------------
-- parse turboloot.ini  ->  { [lowerName] = { name = originalName, status = 'Keep'|'Sell'|'Skip'|'Destroy' } }
-- Only reads lines inside the [ItemLimits] section: everything before that
-- section header is ignored, and reading stops entirely once a [GiveList]
-- section header is reached (give-rules/patterns/excludes are irrelevant
-- and can otherwise be misread as loot entries).
-- Also returns a list of { name, value } entries skipped because their
-- turboloot value is a plain number (no Keep/Sell/Skip/Destroy equivalent)
----------------------------------------------------------------------

local function parseTurboLoot(path)
    local data, err = readFile(path)
    if not data then return nil, 'Could not open ' .. path end

    local results        = {}
    local skippedNumeric = {}   -- entries left out because their value is a plain number (e.g. "5", "1000")
    local inItemLimits    = false
    for _, rawLine in ipairs(splitLines(data)) do
        local line = trim(rawLine)
        if line ~= '' then
            local hdr = line:match('^%[(.+)%]$')
            if hdr then
                if hdr:upper() == 'GIVELIST' then
                    -- everything from [GiveList] onward is unrelated (give rules, patterns,
                    -- excludes) - stop reading entirely.
                    break
                end
                inItemLimits = (hdr:upper() == 'ITEMLIMITS')
            elseif inItemLimits and not line:match('^;') then
                local name, value = line:match('^(.-)=(.*)$')
                if name and value then
                    name  = trim(name)
                    local rawValue = trim(value)
                    value = rawValue:upper()
                    local mapped = mappedStatus[value]
                    if mapped and name ~= '' then
                        results[name:lower()] = { name = name, status = mapped }
                    elseif name ~= '' and rawValue:match('^%d+$') then
                        table.insert(skippedNumeric, { name = name, value = rawValue })
                    end
                end
            end
        end
    end
    table.sort(skippedNumeric, function(a, b) return a.name:lower() < b.name:lower() end)
    return results, nil, skippedNumeric
end

----------------------------------------------------------------------
-- parse Loot Settings.ini -> sections[letter][status] = { names... }
--                             plus lookup[lowerName] = { letter, status, name }
----------------------------------------------------------------------

local function parseLootSettings(path)
    local data, hadBOM = readFile(path)
    if not data then return nil, nil, false, 'Could not open ' .. path end

    local sections   = {}
    local lookup      = {}
    local curSection

    for _, rawLine in ipairs(splitLines(data)) do
        local line = trim(rawLine)
        if line ~= '' then
            local hdr = line:match('^%[(.+)%]$')
            if hdr then
                curSection = hdr
                sections[curSection] = sections[curSection] or {}
            else
                local name, status = line:match('^(.-)=(.*)$')
                if name and status and curSection then
                    name   = trim(name)
                    status = trim(status)
                    sections[curSection][status] = sections[curSection][status] or {}
                    table.insert(sections[curSection][status], name)
                    lookup[name:lower()] = { section = curSection, status = status, name = name }
                end
            end
        end
    end

    return sections, lookup, hadBOM
end

----------------------------------------------------------------------
-- compute a diff between turboloot decisions and the parsed
-- Loot Settings structures WITHOUT mutating anything (used for review)
----------------------------------------------------------------------

local function computeDiff(lookup, turboEntries)
    local adds, changes, unchanged = {}, {}, 0

    for lname, entry in pairs(turboEntries) do
        local existing = lookup[lname]

        if not existing then
            table.insert(adds, {
                name    = entry.name,
                status  = entry.status,
                key     = sectionKeyFor(entry.name),
                include = true,
            })
        elseif existing.status ~= entry.status then
            table.insert(changes, {
                name       = existing.name,
                section    = existing.section,
                oldStatus  = existing.status,
                newStatus  = entry.status,
                include    = true,
            })
        else
            unchanged = unchanged + 1
        end
    end

    table.sort(adds, function(a, b) return a.name:lower() < b.name:lower() end)
    table.sort(changes, function(a, b) return a.name:lower() < b.name:lower() end)

    return adds, changes, unchanged
end

----------------------------------------------------------------------
-- apply only the checked adds/changes into sections/lookup
----------------------------------------------------------------------

local function applyDiff(sections, lookup, adds, changes)
    local addedCount, changedCount = 0, 0

    for _, a in ipairs(adds) do
        if a.include then
            local key = a.key
            sections[key] = sections[key] or {}
            sections[key][a.status] = sections[key][a.status] or {}
            table.insert(sections[key][a.status], a.name)
            lookup[a.name:lower()] = { section = key, status = a.status, name = a.name }
            addedCount = addedCount + 1
            log('ADDED   [%s] %s = %s', key, a.name, a.status)
        end
    end

    for _, c in ipairs(changes) do
        if c.include then
            local oldList = sections[c.section][c.oldStatus]
            if oldList then
                for i, n in ipairs(oldList) do
                    if n:lower() == c.name:lower() then
                        table.remove(oldList, i)
                        break
                    end
                end
            end
            sections[c.section][c.newStatus] = sections[c.section][c.newStatus] or {}
            table.insert(sections[c.section][c.newStatus], c.name)
            changedCount = changedCount + 1
            log('CHANGED [%s] %s : %s -> %s', c.section, c.name, c.oldStatus, c.newStatus)
        end
    end

    return addedCount, changedCount
end

----------------------------------------------------------------------
-- write sections back out in Loot Settings.ini format
----------------------------------------------------------------------

local function sectionOrderList(sections)
    local keys = {}
    for k in pairs(sections) do table.insert(keys, k) end
    table.sort(keys, function(a, b)
        local da, db = a:match('%d'), b:match('%d')
        if da and db then return a < b end
        if da and not db then return false end -- digits after letters
        if db and not da then return true end
        return a < b
    end)
    return keys
end

local function writeLootSettings(path, sections, hadBOM)
    local out = {}
    if hadBOM then out[1] = '\239\187\191' end

    for _, key in ipairs(sectionOrderList(sections)) do
        table.insert(out, '[' .. key .. ']\r\n')

        local seen = {}
        local function writeBlock(status)
            local list = sections[key][status]
            if list and #list > 0 then
                table.sort(list, function(a, b) return a:lower() < b:lower() end)
                for _, name in ipairs(list) do
                    table.insert(out, name .. '=' .. status .. '\r\n')
                end
            end
            seen[status] = true
        end

        for _, status in ipairs(statusOrder) do writeBlock(status) end
        -- any other status names not in our preferred list, alphabetically
        local extras = {}
        for status in pairs(sections[key]) do
            if not seen[status] then table.insert(extras, status) end
        end
        table.sort(extras)
        for _, status in ipairs(extras) do writeBlock(status) end

        table.insert(out, '\r\n')
    end

    local f = io.open(path, 'wb')
    if not f then return false, 'Could not open ' .. path .. ' for writing' end
    f:write(table.concat(out))
    f:close()
    return true
end

----------------------------------------------------------------------
-- write sections back out, flattening each letter block into ONE
-- alphabetically sorted list (ignoring Keep/Sell/Skip grouping)
----------------------------------------------------------------------

local function writeLootSettingsFlatAlpha(path, sections, hadBOM)
    local out = {}
    if hadBOM then out[1] = '\239\187\191' end

    for _, key in ipairs(sectionOrderList(sections)) do
        table.insert(out, '[' .. key .. ']\r\n')

        local items = {}
        for status, list in pairs(sections[key]) do
            for _, name in ipairs(list) do
                table.insert(items, { name = name, status = status })
            end
        end
        table.sort(items, function(a, b) return a.name:lower() < b.name:lower() end)

        for _, it in ipairs(items) do
            table.insert(out, it.name .. '=' .. it.status .. '\r\n')
        end

        table.insert(out, '\r\n')
    end

    local f = io.open(path, 'wb')
    if not f then return false, 'Could not open ' .. path .. ' for writing' end
    f:write(table.concat(out))
    f:close()
    return true
end

----------------------------------------------------------------------
-- resort Loot Settings.ini alphabetically within each [LETTER] block
----------------------------------------------------------------------

local function resortAlpha()
    logLines = {}
    log('Loot target: %s', lootPath)

    local sections, lookup, hadBOM, lerr = parseLootSettings(lootPath)
    if not sections then
        log('ERROR: %s', lerr)
        return
    end

    local backupPath = lootPath .. '.bak'
    local raw = readFile(lootPath)
    if raw then
        local bf = io.open(backupPath, 'wb')
        if bf then bf:write(raw) bf:close() end
    end

    local ok, werr = writeLootSettingsFlatAlpha(lootPath, sections, hadBOM)
    if not ok then
        log('ERROR: %s', werr)
        return
    end

    log('Backup written to %s', backupPath)
    log('Resorted alphabetically within each [LETTER] block.')
end

----------------------------------------------------------------------
-- main actions: plan (read-only, builds review lists) and commit (writes)
----------------------------------------------------------------------

local function planSync()
    logLines = {}
    hasPlan = false
    pendingAdds, pendingChanges, pendingSkippedNumeric = {}, {}, {}

    log('Turbo source : %s', turboPath)
    log('Loot target  : %s', lootPath)

    local turboEntries, terr, skippedNumeric = parseTurboLoot(turboPath)
    if not turboEntries then
        log('ERROR: %s', terr)
        return
    end

    local sections, lookup, hadBOM, lerr = parseLootSettings(lootPath)
    if not sections then
        log('ERROR: %s', lerr)
        return
    end

    local adds, changes, unchanged = computeDiff(lookup, turboEntries)

    plan = { sections = sections, lookup = lookup, hadBOM = hadBOM }
    pendingAdds          = adds
    pendingChanges       = changes
    pendingSkippedNumeric = skippedNumeric or {}
    hasPlan              = true

    planCounts = { adds = #adds, changes = #changes, unchanged = unchanged, skippedNumeric = #pendingSkippedNumeric }
    planSummary = string.format(
        'New items: %d   Status changes: %d   Already in sync: %d   Not migrated (numeric value): %d',
        #adds, #changes, unchanged, #pendingSkippedNumeric)
    log('New items: %d   Status changes: %d   Already in sync: %d   Not migrated (numeric value): %d',
        #adds, #changes, unchanged, #pendingSkippedNumeric)
    if #pendingSkippedNumeric > 0 then
        log('%d item(s) use a plain numeric value in turboloot.ini (e.g. "5", "1000") and have no Keep/Sell/Skip/Destroy equivalent, so they will NOT be migrated. See "Not Migrated" below.', #pendingSkippedNumeric)
    end
    log('Review the lists below, uncheck anything you don\'t want, then click Commit.')
end

local function commitSync()
    if not hasPlan or not plan then
        log('Nothing to commit - run a preview first.')
        return
    end

    -- backup original before touching it - a fresh numbered backup every
    -- commit (e.g. "Loot Settings_1.ini", "Loot Settings_2.ini", ...)
    -- rather than overwriting a single .bak file, so every commit keeps
    -- its own snapshot.
    local backupPath = nextBackupPath(lootPath)
    local raw = readFile(lootPath)
    if raw then
        local bf = io.open(backupPath, 'wb')
        if bf then bf:write(raw) bf:close() end
    end

    local addedCount, changedCount = applyDiff(plan.sections, plan.lookup, pendingAdds, pendingChanges)

    local ok, werr = writeLootSettings(lootPath, plan.sections, plan.hadBOM)
    if not ok then
        log('ERROR: %s', werr)
        return
    end

    log('----')
    log('Backup written to %s', backupPath)
    log('Committed. Added: %d   Changed: %d', addedCount, changedCount)

    hasPlan = false
    plan = nil
    pendingAdds, pendingChanges = {}, {}
end

----------------------------------------------------------------------
-- ImGui window
----------------------------------------------------------------------

local function DrawGUI()
    if not openGUI then return end

    openGUI, shouldDrawGUI = ImGui.Begin('Sync Loot Settings', openGUI)
    if shouldDrawGUI then
        ImGui.Text('TurboLoot source file:')
        turboPath = ImGui.InputText('##turboPath', turboPath)
        ImGui.SameLine()
        if ImGui.Button('Browse##turbo') then
            turboBrowseDir = dirOf(turboPath)
            turboDirs, turboFiles = listDir(turboBrowseDir)
            ImGui.OpenPopup('Select TurboLoot File')
        end
        if ImGui.BeginPopup('Select TurboLoot File') then
            ImGui.Text('Folder:')
            ImGui.SameLine()
            turboBrowseDir = ImGui.InputText('##turboBrowseDir', turboBrowseDir)
            ImGui.SameLine()
            if ImGui.Button('Go##turboGo') then
                turboDirs, turboFiles = listDir(turboBrowseDir)
            end
            if not isDriveRoot(turboBrowseDir) then
                if ImGui.Button('.. (Up)##turboUp') then
                    turboBrowseDir = parentDir(turboBrowseDir)
                    turboDirs, turboFiles = listDir(turboBrowseDir)
                end
            end
            ImGui.Separator()
            ImGui.BeginChild('##turboBrowseList', 400, 250, true)
            for _, d in ipairs(turboDirs) do
                if ImGui.Selectable('[' .. d .. ']') then
                    turboBrowseDir = joinPath(turboBrowseDir, d)
                    turboDirs, turboFiles = listDir(turboBrowseDir)
                end
            end
            for _, fname in ipairs(turboFiles) do
                if ImGui.Selectable(fname) then
                    turboPath = joinPath(turboBrowseDir, fname)
                    ImGui.CloseCurrentPopup()
                end
            end
            if #turboDirs == 0 and #turboFiles == 0 then
                ImGui.Text('(empty or inaccessible folder)')
            end
            ImGui.EndChild()
            ImGui.EndPopup()
        end

        ImGui.Text('Loot Settings target file:')
        lootPath = ImGui.InputText('##lootPath', lootPath)
        ImGui.SameLine()
        if ImGui.Button('Browse##loot') then
            lootBrowseDir = dirOf(lootPath)
            lootDirs, lootFiles = listDir(lootBrowseDir)
            ImGui.OpenPopup('Select Loot Settings File')
        end
        if ImGui.BeginPopup('Select Loot Settings File') then
            ImGui.Text('Folder:')
            ImGui.SameLine()
            lootBrowseDir = ImGui.InputText('##lootBrowseDir', lootBrowseDir)
            ImGui.SameLine()
            if ImGui.Button('Go##lootGo') then
                lootDirs, lootFiles = listDir(lootBrowseDir)
            end
            if not isDriveRoot(lootBrowseDir) then
                if ImGui.Button('.. (Up)##lootUp') then
                    lootBrowseDir = parentDir(lootBrowseDir)
                    lootDirs, lootFiles = listDir(lootBrowseDir)
                end
            end
            ImGui.Separator()
            ImGui.BeginChild('##lootBrowseList', 400, 250, true)
            for _, d in ipairs(lootDirs) do
                if ImGui.Selectable('[' .. d .. ']') then
                    lootBrowseDir = joinPath(lootBrowseDir, d)
                    lootDirs, lootFiles = listDir(lootBrowseDir)
                end
            end
            for _, fname in ipairs(lootFiles) do
                if ImGui.Selectable(fname) then
                    lootPath = joinPath(lootBrowseDir, fname)
                    ImGui.CloseCurrentPopup()
                end
            end
            if #lootDirs == 0 and #lootFiles == 0 then
                ImGui.Text('(empty or inaccessible folder)')
            end
            ImGui.EndChild()
            ImGui.EndPopup()
        end

        ImGui.Spacing()
        if ImGui.Button('Resort Loot Settings ALPHA') then
            resortAlpha()
        end

        ImGui.Spacing()
        if coloredButton('Preview Changes', COLOR_BTN_PREVIEW_BG, COLOR_BTN_PREVIEW_BG_HOVER, COLOR_BTN_PREVIEW_BG_ACTIVE, COLOR_BTN_TEXT_BLACK) then
            planSync()
        end

        if hasPlan then
            ImGui.SameLine()
            if ImGui.Button('Select All') then
                for _, a in ipairs(pendingAdds) do a.include = true end
                for _, c in ipairs(pendingChanges) do c.include = true end
            end
            ImGui.SameLine()
            if ImGui.Button('Select None') then
                for _, a in ipairs(pendingAdds) do a.include = false end
                for _, c in ipairs(pendingChanges) do c.include = false end
            end
            ImGui.SameLine()
            if coloredButton('Commit Selected', COLOR_BTN_COMMIT_BG, COLOR_BTN_COMMIT_BG_HOVER, COLOR_BTN_COMMIT_BG_ACTIVE, COLOR_BTN_TEXT_BLACK) then
                commitSync()
            end

            ImGui.Spacing()
            ctext(COLOR_HEADING, 'New items:')
            ImGui.SameLine()
            ctext(COLOR_VAR, tostring(planCounts.adds))
            ImGui.SameLine()
            ctext(COLOR_HEADING, 'Status changes:')
            ImGui.SameLine()
            ctext(COLOR_VAR, tostring(planCounts.changes))
            ImGui.SameLine()
            ctext(COLOR_HEADING, 'Already in sync:')
            ImGui.SameLine()
            ctext(COLOR_VAR, tostring(planCounts.unchanged))
            ImGui.SameLine()
            ctext(COLOR_HEADING, 'Not migrated (numeric value):')
            ImGui.SameLine()
            ctext(COLOR_VAR, tostring(planCounts.skippedNumeric))

            local newItemsOpen = ImGui.CollapsingHeader('New Items###newitems')
            ImGui.SameLine()
            ctext(COLOR_VAR, string.format('(%d)', #pendingAdds))
            if newItemsOpen then
                ImGui.BeginChild('##addlist', -1, 200, true)
                for i, a in ipairs(pendingAdds) do
                    a.include = ImGui.Checkbox('##add' .. i, a.include)
                    ImGui.SameLine()
                    ctext(COLOR_ITEM_NAME, a.name)
                    ImGui.SameLine()
                    ctext(COLOR_MUTED, string.format('[%s] ->', a.key))
                    ImGui.SameLine()
                    ctext(COLOR_STATUS_KEEP, a.status)
                end
                ImGui.EndChild()
            end

            local statusChangesOpen = ImGui.CollapsingHeader('Status Changes###changeditems')
            ImGui.SameLine()
            ctext(COLOR_VAR, string.format('(%d)', #pendingChanges))
            if statusChangesOpen then
                ImGui.BeginChild('##chglist', -1, 200, true)
                for i, c in ipairs(pendingChanges) do
                    c.include = ImGui.Checkbox('##chg' .. i, c.include)
                    ImGui.SameLine()
                    ctext(COLOR_ITEM_NAME, c.name)
                    ImGui.SameLine()
                    ctext(COLOR_MUTED, string.format('[%s]', c.section))
                    ImGui.SameLine()
                    ctext(COLOR_STATUS_OLD, c.oldStatus)
                    ImGui.SameLine()
                    ctext(COLOR_MUTED, '->')
                    ImGui.SameLine()
                    ctext(COLOR_STATUS_KEEP, c.newStatus)
                end
                ImGui.EndChild()
            end

            local notMigratedOpen = ImGui.CollapsingHeader('Not Migrated - numeric value###numericitems')
            ImGui.SameLine()
            ctext(COLOR_VAR, string.format('(%d)', #pendingSkippedNumeric))
            if notMigratedOpen then
                ctext(COLOR_WARN, 'These use a plain count in turboloot.ini (no Keep/Sell/Skip/Destroy equivalent) and are skipped:')
                ImGui.BeginChild('##numlist', -1, 200, true)
                for i, n in ipairs(pendingSkippedNumeric) do
                    ctext(COLOR_ITEM_NAME, n.name)
                    ImGui.SameLine()
                    ctext(COLOR_WARN, string.format('= %s', n.value))
                end
                ImGui.EndChild()
            end
        end

        ImGui.Spacing()
        ImGui.Separator()
        ImGui.Text('Log:')
        ImGui.BeginChild('##log', -1, -1, true)
        for _, entry in ipairs(logLines) do
            drawLogLine(entry)
        end
        ImGui.EndChild()
    end
    ImGui.End()
end

mq.imgui.init('SyncLootSettings', DrawGUI)

log('Ready. Set paths and click "Preview Changes".')

while openGUI do
    mq.delay(100)
end
