--[[
================================================================================
  BardKite/init.lua
  Authors  : Azote (original .mac), converted and extended to Lua
  Based on : VeksarBoss2.mac, TrakBardKite.mac
  Version  : 1.0
================================================================================

OVERVIEW
--------
BardKite is a MacroQuest Lua kite-assist script for Bards performing raid-kiting
duties. It detects the current zone, selects the appropriate kite routine, and
drives movement and ability usage automatically while displaying a live ImGui
overlay window.

Place the script at:
    <MQ>/lua/BardKite/init.lua

Launch with:
    /lua run BardKite/init

================================================================================
CLASS CHECK AND DELEGATION
================================================================================
On startup the script checks whether the running character is a Bard (class
short name "BRD").

  - IS a Bard: continues normally — opens the overlay, detects the zone, and
    launches the appropriate kite loop.

  - NOT a Bard: scans group members (Group.Member(1..n)) for a Bard by class
    short name. If one is found it issues:
        /e3bct <BardName> /lua run BardKite/init
    and exits without opening a window. If no Bard is in the group it prints
    an error and exits.

================================================================================
ZONE DETECTION AND ROUTING
================================================================================
Zone.ShortName() is lowercased and looked up in the ZONE_LOOP table.

  Mapped zone   → the matching kite loop function runs.
  Unmapped zone → the overlay opens with kitePaused = true and status set to
                  "PAUSED — zone not mapped". The script idles in a 200 ms loop
                  until overlay.open becomes false (user clicks Exit or closes
                  the window), then exits.

Current ZONE_LOOP entries:
  veksar               → veksarKiteLoop()
  sebilis, oldsebilis  → trakKiteLoop()

To add a new zone, insert a line in ZONE_LOOP near the top of the file:
    mynewzone = 'trak'     -- reuse Trak/Reaver logic
    mynewzone = 'veksar'   -- reuse Veksar named logic

================================================================================
IMGUI OVERLAY WINDOW
================================================================================
Registered via mq.imgui.init('BardKiteOverlay', drawOverlay). Fires every
frame. Only displayed when the running character is a Bard.

Window properties: width 290 px (first-use), background alpha 0.82,
NoCollapse + AlwaysAutoResize + NoScrollbar flags set.

Layout (top to bottom):
  Header      — "Bard Kite Controller" in amber.
  Zone        — full zone name, yellow.
  Loop        — active loop label, cyan.
  Status      — one-line status string.
                  Contains "End" or "DEAD" → red.
                  Contains "PAUSED"        → yellow.
                  Otherwise               → green.

  Target block (when a target is selected):
    Target name + [Type] tag inline.
      Type == "NPC" → orange tag; anything else → grey tag.
    <TargetName>'s ToT — target's current target via Me.TargetOfTarget.
      Name present → cyan; absent → "< none >" in grey.
    Distance in yards.
      ≤ 75 yds → green; 76–95 yds → orange; > 95 yds → red.
    HP progress bar (160 × 14 px), percentage centred inside.
      > 60 % → green bar; 31–60 % → yellow bar; ≤ 30 % → red bar.
    No target → centred "< no target >" in red.

  Indicators (shown conditionally, on the same line if both active):
    [NAV ACTIVE] — green; shown when Navigation.Active() is true.
    [IN COMBAT]  — red;   shown when Me.Combat() is true.

  Waypoint N / 4 — cyan; shown only when overlay.locId > 0 (Trak loop only).

  Pause / Resume button (full width):
    kitePaused == true  → green  "Resume Kite" — sets kitePaused = false.
    kitePaused == false → amber  "Pause Kite"  — sets kitePaused = true.

  Exit button (full width, red):
    Sets status = 'Exiting...', kitePaused = true, open = false.
    Any running kite loop detects open == false on its next checkPaused()
    or checkDeath() call and returns, ending the script.

================================================================================
PAUSE BEHAVIOUR
================================================================================
checkPaused() is called at the top of every kite loop iteration.

When kitePaused is true:
  1. /nav stop is issued.
  2. overlay.status is set to 'PAUSED'.
  3. The function spins in a 100 ms mq.delay loop, yielding to ImGui each tick.
  4. If overlay.open becomes false during the spin, checkPaused() returns true
     (signal to the loop to abort and return).
  5. Once kitePaused becomes false (Resume button), overlay.status is set to
     'Resuming...' and checkPaused() returns false; the loop continues.

================================================================================
DEATH HANDLING  (checkDeath)
================================================================================
checkDeath(mZone, agroCheck) is called at the top of every kite loop iteration
alongside checkPaused(). It accepts an optional callback for post-rez agro
checks; pass nil for loops that do not need one.

On death detection (Me.Dead() transitions to true):
  - overlay.status = 'DEAD', kitePaused = true, /nav stop.
  - Raid-says "--- Bard is DEAD ---".
  - Enters a 500 ms idle loop until Me.Dead() is false.
    If overlay.open becomes false during this loop, returns true (abort signal).

On resurrection (Me.Dead() transitions back to false):
  - Waits in a 500 ms loop until Zone.ID() matches mZone (handles GM rezzes).
  - Attempts /lootcorpse every 2 seconds while myCorpseNearby(300) is true,
    up to a maximum of 20 attempts.
  - Raid-says "--- Bard is back in zone — checking agro before resuming ---".
  - Sets kitePaused = false.
  - Calls agroCheck() if one was supplied.
  - Returns false (loop continues normally).

================================================================================
VEKSAR KITE LOOP  (veksarKiteLoop)
================================================================================

Target NPCs : Dirloz (VEKSAR_NAMED1), Gurag (VEKSAR_NAMED2)
NPC escort  : Hierophant (VEKSAR_NPC_FOLLOW)
Debuff wait : 9 seconds (VEKSAR_DEBUFF_WAIT) near each named after arriving

Startup sequence:
  1. /backoff, /afollow off, /nav stop, /stand.
  2. 3-second raid-say countdown: "Starting Event, in 3" / "In 2" / "In 1" /
     "Be ready".
  3. Calls veksarDoNPCFollow().
  4. Raid-says "NPC on Follow starting moving in 10s", waits 10 seconds, then
     raid-says "MOVING".

Main loop (runs indefinitely until exit or event end):
  Each iteration:
    1. checkPaused() — abort if exit pressed.
    2. checkDeath(mZone, nil) — handle death/rez; no agro callback.
    3. Zone-change guard: spins at 3 s intervals until Zone.ID() == mZone;
       resets veksarNPCFollowing = false on zone change.
    4. veksarCheckCorpse() — loot self-corpse within 300 yds if present.
    5. If veksarNPCFollowing == false: calls veksarDoNPCFollow().
    6. Dirloz check (npcNearby(VEKSAR_NAMED1, 500)):
         /backoff "/not|MNK BER CLE SHM SHD MAG WIZ ENC BST WAR PAL DRU ROG"
         /attack off, /Target Clear
         /target Dirloz, /dropbuff torpor, /nav target
         Wait for nav to complete, then wait VEKSAR_DEBUFF_WAIT (9) seconds
         (with per-second zone-change checks).
    7. Second zone-change guard + veksarCheckCorpse() + NPC follow re-check.
    8. Gurag check (npcNearby(VEKSAR_NAMED2, 500)) — identical logic to step 6.
    9. End condition: if both Dirloz and Gurag are absent within 500 yds while
       still in mZone → raid-says event end, sets status 'Event End', returns.

veksarDoNPCFollow():
  Sets backoff to exclude all non-BRD classes, clears attack, clears target.
  If Hierophant is within 500 yds:
    Targets it, gsays the target name, navigates to it, then executes the
    escort dialogue: /hail × 2, /say assist × 2, /say follow × 3.
    Sets veksarNPCFollowing = true on completion.

veksarCheckCorpse():
  If myCorpseNearby(300) is true, loops /lootcorpse every 2 seconds until no
  corpse remains, then gsays a loot-complete message.

================================================================================
TRAK / OLD SEBILIS KITE LOOP  (trakKiteLoop)
================================================================================

Target NPC  : Reaver (TRAK_NAMED)
Kite style  : 4-waypoint circuit driven by MQ2Nav

Startup sequence:
  1. /backoff, /afollow off, /nav stop, /stand.
  2. Raid-says "Be ready".
  3. Navigates to TRAK_WAIT_LOC {y=-2140, x=-722, z=-140} — the centroid of
     the four kite waypoints — to pre-position for agro pickup.
     While pathing, polls npcNearby(TRAK_NAMED, 800) every 200 ms:
       If Reaver spawns en route → /nav stop, sets reaverSpawnedEnRoute = true.

  En-route spawn path (reaverSpawnedEnRoute == true):
    /attack off, /backoff /only|BRD
    Targets Reaver, /nav target, closes to ≤ 80 yds, then:
    /alt act 106 (Boastful Bellow) + trakUseItems() to establish agro.

  Normal spawn path (Reaver not yet up at wait position):
    Polls npcNearby(TRAK_NAMED, 800) every 500 ms until Reaver appears.
    /attack off, /backoff /only|BRD, raid-says "Reaver Popped".
    /nav target → closes to ≤ 80 yds.

  /playmelody combat Force is started after agro is established.

Kite waypoints (cycled in order, wrapping 4 → 1):
  WP 1: y=-2055, x=-630,  z=-140
  WP 2: y=-2248, x=-624,  z=-140
  WP 3: y=-2204, x=-816,  z=-140
  WP 4: y=-2055, x=-816,  z=-140

Main loop (runs indefinitely until exit or zone change):
  Each iteration:
    1. checkPaused() — abort if exit pressed.
    2. checkDeath(mZone, callback):
         callback: if Reaver is present and not targeting bard → trakRegainAgro();
                   otherwise logs agro confirmed.
    3. Zone-change guard: if Zone.ID() != mZone → status 'Zoned out — ending',
       resets overlay.locId = 0, returns.
    4. Re-target Reaver if current target name doesn't match.
    5. /attack off.
    6. /backoff /only|BRD if Me.Combat() is true.
    7. /alt act 199 (Selo's Accelerando sustain AA).
    8. Agro check (trakReaverTargetingMe()):
         false → trakRegainAgro(), then mq.doevents() and skip rest of iteration.
         true  → waypoint step:
           If targetDistance() ≤ 75:
             status update, trakGoLocId(locId), advance locId (mod 4).
             Inner nav loop while Navigation.Active():
               Agro lost mid-nav → /nav stop, trakRegainAgro(), break.
               dist ≥ 95 and nav not paused → /nav pause (slow down).
               dist ≤ 75 and nav paused     → /nav pause (toggle resume).
               dist ≥ 80                    → trakUseItems().
           If targetDistance() ≥ 80 (outside nav): trakUseItems().

trakReaverTargetingMe():
  Looks up Spawn('npc Reaver'), reads TargetOfTarget(), compares
  case-insensitively to Me.Name(). Returns false if Reaver has no valid spawn
  ID or no target.

trakRegainAgro():
  /nav stop, /attack off, /backoff /only|BRD.
  Targets Reaver, /nav target → closes to ≤ 30 yds.
  /alt act 106 (Boastful Bellow), then trakUseItems().
  Polls trakReaverTargetingMe() for up to 5 seconds (50 × 100 ms ticks).
  Reports success or uncertainty to overlay.status, raid-say, and console.
  /attack off, /backoff /only|BRD before returning.

trakUseItems():
  Calls /useitem on each entry in TRAK_ITEMS, followed by a 100 ms delay.

TRAK_ITEMS — proc/clickie items fired at distance ≥ 80 yds and during agro
  regain:
    Invocation Rune: Vulka's Chant of Lightning
    Forsaken Zealot's Incarnadine Sword
    Forsaken Singing Steel Vambraces
    Forsaken Singing Steel Gaunlets
    Forsaken Rod of Lamentation
    Forsaken Sword of the Morning
    Forsaken Fayguard Bladecatcher
    Rapier of Somber Notes

================================================================================
CONSOLE OUTPUT
================================================================================
All script messages use the log() helper:
  Format : \at[BardKite]\ax \ay<message>\ax
  Colours: \at = teal/cyan (tag), \ay = yellow (body), \ax = reset

rs() sends /rs in a raid (Raid.Members() > 0) or /g otherwise.
gsay() always sends /g.

================================================================================
DEPENDENCIES
================================================================================
  MQ2Nav   — required for all /nav commands
  MQ2Melee — required for /backoff
  E3       — required for /e3bct delegation
  ImGui    — bundled with MacroQuest; required for the overlay window

================================================================================
CONFIGURATION REFERENCE
================================================================================
  SCRIPT_NAME        'BardKite/init'        Path passed to /e3bct delegation.
  ZONE_LOOP          table                  Maps zone shortnames → loop keys.
                                            Valid values: 'veksar', 'trak'.
                                            Unmapped zones open the window paused.
  VEKSAR_NAMED1      'Dirloz'               First Veksar named NPC.
  VEKSAR_NAMED2      'Gurag'                Second Veksar named NPC.
  VEKSAR_NPC_FOLLOW  'Hierophant'           NPC to escort in Veksar.
  VEKSAR_DEBUFF_WAIT  9                     Seconds to wait near each named NPC.
  TRAK_NAMED         'Reaver'               Named NPC to kite in Old Sebilis.
  TRAK_WAIT_LOC      {y=-2140,x=-722,       Centroid of TRAK_LOCS. Bard navigates
                      z=-140}               here before Reaver spawns.
  TRAK_LOCS          table (4 entries)      Y/X/Z waypoints for the kite circuit.
  TRAK_ITEMS         table (8 entries)      Items used at range and for agro regain.
================================================================================
--]]

local mq    = require('mq')
local ImGui = require('ImGui')

-- ============================================================
--  SCRIPT IDENTITY
-- ============================================================

local SCRIPT_NAME = 'BardKite/init'

-- ============================================================
--  ZONE → LOOP MAP
--  'veksar' = veksarKiteLoop()
--  'trak'   = trakKiteLoop()
--  Anything not listed = unmapped zone (window opens paused)
-- ============================================================
local ZONE_LOOP = {
    -- Veksar
    veksar     = 'veksar',

    -- Old Sebilis
    sebilis    = 'trak',
    oldsebilis = 'trak',
}

-- ============================================================
--  OVERLAY STATE  (written by kite loops, read by ImGui callback)
-- ============================================================
local overlay = {
    open       = true,       -- window open flag; false = close + stop all loops
    zoneName   = 'Unknown',
    zoneShort  = 'unknown',
    loopActive = 'None',     -- display label for which loop is running
    targetName = '',
    targetDist = 0,
    targetHP   = 0,
    targetType     = '',
    targetOfTarget = '',         -- name of the target's current target
    navActive  = false,
    inCombat   = false,
    locId      = 0,          -- Trak waypoint index (0 = not applicable)
    status     = 'Starting',
    kitePaused = false,      -- toggled by Pause button; checked by both kite loops
}

-- ============================================================
--  SHARED HELPERS
-- ============================================================

--- Send a raid-say if in a raid, otherwise fall back to group say.
local function rs(msg)
    if mq.TLO.Raid.Members() and mq.TLO.Raid.Members() > 0 then
        mq.cmd('/rs ' .. msg)
    else
        mq.cmd('/g '  .. msg)
    end
end
local function gsay(msg) mq.cmd('/g '  .. msg) end

--- Coloured console print: cyan [BardKite] tag + yellow message text.
--- MQ2 colour codes: \at = teal/cyan, \ay = yellow, \ax = reset
local function log(msg)
    print('\at[BardKite]\ax \ay' .. tostring(msg) .. '\ax')
end

local function delay(seconds)
    mq.delay(math.floor(seconds * 1000))
end

local function npcNearby(name, radius)
    return mq.TLO.Spawn('npc radius ' .. radius .. ' ' .. name).ID() >= 1
end

local function myCorpseNearby(radius)
    local myName = mq.TLO.Me.Name()
    return (mq.TLO.Spawn('pccorpse radius ' .. radius .. ' ' .. myName).Name.Find(myName)() or 0) >= 1
end

local function targetDistance()
    return mq.TLO.Target.Distance() or 999
end

--- Blocks while the bard is dead, handles resurrection, corpse loot, and announces.
--- Returns true if the exit button was pressed while waiting (loop should abort).
--- Should be called at the top of every kite loop iteration alongside checkPaused().
local bardWasDead = false   -- tracks whether we were dead last tick

local function checkDeath(mZone, agroCheck)
    local isDead = mq.TLO.Me.Dead()

    -- Announce death the moment it is detected (only once per death event)
    if isDead and not bardWasDead then
        bardWasDead = true
        overlay.status = 'DEAD'
        overlay.kitePaused = true
        mq.cmd('/nav stop')
        rs('--- Bard is DEAD ---')
        log('Bard has died. Waiting for resurrection...')
    end

    -- While dead: idle and yield to ImGui
    while mq.TLO.Me.Dead() do
        if not overlay.open then return true end
        mq.delay(500)
        mq.doevents()
    end

    -- We were dead but are no longer — resurrection detected
    if bardWasDead then
        bardWasDead = false

        -- Wait until back in the correct zone (GM rezzes may move us)
        overlay.status = 'Waiting to return to zone...'
        while mq.TLO.Zone.ID() ~= mZone do
            if not overlay.open then return true end
            mq.delay(500)
            mq.doevents()
        end

        -- Loot our corpse if it is nearby
        overlay.status = 'Looting corpse after rez...'
        local loopCount = 0
        while myCorpseNearby(300) and loopCount < 20 do
            mq.cmd('/lootcorpse')
            mq.delay(2000)
            mq.doevents()
            loopCount = loopCount + 1
        end

        -- Announce return to zone
        rs('--- Bard is back in zone — checking agro before resuming ---')
        log('Back in zone after resurrection. Checking agro before resuming kite.')
        overlay.status = 'Checking agro after rez...'
        overlay.kitePaused = false

        -- If the caller supplied an agro-check callback, run it now.
        -- Each kite loop passes its own function (or nil for loops without agro checks).
        if agroCheck then
            agroCheck()
        end
    end

    return false
end

--- Blocks while paused, yielding to ImGui every 100 ms.
--- Returns true if the exit button was pressed (loop should abort).
local function checkPaused()
    if not overlay.kitePaused then return false end
    mq.cmd('/nav stop')
    overlay.status = 'PAUSED'
    while overlay.kitePaused do
        if not overlay.open then return true end
        mq.delay(100)
        mq.doevents()
    end
    overlay.status = 'Resuming...'
    return false
end

-- ============================================================
--  BARD CHECK / GROUP SCAN
-- ============================================================

local function isBard()
    return mq.TLO.Me.Class.ShortName():upper() == 'BRD'
end

local function findGroupBard()
    local groupSize = mq.TLO.Group.Members() or 0
    for i = 1, groupSize do
        local member = mq.TLO.Group.Member(i)
        if member and member.Class.ShortName():upper() == 'BRD' then
            return member.CleanName()
        end
    end
    return nil
end

local function delegateToBard(bardName)
    local cmd = string.format('/e3bct %s /lua run %s', bardName, SCRIPT_NAME)
    log(string.format('Delegating to Bard %s -> %s', bardName, cmd))
    mq.cmd(cmd)
end

-- ============================================================
--  IMGUI OVERLAY
-- ============================================================
-- MQ Lua ImGui bindings expose NO named flag or enum constants.
-- All flags and ImGuiCol values must be passed as raw integers.
--   ImGuiWindowFlags: NoCollapse=32, AlwaysAutoResize=64, NoScrollbar=8
--   ImGuiCol:         Button=21, ButtonHovered=22, ButtonActive=23,
--                     PlotHistogram=39

local WIN_FLAGS     = 32 + 64 + 8
local COL_BTN       = 21
local COL_BTN_HOV   = 22
local COL_BTN_ACT   = 23
local COL_PLOT_HIST = 39

local C_WHITE  = { 1.00, 1.00, 1.00, 1.0 }
local C_YELLOW = { 1.00, 0.85, 0.00, 1.0 }
local C_GREEN  = { 0.20, 0.90, 0.20, 1.0 }
local C_RED    = { 0.95, 0.20, 0.20, 1.0 }
local C_ORANGE = { 1.00, 0.55, 0.00, 1.0 }
local C_CYAN   = { 0.20, 0.90, 0.90, 1.0 }
local C_GREY   = { 0.55, 0.55, 0.55, 1.0 }
local C_DIM    = { 0.20, 0.80, 0.20, 1.0 }  -- label text colour (green) for zone/loop/status
local C_TGT    = { 0.85, 0.60, 0.85, 1.0 }  -- label text colour (lavender/pink) for target block

local function tc(col, text)
    ImGui.TextColored(col[1], col[2], col[3], col[4], text)
end

local function labelValue(label, value, col)
    tc(C_DIM, label .. ':')
    ImGui.SameLine()
    tc(col or C_WHITE, tostring(value))
end

--- Same as labelValue but uses C_TGT (light blue) for the label — used in the target block.
local function tgtLabelValue(label, value, col)
    tc(C_TGT, label .. ':')
    ImGui.SameLine()
    tc(col or C_WHITE, tostring(value))
end

local function hpColor(pct)
    if     pct > 60 then return 0.10, 0.80, 0.10, 1.0
    elseif pct > 30 then return 0.90, 0.75, 0.00, 1.0
    else                 return 0.90, 0.10, 0.10, 1.0 end
end

local function drawOverlay()
    if not overlay.open then return end

    -- Refresh target data every frame
    local tgt = mq.TLO.Target
    if tgt and tgt.ID() and tgt.ID() > 0 then
        overlay.targetName     = tgt.Name()                or ''
        overlay.targetDist     = math.floor(tgt.Distance() or 0)
        overlay.targetHP       = tgt.PctHPs()              or 0
        overlay.targetType     = tgt.Type()                or ''
        -- Me.TargetOfTarget reflects exactly what the client ToT window shows
        local tot = mq.TLO.Me.TargetOfTarget
        if tot and tot.ID and tot.ID() and tot.ID() > 0 then
            overlay.targetOfTarget = tot.CleanName() or ''
        else
            overlay.targetOfTarget = ''
        end
    else
        overlay.targetName     = ''
        overlay.targetDist     = 0
        overlay.targetHP       = 0
        overlay.targetType     = 'None'
        overlay.targetOfTarget = ''
    end
    overlay.navActive = mq.TLO.Navigation.Active()
    overlay.inCombat  = mq.TLO.Me.Combat()

    ImGui.SetNextWindowSize(290, 0, 2)   -- 2 = ImGuiCond_FirstUseEver
    ImGui.SetNextWindowBgAlpha(0.82)

    overlay.open = ImGui.Begin('BardKite', overlay.open, WIN_FLAGS)
    if not overlay.open then ImGui.End() return end

    -- Header
    ImGui.TextColored(1.0, 0.75, 0.10, 1.0, '  Bard Kite Controller')
    ImGui.Separator()

    -- Zone / loop / status block
    ImGui.Spacing()
    labelValue('Zone',   overlay.zoneName,   C_YELLOW)
    labelValue('Loop',   overlay.loopActive, C_CYAN)
    local statusCol = overlay.status:find('End')    and C_RED
                   or overlay.status:find('PAUSED') and C_YELLOW
                   or overlay.status:find('DEAD')   and C_RED
                   or C_GREEN
    labelValue('Status', overlay.status, statusCol)

    ImGui.Separator()

    -- Target block
    ImGui.Spacing()
    if overlay.targetName ~= '' then
        tgtLabelValue('Target', overlay.targetName, C_WHITE)
        ImGui.SameLine()
        tc(overlay.targetType == 'NPC' and C_ORANGE or C_GREY,
           '[' .. overlay.targetType .. ']')

        -- Target of target — shows who the target is currently targeting
        local totLabel = overlay.targetName .. "'s ToT"
        local totName = overlay.targetOfTarget
        if totName ~= '' then
            tgtLabelValue(totLabel, totName, C_CYAN)
        else
            tgtLabelValue(totLabel, '< none >', C_GREY)
        end

        local distCol = overlay.targetDist <= 75 and C_GREEN
                     or overlay.targetDist <= 95 and C_ORANGE
                     or C_RED
        tgtLabelValue('Distance', overlay.targetDist .. ' yds', distCol)

        local hp = math.max(0, math.min(100, overlay.targetHP))
        local r, g, b, a = hpColor(hp)
        tc(C_TGT, 'HP:')
        ImGui.SameLine()
        local barW, barH = 160, 14
        local label = hp .. '%'
        ImGui.PushStyleColor(COL_PLOT_HIST, r, g, b, a)
        ImGui.ProgressBar(hp / 100, barW, barH, '')
        ImGui.PopStyleColor(1)
        local barMinX, barMinY = ImGui.GetItemRectMin()
        local barMaxX, _       = ImGui.GetItemRectMax()
        local textW            = ImGui.CalcTextSize(label)
        local cx = barMinX + (barMaxX - barMinX) / 2 - textW / 2
        local cy = barMinY + (barH - ImGui.GetTextLineHeight()) / 2
        ImGui.SetCursorScreenPos(cx, cy)
        ImGui.TextUnformatted(label)
        -- Dummy item to restore normal layout flow below the bar
        ImGui.Dummy(0, 0)
    else
        local noTgtText = '< no target >'
        local textW = ImGui.CalcTextSize(noTgtText)
        local winW   = ImGui.GetContentRegionAvail()
        ImGui.SetCursorPosX((winW - textW) / 2)
        ImGui.TextColored(C_RED[1], C_RED[2], C_RED[3], C_RED[4], noTgtText)
    end

    ImGui.Separator()

    -- Nav / combat indicators
    ImGui.Spacing()
    if overlay.navActive then
        ImGui.TextColored(0.20, 0.90, 0.20, 1.0, '[NAV ACTIVE]')
        ImGui.SameLine()
    end
    if overlay.inCombat then
        ImGui.TextColored(0.95, 0.20, 0.20, 1.0, '[IN COMBAT]')
    end

    -- Trak waypoint indicator (Sebilis loop only)
    if overlay.locId > 0 then
        ImGui.Spacing()
        -- TRAK_LOCS is defined in the Trak section below; #TRAK_LOCS = 4
        labelValue('Waypoint', overlay.locId .. ' / 4', C_CYAN)
    end

    -- Pause / Resume button
    ImGui.Spacing()
    if overlay.kitePaused then
        ImGui.PushStyleColor(COL_BTN,     0.10, 0.65, 0.10, 1.0)
        ImGui.PushStyleColor(COL_BTN_HOV, 0.15, 0.80, 0.15, 1.0)
        ImGui.PushStyleColor(COL_BTN_ACT, 0.05, 0.50, 0.05, 1.0)
        if ImGui.Button('  Resume Kite  ', -1, 0) then
            overlay.kitePaused = false
        end
        ImGui.PopStyleColor(3)
    else
        ImGui.PushStyleColor(COL_BTN,     0.70, 0.40, 0.00, 1.0)
        ImGui.PushStyleColor(COL_BTN_HOV, 0.90, 0.55, 0.00, 1.0)
        ImGui.PushStyleColor(COL_BTN_ACT, 0.55, 0.30, 0.00, 1.0)
        if ImGui.Button('  Pause Kite  ', -1, 0) then
            overlay.kitePaused = true
        end
        ImGui.PopStyleColor(3)
    end

    ImGui.Separator()

    -- Exit button
    ImGui.PushStyleColor(COL_BTN,     0.55, 0.10, 0.10, 1.0)
    ImGui.PushStyleColor(COL_BTN_HOV, 0.75, 0.15, 0.15, 1.0)
    ImGui.PushStyleColor(COL_BTN_ACT, 0.40, 0.05, 0.05, 1.0)
    if ImGui.Button('  Exit Script  ', -1, 0) then
        overlay.status     = 'Exiting...'
        overlay.kitePaused = true
        overlay.open       = false
    end
    ImGui.PopStyleColor(3)

    ImGui.Spacing()
    ImGui.End()
end

-- Register ImGui callback (fires every frame, non-blocking)
mq.imgui.init('BardKiteOverlay', drawOverlay)

-- ============================================================
--  VEKSAR KITE  (VeksarBoss2.mac)
--    Named NPCs: Dirloz, Gurag
--    NPC escort: Hierophant
-- ============================================================

local VEKSAR_NAMED1       = 'Dirloz'
local VEKSAR_NAMED2       = 'Gurag'
local VEKSAR_NPC_FOLLOW   = 'Hierophant'
local VEKSAR_DEBUFF_WAIT  = 9     -- seconds to wait after each named is reached

local veksarNPCFollowing = false

local function veksarDoNPCFollow()
    rs('--- Talking ' .. VEKSAR_NPC_FOLLOW .. ' to Follow me ---')
    mq.cmd('/backoff "/not|MNK BER CLE SHM SHD MAG WIZ ENC BST WAR PAL DRU ROG"')
    mq.cmd('/attack off')
    mq.cmd('/Target Clear')

    if npcNearby(VEKSAR_NPC_FOLLOW, 500) then
        mq.cmd('/target ' .. VEKSAR_NPC_FOLLOW)
        delay(0.1)
        gsay('Target ' .. (mq.TLO.Target.Name() or VEKSAR_NPC_FOLLOW))

        if mq.TLO.Target.Name.Find(VEKSAR_NPC_FOLLOW)() then
            mq.cmd('/nav target')
            while mq.TLO.Navigation.Active() do delay(0.5) end

            mq.cmd('/hail')         ; delay(0.2)
            mq.cmd('/hail')         ; delay(1.0)
            mq.cmd('/say assist')   ; delay(0.5)
            mq.cmd('/say assist')   ; delay(0.5)
            mq.cmd('/say follow')   ; delay(0.5)
            mq.cmd('/say follow')   ; delay(0.5)
            mq.cmd('/say follow')   ; delay(0.5)

            veksarNPCFollowing = true
        end
    end
end

local function veksarCheckCorpse()
    if myCorpseNearby(300) then
        overlay.status = 'Looting corpse'
        while myCorpseNearby(300) do
            delay(2.0)
            mq.cmd('/lootcorpse')
        end
        gsay('Corpse Looted. Going to Hail and make ' .. VEKSAR_NPC_FOLLOW .. ' Follow me.')
    end
end

local function veksarKiteLoop()
    local mZone = mq.TLO.Zone.ID()

    mq.cmd('/backoff')
    mq.cmd('/afollow off')
    mq.cmd('/nav stop')
    mq.cmd('/stand')

    overlay.status = 'Starting in 3...'
    rs('Starting Event, in 3') ; delay(1)
    overlay.status = 'Starting in 2...'
    rs('In 2')                 ; delay(1)
    overlay.status = 'Starting in 1...'
    rs('In 1')                 ; delay(1)
    rs('Be ready')

    veksarDoNPCFollow()

    overlay.status = 'NPC follow — moving in 10s'
    rs('NPC on Follow starting moving in 10s')
    delay(10)
    rs('MOVING')
    overlay.status = 'Kiting'

    while true do
        if checkPaused() then return end
        if checkDeath(mZone, nil) then return end

        while mq.TLO.Zone.ID() ~= mZone do
            veksarNPCFollowing = false
            overlay.status = 'Zone change — waiting'
            delay(3)
        end

        veksarCheckCorpse()
        if not veksarNPCFollowing then
            overlay.status = 'Re-establishing NPC follow'
            veksarDoNPCFollow()
        end

        -- Named 1: Dirloz
        if npcNearby(VEKSAR_NAMED1, 500) then
            mq.cmd('/backoff "/not|MNK BER CLE SHM SHD MAG WIZ ENC BST WAR PAL DRU ROG"')
            mq.cmd('/attack off')
            mq.cmd('/Target Clear')
            overlay.status = 'Moving to ' .. VEKSAR_NAMED1
            rs('--- Moving to ' .. VEKSAR_NAMED1 .. ' ---')
            mq.cmd('/target ' .. VEKSAR_NAMED1)
            mq.cmd('/dropbuff torpor')
            mq.cmd('/nav target')
            while mq.TLO.Navigation.Active() do delay(0.5) end
            for _ = 1, VEKSAR_DEBUFF_WAIT do
                if mq.TLO.Zone.ID() ~= mZone then break end
                delay(1.0)
            end
        end

        while mq.TLO.Zone.ID() ~= mZone do
            veksarNPCFollowing = false
            overlay.status = 'Zone change — waiting'
            delay(1.0)
        end

        veksarCheckCorpse()
        if not veksarNPCFollowing then
            overlay.status = 'Re-establishing NPC follow'
            veksarDoNPCFollow()
        end

        -- Named 2: Gurag
        if npcNearby(VEKSAR_NAMED2, 500) then
            mq.cmd('/backoff "/not|MNK BER CLE SHM SHD MAG WIZ ENC BST WAR PAL DRU ROG"')
            mq.cmd('/attack off')
            mq.cmd('/Target Clear')
            overlay.status = 'Moving to ' .. VEKSAR_NAMED2
            rs('--- Moving to ' .. VEKSAR_NAMED2 .. ' ---')
            mq.cmd('/target ' .. VEKSAR_NAMED2)
            mq.cmd('/dropbuff torpor')
            mq.cmd('/nav target')
            while mq.TLO.Navigation.Active() do delay(0.5) end
            for _ = 1, VEKSAR_DEBUFF_WAIT do
                if mq.TLO.Zone.ID() ~= mZone then break end
                delay(1.0)
            end
        end

        -- End condition: both named gone
        if  mq.TLO.Zone.ID() == mZone
        and not npcNearby(VEKSAR_NAMED1, 500)
        and not npcNearby(VEKSAR_NAMED2, 500) then
            overlay.status = 'Event End'
            rs('--- ' .. VEKSAR_NAMED1 .. ' and ' .. VEKSAR_NAMED2 .. ' not found ---')
            rs('--- Event End ---')
            return
        end

        overlay.status = 'Kiting'
        mq.doevents()
    end
end

-- ============================================================
--  OLD SEBILIS / TRAK KITE  (TrakBardKite.mac)
--    Named NPC : Reaver
--    Kite style: 4-waypoint circuit, proc items at range.
--    Agro check: Reaver must always have the Bard as its target.
--                If agro is lost, run to Reaver, use Boastful Bellow
--                + TRAK_ITEMS to regain it before resuming the circuit.
-- ============================================================

local TRAK_NAMED = 'Reaver'

-- Waypoints cycled in order; coordinates are Y, X, Z for /nav loc
local TRAK_LOCS = {
    { y = -2055, x = -630,  z = -140 },
    { y = -2248, x = -624,  z = -140 },
    { y = -2204, x = -816,  z = -140 },
    { y = -2055, x = -816,  z = -140 },
}

-- Centroid of TRAK_LOCS — where the bard waits before Reaver spawns.
-- Calculated as the average Y/X/Z of all four waypoints so the bard is
-- centrally positioned to pick up agro the moment Reaver appears.
local TRAK_WAIT_LOC = { y = -2140, x = -722, z = -140 }

-- Proc/clickie items used when mob distance >= 80 (and for agro regain)
local TRAK_ITEMS = {
    "Invocation Rune: Vulka's Chant of Lightning",
    "Forsaken Zealot's Incarnadine Sword",
    "Forsaken Singing Steel Vambraces",
    "Forsaken Singing Steel Gaunlets",
    "Forsaken Rod of Lamentation",
    "Forsaken Sword of the Morning",
    "Forsaken Fayguard Bladecatcher",
    "Rapier of Somber Notes",
}

local function trakUseItems()
    for _, item in ipairs(TRAK_ITEMS) do
        mq.cmd('/useitem ' .. item)
    end
    delay(0.1)
end

local function trakGoLocId(locId)
    local loc = TRAK_LOCS[locId]
    mq.cmd(string.format('/nav loc %d %d %d', loc.y, loc.x, loc.z))
end

--- Returns true when Reaver's current target is the bard (Me).
local function trakReaverTargetingMe()
    local myName     = mq.TLO.Me.Name()
    local reaverSpawn = mq.TLO.Spawn('npc ' .. TRAK_NAMED)
    if not reaverSpawn or not reaverSpawn.ID() or reaverSpawn.ID() == 0 then
        return false
    end
    local reaverTarget = reaverSpawn.TargetOfTarget()
    if not reaverTarget then return false end
    return (reaverTarget() or ''):lower() == myName:lower()
end

--- Run to Reaver and use Boastful Bellow + all TRAK_ITEMS to regain agro.
--- Blocks until Reaver is targeting the bard again or the bard is close.
local function trakRegainAgro()
    overlay.status = 'Agro lost — running to ' .. TRAK_NAMED
    rs('--- Agro lost! Running to ' .. TRAK_NAMED .. ' to regain ---')
    log('Agro lost on ' .. TRAK_NAMED .. ' — running in to regain.')

    mq.cmd('/nav stop')
    mq.cmd('/attack off')
    mq.cmd('/backoff /only|BRD')

    -- Target Reaver
    mq.cmd('/target ' .. TRAK_NAMED)
    delay(0.2)

    -- Navigate directly to Reaver
    if mq.TLO.Target.Name.Find(TRAK_NAMED)() then
        mq.cmd('/nav target')
        while mq.TLO.Navigation.Active() do
            if targetDistance() <= 30 then
                mq.cmd('/nav stop')
                break
            end
            mq.doevents()
            delay(0.1)
        end
    end

    -- Fire Boastful Bellow AA then all proc items to re-establish agro
    mq.cmd('/alt act 106')      -- Boastful Bellow
    delay(0.3)
    trakUseItems()

    -- Wait up to 5 s for Reaver to swing back to us
    local waited = 0
    while not trakReaverTargetingMe() and waited < 50 do
        delay(0.1)
        waited = waited + 1
        mq.doevents()
    end

    if trakReaverTargetingMe() then
        overlay.status = 'Agro regained — resuming kite'
        rs('--- Agro regained on ' .. TRAK_NAMED .. ' ---')
        log('Agro regained on ' .. TRAK_NAMED .. '. Resuming kite circuit.')
    else
        overlay.status = 'Agro uncertain — continuing'
        rs('--- Warning: could not confirm agro regain on ' .. TRAK_NAMED .. ' — continuing ---')
        log('Warning: could not confirm agro regain. Continuing kite.')
    end

    mq.cmd('/attack off')
    mq.cmd('/backoff /only|BRD')
end

local function trakKiteLoop()
    local mZone = mq.TLO.Zone.ID()
    local locId = 1
    overlay.locId = locId

    mq.cmd('/backoff')
    mq.cmd('/afollow off')
    mq.cmd('/nav stop')
    mq.cmd('/stand')
    rs('Be ready')

    -- Navigate to the centre of the kite circuit before Reaver spawns.
    -- This positions the bard to pick up agro the moment Reaver appears.
    overlay.status = 'Moving to wait position...'
    rs('--- Moving to kite wait position — waiting for ' .. TRAK_NAMED .. ' to spawn ---')
    log('Moving to kite wait position while waiting for ' .. TRAK_NAMED .. ' to spawn.')
    mq.cmd(string.format('/nav loc %d %d %d',
        TRAK_WAIT_LOC.y, TRAK_WAIT_LOC.x, TRAK_WAIT_LOC.z))

    local reaverSpawnedEnRoute = false
    while mq.TLO.Navigation.Active() do
        if npcNearby(TRAK_NAMED, 800) then
            mq.cmd('/nav stop')
            reaverSpawnedEnRoute = true
            break
        end
        mq.doevents()
        delay(0.2)
    end

    -- If Reaver spawned while we were still pathing, close in first then grab agro
    if reaverSpawnedEnRoute then
        overlay.status = TRAK_NAMED .. ' spawned en route — closing in!'
        rs(TRAK_NAMED .. ' Popped en route — closing in to grab agro!')
        log(TRAK_NAMED .. ' spawned while pathing to wait position — closing in immediately.')
        mq.cmd('/attack off')
        mq.cmd('/backoff /only|BRD')
        mq.cmd('/target ' .. TRAK_NAMED)
        delay(0.2)
        if mq.TLO.Target.Name.Find(TRAK_NAMED)() then
            overlay.status = 'Closing in on ' .. TRAK_NAMED .. '...'
            mq.cmd('/nav target')
            while mq.TLO.Navigation.Active() do
                if targetDistance() <= 80 then
                    mq.cmd('/nav stop')
                    break
                end
                mq.doevents()
                delay(0.2)
            end
        end
        -- Now in range — fire Boastful Bellow + all proc items to establish agro
        overlay.status = 'Grabbing agro on ' .. TRAK_NAMED
        mq.cmd('/alt act 106')   -- Boastful Bellow
        delay(0.3)
        trakUseItems()
    else
        -- We reached the wait position normally — wait for Reaver to spawn
        overlay.status = 'Waiting for ' .. TRAK_NAMED
        rs('--- Waiting for ' .. TRAK_NAMED .. ' to spawn ---')
        log('Waiting for ' .. TRAK_NAMED .. ' to spawn...')
        while not npcNearby(TRAK_NAMED, 800) do
            delay(0.5)
            mq.doevents()
        end
        mq.cmd('/attack off')
        mq.cmd('/backoff /only|BRD')
        rs(TRAK_NAMED .. ' Popped')
        overlay.status = TRAK_NAMED .. ' popped — closing in'
    end

    -- Navigate to within 80 yards of Reaver before starting the kite
    -- (skipped if we already closed in during the en-route spawn path)
    if not reaverSpawnedEnRoute and npcNearby(TRAK_NAMED, 800) then
        mq.cmd('/target ' .. TRAK_NAMED)
        delay(0.1)
        if mq.TLO.Target.Name.Find(TRAK_NAMED)() then
            mq.cmd('/nav target')
            while mq.TLO.Navigation.Active() do
                delay(0.2)
                if targetDistance() <= 80 then
                    mq.cmd('/nav stop')
                    break
                end
            end
        end
    end
    delay(0.5)

    mq.cmd('/playmelody combat Force')
    overlay.status = 'Kiting ' .. TRAK_NAMED

    while true do
        if checkPaused() then return end
        if checkDeath(mZone, function()
            if npcNearby(TRAK_NAMED, 800) and not trakReaverTargetingMe() then
                rs('--- Agro not confirmed after rez — running regain routine ---')
                log('Agro not confirmed after rez — running regain routine.')
                trakRegainAgro()
            else
                rs('--- Agro confirmed after rez — resuming kite ---')
                log('Agro confirmed after rez — resuming kite.')
                overlay.status = 'Agro confirmed — resuming kite'
            end
        end) then return end

        -- Zone-change guard: Reaver is dead or we zoned — end
        if mq.TLO.Zone.ID() ~= mZone then
            overlay.status = 'Zoned out — ending'
            rs('--- Zoned out — Trak kite ending ---')
            overlay.locId = 0
            return
        end

        -- Re-target Reaver on our end if we've lost it
        if not mq.TLO.Target.Name.Find(TRAK_NAMED)() then
            mq.cmd('/target ' .. TRAK_NAMED)
            delay(0.1)
        end

        mq.cmd('/attack off')

        if mq.TLO.Me.Combat() then
            mq.cmd('/backoff /only|BRD')
        end

        -- Sustain AA (Selo's Accelerando)
        mq.cmd('/alt act 199')

        -- ---- Agro check ----
        -- Only kite the waypoint circuit while Reaver is targeting the bard.
        -- If agro is lost, run in and regain it before continuing.
        if not trakReaverTargetingMe() then
            trakRegainAgro()
            -- Skip the rest of this iteration; re-evaluate next tick
            mq.doevents()
        else
            -- Mob is too close: run the next waypoint
            if targetDistance() <= 75 then
                overlay.status = 'Too close — moving to waypoint ' .. locId
                trakGoLocId(locId)
                overlay.locId = locId
                locId = locId % #TRAK_LOCS + 1

                while mq.TLO.Navigation.Active() do
                    local dist = targetDistance()

                    -- Agro lost mid-nav — stop and regain before continuing
                    if not trakReaverTargetingMe() then
                        mq.cmd('/nav stop')
                        trakRegainAgro()
                        break
                    end

                    -- Mob caught up while moving — pause nav
                    if dist >= 95 and not mq.TLO.Navigation.Paused() then
                        mq.cmd('/nav pause')
                    end

                    -- Mob fell back — unpause nav (toggle)
                    if dist <= 75 and mq.TLO.Navigation.Paused() then
                        mq.cmd('/nav pause')
                    end

                    -- Mob is far enough — fire proc items
                    if dist >= 80 then
                        trakUseItems()
                    end

                    mq.doevents()
                end
                overlay.status = 'Kiting ' .. TRAK_NAMED
            end

            -- Fire proc items whenever mob is at range outside of nav
            if targetDistance() >= 80 then
                trakUseItems()
            end
        end

        mq.doevents()
    end
end

-- ============================================================
--  ZONE DETECTION
-- ============================================================

local function getZoneLoop()
    local zoneSN = (mq.TLO.Zone.ShortName() or ''):lower()
    return ZONE_LOOP[zoneSN]
end

-- ============================================================
--  ENTRY POINT
-- ============================================================

local function main()
    -- Step 1: Am I a Bard?
    if not isBard() then
        log('I am not a Bard (' .. mq.TLO.Me.Class.ShortName() .. ').')
        local bardName = findGroupBard()
        if bardName then
            log('Found group Bard: ' .. bardName .. '. Delegating...')
            delegateToBard(bardName)
        else
            log('No Bard found in group. Cannot run kite script.')
            rs('No Bard in group — kite script aborted.')
        end
        return  -- no overlay for non-bards
    end

    log('I am a Bard. Continuing as kite driver.')

    -- Step 2: Zone detection
    local zoneID   = mq.TLO.Zone.ID()
    local zoneName = mq.TLO.Zone.Name()      or 'Unknown'
    local zoneSN   = mq.TLO.Zone.ShortName() or 'unknown'

    log(string.format('Zone: %s (ID %d, shortname "%s")', zoneName, zoneID, zoneSN))

    overlay.zoneName  = zoneName
    overlay.zoneShort = zoneSN

    -- Step 3: Select and run the correct kite loop
    local loopKey = getZoneLoop()

    if loopKey == 'veksar' then
        overlay.loopActive = 'Veksar Named'
        log('Veksar detected. Running Veksar kite loop.')
        rs('Veksar — starting Named kite loop.')
        veksarKiteLoop()

    elseif loopKey == 'trak' then
        overlay.loopActive = 'Trak / Reaver (Sebilis)'
        overlay.locId      = 1
        log('Old Sebilis detected. Running Trak/Reaver kite loop.')
        rs('Old Sebilis — starting Reaver kite loop.')
        trakKiteLoop()

    else
        -- Zone not in map: stay alive with the window open and script paused
        overlay.loopActive = 'None'
        overlay.kitePaused = true
        overlay.status     = 'PAUSED — zone not mapped'
        local msg = string.format('Zone "%s" (ID %d) is not in the kite map.', zoneName, zoneID)
        local msg2 = 'Add it to ZONE_LOOP to enable kiting here.'
        log(msg)
        log(msg2)
        while overlay.open do
            mq.delay(200)
            mq.doevents()
        end
        log('Window closed — exiting.')
        return
    end

    overlay.status = 'Script finished'
    log('Script finished.')
end

main()
