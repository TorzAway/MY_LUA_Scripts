--[[
The Column class represents the static configuration of a column defined in boxhud-settings
--]]
local BaseClass = require 'classes.base'
local state = require 'state'
local helpers = require 'utils.uihelpers'

local Column = BaseClass(function(c,columnSettings)
    c.Name = columnSettings['Name']
    c.Type = columnSettings['Type']
    c.Properties = columnSettings['Properties']
    c.Mappings = columnSettings['Mappings']
    c.Thresholds = columnSettings['Thresholds']
    c.Percentage = columnSettings['Percentage']
    c.Ascending = columnSettings['Ascending']
    c.InZone = columnSettings['InZone']
    c.Action = columnSettings['Action']
    c.IncludeLevel = columnSettings['IncludeLevel']
    c.OwnColor = columnSettings['OwnColor']
    c.Color = columnSettings['Color']
    c.Prettify = columnSettings['Prettify']
end)

function Column:validateProperties()
    local message = nil
    local valid = true
    for _,propName in pairs(self.Properties) do
        if string.len(propName) > 0 then
            if not state.Settings['Properties'][propName] then
                message = string.format('Column \'Properties\' must reference a valid \'Observed\', \'NetBots\' or \'Spawn\' property. Name=%s', propName)
                print_err(string.format('[Column %s] %s', self.Name, message))
                valid = false
            end
        else
            message = 'Column \'Properties\' must be non-empty \'string\''
            print_err(string.format('[Column %s] %s', self.Name, message))
            valid = false
        end
    end
    return valid, message
end

function Column:validateMappings()
    local valid = true
    -- what makes a mapping invalid?
    return valid
end

function Column:validateThresholds()
    local message = nil
    if #self.Thresholds > 2 then
        message = 'Column \'Thresholds\' may contain either 1 or 2 number values, no more'
        print_err(string.format('[Column %s] %s', self.Name, message))
        return false, message
    else
        for thresholdIdx, value in ipairs(self.Thresholds) do
            if type(value) ~= 'number' then
                message = 'Column \'Thresholds\' values must be numbers in ascending order'
                print_err(string.format('[Column %s] %s', self.Name, message))
                return false, message
            end
            if thresholdIdx == 2 and value < self.Thresholds[1] then
                message = 'Column \'Thresholds\' values must be numbers in ascending order'
                print_err(string.format('[Column %s] %s', self.Name, message))
                return false, message
            end
        end
    end
    return true, message
end

function Column:validate()
    local message = nil
    if not self.Name or type(self.Name) ~= 'string' or string.len(self.Name) == 0 then
        message = 'Columns name is invalid. Name must be a non-empty string.'
        print_err(string.format('[Column %s] %s', self.Name, message))
        return false, message
    elseif self.Name == 'Name' then
        -- special case name column
        return true, nil
    end
    if self.Type then
        if type(self.Type) ~= 'string' or (self.Type ~= 'button' and self.Type ~= 'property') then
            message = string.format('Column Type must be \'property\' or \'button\'. Type=%s', self.Type)
            print_err(string.format('[Column %s] %s', self.Name, message))
            return false, message
        end
    else
        self.Type = 'property'
    end
    local valid = true
    if self.Type == 'property' then
        if not self.Properties or type(self.Properties) ~= 'table' then
            message = 'Property Columns must have a \'Properties\' table'
            print_err(string.format('[Column %s] %s', self.Name, message))
            valid = false
        else
            local ok, m1 = self:validateProperties()
            if not ok then
                message = m1
                valid = false
            end
        end
        if self.Mappings then
            if type(self.Mappings) ~= 'table' then
                message = 'Column \'Mappings\' must be a table'
                print_err(string.format('[Column %s] %s', self.Name, message))
                valid = false
            else
                local ok, m1 = self:validateMappings()
                if not ok then
                    message = m1
                    valid = false
                end
            end
        end
        if self.Thresholds then 
            if type(self.Thresholds) ~= 'table' then
                message = 'Column \'Thresholds\' must be a table'
                print_err(string.format('[Column %s] %s', self.Name, message))
                valid = false
            else
                local ok, m1 = self:validateThresholds()
                if not ok then
                    message = m1
                    valid = false
                end
            end
        end
        if self.Percentage and type(self.Percentage) ~= 'boolean' then
            message = 'Columns \'Percentage\' must be true or false'
            print_err(string.format('[Column %s] %s', self.Name, message))
            valid = false
        end
        if self.Ascending and type(self.Ascending) ~= 'boolean' then
            message = 'Columns \'Ascending\' must be true or false'
            print_err(string.format('[Column %s] %s', self.Name, message))
            valid = false
        end
        if self.InZone and type(self.InZone) ~= 'boolean' then
            message = 'Column \'InZone\' must be true or false'
            print_err(string.format('[Column %s] %s', self.Name, message))
            valid = false
        end
    elseif self.Type == 'button' then
        if not self.Action or type(self.Action) ~= 'string' then
            message = 'Button Columns must have an \'Actions\' property'
            print_err(string.format('[Column %s] %s', self.Name, message))
            valid = false
        end
    end
    return valid, message
end

local function tableToRows(t)
    local rows = {}
    if t then
        for k,v in pairs(t) do
            rows[#rows+1] = {k, v}
        end
    end
    if #rows == 0 then rows[1] = {'', ''} end
    return rows
end

local function rowsToTable(rows)
    local result = {}
    local any = false
    for _,row in ipairs(rows) do
        if row[1] and string.len(row[1]) > 0 then
            result[row[1]] = row[2]
            any = true
        end
    end
    if not any then return nil end
    return result
end

function Column:drawPropertiesRows()
    if not self._editProperties then self._editProperties = tableToRows(self.Properties) end
    ImGui.Separator()
    ImGui.Text('Properties')
    for i,row in ipairs(self._editProperties) do
        ImGui.PushID('editpropkey'..i)
        row[1],_ = ImGui.InputText('Key##'..i, row[1])
        ImGui.PopID()
        ImGui.SameLine()
        ImGui.PushID('editpropval'..i)
        row[2] = helpers.DrawComboBox('Property##'..i, row[2], state.Settings['Properties'], true)
        ImGui.PopID()
    end
    if ImGui.Button('Add Property Row') then
        self._editProperties[#self._editProperties+1] = {'', ''}
    end
    ImGui.SameLine()
    if ImGui.Button('Remove Property Row') and #self._editProperties > 1 then
        self._editProperties[#self._editProperties] = nil
    end
end

function Column:drawMappingsRows()
    if not self._editMappings then self._editMappings = tableToRows(self.Mappings) end
    ImGui.Separator()
    ImGui.Text('Mappings')
    for i,row in ipairs(self._editMappings) do
        ImGui.PushID('editmapkey'..i)
        row[1],_ = ImGui.InputText('Value##'..i, row[1])
        ImGui.PopID()
        ImGui.SameLine()
        ImGui.PushID('editmapval'..i)
        row[2],_ = ImGui.InputText('Displays As##'..i, row[2])
        ImGui.PopID()
    end
    if ImGui.Button('Add Mapping Row') then
        self._editMappings[#self._editMappings+1] = {'', ''}
    end
    ImGui.SameLine()
    if ImGui.Button('Remove Mapping Row') and #self._editMappings > 0 then
        self._editMappings[#self._editMappings] = nil
    end
end

function Column:drawThresholdsRows()
    if not self._editThresholds then
        self._editThresholds = {}
        if self.Thresholds then
            for i,v in ipairs(self.Thresholds) do self._editThresholds[i] = v end
        end
    end
    ImGui.Separator()
    ImGui.Text('Thresholds')
    for i,_ in ipairs(self._editThresholds) do
        ImGui.PushID('editthreshold'..i)
        self._editThresholds[i],_ = ImGui.InputInt('Threshold##'..i, self._editThresholds[i])
        ImGui.PopID()
    end
    if ImGui.Button('Add Threshold') and #self._editThresholds < 2 then
        self._editThresholds[#self._editThresholds+1] = 0
    end
    ImGui.SameLine()
    if ImGui.Button('Remove Threshold') and #self._editThresholds > 0 then
        self._editThresholds[#self._editThresholds] = nil
    end
end

function Column:draw(panel)
    ImGui.Text('Column: '..self.Name)
    ImGui.Separator()
    helpers.DrawLabelAndTextValue('Type: ', self.Type)

    if self.Type == 'button' then
        if self._editAction == nil then self._editAction = self.Action end
        self._editAction = helpers.DrawLabelAndTextInput('Action', '##editcolumnaction', self._editAction, 'Command to run on click. Use #botName# to substitute the row\'s character name.')
    else
        self:drawPropertiesRows()
        self:drawMappingsRows()
        self:drawThresholdsRows()
        if self._editPercentage == nil then self._editPercentage = self.Percentage or false end
        if self._editAscending == nil then self._editAscending = self.Ascending or false end
        if self._editInZone == nil then self._editInZone = self.InZone or false end
        self._editPercentage = helpers.DrawCheckBox('Percentage', '##editcolumnpercentage', self._editPercentage, 'Display and color the value as a percentage.')
        self._editAscending = helpers.DrawCheckBox('Ascending', '##editcolumnascending', self._editAscending, 'Color low-to-high as red-to-green instead of green-to-red.')
        self._editInZone = helpers.DrawCheckBox('In Zone Only', '##editcolumninzone', self._editInZone, 'Only display this column\'s value for characters in your current zone.')
    end

    ImGui.Separator()
    if self.Message then
        ImGui.TextColored(1, 0, 0, 1, self.Message)
    end

    if ImGui.Button('Save##editcolumn') then
        self.Message = nil
        if self.Type == 'button' then
            self.Action = self._editAction
        else
            self.Properties = rowsToTable(self._editProperties)
            self.Mappings = rowsToTable(self._editMappings)
            self.Thresholds = (#self._editThresholds > 0) and self._editThresholds or nil
            self.Percentage = self._editPercentage
            self.Ascending = self._editAscending
            self.InZone = self._editInZone
        end
        local valid, message = self:validate()
        if valid then
            require('settings.settings').SaveSettings()
        else
            self.Message = message or 'Invalid column configuration.'
        end
    end
    ImGui.SameLine()
    if ImGui.Button('Delete##editcolumn') then
        state.Settings['Columns'][self.Name] = nil
        require('settings.settings').SaveSettings()
        panel:selectItem(nil, nil)
    end
end

return Column