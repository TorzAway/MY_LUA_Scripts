--[[
The ColumnInput class holds the inputs for creating a new Column
--]]
local BaseClass = require 'classes.base'
local Input = require 'classes.inputs.input'
local helpers = require 'utils.uihelpers'
local Column = require 'classes.config.column'
local state = require 'state'

local ColumnInput = BaseClass(Input(), function(c)
    c.Type=1
    c.Properties={[1]={[1]='',[2]=''}}
    c.PropertyCount=1
    c.Mappings={}
    c.MappingCount=0
    c.Thresholds={}
    c.ThresholdCount=0
    c.Percentage=false
    c.Ascending=true
    c.InZone=true
    c.OwnColor=false
    c.Prettify=false
    c.Action=''
end)

local TYPE_OPTIONS = {'property', 'button'}

function ColumnInput:fromColumn(column)
    local input = ColumnInput()
    if not column then return input end

    input.Name = column.Name

    input.Type = 1
    for i, opt in ipairs(TYPE_OPTIONS) do
        if opt == column.Type then
            input.Type = i
            break
        end
    end

    input.Action = column.Action or ''

    input.Properties = {}
    input.PropertyCount = 0
    if column.Properties then
        for key, value in pairs(column.Properties) do
            input.PropertyCount = input.PropertyCount + 1
            input.Properties[input.PropertyCount] = {key, value}
        end
    end
    if input.PropertyCount == 0 then
        input.Properties = {[1] = {[1] = '', [2] = ''}}
        input.PropertyCount = 1
    end

    input.Mappings = {}
    input.MappingCount = 0
    if column.Mappings then
        for key, value in pairs(column.Mappings) do
            input.MappingCount = input.MappingCount + 1
            input.Mappings[input.MappingCount] = {key, value}
        end
    end

    input.Thresholds = {}
    input.ThresholdCount = 0
    if column.Thresholds then
        for _, value in ipairs(column.Thresholds) do
            input.ThresholdCount = input.ThresholdCount + 1
            input.Thresholds[input.ThresholdCount] = value
        end
    end

    input.Percentage = column.Percentage or false
    input.Ascending = column.Ascending
    if input.Ascending == nil then input.Ascending = true end
    input.InZone = column.InZone
    if input.InZone == nil then input.InZone = true end
    input.OwnColor = column.OwnColor or false
    input.Color = column.Color
    input.Prettify = column.Prettify or false

    return input
end

function ColumnInput:drawPropertiesInputs()
    ImGui.Separator()
    ImGui.Text('Properties')
    ImGui.SameLine()
    helpers.HelpMarker('Map a key (e.g. \'all\' or a class name) to one of your defined Properties. Most columns just need a single \'all\' entry.')
    for i=1,self.PropertyCount do
        if not self.Properties[i] then self.Properties[i] = {[1]='', [2]=''} end
        ImGui.PushID('propkey'..i)
        self.Properties[i][1],_ = ImGui.InputText('Key##'..i, self.Properties[i][1])
        ImGui.PopID()
        ImGui.SameLine()
        ImGui.PushID('propval'..i)
        self.Properties[i][2] = helpers.DrawComboBox('Property##'..i, self.Properties[i][2], state.Settings['Properties'], true)
        ImGui.PopID()
    end
    if ImGui.Button('Add Property Row') then
        self.PropertyCount = self.PropertyCount + 1
        self.Properties[self.PropertyCount] = {[1]='', [2]=''}
    end
    ImGui.SameLine()
    if ImGui.Button('Remove Property Row') and self.PropertyCount > 1 then
        self.Properties[self.PropertyCount] = nil
        self.PropertyCount = self.PropertyCount - 1
    end
end

function ColumnInput:drawMappingsInputs()
    ImGui.Separator()
    ImGui.Text('Mappings')
    ImGui.SameLine()
    helpers.HelpMarker('Optional: map raw property values to display text, e.g. 1 -> \'Yes\'.')
    for i=1,self.MappingCount do
        if not self.Mappings[i] then self.Mappings[i] = {[1]='', [2]=''} end
        ImGui.PushID('mapkey'..i)
        self.Mappings[i][1],_ = ImGui.InputText('Value##'..i, self.Mappings[i][1])
        ImGui.PopID()
        ImGui.SameLine()
        ImGui.PushID('mapval'..i)
        self.Mappings[i][2],_ = ImGui.InputText('Displays As##'..i, self.Mappings[i][2])
        ImGui.PopID()
    end
    if ImGui.Button('Add Mapping Row') then
        self.MappingCount = self.MappingCount + 1
        self.Mappings[self.MappingCount] = {[1]='', [2]=''}
    end
    ImGui.SameLine()
    if ImGui.Button('Remove Mapping Row') and self.MappingCount > 0 then
        self.Mappings[self.MappingCount] = nil
        self.MappingCount = self.MappingCount - 1
    end
end

function ColumnInput:drawThresholdsInputs()
    ImGui.Separator()
    ImGui.Text('Thresholds')
    ImGui.SameLine()
    helpers.HelpMarker('Optional: 1 or 2 ascending numeric thresholds used for red/yellow/green coloring.')
    for i=1,self.ThresholdCount do
        if not self.Thresholds[i] then self.Thresholds[i] = 0 end
        ImGui.PushID('threshold'..i)
        self.Thresholds[i],_ = ImGui.InputInt('Threshold##'..i, self.Thresholds[i])
        ImGui.PopID()
    end
    if ImGui.Button('Add Threshold') and self.ThresholdCount < 2 then
        self.ThresholdCount = self.ThresholdCount + 1
        self.Thresholds[self.ThresholdCount] = 0
    end
    ImGui.SameLine()
    if ImGui.Button('Remove Threshold') and self.ThresholdCount > 0 then
        self.Thresholds[self.ThresholdCount] = nil
        self.ThresholdCount = self.ThresholdCount - 1
    end
end

function ColumnInput:buildPropertiesTable()
    local result = {}
    for i=1,self.PropertyCount do
        local entry = self.Properties[i]
        if entry and entry[1] and string.len(entry[1]) > 0 then
            result[entry[1]] = entry[2]
        end
    end
    return result
end

function ColumnInput:buildMappingsTable()
    if self.MappingCount == 0 then return nil end
    local result = {}
    for i=1,self.MappingCount do
        local entry = self.Mappings[i]
        if entry and entry[1] and string.len(entry[1]) > 0 then
            result[entry[1]] = entry[2]
        end
    end
    return result
end

function ColumnInput:buildThresholdsTable()
    if self.ThresholdCount == 0 then return nil end
    local result = {}
    for i=1,self.ThresholdCount do
        result[i] = self.Thresholds[i]
    end
    return result
end

function ColumnInput:draw(width, panel)
    ImGui.PushTextWrapPos(width-17)
    ImGui.Text('Add New Column')
    ImGui.PopTextWrapPos()
    ImGui.Separator()

    self.Name = helpers.DrawLabelAndTextInput('Name', '##columnname', self.Name, 'The name of this column, used to reference it from Tabs.')
    self.Type = helpers.DrawComboBox('Type', self.Type, TYPE_OPTIONS, false)

    if self.Type == 'button' then
        self.Action = helpers.DrawLabelAndTextInput('Action', '##columnaction', self.Action, 'Command to run on click. Use #botName# to substitute the row\'s character name, e.g. /dex #botName# /mqp')
    else
        self:drawPropertiesInputs()
        self:drawMappingsInputs()
        self:drawThresholdsInputs()
        self.Percentage = helpers.DrawCheckBox('Percentage', '##columnpercentage', self.Percentage, 'Display and color the value as a percentage.')
        self.Ascending = helpers.DrawCheckBox('Ascending', '##columnascending', self.Ascending, 'Color low-to-high as red-to-green instead of green-to-red.')
        self.InZone = helpers.DrawCheckBox('In Zone Only', '##columninzone', self.InZone, 'Only display this column\'s value for characters in your current zone.')
    end

    self.OwnColor = helpers.DrawCheckBox('Custom Color', '##columnowncolor', self.OwnColor, 'Use a fixed custom color instead of the default/threshold coloring.')
    if self.OwnColor then
        self.Color = helpers.DrawColorEditor('Color##column', self.Color or {1,1,1})
    end
    self.Prettify = helpers.DrawCheckBox('Prettify', '##columnprettify', self.Prettify, 'Attempt to format the raw value for nicer display.')

    ImGui.Separator()
    if self.Message then
        ImGui.TextColored(1, 0, 0, 1, self.Message)
    end

    if ImGui.Button('Save##column') then
        self.Message = nil
        if not self.Name or string.len(self.Name) == 0 then
            self.Message = 'Name is required.'
        elseif state.Settings['Columns'][self.Name] then
            self.Message = 'A column with this name already exists.'
        else
            local columnSettings = {
                Name = self.Name,
                Type = self.Type,
                Properties = self.Type == 'property' and self:buildPropertiesTable() or nil,
                Mappings = self.Type == 'property' and self:buildMappingsTable() or nil,
                Thresholds = self.Type == 'property' and self:buildThresholdsTable() or nil,
                Percentage = self.Type == 'property' and self.Percentage or nil,
                Ascending = self.Type == 'property' and self.Ascending or nil,
                InZone = self.Type == 'property' and self.InZone or nil,
                Action = self.Type == 'button' and self.Action or nil,
                OwnColor = self.OwnColor,
                Color = self.Color,
                Prettify = self.Prettify,
            }
            local newColumn = Column(columnSettings)
            local valid, message = newColumn:validate()
            if valid then
                state.Settings['Columns'][self.Name] = newColumn
                require('settings.settings').SaveSettings()
                panel:selectItem(self.Name, 'column')
            else
                self.Message = message or 'Invalid column configuration.'
            end
        end
    end
    ImGui.SameLine()
    if ImGui.Button('Cancel##column') then
        panel:selectItem(nil, nil)
    end
end

return ColumnInput