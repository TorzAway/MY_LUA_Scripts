-- Persistent Data
local multiRefObjects = {

} -- multiRefObjects
local obj1 = {
	["TitleBar"] = false;
	["DanNetPeerGroup"] = "zone";
	["PeerSource"] = "dannet";
	["Transparency"] = false;
	["RefreshInterval"] = 250;
	["SchemaVersion"] = 2;
	["Columns"] = {
		["Silver"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Me.Silver";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "Silver";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["Copper"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Me.Copper";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "Copper";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["Gimme $$$"] = {
			["Action"] = "/dex #botName# /macro DoConv STICKEMUP";
			["Name"] = "Gimme $$$";
			["Type"] = "button";
		};
		["Get Stats"] = {
			["Action"] = "/multi ; /e3bcaa /timed 5 /squelch /windowstate AdventureRequestWnd open ; /e3bcaa /timed 10 /squelch /notify AdventureRequestWnd AdvRqst_ViewStatsButton leftmouseup ; /e3bcaa /timed 15 /squelch /notify AdventureStatsWnd AdvStats_DoneButton leftmouseup ; /e3bcaa /timed 20 /squelch /windowstate AdventureRequestWnd close";
			["Name"] = "Get Stats";
			["Type"] = "button";
		};
		["GUK #"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[1,3]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "GUK #";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["MIRA #"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[2,3]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "MIRA #";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["MIST #"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[3,3]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "MIST #";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["RUJ #"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[4,3]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "RUJ #";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["TAK #"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[5,3]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "TAK #";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["Rez"] = {
			["Action"] = "/e3bct #botName# /multi ; /rrez ; /grez";
			["Name"] = "Rez";
			["Type"] = "button";
		};
		["Get Corpse"] = {
			["Action"] = "/e3bct #botName# /multi ; /corpse ; /timed 5 /gathercorpse";
			["Name"] = "Get Corpse";
			["Type"] = "button";
		};
		["HP Pot"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "FindItemCount[=Distillate of Divine Healing XI]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "HP Pot";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["Res Sick"] = {
			["Percentage"] = false;
			["Type"] = "property";
			["InZone"] = true;
			["Ascending"] = false;
			["Name"] = "Res Sick";
			["Prettify"] = true;
			["Properties"] = {
				["all"] = "Me.Buff[Resurrection Sickness].Duration";
			};
			["Thresholds"] = {
				[1] = 38000;
			};
			["OwnColor"] = false;
		};
		["Rez Tokens"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "FindItemCount[=Token of Resurrection]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "Rez Tokens";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["WIPE"] = {
			["Action"] = "/e3bcgza /wipe";
			["Name"] = "WIPE";
			["Type"] = "button";
		};
		["E3 Reload"] = {
			["Action"] = "/dex #botName# /mono e3";
			["Name"] = "E3 Reload";
			["Type"] = "button";
		};
		["Exp%"] = {
			["InZone"] = false;
			["Percentage"] = true;
			["Name"] = "Exp%";
			["Ascending"] = true;
			["Properties"] = {
				["all"] = "Me.PctExp";
			};
			["Thresholds"] = {
				[1] = 33;
				[2] = 66;
			};
			["Type"] = "property";
		};
		["AA%"] = {
			["Percentage"] = true;
			["Type"] = "property";
			["InZone"] = true;
			["Ascending"] = true;
			["Name"] = "AA%";
			["Prettify"] = false;
			["Properties"] = {
				["all"] = "Me.PctAAExp";
			};
			["Thresholds"] = {
				[1] = 33;
				[2] = 66;
			};
			["OwnColor"] = false;
		};
		["AASpent"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Me.AAPointsAssigned";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "AASpent";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["AA Unspent"] = {
			["InZone"] = false;
			["Percentage"] = false;
			["Name"] = "AA Unspent";
			["Ascending"] = false;
			["Properties"] = {
				["all"] = "Me.AAPoints";
			};
			["Thresholds"] = {
				[1] = 50;
				[2] = 100;
			};
			["Type"] = "property";
		};
		["Invis *"] = {
			["_editAction"] = "/multi ; /e3bcgza /alt act 630 ; /e3bcgza /alt act 518 ; /e3bcgza /alt act 1210 ; /e3bcgza /alt act 231";
			["Type"] = "button";
			["Name"] = "Invis *";
			["Action"] = "/multi ; /e3bcgza /alt act 630 ; /e3bcgza /alt act 518 ; /e3bcgza /alt act 1210 ; /e3bcgza /alt act 231";
		};
		["Drop Invis"] = {
			["Action"] = "/dropinvis";
			["Name"] = "Drop Invis";
			["Type"] = "button";
		};
		["Bando Reset"] = {
			["Action"] = "/multiline ; /e3bcgza /timed 5 /e3varset main true ; /e3bcgza /timed 12 /bando activate main";
			["Name"] = "Bando Reset";
			["Type"] = "button";
		};
		["Group Shrink"] = {
			["Action"] = "/e3bct #botName# /multiline ; /e3bcgza /useitem Umbracite Swarm Orb ; /e3bcgza /useitem Shrunken Goblin Head";
			["Name"] = "Group Shrink";
			["Type"] = "button";
		};
		["Tribute Pts."] = {
			["Prettify"] = false;
			["_editMappings"] = {
				[1] = {
					[1] = "";
					[2] = "";
				};
			};
			["_editInZone"] = true;
			["_editPercentage"] = false;
			["Type"] = "property";
			["InZone"] = true;
			["Ascending"] = true;
			["Properties"] = {
				["all"] = "Me.CurrentFavor";
			};
			["_editProperties"] = {
				[1] = {
					[1] = "all";
					[2] = "Me.CurrentFavor";
				};
			};
			["_editAscending"] = true;
			["_editThresholds"] = {
			};
			["Name"] = "Tribute Pts.";
			["OwnColor"] = false;
		};
		["Trib ON"] = {
			["Prettify"] = false;
			["Name"] = "Trib ON";
			["Action"] = "/dex #botName# /tribute on";
			["_editAction"] = "/dex #botName# /tribute on";
			["Type"] = "button";
			["OwnColor"] = false;
		};
		["Trib OFF"] = {
			["Prettify"] = false;
			["Name"] = "Trib OFF";
			["Action"] = "/dex#botName# /tribute off";
			["_editAction"] = "/dex#botName# /tribute off";
			["Type"] = "button";
			["OwnColor"] = false;
		};
		["Pull"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "SpawnCount[npc loc ${Me.X} ${Me.Y} radius 100]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "Pull";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["HP%"] = {
			["InZone"] = false;
			["Percentage"] = true;
			["Name"] = "HP%";
			["Ascending"] = true;
			["Properties"] = {
				["all"] = "Me.PctHPs";
			};
			["Thresholds"] = {
				[1] = 35;
				[2] = 70;
			};
			["Type"] = "property";
		};
		["MP%"] = {
			["InZone"] = false;
			["Percentage"] = true;
			["Name"] = "MP%";
			["Ascending"] = true;
			["Properties"] = {
				["all"] = "Me.PctMana";
			};
			["Thresholds"] = {
				[1] = 35;
				[2] = 70;
			};
			["Type"] = "property";
		};
		["EP%"] = {
			["InZone"] = false;
			["Percentage"] = true;
			["Name"] = "EP%";
			["Ascending"] = true;
			["Properties"] = {
				["all"] = "Me.PctEndurance";
			};
			["Thresholds"] = {
				[1] = 35;
				[2] = 70;
			};
			["Type"] = "property";
		};
		["Target"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Target.CleanName";
			};
			["Name"] = "Target";
			["Type"] = "property";
		};
		["Conv AA (ME)"] = {
			["Action"] = "/dex #botName# /macro DoConv ALL-AA";
			["Name"] = "Conv AA (ME)";
			["Type"] = "button";
		};
		["Conv DC (ME)"] = {
			["Action"] = "/dex #botName# /macro DoConv ALL-DC";
			["Name"] = "Conv DC (ME)";
			["Type"] = "button";
		};
		["* Conv AA"] = {
			["Action"] = "/e3bcgza /macro DoConv ALL-AA";
			["Name"] = "* Conv AA";
			["Type"] = "button";
		};
		["* Conv DC"] = {
			["Action"] = "/e3bcgza /macro DoConv ALL-DC";
			["Name"] = "* Conv DC";
			["Type"] = "button";
		};
		["Gimme  DC"] = {
			["Action"] = "/dex #botName# /macro DoConv GIMME";
			["Name"] = "Gimme  DC";
			["Type"] = "button";
		};
		["Tribute Active"] = {
			["Prettify"] = false;
			["_editMappings"] = {
				[1] = {
					[1] = "";
					[2] = "";
				};
			};
			["_editInZone"] = true;
			["_editPercentage"] = false;
			["Type"] = "property";
			["InZone"] = true;
			["Ascending"] = true;
			["Properties"] = {
				["all"] = "Me.TributeActive";
			};
			["_editProperties"] = {
				[1] = {
					[1] = "all";
					[2] = "Me.TributeActive";
				};
			};
			["_editAscending"] = true;
			["_editThresholds"] = {
			};
			["Name"] = "Tribute Active";
			["OwnColor"] = false;
		};
		["Tribute Cost"] = {
			["_editAscending"] = true;
			["Prettify"] = false;
			["InZone"] = true;
			["_editMappings"] = {
				[1] = {
					[1] = "";
					[2] = "";
				};
			};
			["Percentage"] = false;
			["Name"] = "Tribute Cost";
			["_editPercentage"] = false;
			["Type"] = "property";
			["_editInZone"] = true;
			["Ascending"] = true;
			["Properties"] = {
				["all"] = "Me.ActiveFavorCost";
			};
			["_editThresholds"] = {
			};
			["_editProperties"] = {
				[1] = {
					[1] = "all";
					[2] = "Me.ActiveFavorCost";
				};
			};
			["OwnColor"] = false;
		};
		["ME Conv AA"] = {
			["Action"] = "/e3bct #botName# /macro DoConv ALL-AA";
			["Name"] = "ME Conv AA";
			["Type"] = "button";
		};
		["ME Conv DC"] = {
			["Action"] = "/e3bct #botName# /macro DoConv ALL-DC";
			["Name"] = "ME Conv DC";
			["Type"] = "button";
		};
		["End"] = {
			["Action"] = "/dex #botName# /end";
			["Name"] = "End";
			["Type"] = "button";
		};
		["Macro"] = {
			["InZone"] = false;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Macro.Name";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "Macro";
			["Ascending"] = false;
			["OwnColor"] = false;
		};
		["Paused"] = {
			["Percentage"] = false;
			["Type"] = "property";
			["InZone"] = false;
			["Ascending"] = false;
			["Properties"] = {
				["all"] = "Macro.Paused";
			};
			["Prettify"] = false;
			["Mappings"] = {
				["TRUE"] = "PAUSED";
				["FALSE"] = "";
			};
			["Name"] = "Paused";
			["OwnColor"] = false;
		};
		["LDoN"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Window[AdventureRequestWnd].Child[AdvRqst_ProgressTextLabel].Text";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "LDoN";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["Distance"] = {
			["Percentage"] = false;
			["Type"] = "property";
			["InZone"] = true;
			["Ascending"] = false;
			["Name"] = "Distance";
			["Prettify"] = false;
			["Properties"] = {
				["all"] = "Distance3D";
			};
			["Thresholds"] = {
				[2] = 200;
				[1] = 100;
			};
			["OwnColor"] = false;
		};
		["Pause"] = {
			["Action"] = "/dex #botName# /mqp";
			["Name"] = "Pause";
			["Type"] = "button";
		};
		["Origin"] = {
			["Action"] = "/dex #botName# /multiline ; /e3p on ; /stand ; /timed 5 /anchoroff ; /timed 5 /backoff me ; /timed 5 /followoff me ; /timed 5 /playmelody stop ; /timed 5 /stopcast ; /timed 5 /nav stop ; /timed 10 /alt activate 331 ; /timed 10 /alt activate 331 ; /timed 210 /e3p off";
			["Name"] = "Origin";
			["Type"] = "button";
		};
		["Marrs"] = {
			["_editAction"] = "/dex #botName# /multi ; /playmelody stop ; /alt act 511";
			["Type"] = "button";
			["Name"] = "Marrs";
			["Action"] = "/dex #botName# /multi ; /playmelody stop ; /alt act 511";
		};
		["Drunk"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Me.Drunk";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "Drunk";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["Spell/Disc"] = {
			["InZone"] = false;
			["Percentage"] = false;
			["Properties"] = {
				["melee"] = "Me.ActiveDisc.Name";
				["all"] = "Me.Casting.Name";
			};
			["Name"] = "Spell/Disc";
			["Type"] = "property";
		};
		["Camp"] = {
			["Action"] = "/dex #botName# /camp desktop";
			["Name"] = "Camp";
			["Type"] = "button";
		};
		["Exit"] = {
			["Action"] = "/dex #botName# /exit";
			["Name"] = "Exit";
			["Type"] = "button";
		};
		["Name"] = {
			["InZone"] = false;
			["Percentage"] = false;
			["Name"] = "Name";
			["IncludeLevel"] = true;
			["Type"] = "property";
		};
		["DC Rec*"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Me.AltCurrency[Diamond Coin]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "DC Rec*";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["DC"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "FindItemCount[=Diamond Coin]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "DC";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["CC"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "FindItemCount[=Celestial Crest]";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "CC";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["Plat"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Me.Platinum";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "Plat";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
		["Gold"] = {
			["InZone"] = true;
			["Percentage"] = false;
			["Properties"] = {
				["all"] = "Me.Gold";
			};
			["Prettify"] = false;
			["Type"] = "property";
			["Name"] = "Gold";
			["Ascending"] = true;
			["OwnColor"] = false;
		};
	};
	["Properties"] = {
		["Window[AdventureRequestWnd].Child[AdvRqst_ProgressTextLabel].Text"] = {
			["Inverse"] = false;
			["Name"] = "Window[AdventureRequestWnd].Child[AdvRqst_ProgressTextLabel].Text";
			["Type"] = "Observed";
		};
		["Me.PctEndurance"] = {
			["Name"] = "Me.PctEndurance";
			["Type"] = "Observed";
		};
		["Target.CleanName"] = {
			["Name"] = "Target.CleanName";
			["Type"] = "Observed";
		};
		["Me.PctHPs"] = {
			["Name"] = "Me.PctHPs";
			["Type"] = "Observed";
		};
		["Me.AltCurrency[Diamond Coin]"] = {
			["Inverse"] = false;
			["Name"] = "Me.AltCurrency[Diamond Coin]";
			["Type"] = "Observed";
		};
		["Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[2,3]"] = {
			["Inverse"] = false;
			["Name"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[2,3]";
			["Type"] = "Observed";
		};
		["Me.PctMana"] = {
			["Name"] = "Me.PctMana";
			["Type"] = "Observed";
		};
		["Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[3,3]"] = {
			["Inverse"] = false;
			["Name"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[3,3]";
			["Type"] = "Observed";
		};
		["Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[4,3]"] = {
			["Inverse"] = false;
			["Name"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[4,3]";
			["Type"] = "Observed";
		};
		["Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[5,3]"] = {
			["Inverse"] = false;
			["Name"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[5,3]";
			["Type"] = "Observed";
		};
		["Me.Class.ShortName"] = {
			["Name"] = "Me.Class.ShortName";
			["Type"] = "Observed";
		};
		["FindItemCount[=Distillate of Divine Healing XI]"] = {
			["Inverse"] = false;
			["Name"] = "FindItemCount[=Distillate of Divine Healing XI]";
			["Type"] = "Observed";
		};
		["Me.Buff[Resurrection Sickness].Duration"] = {
			["Inverse"] = false;
			["Name"] = "Me.Buff[Resurrection Sickness].Duration";
			["Type"] = "Observed";
		};
		["Me.PctExp"] = {
			["Name"] = "Me.PctExp";
			["Type"] = "Observed";
		};
		["Macro.Paused"] = {
			["Name"] = "Macro.Paused";
			["Type"] = "Observed";
		};
		["Me.Copper"] = {
			["Inverse"] = false;
			["Name"] = "Me.Copper";
			["Type"] = "Observed";
		};
		["SpawnCount[npc loc ${Me.X} ${Me.Y} radius 100]"] = {
			["Inverse"] = false;
			["Name"] = "SpawnCount[npc loc ${Me.X} ${Me.Y} radius 100]";
			["Type"] = "Observed";
		};
		["FindItemCount[=Token of Resurrection]"] = {
			["Inverse"] = false;
			["Name"] = "FindItemCount[=Token of Resurrection]";
			["Type"] = "Observed";
		};
		["Distance3D"] = {
			["Name"] = "Distance3D";
			["Type"] = "Spawn";
		};
		["Macro.Name"] = {
			["Name"] = "Macro.Name";
			["Type"] = "Observed";
		};
		["Me.PctAAExp"] = {
			["Inverse"] = false;
			["Name"] = "Me.PctAAExp";
			["Type"] = "Observed";
		};
		["SpawnCount[npc radius 100]"] = {
			["Inverse"] = false;
			["Name"] = "SpawnCount[npc radius 100]";
			["Type"] = "Observed";
		};
		["Me.Buff[Revival Sickness].Duration"] = {
			["Inverse"] = false;
			["Name"] = "Me.Buff[Revival Sickness].Duration";
			["Type"] = "Observed";
		};
		["Me.Buff[Bottle of Shared Adventure V].Duration"] = {
			["Inverse"] = false;
			["Name"] = "Me.Buff[Bottle of Shared Adventure V].Duration";
			["Type"] = "Observed";
		};
		["Me.AAPointsAssigned"] = {
			["Inverse"] = false;
			["Name"] = "Me.AAPointsAssigned";
			["Type"] = "Observed";
		};
		["Me.Drunk"] = {
			["Inverse"] = false;
			["Name"] = "Me.Drunk";
			["Type"] = "Observed";
		};
		["Me.AAPoints"] = {
			["Name"] = "Me.AAPoints";
			["Type"] = "Observed";
		};
		["Me.ActiveDisc.Name"] = {
			["Name"] = "Me.ActiveDisc.Name";
			["Type"] = "Observed";
		};
		["Me.Casting.Name"] = {
			["Name"] = "Me.Casting.Name";
			["Type"] = "Observed";
		};
		["Me.CurrentFavor"] = {
			["Inverse"] = false;
			["Name"] = "Me.CurrentFavor";
			["Type"] = "Observed";
		};
		["FindItemCount[=Diamond Coin]"] = {
			["Inverse"] = false;
			["Name"] = "FindItemCount[=Diamond Coin]";
			["Type"] = "Observed";
		};
		["FindItemCount[=Celestial Crest]"] = {
			["Inverse"] = false;
			["Name"] = "FindItemCount[=Celestial Crest]";
			["Type"] = "Observed";
		};
		["Me.Platinum"] = {
			["Inverse"] = false;
			["Name"] = "Me.Platinum";
			["Type"] = "Observed";
		};
		["Me.Silver"] = {
			["Inverse"] = false;
			["Name"] = "Me.Silver";
			["Type"] = "Observed";
		};
		["Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[1,3]"] = {
			["Inverse"] = false;
			["Name"] = "Window[AdventureStatsWnd].Child[AdvStats_ThemeList].List[1,3]";
			["Type"] = "Observed";
		};
		["Me.TributeActive"] = {
			["Inverse"] = false;
			["Name"] = "Me.TributeActive";
			["Type"] = "Observed";
		};
		["Me.Level"] = {
			["Name"] = "Me.Level";
			["Type"] = "Observed";
		};
		["Me.Gold"] = {
			["Inverse"] = false;
			["Name"] = "Me.Gold";
			["Type"] = "Observed";
		};
		["Me.ActiveFavorCost"] = {
			["Inverse"] = false;
			["Name"] = "Me.ActiveFavorCost";
			["Type"] = "Observed";
		};
	};
	["Tabs"] = {
		[2] = {
			["Name"] = "Macros";
			["Columns"] = {
				[1] = "Name";
				[2] = "Macro";
				[3] = "Paused";
				[4] = "Pause";
				[5] = "End";
				[6] = "LDoN";
				[7] = "Distance";
			};
		};
		[5] = {
			["Name"] = "Ports";
			["Columns"] = {
				[1] = "Name";
				[2] = "Origin";
				[3] = "Marrs";
				[4] = "Drunk";
				[5] = "Spell/Disc";
				[6] = "Camp";
				[7] = "Exit";
			};
		};
		[4] = {
			["Name"] = "Counts";
			["Columns"] = {
				[1] = "Name";
				[2] = "DC Rec*";
				[3] = "DC";
				[4] = "CC";
				[5] = "Plat";
				[6] = "Gold";
				[7] = "Silver";
				[8] = "Copper";
				[9] = "Gimme $$$";
			};
		};
		[10] = {
			["Name"] = "Tribute";
			["Columns"] = {
				[1] = "Name";
				[2] = "Tribute Pts.";
				[3] = "Tribute Cost";
				[4] = "Tribute Active";
				[5] = "Trib ON";
				[6] = "Trib OFF";
			};
		};
		[9] = {
			["Name"] = "LDoN";
			["Columns"] = {
				[1] = "Name";
				[2] = "Get Stats";
				[3] = "LDoN";
				[4] = "GUK #";
				[5] = "MIRA #";
				[6] = "MIST #";
				[7] = "RUJ #";
				[8] = "TAK #";
			};
		};
		[8] = {
			["Name"] = "Rez";
			["Columns"] = {
				[1] = "Name";
				[2] = "Get Corpse";
				[3] = "Rez";
				[4] = "HP Pot";
				[5] = "Res Sick";
				[6] = "Rez Tokens";
				[7] = "WIPE";
				[8] = "E3 Reload";
			};
		};
		[3] = {
			["Name"] = "XP";
			["Columns"] = {
				[1] = "Name";
				[2] = "Exp%";
				[3] = "AA%";
				[4] = "AASpent";
				[5] = "AA Unspent";
				[6] = "Distance";
			};
		};
		[7] = {
			["Name"] = "Utility";
			["Columns"] = {
				[1] = "Name";
				[2] = "Invis *";
				[3] = "Drop Invis";
				[4] = "Bando Reset";
				[5] = "Group Shrink";
				[6] = "Spell/Disc";
			};
		};
		[1] = {
			["Name"] = "General";
			["Columns"] = {
				[1] = "Name";
				[2] = "HP%";
				[3] = "MP%";
				[4] = "EP%";
				[5] = "Distance";
				[6] = "Target";
				[7] = "Spell/Disc";
				[8] = "E3 Reload";
			};
		};
		[6] = {
			["Name"] = "DoConv";
			["Columns"] = {
				[1] = "Name";
				[2] = "Conv AA (ME)";
				[3] = "Conv DC (ME)";
				[4] = "* Conv AA";
				[5] = "* Conv DC";
				[6] = "Gimme  DC";
			};
		};
	};
	["StaleDataTimeout"] = 30;
	["Windows"] = {
		["default"] = {
			["PeerGroup"] = "zone";
			["CurrentTab"] = "Tribute";
			["Name"] = "default";
			["Tabs"] = {
				[1] = "General";
				[2] = "Macros";
				[3] = "XP";
				[4] = "Counts";
				[5] = "Ports";
				[6] = "DoConv";
				[7] = "LDoN";
				[8] = "Rez";
				[9] = "Utility";
				[10] = "Tribute";
			};
			["SortDirty"] = true;
			["Transparency"] = false;
			["TitleBar"] = false;
			["Locked"] = true;
		};
	};
	["Colors"] = {
		["Default"] = {
			[1] = 1;
			[2] = 1;
			[3] = 1;
		};
		["Low"] = {
			[1] = 1;
			[2] = 0;
			[3] = 0;
		};
		["Medium"] = {
			[1] = 1;
			[2] = 1;
			[3] = 0;
		};
		["High"] = {
			[1] = 0;
			[2] = 1;
			[3] = 0;
		};
		["True"] = {
			[1] = 0;
			[2] = 1;
			[3] = 0;
		};
		["False"] = {
			[1] = 1;
			[2] = 0;
			[3] = 0;
		};
		["InZone"] = {
			[1] = 0;
			[2] = 1;
			[3] = 0;
		};
		["Invis"] = {
			[1] = 0.25999999046326;
			[2] = 0.98000001907349;
			[3] = 0.98000001907349;
		};
		["IVU"] = {
			[1] = 0.94999998807907;
			[2] = 0.98000001907349;
			[3] = 0.25999999046326;
		};
		["DoubleInvis"] = {
			[1] = 0.68000000715256;
			[2] = 0.98000001907349;
			[3] = 0.98000001907349;
		};
		["NotInZone"] = {
			[1] = 1;
			[2] = 0;
			[3] = 0;
		};
	};
}
return obj1
