-- ============================================================
--  menu_bar.lua  -  MacroQuest LUA Script Launcher
--  Version : 1.4
--  Author  : (you)
--
--  CHANGELOG
--  ---------
--  1.4 — Renamed to "LUA Script Launcher" and added the version
--        to the ImGui window title (now "LUA Script Launcher v1.4").
--        Console notification prefix renamed to match.
--  1.1 — Added console notification system (see CONSOLE
--        NOTIFICATIONS below): a startup scan summary plus
--        verified Started/Stopped messages on each button toggle.
--  1.0 — Initial release.
--
--  OVERVIEW
--  --------
--  Renders a compact horizontal ImGui toolbar that lets you
--  launch and stop any Lua scripts listed in menu_config.lua
--  with a single click.  Each button reflects the live running
--  state of its script: green with an [ACTIVE] suffix when
--  running, grey when stopped.
--
--  INSTALLATION
--  ------------
--  1. Place menu_bar.lua  in MacroQuest/lua/
--  2. Place menu_config.lua in MacroQuest/lua/
--  3. Start with:  /lua run menu_bar
--  4. Stop  with:  /lua stop menu_bar
--
--  ADDING / REMOVING SCRIPTS
--  -------------------------
--  Edit menu_config.lua.  Each entry in the `apps` table needs:
--
--    { label = "Display Name", script = "FolderName/init.lua" }
--
--  `label`  — text shown on the button (keep it short).
--  `script` — path relative to MacroQuest/lua/.
--             For single-file scripts just use the filename,
--             e.g. "myscript.lua".
--             For folder-based scripts use "FolderName/init.lua";
--             MacroQuest identifies these by the folder name, and
--             menu_bar.lua handles that mapping automatically.
--  No restart of menu_bar is needed between config edits; just
--  stop and re-run it.
--
--  BUTTON BEHAVIOUR
--  ----------------
--  • Clicking a grey  button runs   the script (/lua run ...).
--  • Clicking a green button stops  the script (/lua stop ...).
--  • Active state is detected by scanning Lua PIDs 1-100 and
--    matching the script's reported Name() against the derived
--    script ID (top-level directory name, or filename without
--    extension, lowercased).
--  • State is re-synced automatically every 2 seconds, and
--    immediately after any run or stop action.
--
--  CONSOLE NOTIFICATIONS
--  ---------------------
--  Plain print statements to the MacroQuest console (the MQ chat
--  window) — NOT the ImGui window.  All lines are prefixed with
--  [LUA Script Launcher] and colour-coded via MQ colour codes.
--  • On startup: one "ACTIVE on startup: <label>" line per
--    configured script already running, then a count summary —
--    or a single "none active" line if none are running.
--  • On each button toggle: the script is run/stopped, then the
--    running set is re-scanned and the message reflects the real
--    post-action state rather than just the command issued:
--      run  → "Started: <label>"  or  "Failed to start: <label>"
--      stop → "Stopped: <label>"  or  "Still running: <label>"
--    The failure variants surface scripts that errored on launch
--    or refused to stop, instead of silently misreporting.
--
--  WINDOW SIZING
--  -------------
--  The window width is calculated every frame from the exact
--  pixel widths of all button labels (via ImGui.CalcTextSize)
--  plus the configured padding and spacing constants — then
--  taken as the larger of that button row and the title-bar
--  width, so the title (name + version) is never clipped when
--  the buttons are narrower than it.  The result fits its
--  contents precisely — no blank space, no clipping — even when
--  button labels change between active and inactive states.
--
--  STARTUP SEQUENCING
--  ------------------
--  Active states are fully resolved before ImGui is initialised.
--  This prevents any first-frame flash where active scripts
--  would briefly appear as inactive.  A single mq.delay(1)
--  yields one MQ frame after the scan so that TLO state is
--  settled before the render callback is ever registered.
--
--  STYLE CONSTANTS  (top of script, easy to tune)
--  ---------------
--  WIN_PAD_X   — horizontal window padding (pixels)
--  FRAME_PAD_X — horizontal padding inside each button
--  ITEM_SPC_X  — gap between adjacent buttons
--  Colour values are inline in renderUI() as RGBA 0-1 floats.
-- ============================================================

mq     = require('mq')
require 'ImGui'
local cfg = require('menu_config')

-- ============================================================
--  Identity
--  Single source of truth for the app name and version.  APP_NAME
--  is used as the console notification prefix; WIN_TITLE (name +
--  version) is the ImGui window title.  Bump VERSION here only.
-- ============================================================

local VERSION   = '1.4'
local APP_NAME  = 'LUA Script Launcher'
local WIN_TITLE = APP_NAME .. ' v' .. VERSION   -- "LUA Script Launcher v1.4"

-- ============================================================
--  State
-- ============================================================

local buttons     = {}   -- built from menu_config; each entry:
                         --   .label  (string) display name
                         --   .script (string) config path
                         --   .active (bool)   live running state

local open        = true   -- false when the window X is clicked → exits main loop
local showUI      = true   -- false when the window is collapsed
local pendingRun  = nil    -- {id,label} queued to start on next main-loop tick
local pendingStop = nil    -- {id,label} queued to stop  on next main-loop tick

-- Render callback is registered after the initial sync completes.
-- This flag prevents renderUI from touching ImGui before that point.
local initialSyncDone = false

-- ============================================================
--  Style constants
--  These must match the PushStyleVar values in renderUI() so
--  that CalcTextSize-based width calculations stay accurate.
-- ============================================================

local WIN_PAD_X   = 4   -- ImGuiStyleVar.WindowPadding x  (left & right border)
local FRAME_PAD_X = 6   -- ImGuiStyleVar.FramePadding  x  (inside each button)
local ITEM_SPC_X  = 4   -- ImGuiStyleVar.ItemSpacing   x  (gap between buttons)

-- ============================================================
--  Helpers
-- ============================================================

-- Prints a prefixed, colour-coded line to the MacroQuest console
-- (MQ chat window), NOT to the ImGui window.  Prefix is APP_NAME.
-- Uses MQ colour codes:
--   \ay yellow  \ag green  \ar red  \aw white  \ax reset
-- If a given MQ build does not expose printf as a global, replace
-- the body with: print(string.format('[' .. APP_NAME .. '] ' .. fmt, ...))
local function notify(fmt, ...)
    printf('\aw[\ay' .. APP_NAME .. '\aw]\ax ' .. fmt, ...)
end

-- Derives the key MacroQuest uses to identify a running script.
-- For folder-based scripts ("GuildBankMaint/init.lua") MQ reports
-- the folder name ("GuildBankMaint"), so that is used as the key.
-- For flat scripts ("myscript.lua") the extension is stripped.
-- Result is always lowercased for case-insensitive comparison.
local function scriptID(script)
    local dir = script:match('^([^/\\]+)[/\\]')
    if dir then return dir:lower() end
    local base = script:match('([^/\\]+)$') or script
    return (base:gsub('%.lua$', '')):lower()
end

-- Scans Lua PIDs 1-100 and returns a set (table keyed by lowercase
-- script name) of every script currently in the "running" state.
local function getRunningScripts()
    local running = {}
    for pid = 1, 100 do
        local s = mq.TLO.Lua.Script(pid)
        if s then
            local name   = s.Name()
            local status = s.Status()
            if name and name ~= '' and status and status:lower() == 'running' then
                running[name:lower()] = true
            end
        end
    end
    return running
end

-- Updates every button's .active field against the current set of
-- running scripts.  Accepts an optional precomputed running set to
-- avoid a redundant PID scan; returns the set used either way.
local function syncActiveStates(running)
    running = running or getRunningScripts()
    for _, btn in ipairs(buttons) do
        btn.active = running[scriptID(btn.script)] == true
    end
    return running
end

-- Returns the pixel width that a button will occupy for a given label.
--   button width = text width + 2 × FramePadding.x
local function buttonWidth(label)
    return ImGui.CalcTextSize(label) + FRAME_PAD_X * 2
end

-- Calculates the window width required to contain all buttons
-- without surplus space:
--   buttonRow = WindowPadding.x×2 + Σ buttonWidths + ItemSpacing.x×(n-1)
-- The final width is the larger of the button row and the title bar,
-- so the window title (name + version) is never clipped when the
-- buttons are narrower than the title text.  The title-bar estimate
-- allows for the collapse arrow and close button (≈ one font height
-- each) plus padding/spacing around them.
local function calcWindowWidth()
    -- Button-row width
    local buttonRow = WIN_PAD_X * 2
    for i, btn in ipairs(buttons) do
        local lbl = btn.active and (btn.label .. ' [ACTIVE]') or btn.label
        buttonRow = buttonRow + buttonWidth(lbl)
        if i > 1 then buttonRow = buttonRow + ITEM_SPC_X end
    end

    -- Title-bar width estimate: padding + title text + the two title-bar
    -- widgets (collapse arrow, close button) + inter-widget spacing.
    local font     = ImGui.GetFontSize()
    local titleBar = WIN_PAD_X * 2
                   + ImGui.CalcTextSize(WIN_TITLE)
                   + font * 2                 -- collapse arrow + close button
                   + ITEM_SPC_X * 2 + FRAME_PAD_X * 2

    return math.max(buttonRow, titleBar)
end

-- ============================================================
--  Initialisation — Phase 1: build button table from config
-- ============================================================

for i, app in ipairs(cfg.apps) do
    buttons[i] = {
        label  = app.label  or ('App' .. i),
        script = app.script or '',
        active = false,
    }
end

-- ============================================================
--  Initialisation — Phase 2: blocking pre-render state sync
--  Resolves the active flag for every button before ImGui is
--  touched, preventing any first-frame flash of wrong state.
-- ============================================================

syncActiveStates()
mq.delay(1)          -- yield one MQ frame so TLO state settles
initialSyncDone = true

-- Report which configured scripts were already running at startup.
-- This is console output only; the ImGui window is unaffected.
do
    local activeCount = 0
    for _, btn in ipairs(buttons) do
        if btn.active then
            notify('\agACTIVE\ax on startup: %s', btn.label)
            activeCount = activeCount + 1
        end
    end
    if activeCount == 0 then
        notify('No configured scripts detected active on startup.')
    else
        notify('%d configured script(s) already active.', activeCount)
    end
end

-- ============================================================
--  Render callback
--  Registered after the pre-render sync; gated by initialSyncDone
--  as a safety net against any edge-case early fire.
-- ============================================================

local function renderUI()
    if not initialSyncDone then return end

    -- Force the window to exactly the width needed for the current
    -- set of labels.  ImGuiCond.Always reapplies every frame so the
    -- window tracks label changes (e.g. [ACTIVE] suffix toggling).
    -- Height 0 lets ImGui auto-fit vertically.
    ImGui.SetNextWindowSize(calcWindowWidth(), 0, ImGuiCond.Always)

    open, showUI = ImGui.Begin(WIN_TITLE, open, ImGuiWindowFlags.NoResize)

    if showUI then
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, WIN_PAD_X,   4)
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding,  FRAME_PAD_X, 3)
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing,   ITEM_SPC_X,  0)

        for i, btn in ipairs(buttons) do
            if i > 1 then ImGui.SameLine() end

            if btn.active then
                ImGui.PushStyleColor(ImGuiCol.Button,        0.1,  0.55, 0.1,  1)
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.15, 0.65, 0.15, 1)
                ImGui.PushStyleColor(ImGuiCol.ButtonActive,  0.05, 0.45, 0.05, 1)
                ImGui.PushStyleColor(ImGuiCol.Text,          1,    1,    0.4,  1)
                if ImGui.Button(btn.label .. ' [ACTIVE]##' .. i) then
                    pendingStop = { id = scriptID(btn.script), label = btn.label }
                end
                ImGui.PopStyleColor(4)
            else
                ImGui.PushStyleColor(ImGuiCol.Button,        0.2,  0.2,  0.2,  1)
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.35, 0.35, 0.35, 1)
                ImGui.PushStyleColor(ImGuiCol.ButtonActive,  0.15, 0.15, 0.15, 1)
                ImGui.PushStyleColor(ImGuiCol.Text,          0.9,  0.9,  0.9,  1)
                if ImGui.Button(btn.label .. '##' .. i) then
                    pendingRun = { id = scriptID(btn.script), label = btn.label }
                end
                ImGui.PopStyleColor(4)
            end
        end

        ImGui.PopStyleVar(3)
    end

    ImGui.End()
end

-- ============================================================
--  Initialisation — Phase 3: register ImGui callback
--  Done last, after all state is ready.
-- ============================================================

mq.imgui.init('ScriptLauncher', renderUI)

-- ============================================================
--  Main loop
--  Runs at ~10 Hz.  Handles deferred run/stop actions and
--  periodic re-sync of active states every 2 seconds.
-- ============================================================

local lastSync = mq.gettime()

while open do
    mq.delay(100)

    if pendingRun then
        -- Issue the run, wait for it to spin up, re-scan, then report
        -- the actual result (running[id] confirms it truly started).
        local id, label = pendingRun.id, pendingRun.label
        mq.cmdf('/lua run %s', id)
        pendingRun = nil
        mq.delay(500)      -- allow the script time to start before re-scanning
        local running = syncActiveStates()
        if running[id] then
            notify('\agStarted\ax: %s', label)
        else
            notify('\arFailed to start\ax: %s', label)
        end
    end

    if pendingStop then
        -- Issue the stop, wait for it to exit, re-scan, then report
        -- the actual result (running[id] still set ⇒ it did not stop).
        local id, label = pendingStop.id, pendingStop.label
        mq.cmdf('/lua stop %s', id)
        pendingStop = nil
        mq.delay(200)      -- allow the script time to exit before re-scanning
        local running = syncActiveStates()
        if running[id] then
            notify('\arStill running\ax: %s', label)
        else
            notify('\arStopped\ax: %s', label)
        end
    end

    local now = mq.gettime()
    if now - lastSync >= 2000 then
        syncActiveStates()
        lastSync = now
    end
end
