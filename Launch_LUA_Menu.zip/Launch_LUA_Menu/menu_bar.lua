-- ============================================================
--  menu_bar.lua  -  MacroQuest LUA Script Launcher
--  Version : 1.8
--  Author  : Kroaking DaKnightsAway
--
--  CHANGELOG
--  ---------
--  1.8 — Fixed missed detection once many scripts have been launched.
--        MQ's Lua PIDs are assigned like OS process IDs: every /lua run
--        (any script, including repeat runs and restarts during testing)
--        consumes a new, ever-increasing number for the whole MQ session -
--        they are never recycled. Detection previously scanned a hardcoded
--        PID range of 1-100, so once cumulative launches pushed a script's
--        assigned PID past 100 it silently stopped being detected: its
--        button never lit up even while running, and launching it reported
--        "Failed to start" even on a clean launch. The scan now follows
--        PIDs upward from 1 and only stops after a run of consecutive
--        unassigned PIDs long enough to be sure it has reached the end of
--        the sequence (PID_SCAN_MISS_STREAK), so it keeps working no matter
--        how many scripts have been run in the session.
--  1.7 — Reliable detection of short-lived scripts.  Some scripts
--        start, perform one action and terminate on their own.  The
--        old verify-after-run logic issued the run, waited a fixed
--        500 ms, then scanned the PID table ONCE — by which point such
--        a script had already exited, so it was wrongly reported as
--        "Failed to start" and its button never lit up.  Launch
--        verification now POLLS across a window (waitForStart) and
--        counts the script as started the instant it is seen running
--        even once, so transient scripts are detected while briefly
--        alive and persistent ones are confirmed faster (it returns
--        as soon as the script appears instead of always waiting the
--        full delay).  Scripts that finish faster than any poll can
--        sample can be marked `oneshot = true` (alias `transient =
--        true`) in menu_config.lua: those report "Launched" instead
--        of "Failed to start" when no running state is observed.
--  1.6 — Minimise-to-icon.  Clicking the title-bar chevron now hides
--        the toolbar and shows a small clickable image representing
--        the minimised launcher; drag the image to move it, or click
--        it to restore the toolbar.  Image is loaded with mq.CreateTexture and drawn as
--        an ImGui.ImageButton (same approach as the BIS tracker).
--        Because ImGui's native collapse only hides content (it can't
--        show an image), the chevron click is intercepted and turned
--        into a custom "minimised" mode that draws a separate
--        borderless icon window; the toolbar's collapsed flag is
--        cleared on restore so it reopens expanded.  Configure the
--        image via the ICON_* constants (see MINIMISE-TO-ICON below);
--        falls back to a small "Menu" button if no image loads.
--  1.5 — Even left/right margins.  The toolbar's side spacing no
--        longer relies on ImGui's WindowPadding, which rendered a
--        gap before the first button but none after the last on a
--        force-sized window.  WIN_PAD_X is now applied manually as
--        an equal left inset (SetCursorPosX) and a matching trailing
--        spacer (Dummy), so both edges have an identical margin.
--  1.4 — Renamed to "LUA Script Launcher" and added the version
--        to the ImGui window title (now "LUA Script Launcher v1.4").
--        Console notification prefix renamed to match.
--  1.1 — Added console notification system (see CONSOLE
--        NOTIFICATIONS below): a startup scan summary plus
--        verified Started/Stopped messages on each button toggle.
--  1.0 — Initial release.
--
--  OVERVIEW
--  --------
--  Renders a compact horizontal ImGui toolbar that lets you
--  launch and stop any Lua scripts listed in menu_config.lua
--  with a single click.  Each button reflects the live running
--  state of its script: green with an [ACTIVE] suffix when
--  running, grey when stopped.
--
--  INSTALLATION
--  ------------
--  1. Place menu_bar.lua  in MacroQuest/lua/
--  2. Place menu_config.lua in MacroQuest/lua/
--  3. Start with:  /lua run menu_bar
--  4. Stop  with:  /lua stop menu_bar
--
--  ADDING / REMOVING SCRIPTS
--  -------------------------
--  Edit menu_config.lua.  Each entry in the `apps` table needs:
--
--    { label = "Display Name", script = "FolderName/init.lua" }
--
--  `label`  — text shown on the button (keep it short).
--  `script` — path relative to MacroQuest/lua/.
--             For single-file scripts just use the filename,
--             e.g. "myscript.lua".
--             For folder-based scripts use "FolderName/init.lua";
--             MacroQuest identifies these by the folder name, and
--             menu_bar.lua handles that mapping automatically.
--  No restart of menu_bar is needed between config edits; just
--  stop and re-run it.
--
--  BUTTON BEHAVIOUR
--  ----------------
--  • Clicking a grey  button runs   the script (/lua run ...).
--  • Clicking a green button stops  the script (/lua stop ...).
--  • Active state is detected by scanning Lua PIDs upward from 1
--    (following MQ's actual PID sequence, not a fixed cap - see
--    PID_SCAN_MISS_STREAK) and matching the script's reported
--    Name() against the derived script ID (top-level directory
--    name, or filename without extension, lowercased).
--  • State is re-synced automatically every 2 seconds, and
--    immediately after any run or stop action.
--  • SHORT-LIVED SCRIPTS: a script that starts, does one action and
--    exits on its own is verified by polling during the start window
--    (it counts as started the moment it is seen running once).  If a
--    script terminates faster than the poll can sample it, mark it
--    `oneshot = true` in menu_config.lua so a missing running state is
--    reported as "Launched" rather than "Failed to start".
--
--  CONSOLE NOTIFICATIONS
--  ---------------------
--  Plain print statements to the MacroQuest console (the MQ chat
--  window) — NOT the ImGui window.  All lines are prefixed with
--  [LUA Script Launcher] and colour-coded via MQ colour codes.
--  • On startup: one "ACTIVE on startup: <label>" line per
--    configured script already running, then a count summary —
--    or a single "none active" line if none are running.
--  • On each button toggle: the script is run/stopped, then the
--    running set is re-scanned and the message reflects the real
--    post-action state rather than just the command issued:
--      run  → "Started: <label>"  or  "Failed to start: <label>"
--      stop → "Stopped: <label>"  or  "Still running: <label>"
--    The failure variants surface scripts that errored on launch
--    or refused to stop, instead of silently misreporting.
--
--  WINDOW SIZING
--  -------------
--  The window width is calculated every frame from the exact
--  pixel widths of all button labels (via ImGui.CalcTextSize)
--  plus the per-button frame padding, the inter-button spacing,
--  and WIN_PAD_X reserved twice for the equal left/right side
--  margins — then taken as the larger of that button row and the
--  title-bar width, so the title (name + version) is never clipped
--  when the buttons are narrower than it.  The result fits its
--  contents precisely — no blank space, no clipping — even when
--  button labels change between active and inactive states.
--
--  STARTUP SEQUENCING
--  ------------------
--  Active states are fully resolved before ImGui is initialised.
--  This prevents any first-frame flash where active scripts
--  would briefly appear as inactive.  A single mq.delay(1)
--  yields one MQ frame after the scan so that TLO state is
--  settled before the render callback is ever registered.
--
--  STYLE CONSTANTS  (top of script, easy to tune)
--  ---------------
--  WIN_PAD_X   — symmetric left & right side margin (pixels),
--                applied manually, NOT via ImGui WindowPadding
--  FRAME_PAD_X — horizontal padding inside each button
--  ITEM_SPC_X  — gap between adjacent buttons
--  ICON_PATH   — image shown while minimised (see below)
--  ICON_W/H    — size the minimised image is drawn at (pixels)
--  ICON_PAD    — window padding around the minimised image
--  Colour values are inline in renderUI() as RGBA 0-1 floats.
--
--  MINIMISE-TO-ICON
--  ----------------
--  Click the title-bar chevron to minimise the toolbar to a small
--  image.  While minimised, drag the image to reposition it and click
--  it (a press-release with no drag) to restore the toolbar.  Set ICON_PATH to
--  the image you want (PNG works well).  By default it is loaded from
--  THIS script's own directory (wherever menu_bar.lua lives):
--    <dir containing menu_bar.lua>/menu_bar_icon.png
--  so just drop a file named menu_bar_icon.png next to menu_bar.lua;
--  otherwise set ICON_PATH to any absolute path.  The image is loaded
--  once at startup via mq.CreateTexture, and a startup console line
--  reports whether it was found.  If it is missing or fails to load,
--  the minimised view falls back to a small "Menu" button so the
--  launcher still works.
-- ============================================================

mq     = require('mq')
require 'ImGui'
local cfg = require('menu_config')

-- ============================================================
--  Identity
--  Single source of truth for the app name and version.  APP_NAME
--  is used as the console notification prefix; WIN_TITLE (name +
--  version) is the ImGui window title.  Bump VERSION here only.
-- ============================================================

local VERSION   = '1.8'
local APP_NAME  = 'LUA Script Launcher'
local WIN_TITLE = APP_NAME .. ' v' .. VERSION   -- "LUA Script Launcher v1.8"

-- ============================================================
--  State
-- ============================================================

local buttons     = {}   -- built from menu_config; each entry:
                         --   .label  (string) display name
                         --   .script (string) config path
                         --   .active (bool)   live running state

local open        = true   -- false when the window X is clicked → exits main loop
local pendingRun  = nil    -- {id,label} queued to start on next main-loop tick
local pendingStop = nil    -- {id,label} queued to stop  on next main-loop tick

-- Minimise-to-icon state.
local minimized   = false  -- true → show the icon instead of the toolbar
local forceExpand = false  -- one-shot: un-collapse the toolbar window when
                           -- restoring, clearing the collapsed flag ImGui set
                           -- on the chevron click (else it would re-minimise).
local iconPressed = false  -- mouse button is down having pressed on the icon
local iconDragged = false  -- that press has moved → treat as a window drag,
                           -- not a click, so it moves instead of restoring.

-- Render callback is registered after the initial sync completes.
-- This flag prevents renderUI from touching ImGui before that point.
local initialSyncDone = false

-- ============================================================
--  Style constants
--  FRAME_PAD_X and ITEM_SPC_X must match the PushStyleVar values
--  in renderUI() so the CalcTextSize-based width calculation stays
--  accurate.  WIN_PAD_X is NOT a PushStyleVar — it is applied
--  manually as the left inset and trailing spacer (see renderUI),
--  but calcWindowWidth() still reserves it twice for those margins.
-- ============================================================

local WIN_PAD_X   = 4   -- Symmetric left & right side margin (pixels).
                       -- NOTE: this is applied MANUALLY, not via ImGui's
                       -- WindowPadding (which is forced to 0 in renderUI).
                       -- ImGui's WindowPadding renders the left inset but, on
                       -- a force-sized window, lets the last button sit flush
                       -- against the right border — producing a lopsided look.
                       -- Instead we inset the first button by WIN_PAD_X from
                       -- the left and add a matching WIN_PAD_X spacer after the
                       -- last button, so both edges have an identical margin.
                       -- calcWindowWidth() reserves WIN_PAD_X * 2 for exactly
                       -- these two margins, so no width change is needed.
local FRAME_PAD_X = 6   -- ImGuiStyleVar.FramePadding  x  (inside each button)
local ITEM_SPC_X  = 4   -- ImGuiStyleVar.ItemSpacing   x  (gap between buttons)

-- ============================================================
--  Minimise-to-icon constants  (see MINIMISE-TO-ICON in header)
-- ============================================================

-- Image shown while minimised.  Looked for as menu_bar_icon.png in THIS
-- script's own directory, resolved from debug.getinfo so it works no matter
-- where menu_bar.lua is placed (lua root or a subfolder).  SCRIPT_DIR keeps
-- the trailing path separator.  Set ICON_PATH to an absolute path instead if
-- you prefer a different location.
local SCRIPT_DIR = (debug.getinfo(1, 'S').short_src or ''):match('^(.*[/\\])')
                   or ((mq.luaDir or '.') .. '/')
local ICON_PATH  = SCRIPT_DIR .. 'menu_bar_icon.png'
local ICON_W     = 48   -- drawn image width  (pixels)
local ICON_H     = 48   -- drawn image height (pixels)
local ICON_PAD   = 0    -- window padding around the minimised image
                        -- (0 = the window hugs the image with no surrounding box)

-- Load the icon texture once (same call the BIS tracker uses).  We first
-- confirm the file actually exists, because mq.CreateTexture can return a
-- non-nil but blank texture for a missing path — which would show an empty
-- box instead of cleanly falling back.  If the file is absent (or the build
-- lacks mq.CreateTexture), iconImg stays nil and the minimised view uses a
-- small "Menu" button instead.  A startup console line (below) reports which.
local iconImg     = nil
local iconLoaded  = false
do
    local f = io.open(ICON_PATH, 'rb')
    if f then
        f:close()
        local ok, tex = pcall(mq.CreateTexture, ICON_PATH)
        if ok and tex then
            iconImg    = tex
            iconLoaded = true
        end
    end
end

-- ============================================================
--  Helpers
-- ============================================================

-- Prints a prefixed, colour-coded line to the MacroQuest console
-- (MQ chat window), NOT to the ImGui window.  Prefix is APP_NAME.
-- Uses MQ colour codes:
--   \ay yellow  \ag green  \ar red  \aw white  \ax reset
-- If a given MQ build does not expose printf as a global, replace
-- the body with: print(string.format('[' .. APP_NAME .. '] ' .. fmt, ...))
local function notify(fmt, ...)
    printf('\aw[\ay' .. APP_NAME .. '\aw]\ax ' .. fmt, ...)
end

-- Derives the key MacroQuest uses to identify a running script.
-- For folder-based scripts ("GuildBankMaint/init.lua") MQ reports
-- the folder name ("GuildBankMaint"), so that is used as the key.
-- For flat scripts ("myscript.lua") the extension is stripped.
-- Result is always lowercased for case-insensitive comparison.
local function scriptID(script)
    local dir = script:match('^([^/\\]+)[/\\]')
    if dir then return dir:lower() end
    local base = script:match('([^/\\]+)$') or script
    return (base:gsub('%.lua$', '')):lower()
end

-- MacroQuest's Lua PIDs are NOT a small rotating pool of "slots" - they are
-- assigned like OS process IDs: every /lua run (even repeat runs of the same
-- script, even ones that already finished) consumes a new, ever-increasing
-- number for the life of the MQ session, and old ones are never recycled.
-- A hardcoded "scan PIDs 1-100" cap therefore quietly stops seeing anything
-- once enough scripts have been launched (across ALL buttons, including
-- restarts during testing) to push a script's assigned PID past 100 - it
-- then reports "Failed to start" on launch and never lights up green even
-- when the script is already running. PID_SCAN_MISS_STREAK instead defines
-- how many consecutive *unassigned* PIDs in a row mean we've genuinely
-- reached the end of the sequence (no real gap in MQ's PID assignment is
-- ever that wide), so the scan follows the sequence as far as it actually
-- goes instead of stopping at an arbitrary number.
local PID_SCAN_MISS_STREAK = 25

-- Scans Lua PIDs from 1 up through the current high-water mark (see
-- PID_SCAN_MISS_STREAK above) and returns a set (table keyed by lowercase
-- script name) of every script currently in the "running" state.
local function getRunningScripts()
    local running    = {}
    local pid        = 0
    local missStreak = 0
    while missStreak < PID_SCAN_MISS_STREAK do
        pid = pid + 1
        local s    = mq.TLO.Lua.Script(pid)
        local name = s and s.Name()
        if name and name ~= '' then
            missStreak = 0
            local status = s.Status()
            if status and status:lower() == 'running' then
                running[name:lower()] = true
            end
        else
            missStreak = missStreak + 1
        end
    end
    return running
end

-- Updates every button's .active field against the current set of
-- running scripts.  Accepts an optional precomputed running set to
-- avoid a redundant PID scan; returns the set used either way.
local function syncActiveStates(running)
    running = running or getRunningScripts()
    for _, btn in ipairs(buttons) do
        btn.active = running[scriptID(btn.script)] == true
    end
    return running
end

-- Returns true if a single script `id` is currently in the "running"
-- state.  Lighter than getRunningScripts when only one id matters (used by
-- the launch poll below): it stops at the first PID whose name matches.
local function isRunning(id)
    local pid        = 0
    local missStreak = 0
    while missStreak < PID_SCAN_MISS_STREAK do
        pid = pid + 1
        local s    = mq.TLO.Lua.Script(pid)
        local name = s and s.Name()
        if name and name ~= '' then
            missStreak = 0
            if name:lower() == id then
                local status = s.Status()
                return status ~= nil and status:lower() == 'running'
            end
        else
            missStreak = missStreak + 1
        end
    end
    return false
end

-- Polls for up to timeoutMs (default 1500) for `id` to appear running,
-- returning true the instant it is first seen.  This is what makes
-- short-lived scripts detectable: a script that starts, performs its
-- action and exits on its own would already be gone by the time of a
-- single post-run scan, so the previous fixed-delay check misreported it
-- as "Failed to start".  By sampling across the whole window we catch it
-- while it is briefly alive.  It returns early on success, so a normal
-- persistent script is confirmed as soon as it appears rather than after
-- a full fixed wait.
local function waitForStart(id, timeoutMs)
    local deadline = mq.gettime() + (timeoutMs or 1500)
    repeat
        if isRunning(id) then return true end
        mq.delay(25)
    until mq.gettime() >= deadline
    return isRunning(id)
end

-- Returns the pixel width that a button will occupy for a given label.
--   button width = text width + 2 × FramePadding.x
local function buttonWidth(label)
    return ImGui.CalcTextSize(label) + FRAME_PAD_X * 2
end

-- Calculates the window width required to contain all buttons
-- without surplus space:
--   buttonRow = WIN_PAD_X×2 + Σ buttonWidths + ItemSpacing.x×(n-1)
-- The WIN_PAD_X×2 term reserves the equal left and right side
-- margins (the left inset and the trailing spacer in renderUI).
-- The final width is the larger of the button row and the title bar,
-- so the window title (name + version) is never clipped when the
-- buttons are narrower than the title text.  The title-bar estimate
-- allows for the collapse arrow and close button (≈ one font height
-- each) plus padding/spacing around them.
local function calcWindowWidth()
    -- Button-row width
    local buttonRow = WIN_PAD_X * 2
    for i, btn in ipairs(buttons) do
        local lbl = btn.active and (btn.label .. ' [ACTIVE]') or btn.label
        buttonRow = buttonRow + buttonWidth(lbl)
        if i > 1 then buttonRow = buttonRow + ITEM_SPC_X end
    end

    -- Title-bar width estimate: padding + title text + the two title-bar
    -- widgets (collapse arrow, close button) + inter-widget spacing.
    local font     = ImGui.GetFontSize()
    local titleBar = WIN_PAD_X * 2
                   + ImGui.CalcTextSize(WIN_TITLE)
                   + font * 2                 -- collapse arrow + close button
                   + ITEM_SPC_X * 2 + FRAME_PAD_X * 2

    return math.max(buttonRow, titleBar)
end

-- ============================================================
--  Initialisation — Phase 1: build button table from config
-- ============================================================

for i, app in ipairs(cfg.apps) do
    buttons[i] = {
        label     = app.label  or ('App' .. i),
        script    = app.script or '',
        active    = false,
        -- One-shot scripts (start → act → exit on their own) that
        -- finish faster than the launch poll can sample.  When set,
        -- an unobserved running state after a run reports "Launched"
        -- rather than "Failed to start".  Accepts `oneshot` or the
        -- alias `transient` in menu_config.lua.
        transient = (app.oneshot or app.transient) == true,
    }
end

-- ============================================================
--  Initialisation — Phase 2: blocking pre-render state sync
--  Resolves the active flag for every button before ImGui is
--  touched, preventing any first-frame flash of wrong state.
-- ============================================================

syncActiveStates()
mq.delay(1)          -- yield one MQ frame so TLO state settles
initialSyncDone = true

-- Report which configured scripts were already running at startup.
-- This is console output only; the ImGui window is unaffected.
do
    local activeCount = 0
    for _, btn in ipairs(buttons) do
        if btn.active then
            notify('\agACTIVE\ax on startup: %s', btn.label)
            activeCount = activeCount + 1
        end
    end
    if activeCount == 0 then
        notify('No configured scripts detected active on startup.')
    else
        notify('%d configured script(s) already active.', activeCount)
    end
end

-- Report whether the minimise icon was found, so its absence is obvious
-- rather than silently showing the text-button fallback.
if iconLoaded then
    notify('Minimise icon loaded: \ag%s\ax', ICON_PATH)
else
    notify('\arNo minimise icon\ax at %s', ICON_PATH)
    notify('  → minimised view will show a "Menu" button. Drop a PNG there to use an image.')
end

-- ============================================================
--  Render callback
--  Registered after the pre-render sync; gated by initialSyncDone
--  as a safety net against any edge-case early fire.
-- ============================================================

-- Minimised view: a small borderless, auto-sized window whose only
-- content is the icon drawn as an ImageButton (the same call the BIS
-- tracker uses).  Clicking it restores the toolbar.  Uses its own
-- window id so it is independent of the toolbar window.
local MIN_FLAGS = bit32.bor(ImGuiWindowFlags.AlwaysAutoResize,
                            ImGuiWindowFlags.NoResize,
                            ImGuiWindowFlags.NoScrollbar,
                            ImGuiWindowFlags.NoTitleBar,
                            (ImGuiWindowFlags.NoBackground or 0))  -- no panel/border box

local function renderIcon()
    ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, ICON_PAD, ICON_PAD)

    local visible
    open, visible = ImGui.Begin(APP_NAME .. ' Icon###LauncherMini', open, MIN_FLAGS)
    if visible then
        local restore = false

        if iconImg then
            -- Draw the icon as a plain image (not a button).  A plain image is
            -- non-interactive, so ImGui lets the borderless window be dragged by
            -- it — giving us "drag the image to move" for free.  Restoring is
            -- handled below by detecting a click (press + release with no drag).
            local ok = pcall(function()
                ImGui.Image(iconImg:GetTextureID(), ImVec2(ICON_W, ICON_H))
            end)

            if ok then
                local hovered = ImGui.IsItemHovered()
                if hovered and not iconPressed then
                    ImGui.SetTooltip(APP_NAME .. ' — drag to move, click to restore')
                end

                -- Press started on the icon → begin tracking a potential click.
                if hovered and ImGui.IsMouseClicked(0) then
                    iconPressed = true
                    iconDragged = false
                end
                -- Any movement while held turns it into a drag (window move),
                -- which must NOT restore.
                if iconPressed and ImGui.IsMouseDragging(0) then
                    iconDragged = true
                end
                -- Release: a press that never became a drag is a click → restore.
                if ImGui.IsMouseReleased(0) then
                    if iconPressed and not iconDragged then
                        restore = true
                    end
                    iconPressed = false
                    iconDragged = false
                end
            else
                iconImg = nil
            end
        end

        if not iconImg then
            if ImGui.Button('Menu##restore') then restore = true end
        end

        if restore then
            minimized   = false
            forceExpand = true   -- un-collapse the toolbar window next frame
        end
    end

    ImGui.End()
    ImGui.PopStyleVar()
end

-- Expanded toolbar.  When the user clicks the title-bar chevron, ImGui
-- reports the window as collapsed (visible == false); that is the cue to
-- switch into minimised/icon mode instead of showing a bare title bar.
local function renderToolbar()
    -- Clear any collapsed flag left over from the chevron click so the
    -- toolbar reopens expanded rather than immediately re-minimising.
    if forceExpand then
        ImGui.SetNextWindowCollapsed(false, ImGuiCond.Always)
        forceExpand = false
    end

    -- Force the window to exactly the width needed for the current
    -- set of labels.  ImGuiCond.Always reapplies every frame so the
    -- window tracks label changes (e.g. [ACTIVE] suffix toggling).
    -- Height 0 lets ImGui auto-fit vertically.
    ImGui.SetNextWindowSize(calcWindowWidth(), 0, ImGuiCond.Always)

    local visible
    open, visible = ImGui.Begin(WIN_TITLE, open, ImGuiWindowFlags.NoResize)

    -- Detect the chevron click via the window's collapsed state directly.
    -- This is more reliable than Begin's second return value, which does not
    -- flag a collapse consistently across MQ/ImGui builds.
    if ImGui.IsWindowCollapsed() then
        -- Chevron clicked → minimise to the icon instead of a bare title bar.
        minimized = true
    elseif visible then
        -- WindowPadding.x is forced to 0 here; the left/right margins are
        -- created manually below (left inset + trailing spacer) so they stay
        -- perfectly symmetric. WindowPadding.y is kept at 4 for vertical room.
        ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, 0,           4)
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding,  FRAME_PAD_X, 3)
        ImGui.PushStyleVar(ImGuiStyleVar.ItemSpacing,   ITEM_SPC_X,  0)

        -- Left margin: inset the first button by WIN_PAD_X.
        ImGui.SetCursorPosX(WIN_PAD_X)

        for i, btn in ipairs(buttons) do
            if i > 1 then ImGui.SameLine() end

            if btn.active then
                ImGui.PushStyleColor(ImGuiCol.Button,        0.1,  0.55, 0.1,  1)
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.15, 0.65, 0.15, 1)
                ImGui.PushStyleColor(ImGuiCol.ButtonActive,  0.05, 0.45, 0.05, 1)
                ImGui.PushStyleColor(ImGuiCol.Text,          1,    1,    0.4,  1)
                if ImGui.Button(btn.label .. ' [ACTIVE]##' .. i) then
                    pendingStop = { id = scriptID(btn.script), label = btn.label }
                end
                ImGui.PopStyleColor(4)
            else
                ImGui.PushStyleColor(ImGuiCol.Button,        0.2,  0.2,  0.2,  1)
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.35, 0.35, 0.35, 1)
                ImGui.PushStyleColor(ImGuiCol.ButtonActive,  0.15, 0.15, 0.15, 1)
                ImGui.PushStyleColor(ImGuiCol.Text,          0.9,  0.9,  0.9,  1)
                if ImGui.Button(btn.label .. '##' .. i) then
                    pendingRun = { id = scriptID(btn.script), label = btn.label, transient = btn.transient }
                end
                ImGui.PopStyleColor(4)
            end
        end

        -- Right margin: an invisible spacer the same width as the left inset,
        -- placed flush (no item spacing) after the last button. This guarantees
        -- the trailing margin equals the leading one regardless of how ImGui
        -- handles the forced window width.
        ImGui.SameLine(0, 0)
        ImGui.Dummy(WIN_PAD_X, 1)

        ImGui.PopStyleVar(3)
    end

    ImGui.End()
end

local function renderUI()
    if not initialSyncDone then return end

    if minimized then
        renderIcon()
    else
        renderToolbar()
    end
end

-- ============================================================
--  Initialisation — Phase 3: register ImGui callback
--  Done last, after all state is ready.
-- ============================================================

mq.imgui.init('ScriptLauncher', renderUI)

-- ============================================================
--  Main loop
--  Runs at ~10 Hz.  Handles deferred run/stop actions and
--  periodic re-sync of active states every 2 seconds.
-- ============================================================

local lastSync = mq.gettime()

while open do
    mq.delay(100)

    if pendingRun then
        -- Issue the run, then poll across a window for the script to appear
        -- running.  waitForStart returns true the moment it is seen, so a
        -- short-lived script that starts, acts and exits on its own is still
        -- caught while briefly alive instead of being missed by a single
        -- late scan.  A `transient`-flagged script that is never observed is
        -- assumed to have completed too fast to sample (reported "Launched"),
        -- not failed.
        local id, label, transient = pendingRun.id, pendingRun.label, pendingRun.transient
        mq.cmdf('/lua run %s', id)
        pendingRun = nil
        if waitForStart(id, transient and 500 or 1500) then
            notify('\agStarted\ax: %s', label)
        elseif transient then
            notify('\agLaunched\ax: %s \aw(one-shot; exited too quickly to confirm)\ax', label)
        else
            notify('\arFailed to start\ax: %s', label)
        end
        syncActiveStates()   -- refresh button colours against current state
    end

    if pendingStop then
        -- Issue the stop, wait for it to exit, re-scan, then report
        -- the actual result (running[id] still set ⇒ it did not stop).
        local id, label = pendingStop.id, pendingStop.label
        mq.cmdf('/lua stop %s', id)
        pendingStop = nil
        mq.delay(200)      -- allow the script time to exit before re-scanning
        local running = syncActiveStates()
        if running[id] then
            notify('\arStill running\ax: %s', label)
        else
            notify('\arStopped\ax: %s', label)
        end
    end

    local now = mq.gettime()
    if now - lastSync >= 2000 then
        syncActiveStates()
        lastSync = now
    end
end
