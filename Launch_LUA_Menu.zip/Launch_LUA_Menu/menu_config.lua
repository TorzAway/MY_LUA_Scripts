-- ============================================================
--  menu_config.lua  -  Add your scripts here
--  script: just the filename without .lua extension,
--          relative to MacroQuest/lua/
-- ============================================================

return {
    apps = {
        { label = "Guild Bank Mgr",    script = "GuildBankMaint/init.lua"},
		{ label = "Merchant Buyer", script = "MerchantBuyer/init.lua"},		
        { label = "Raid AssBot", script = "RaidAssistBot/init.lua"},        		
		{ label = "Bard Kite",    script = "BardKite/init.lua"},
		{ label = "Gambler",    script = "Gambler/init.lua"},
    }
}
