-- ============================================================
--  menu_config.lua  -  Add your scripts here
--  script: just the filename without .lua extension,
--          relative to MacroQuest/lua/
-- ============================================================

return {
    apps = {
		{ label = "Button-M",    script = "buttonmaster/init.lua"},
        { label = "GLD-Bank-Mgr",    script = "GuildBankMaint/init.lua"},
		{ label = "Merch-Buy", script = "MerchantBuyer/init.lua"},		
        { label = "Raid-Bot", script = "RaidAssistBot/init.lua"},        		
		{ label = "BRD-Kite",    script = "BardKite/init.lua"},
		{ label = "Gambler",    script = "Gambler/init.lua"},		
    }
}
