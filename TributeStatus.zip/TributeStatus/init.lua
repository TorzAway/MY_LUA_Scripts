--[[
    TributeStatus.lua
    ------------------
    Displays your Tribute Active/Inactive status plus the tribute status of
    every other member in your group (pulled via a published e3 variable
    called MyTributeState), and provides buttons to send /e3bct tribute
    on/off commands to a selected group member.

    Run with:  /lua run TributeStatus
    Stop with: /lua stop TributeStatus
--]]

local mq    = require('mq')
local ImGui = require('ImGui')

------------------------------------------------------------------
-- CONFIG - adjust these to match your e3/mq2mono setup if needed
------------------------------------------------------------------

-- The name of the published e3 variable other clients are broadcasting.
local REMOTE_VAR_NAME = 'MyTributeState'
local REMOTE_COST_VAR  = 'MyTributeActiveCost'
local REMOTE_TIME_VAR  = 'MyTributeTimeLeft'
local REMOTE_FAVOR_VAR = 'MyTributeCurrentFavor'

-- How the script queries a remote client's published e3/mq2mono variable.
-- This is the one part most likely to need tweaking to match your exact
-- e3/E3Next build. Common patterns look like:
--   ${E3Bots[Name].ObservedMQ2[MyTributeState]}
--   ${E3Bots[Name].MQ2[MyTributeState]}
-- Edit the format string below to match what works when you type it
-- directly into the EQ chat window (e.g. /echo ${E3Bots[Name].ObservedMQ2[MyTributeState]}).
local function QueryRemoteVar(name, varName)
    local expr = string.format('${MQ2Mono.Query[e3,E3Bots(%s).Query(%s)]}', name, varName)
    local ok, result = pcall(mq.parse, expr)
    if ok and result then
        local trimmed = tostring(result):gsub('^%s+', ''):gsub('%s+$', '')
        if trimmed ~= '' and trimmed:upper() ~= 'NULL' then
            return trimmed
        end
    end
    return 'NO DATA'
end

-- The command sent via /e3bct to remotely toggle tribute on a given char.
-- Adjust this if your server/setup uses a different notify target to
-- actually flip tribute state.
local function SendTributeToggle(name)
    mq.cmdf('/e3bct %s /notify TributeBenefitWnd TBWP_ActivateButton leftmouseup', name)
end

------------------------------------------------------------------
-- STATE
------------------------------------------------------------------

local openGUI = true
local groupMembers = {}     -- { name = ..., state = "Active"/"Inactive"/"Unknown", isSelf = true/false }

local REFRESH_INTERVAL = 6000 -- ms between polling group member states
local lastRefresh = 0

------------------------------------------------------------------
-- DATA REFRESH
------------------------------------------------------------------

-- Formats a numeric string with thousands separators (e.g. 1234567 -> 1,234,567).
-- Non-numeric values (like 'NO DATA') are returned unchanged.
local function FormatNumber(value)
    local n = tonumber(value)
    if not n then return tostring(value) end
    local formatted = tostring(math.floor(n))
    local k
    repeat
        formatted, k = formatted:gsub('^(-?%d+)(%d%d%d)', '%1,%2')
    until k == 0
    return formatted
end

local function RefreshGroupMembers()
    groupMembers = {}

    -- Self, listed first (cost/favor read directly from TLO)
    local myName = mq.TLO.Me.Name()
    local myState = QueryRemoteVar(myName, REMOTE_VAR_NAME)
    table.insert(groupMembers, {
        name  = myName,
        state = myState,
        cost  = tostring(mq.TLO.Me.ActiveFavorCost() or 0),
        timeLeft = QueryRemoteVar(myName, REMOTE_TIME_VAR),
        favor = tostring(mq.TLO.Me.CurrentFavor() or 0),
        isSelf = true,
    })

    -- Other group members
    local groupSize = mq.TLO.Group.GroupSize() or 0
    for i = 1, groupSize do
        local member = mq.TLO.Group.Member(i)
        if member() then
            local name = member.Name()
            if name and name ~= myName then
                local state = QueryRemoteVar(name, REMOTE_VAR_NAME)
                local cost  = QueryRemoteVar(name, REMOTE_COST_VAR)
                local timeLeft = QueryRemoteVar(name, REMOTE_TIME_VAR)
                local favor = QueryRemoteVar(name, REMOTE_FAVOR_VAR)
                table.insert(groupMembers, { name = name, state = state, cost = cost, timeLeft = timeLeft, favor = favor, isSelf = false })
            end
        end
    end
end

local function RefreshAll()
    RefreshGroupMembers()
end------------------------------------------------------------------
-- UI HELPERS
------------------------------------------------------------------

local function StateColor(state)
    local s = tostring(state):gsub('^%s+', ''):gsub('%s+$', ''):upper()
    if s == 'ACTIVE' then
        return ImVec4(0.0, 1.0, 0.0, 1.0)    -- pure green
    elseif s == 'INACTIVE' then
        return ImVec4(1.0, 0.0, 0.0, 1.0)    -- pure red
    else
        return ImVec4(0.7, 0.7, 0.7, 1.0)    -- gray for unknown
    end
end

local function IsKnownState(state)
    local s = tostring(state):gsub('^%s+', ''):gsub('%s+$', ''):upper()
    return s == 'ACTIVE' or s == 'INACTIVE'
end

-- ImGui has no native bold toggle without a separate bold font loaded, so we
-- fake bold by drawing the text twice with a 1px horizontal offset.
local function TextBoldColored(color, text)
    local x, y = ImGui.GetCursorPosX(), ImGui.GetCursorPosY()
    ImGui.SetCursorPos(x + 1, y)
    ImGui.TextColored(color, text)
    ImGui.SetCursorPos(x, y)
    ImGui.TextColored(color, text)
end

local function RenderStateCell(state)
    if not IsKnownState(state) then
        ImGui.TextDisabled('NO DATA')
    else
        TextBoldColored(StateColor(state), state)
    end
end

------------------------------------------------------------------
-- MAIN WINDOW
------------------------------------------------------------------

local showSetupWindow = false

local function SetupDataWindow()
    if not showSetupWindow then return end

    local open, shouldDrawSetup = ImGui.Begin('Setup Data', showSetupWindow, ImGuiWindowFlags.AlwaysAutoResize)
    showSetupWindow = open
    if shouldDrawSetup then
        ImGui.TextDisabled('Monitoring published e3 variables: ')
        local tributeExprText = 'MyTributeState=${If[${Me.TributeActive}, Active, Inactive]}\n'
            .. 'MyTributeCost=${Me.ActiveFavorCost}\n'
            .. 'MyTributeTimeLeft=${Me.TributeTimer}\n'
            .. 'MyCurrentFavor=${Me.CurrentFavor}'
        ImGui.Separator()
        ImGui.Text(tributeExprText)
        ImGui.Separator()

        -- Center the two buttons as a group
        do
            local copyLabel  = 'Copy to Clipboard'
            local closeLabel = 'CLOSE POPUP'
            local style      = ImGui.GetStyle()
            local padX       = style.FramePadding.x * 2
            local spacing    = style.ItemSpacing.x
            local groupW     = (ImGui.CalcTextSize(copyLabel) + padX)
                             + spacing
                             + (ImGui.CalcTextSize(closeLabel) + padX)
            local availW     = ImGui.GetContentRegionAvail()
            local offsetX    = (availW - groupW) / 2
            if offsetX > 0 then
                ImGui.SetCursorPosX(ImGui.GetCursorPosX() + offsetX)
            end
        end

        -- Copy to Clipboard: yellow background, black text
        ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(1.0, 1.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.85, 0.85, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.7, 0.7, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.Text, ImVec4(0.0, 0.0, 0.0, 1.0))
        if ImGui.Button('Copy to Clipboard##State') then
            ImGui.SetClipboardText(tributeExprText)
        end
        ImGui.PopStyleColor(4)

        ImGui.SameLine()

        -- Close Popup: red background, black text
        ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(1.0, 0.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.8, 0.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.6, 0.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.Text, ImVec4(0.0, 0.0, 0.0, 1.0))
        if ImGui.Button('CLOSE POPUP') then
            showSetupWindow = false
        end
        ImGui.PopStyleColor(4)
    end
    ImGui.End()
end

local function TributeWindow()
    openGUI, shouldDraw = ImGui.Begin('Tribute Status', openGUI, ImGuiWindowFlags.AlwaysAutoResize)
    if shouldDraw then

        -- Manual refresh button
        if ImGui.Button('Refresh Now') then
            RefreshAll()
        end
        ImGui.SameLine()
        ImGui.Text(string.format('(auto-refresh every %ds)', REFRESH_INTERVAL / 1000))

        -- Turn All Tribute On: green background, black text
        ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(0.0, 1.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.0, 0.8, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.0, 0.6, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.Text, ImVec4(0.0, 0.0, 0.0, 1.0))
        if ImGui.Button('Turn All Tribute On') then
            for _, m in ipairs(groupMembers) do
                mq.cmdf('/e3bct %s /if (!${Me.TributeActive}) /notify TributeBenefitWnd TBWP_ActivateButton leftmouseup', m.name)
            end
        end
        ImGui.PopStyleColor(4)

        ImGui.SameLine()

        -- Turn All Tribute Off: red background, black text
        ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(1.0, 0.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.8, 0.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.6, 0.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.Text, ImVec4(0.0, 0.0, 0.0, 1.0))
        if ImGui.Button('Turn All Tribute Off') then
            for _, m in ipairs(groupMembers) do
                mq.cmdf('/e3bct %s /if (${Me.TributeActive}) /notify TributeBenefitWnd TBWP_ActivateButton leftmouseup', m.name)
            end
        end
        ImGui.PopStyleColor(4)

        ImGui.Separator()
        ImGui.Text('Group Members:')

        if ImGui.BeginTable('TributeTable', 6, ImGuiTableFlags.Borders + ImGuiTableFlags.RowBg) then
            local nameColWidth = ImGui.CalcTextSize('Name')
            for _, m in ipairs(groupMembers) do
                local label = m.isSelf and (m.name .. ' (You)') or m.name
                local w = ImGui.CalcTextSize(label)
                if w > nameColWidth then
                    nameColWidth = w
                end
            end
            nameColWidth = nameColWidth + 20 -- padding

            local toggleButtonLabel = 'Toggle Tribute'
            local toggleButtonW = ImGui.CalcTextSize(toggleButtonLabel) + ImGui.GetStyle().FramePadding.x * 2
            local toggleColWidth = toggleButtonW + 60 -- extra padding so the button has room to be centered

            ImGui.TableSetupColumn('Name', ImGuiTableColumnFlags.WidthFixed, nameColWidth)
            ImGui.TableSetupColumn('Status')
            ImGui.TableSetupColumn('Tribute Cost')
            ImGui.TableSetupColumn('Current Favor')
            ImGui.TableSetupColumn('Time Left')
            ImGui.TableSetupColumn('', ImGuiTableColumnFlags.WidthFixed, toggleColWidth)
            ImGui.TableHeadersRow()

            for _, m in ipairs(groupMembers) do
                ImGui.TableNextRow()

                ImGui.TableNextColumn()
                if m.isSelf then
                    ImGui.Text(m.name .. ' (You)')
                else
                    ImGui.Text(m.name)
                end

                ImGui.TableNextColumn()
                RenderStateCell(m.state)

                ImGui.TableNextColumn()
                local costStateUpper = tostring(m.state):gsub('^%s+', ''):gsub('%s+$', ''):upper()
                if costStateUpper == 'INACTIVE' or m.cost == 'NO DATA' then
                    ImGui.TextDisabled('NO DATA')
                else
                    ImGui.Text(FormatNumber(m.cost))
                end

                ImGui.TableNextColumn()
                if m.favor == 'NO DATA' then
                    ImGui.TextDisabled('NO DATA')
                else
                    ImGui.Text(FormatNumber(m.favor))
                end

                ImGui.TableNextColumn()
                local stateUpper = tostring(m.state):gsub('^%s+', ''):gsub('%s+$', ''):upper()
                if stateUpper == 'INACTIVE' then
                    ImGui.Text('')
                elseif m.timeLeft == 'NO DATA' then
                    ImGui.TextDisabled('NO DATA')
                else
                    TextBoldColored(StateColor('ACTIVE'), m.timeLeft)
                end

                ImGui.TableNextColumn()
                do
                    local offsetX = (toggleColWidth - toggleButtonW) / 2
                    if offsetX > 0 then
                        ImGui.SetCursorPosX(ImGui.GetCursorPosX() + offsetX)
                    end
                    if ImGui.Button(toggleButtonLabel .. '##' .. m.name) then
                        SendTributeToggle(m.name)
                    end
                end
            end

            ImGui.EndTable()
        end

        if #groupMembers == 0 then
            ImGui.Text('(no other group members found)')
        end

        ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(1.0, 1.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.85, 0.85, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.7, 0.7, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.Text, ImVec4(0.0, 0.0, 0.0, 1.0))
        do
            local setupLabel = 'CLICK TO SEE CLIENT SETUP DATA'
            local setupW = ImGui.CalcTextSize(setupLabel) + ImGui.GetStyle().FramePadding.x * 2
            local setupAvail = ImGui.GetContentRegionAvail()
            local setupOffset = (setupAvail - setupW) / 2
            if setupOffset > 0 then
                ImGui.SetCursorPosX(ImGui.GetCursorPosX() + setupOffset)
            end
            if ImGui.Button(setupLabel) then
                showSetupWindow = true
            end
        end
        ImGui.PopStyleColor(4)

        ImGui.Separator()

        ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(1.0, 0.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.8, 0.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.6, 0.0, 0.0, 1.0))
        ImGui.PushStyleColor(ImGuiCol.Text, ImVec4(0.0, 0.0, 0.0, 1.0))
        do
            local buttonLabel = 'Exit'
            local textW = ImGui.CalcTextSize(buttonLabel)
            local framePaddingX = ImGui.GetStyle().FramePadding.x
            local buttonW = textW + framePaddingX * 2
            local availW = ImGui.GetContentRegionAvail()
            local offsetX = (availW - buttonW) / 2
            if offsetX > 0 then
                ImGui.SetCursorPosX(ImGui.GetCursorPosX() + offsetX)
            end
            if ImGui.Button(buttonLabel) then
                openGUI = false
            end
        end
        ImGui.PopStyleColor(4)
    end
    ImGui.End()

    SetupDataWindow()
end

mq.imgui.init('TributeStatusWindow', TributeWindow)

------------------------------------------------------------------
-- MAIN LOOP
------------------------------------------------------------------

RefreshAll()

while openGUI do
    mq.doevents()

    local now = mq.gettime()
    if now - lastRefresh >= REFRESH_INTERVAL then
        RefreshAll()
        lastRefresh = now
    end

    mq.delay(100)
end
