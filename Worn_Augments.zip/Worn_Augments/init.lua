local mq = require('mq')
local ImGui = require('ImGui')
local sqlite3 = require('lsqlite3')

-- Global application control flags
local run_script = true
local show_window = true
local export_status = ""
local status_timer = 0

-- State tracking for the Compare tab dropdown lists
local character_list = {}
local selected_char1_idx = 1
local selected_char2_idx = 1

-- State tracking for the comparison window popup
local show_compare_window = false
local comp_char1_name = ""
local comp_char2_name = ""
local comp_data_char1 = {}
local comp_data_char2 = {}

-- CUSTOM ORDERED INVENTORY SLOT ID ASSIGNMENTS
local inventory_slots = {
    { id = 2,  name = "Head" },
    { id = 1,  name = "Left Ear" },
    { id = 4,  name = "Right Ear" },
    { id = 3,  name = "Face" },
    { id = 5,  name = "Neck" },
    { id = 6,  name = "Shoulders" },
    { id = 7,  name = "Arms" },
    { id = 8,  name = "Back" },
    { id = 17, name = "Chest" },
    { id = 9,  name = "Left Wrist" },
    { id = 10, name = "Right Wrist" },
    { id = 12, name = "Hands" },
    { id = 15, name = "Left Finger" },
    { id = 16, name = "Right Finger" },
    { id = 13, name = "Primary" },
    { id = 14, name = "Secondary" },
    { id = 11, name = "Range" },
    { id = 18, name = "Legs" },
    { id = 19, name = "Feet" },
    { id = 20, name = "Waist" },
    { id = 21, name = "Powersource" },
    { id = 0,  name = "Charm" },
    { id = 22, name = "Ammo" },
}

-- Database function to pull all saved character names
local function refresh_character_list()
    character_list = {}
    local db_path = string.format("%s/WornGearExport.db", mq.configDir)
    local db = sqlite3.open(db_path)
    
    if not db then return end

    local table_check = db:execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='characters';")
    if table_check == sqlite3.OK then
        for row in db:nrows("SELECT name FROM characters ORDER BY name ASC") do
            table.insert(character_list, row.name)
        end
    end
    db:close()
end

-- Database helper function to dump all character gear cleanly
local function export_to_database()
    local char_name = mq.TLO.Me.Name() or "Unknown"
    local db_path = string.format("%s/WornGearExport.db", mq.configDir)
    
    local db, err = sqlite3.open(db_path)
    if not db then
        export_status = "DB Error: " .. tostring(err)
        status_timer = os.time() + 5
        return
    end

    db:exec([[
        CREATE TABLE IF NOT EXISTS characters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE,
            class TEXT,
            level INTEGER,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS equipment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            character_name TEXT,
            slot_id INTEGER,
            slot_name TEXT,
            item_name TEXT,
            FOREIGN KEY(character_name) REFERENCES characters(name)
        );
        CREATE TABLE IF NOT EXISTS augments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            equipment_id INTEGER,
            socket_index INTEGER,
            socket_type INTEGER,
            augment_name TEXT,
            FOREIGN KEY(equipment_id) REFERENCES equipment(id)
        );
    ]])

    local stmt = db:prepare("INSERT OR REPLACE INTO characters (name, class, level, timestamp) VALUES (?, ?, ?, CURRENT_TIMESTAMP);")
    stmt:bind_values(char_name, mq.TLO.Me.Class.Name(), mq.TLO.Me.Level())
    stmt:step()
    stmt:finalize()

    local del_stmt = db:prepare("DELETE FROM augments WHERE equipment_id IN (SELECT id FROM equipment WHERE character_name = ?);")
    del_stmt:bind_values(char_name)
    del_stmt:step()
    del_stmt:finalize()

    del_stmt = db:prepare("DELETE FROM equipment WHERE character_name = ?;")
    del_stmt:bind_values(char_name)
    del_stmt:step()
    del_stmt:finalize()

    for _, slot in ipairs(inventory_slots) do
        local item = mq.TLO.Me.Inventory(slot.id)
        
        if item and item() then
            local eq_stmt = db:prepare("INSERT INTO equipment (character_name, slot_id, slot_name, item_name) VALUES (?, ?, ?, ?);")
            eq_stmt:bind_values(char_name, slot.id, slot.name, item.Name())
            eq_stmt:step()
            local eq_id = db:last_insert_rowid()
            eq_stmt:finalize()

            for i = 1, 6 do
                local slot_type = 0
                if i == 1 then slot_type = item.AugSlot1() or 0
                elseif i == 2 then slot_type = item.AugSlot2() or 0
                elseif i == 3 then slot_type = item.AugSlot3() or 0
                elseif i == 4 then slot_type = item.AugSlot4() or 0
                elseif i == 5 then slot_type = item.AugSlot5() or 0
                elseif i == 6 then slot_type = item.AugSlot6() or 0
                end

                if slot_type > 0 then
                    local aug_item = item.AugSlot(i)
                    local aug_name = (aug_item and aug_item()) and aug_item.Name() or "Empty"
                    
                    local aug_stmt = db:prepare("INSERT INTO augments (equipment_id, socket_index, socket_type, augment_name) VALUES (?, ?, ?, ?);")
                    aug_stmt:bind_values(eq_id, i, slot_type, aug_name)
                    aug_stmt:step()
                    aug_stmt:finalize()
                end
            end
        end
    end

    db:close()
    export_status = "Updated profile inside Config/WornGearExport.db!"
    status_timer = os.time() + 5
    
    refresh_character_list()
end

-- Load character gear state from DB into a local structured array for comparison mapping
local function load_comparison_data(char_name)
    local data = {}
    local db_path = string.format("%s/WornGearExport.db", mq.configDir)
    local db = sqlite3.open(db_path)
    if not db then return data end

    local query = [[
        SELECT eq.slot_id, eq.item_name, aug.socket_index, aug.socket_type, aug.augment_name
        FROM equipment eq
        LEFT JOIN augments aug ON eq.id = aug.equipment_id
        WHERE eq.character_name = ?
    ]]
    
    local stmt = db:prepare(query)
    if stmt then
        stmt:bind_values(char_name)
        for row in stmt:nrows() do
            local s_id = row.slot_id
            if not data[s_id] then
                data[s_id] = { item_name = row.item_name, augs = {} }
            end
            if row.socket_index then
                table.insert(data[s_id].augs, {
                    index = row.socket_index,
                    type = row.socket_type,
                    name = row.augment_name
                })
            end
        end
        stmt:finalize()
    end
    db:close()
    
    -- Ensure augment arrays remain sorted by socket index
    for _, slot_data in pairs(data) do
        table.sort(slot_data.augs, function(a, b) return a.index < b.index end)
    end
    
    return data
end

-- Execute the comparison request by fetching data and turning on the popup window flag
local function execute_gear_comparison(name1, name2)
    comp_char1_name = name1
    comp_char2_name = name2
    comp_data_char1 = load_comparison_data(name1)
    comp_data_char2 = load_comparison_data(name2)
    show_compare_window = true
end

-- Target explicit socket assignments cleanly for Live character UI layout
local function render_socket_data(item_obj, idx)
    local slot_type = 0
    if idx == 1 then slot_type = item_obj.AugSlot1() or 0
    elseif idx == 2 then slot_type = item_obj.AugSlot2() or 0
    elseif idx == 3 then slot_type = item_obj.AugSlot3() or 0
    elseif idx == 4 then slot_type = item_obj.AugSlot4() or 0
    elseif idx == 5 then slot_type = item_obj.AugSlot5() or 0
    elseif idx == 6 then slot_type = item_obj.AugSlot6() or 0
    end

    if slot_type > 0 then
        local aug_item = item_obj.AugSlot(idx)
        if aug_item and aug_item() then
            ImGui.Text(string.format("Slot %d (Type %d): ", idx, slot_type))
            ImGui.SameLine()
            ImGui.TextColored(0.0, 1.0, 0.0, 1.0, tostring(aug_item.Name()))
        else
            ImGui.Text(string.format("Slot %d (Type %d): ", idx, slot_type))
            ImGui.SameLine()
            ImGui.TextColored(1.0, 0.0, 0.0, 1.0, "Empty")
        end
        return true
    end
    return false
end

-- Render function to draw database-pulled augments inside the comparison table grid
local function render_db_socket_data(slot_data)
    if not slot_data or #slot_data.augs == 0 then
        ImGui.TextColored(1.0, 1.0, 0.0, 1.0, "No Sockets Available")
        return
    end
    for _, aug in ipairs(slot_data.augs) do
        if aug.name == "Empty" then
            ImGui.Text(string.format("Slot %d (Type %d): ", aug.index, aug.type))
            ImGui.SameLine()
            ImGui.TextColored(1.0, 0.0, 0.0, 1.0, "Empty")
        else
            ImGui.Text(string.format("Slot %d (Type %d): ", aug.index, aug.type))
            ImGui.SameLine()
            ImGui.TextColored(0.0, 1.0, 0.0, 1.0, aug.name)
        end
    end
end

-- Primary layout drawing loop callback execution function
local function draw_ui()
    -- RENDER SEPARATE POPUP COMPARISON WINDOW
    if show_compare_window then
        local comp_open, comp_visible = ImGui.Begin("Side-by-Side Equipment Comparison", show_compare_window, ImGuiWindowFlags.None)
        show_compare_window = comp_open
        
        if comp_visible then
            ImGui.TextColored(0.0, 1.0, 1.0, 1.0, string.format("Comparing Profile: %s  vs  %s", comp_char1_name, comp_char2_name))
            
            ImGui.SameLine(ImGui.GetWindowWidth() - 150.0)
            if ImGui.Button("Close Comparison", 130, 20) then
                show_compare_window = false
            end
            
            ImGui.Separator()
            
            -- Setup a 5-Column Side-by-Side Table Layout matrix
            if ImGui.BeginTable("ComparisonGridTable", 5, ImGuiTableFlags.Borders + ImGuiTableFlags.RowBg + ImGuiTableFlags.Resizable) then
                ImGui.TableSetupColumn("Slot", ImGuiTableColumnFlags.WidthFixed, 90.0)
                ImGui.TableSetupColumn(comp_char1_name .. " Item", ImGuiTableColumnFlags.WidthStretch, 2.0)
                ImGui.TableSetupColumn(comp_char1_name .. " Augments", ImGuiTableColumnFlags.WidthStretch, 2.5)
                ImGui.TableSetupColumn(comp_char2_name .. " Item", ImGuiTableColumnFlags.WidthStretch, 2.0)
                ImGui.TableSetupColumn(comp_char2_name .. " Augments", ImGuiTableColumnFlags.WidthStretch, 2.5)
                ImGui.TableHeadersRow()
                
                for _, slot in ipairs(inventory_slots) do
                    ImGui.TableNextRow()
                    
                    ImGui.TableSetColumnIndex(0)
                    ImGui.Text(slot.name)
                    
                    local s1 = comp_data_char1[slot.id]
                    local s2 = comp_data_char2[slot.id]
                    
                    ImGui.TableSetColumnIndex(1)
                    if s1 and s1.item_name then
                        ImGui.TextColored(0.4, 0.8, 1.0, 1.0, s1.item_name)
                    else
                        ImGui.TextDisabled("<Empty>")
                    end
                    
                    ImGui.TableSetColumnIndex(2)
                    render_db_socket_data(s1)
                    
                    ImGui.TableSetColumnIndex(3)
                    if s2 and s2.item_name then
                        ImGui.TextColored(0.4, 0.8, 1.0, 1.0, s2.item_name)
                    else
                        ImGui.TextDisabled("<Empty>")
                    end
                    
                    ImGui.TableSetColumnIndex(4)
                    render_db_socket_data(s2)
                end
                ImGui.EndTable()
            end
        end
        ImGui.End()
    end

    -- RENDER PRIMARY APPLICATION MAIN WINDOW
    if not show_window then return end

    local open_state, visible = ImGui.Begin("Worn Gear & Augments", show_window, ImGuiWindowFlags.None)
    show_window = open_state

    if visible then
        if ImGui.BeginTabBar("GearScriptTabs") then
            
            -- TAB 1: MyAugs
            if ImGui.BeginTabItem("MyAugs") then
                if ImGui.Button("Export to SQL DB") then
                    export_to_database()
                end
                
                if export_status ~= "" then
                    ImGui.SameLine()
                    if os.time() < status_timer then
                        ImGui.TextColored(1.0, 1.0, 0.0, 1.0, export_status)
                    else
                        export_status = ""
                    end
                end

                ImGui.Separator()

                if ImGui.BeginTable("WornGearTable", 3, ImGuiTableFlags.Borders + ImGuiTableFlags.RowBg + ImGuiTableFlags.Resizable) then
                    ImGui.TableSetupColumn("Slot", ImGuiTableColumnFlags.WidthFixed, 100.0)
                    ImGui.TableSetupColumn("Item Name", ImGuiTableColumnFlags.WidthStretch, 2.0)
                    ImGui.TableSetupColumn("Augmentations", ImGuiTableColumnFlags.WidthStretch, 3.0)
                    ImGui.TableHeadersRow()

                    for _, slot in ipairs(inventory_slots) do
                        local item = mq.TLO.Me.Inventory(slot.id)

                        ImGui.TableNextRow()
                        
                        ImGui.TableSetColumnIndex(0)
                        ImGui.Text(slot.name)

                        ImGui.TableSetColumnIndex(1)
                        if item and item() then
                            ImGui.TextColored(0.0, 1.0, 1.0, 1.0, tostring(item.Name()))
                        else
                            ImGui.TextDisabled("<Empty>")
                        end

                        ImGui.TableSetColumnIndex(2)
                        if item and item() then
                            local sockets_found = 0
                            for i = 1, 6 do
                                if render_socket_data(item, i) then
                                    sockets_found = sockets_found + 1
                                end
                            end
                            if sockets_found == 0 then
                                ImGui.TextColored(1.0, 1.0, 0.0, 1.0, "No Sockets")
                            end
                        else
                            ImGui.TextDisabled("-")
                        end
                    end
                    ImGui.EndTable()
                end
                ImGui.EndTabItem()
            end

            -- TAB 2: Compare
            if ImGui.BeginTabItem("Compare") then
                if ImGui.IsWindowAppearing() or #character_list == 0 then
                    refresh_character_list()
                end

                if #character_list > 0 then
                    -- Row 1: Character 1 Selector
                    ImGui.Text("Character 1:")
                    ImGui.SameLine()
                    ImGui.SetNextItemWidth(130.0)
                    local preview_val1 = character_list[selected_char1_idx] or "Select..."
                    if ImGui.BeginCombo("##CharSelectCombo1", preview_val1) then
                        for i, name in ipairs(character_list) do
                            local is_selected = (selected_char1_idx == i)
                            if ImGui.Selectable(name, is_selected) then
                                selected_char1_idx = i
                            end
                        end
                        ImGui.EndCombo()
                    end

                    -- Row 1 Continued: Character 2 Selector
                    ImGui.SameLine()
                    ImGui.Text("   Character 2:")
                    ImGui.SameLine()
                    ImGui.SetNextItemWidth(130.0)
                    local preview_val2 = character_list[selected_char2_idx] or "Select..."
                    if ImGui.BeginCombo("##CharSelectCombo2", preview_val2) then
                        for i, name in ipairs(character_list) do
                            local is_selected = (selected_char2_idx == i)
                            if ImGui.Selectable(name, is_selected) then
                                selected_char2_idx = i
                            end
                        end
                        ImGui.EndCombo()
                    end

                    ImGui.Spacing()
                    ImGui.Separator()
                    ImGui.Spacing()
                    
                    -- FIXED CHANGES: Centering calculation math injection zone
                    local button_width = 150.0
                    local window_width = ImGui.GetContentRegionAvail() -- Calculates current drawing width limits
                    local centering_offset = (window_width - button_width) / 2
                    
                    if centering_offset > 0 then
                        ImGui.SetCursorPosX(ImGui.GetCursorPosX() + centering_offset)
                    end
                    
                    if ImGui.Button("Run Comparison", button_width, 24) then
                        execute_gear_comparison(character_list[selected_char1_idx], character_list[selected_char2_idx])
                    end
                else
                    ImGui.TextColored(1.0, 0.0, 0.0, 1.0, "No records found! Export data on your characters first.")
                end

                ImGui.EndTabItem()
            end

            ImGui.EndTabBar()
        end
    end
    ImGui.End()

    if not show_window and not show_compare_window then
        run_script = false
    end
end

-- Initialize the standalone user interface layout frame handler
mq.imgui.init('WornAugmentsUI', draw_ui)

-- Loop tracking frame executions safely without letting the thread drop
while run_script do
    mq.delay(20)
end
