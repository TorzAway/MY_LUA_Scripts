-- Save this script as handin.lua in your MacroQuest lua folder
-- Run it ingame using: /lua run handin

local mq = require('mq')
local imgui = require('ImGui')

-- Script State
local open_gui = true
local inventory_items = {}
local item_names = {}
local selected_idx = 1
local items_per_handin = 1
local total_handins = 1

-- Toggle radio button states (1 = Quantity, 2 = Faction)
local current_radio_mode = 1

-- Execution & Interaction States
local should_execute = false
local last_target_id = 0
local faction_standing_text = "None"
local fx_r, fx_g, fx_b = 1.0, 1.0, 1.0
local fetch_timer = 0

-- Clean and explicit event callbacks to isolate faction matches instantly
local function faction_ally()      faction_standing_text = "ALLY";         fx_r, fx_g, fx_b = 0.0, 1.0, 0.0 end
local function faction_warmly()    faction_standing_text = "WARMLY";       fx_r, fx_g, fx_b = 0.3, 0.9, 0.3 end
local function faction_kindly()    faction_standing_text = "KINDLY";       fx_r, fx_g, fx_b = 0.5, 0.9, 0.5 end
local function faction_amiable()   faction_standing_text = "AMIABLE";      fx_r, fx_g, fx_b = 0.6, 1.0, 0.6 end
local function faction_indiff()    faction_standing_text = "INDIFFERENT";   fx_r, fx_g, fx_b = 1.0, 1.0, 1.0 end
local function faction_appre()     faction_standing_text = "APPREHENSIVE";  fx_r, fx_g, fx_b = 1.0, 0.6, 0.0 end
local function faction_dubious()   faction_standing_text = "DUBIOUS";       fx_r, fx_g, fx_b = 0.9, 0.4, 0.0 end
local function faction_threat()    faction_standing_text = "THREATENING";   fx_r, fx_g, fx_b = 1.0, 0.2, 0.2 end
local function faction_scowls()    faction_standing_text = "SCOWLS (KOS)";  fx_r, fx_g, fx_b = 1.0, 0.0, 0.0 end

-- Resolves the true absolute maximum stack size using safe string macro parsing
local function get_max_stack_size(item_name)
    if not item_name or item_name == "" then return 20 end
    
    local query = string.format("${FindItem[=%s].StackSize}", item_name)
    local result = mq.parse(query)
    
    if not result or result == "" or result == "NULL" then
        return 20
    end
    
    local parsed_max = tonumber(result)
    if parsed_max and parsed_max > 0 then
        return parsed_max
    end
    
    return 20
end

-- Safely scan inventory using top-level InvSlot alias structures
local function populate_inventory()
    inventory_items = {}
    item_names = {}
    
    for pack_num = 1, 12 do
        local slot_name = string.format("pack%d", pack_num)
        local container_item = mq.TLO.InvSlot(slot_name).Item
        
        if container_item and container_item() and (container_item.ID() or 0) > 0 then
            local container_slots = container_item.Container() or 0
            
            if container_slots > 0 then
                for pack_slot = 1, container_slots do
                    local inner_item = container_item.Item(pack_slot)
                    
                    if inner_item and inner_item() and (inner_item.ID() or 0) > 0 then
                        if not inner_item.NoDrop() then
                            local qty = inner_item.Stack() or inner_item.Count() or 1
                            local item_name = inner_item.Name()
                            
                            local max_stack_rule = get_max_stack_size(item_name)
                            local allowed_max = math.min(max_stack_rule, qty)
                            
                            table.insert(inventory_items, {
                                name = item_name,
                                inv_slot = pack_num + 22,
                                bag_slot = pack_slot,
                                count = qty,
                                max_stack = allowed_max
                            })
                            table.insert(item_names, string.format("%s (Qty: %d)", item_name, qty))
                        end
                    end
                end
            else
                if not container_item.NoDrop() then
                    local qty = container_item.Stack() or container_item.Count() or 1
                    local item_name = container_item.Name()
                    
                    local max_stack_rule = get_max_stack_size(item_name)
                    local allowed_max = math.min(max_stack_rule, qty)
                    
                    table.insert(inventory_items, {
                        name = item_name,
                        inv_slot = pack_num + 22,
                        bag_slot = -1,
                        count = qty,
                        max_stack = allowed_max
                    })
                    table.insert(item_names, string.format("%s (Qty: %d)", container_item.Name(), qty))
                end
            end
        end
    end
    
    if selected_idx > #inventory_items then
        selected_idx = 1
    end
end

-- Helper logic to determine if the script loop should terminate based on conditions
local function check_automation_termination(item_name)
    -- Refresh available items tracking data fields
    populate_inventory() 
    local total_available_items = 0
    
    for _, item in ipairs(inventory_items) do
        if item.name == item_name then
            total_available_items = total_available_items + item.count
        end
    end

    local total_items_needed_per_turn = total_handins * items_per_handin

    -- Termination Condition 1: Check if inventory items fell underneath requirements threshold
    if total_available_items < total_items_needed_per_turn then
        print(string.format("\ar[HandIn Assistant] Not enough items remaining (%d/%d needed). Stopping loop.\ax", total_available_items, total_items_needed_per_turn))
        return true
    end

    -- Termination Condition 2: Faction mode validation loops (Ignored if PC target)
    if current_radio_mode == 2 then
        local target = mq.TLO.Target
        if target() and target.Type() == "NPC" then
            faction_standing_text = "Updating Faction..."
            mq.cmd("/consider")
            
            local wait_start = os.clock()
            while faction_standing_text == "Updating Faction..." and (os.clock() - wait_start) < 1.0 do
                mq.doevents()
                mq.delay(20)
            end
            
            if faction_standing_text == "ALLY" then
                print("\ay[HandIn Assistant] Target NPC faction is verified ALLY! Stopping loop.\ax")
                return true
            end
        end
    end

    return false
end

-- Asynchronous loop automation runner
local function process_handin_routine()
    local selected_item = inventory_items[selected_idx]
    if not selected_item then 
        should_execute = false
        return 
    end
    
    local target = mq.TLO.Target
    if not target() or (target.Type() ~= "NPC" and target.Type() ~= "PC") then
        -- MODIFIED: Changed color prefix formatting string from \ay to \ar (red warning text style)
        print("\ar[HandIn Error] You must target a valid PC or NPC first!\ax")
        should_execute = false
        return
    end
    
    local preserved_item_name = selected_item.name

    -- Primary structural loop runner layer
    while should_execute do
        local active_item = nil
        for _, item in ipairs(inventory_items) do
            if item.name == preserved_item_name then
                active_item = item
                break
            end
        end

        if not active_item then break end

        local execution_stacks = math.min(total_handins, 4)
        local final_handin_qty = math.min(items_per_handin, active_item.count)
        
        mq.cmd("/autoinventory")
        mq.delay(200) 
        
        -- Click loop targeting up to trade space slots cap matching choice stacks
        for slot_idx = 1, execution_stacks do
            if active_item.bag_slot ~= -1 then
                local pack_num = active_item.inv_slot - 22
                mq.cmdf("/itemnotify in pack%d %d leftmouseup", pack_num, active_item.bag_slot)
            else
                mq.cmdf("/itemnotify %d leftmouseup", active_item.inv_slot)
            end
            mq.delay(250) 
            
            if mq.TLO.Window("QuantityWnd").Open() then
                mq.cmdf("/notify QuantityWnd QTYW_Slider newvalue %d", final_handin_qty)
                mq.delay(100)
                mq.cmd("/notify QuantityWnd QTYW_Accept_Button leftmouseup")
                mq.delay(250) 
            end
            
            mq.cmdf("/click left target trade %d", slot_idx)
            mq.delay(300)
        end
        
        mq.cmd("/notify GiveWnd GVW_Give_Button leftmouseup")
        mq.delay(500)
        
        while mq.TLO.Cursor() do
            mq.cmd("/autoinventory")
            mq.delay(200)
        end
        
        -- Evaluate termination conditions based on your radio toggle rules
        if check_automation_termination(preserved_item_name) then
            break
        end

        mq.delay(300) 
    end

    should_execute = false 
end

-- Draw ImGui Interface
local function draw_gui()
    if not open_gui then return end
    
    local open, draw = imgui.Begin("MQ Item Hand-In Assistant", true, ImGuiWindowFlags.AlwaysAutoResize)
    if not open then
        open_gui = false
        imgui.End()
        return
    end
    
    if draw then
        if should_execute then
            imgui.TextColored(1, 1, 0, 1, "LOOP ACTIVE: Processing repeat hand-ins...")
            if imgui.Button("Emergency Stop") then
                should_execute = false
            end
            imgui.End()
            return
        end

        if imgui.Button("Refresh Inventory") then
            populate_inventory()
        end
        imgui.Separator()
        
        -- Target Display Information
        local target = mq.TLO.Target
        if target() and (target.Type() == "NPC" or target.Type() == "PC") then
            if target.ID() ~= last_target_id then
                last_target_id = target.ID()
                if target.Type() == "PC" then
                    faction_standing_text = "ALLY (PLAYER)"
                    fx_r, fx_g, fx_b = 0.3, 0.6, 1.0
                    fetch_timer = 0
                    current_radio_mode = 1 
                else
                    faction_standing_text = "Fetching..."
                    fx_r, fx_g, fx_b = 1.0, 1.0, 1.0
                    fetch_timer = os.clock() 
                    mq.cmd("/consider") 
                end
            end

            if faction_standing_text == "Fetching..." and fetch_timer > 0 and (os.clock() - fetch_timer) > 1.5 then
                faction_standing_text = "INDIFFERENT (TIMEOUT)"
                fx_r, fx_g, fx_b = 1.0, 1.0, 1.0
                fetch_timer = 0
            end

            local r, g, b = 0.3, 0.9, 0.3
            if target.Type() == "PC" then r, g, b = 0.3, 0.6, 1.0 end
            imgui.Text("Target Unit:")
            imgui.SameLine()
            imgui.TextColored(r, g, b, 1, string.format("%s (%s)", target.CleanName(), target.Type()))
            
            imgui.Text("Target Faction:")
            imgui.SameLine()
            imgui.TextColored(fx_r, fx_g, fx_b, 1.0, faction_standing_text)
        else
            last_target_id = 0
            faction_standing_text = "None"
            imgui.Text("Target Unit:")
            imgui.SameLine()
            imgui.TextColored(1, 0.2, 0.2, 1, "None (Select a PC or NPC)")
        end
        
        imgui.Separator()
        
        -- MODE SELECTION: Radio Buttons block logic
        imgui.Text("Automation Hand-In Focus:")
        
        if imgui.RadioButton("Quantity", current_radio_mode == 1) then
            current_radio_mode = 1
        end
        imgui.SameLine()
        
        local disable_faction_radio = (target() and target.Type() == "PC")
        if disable_faction_radio then imgui.BeginDisabled() end
        
        if imgui.RadioButton("Faction", current_radio_mode == 2) then
            current_radio_mode = 2
        end
        
        if disable_faction_radio then imgui.EndDisabled() end
        
        imgui.Separator()
        
        if #item_names > 0 then
            if imgui.BeginCombo("Select Item", item_names[selected_idx] or "") then
                for i, name in ipairs(item_names) do
                    local is_selected = (selected_idx == i)
                    if imgui.Selectable(name, is_selected) then
                        selected_idx = i
                        if items_per_handin > inventory_items[selected_idx].max_stack then
                            items_per_handin = inventory_items[selected_idx].max_stack
                        end
                    end
                end
                imgui.EndCombo()
            end
            
            local current_item = inventory_items[selected_idx]
            local max_allowed_stack = current_item and current_item.max_stack or 1
            
            items_per_handin = imgui.SliderInt(string.format("Items per stack (Max Allowed: %d)", max_allowed_stack), items_per_handin, 1, max_allowed_stack)
            total_handins = imgui.SliderInt("Number of stacks/turns (Max 4)", total_handins, 1, 4)
            
            imgui.Separator()
            
            if target() and (target.Type() == "NPC" or target.Type() == "PC") then
                local btn_text = current_radio_mode == 2 and "Hand in until ALLY" or "Hand in ALL items"
                if imgui.Button(btn_text) then
                    should_execute = true
                end
            else
                imgui.TextColored(1, 0, 0, 1, "Hand-in locked: Invalid or empty target.")
            end
        else
            imgui.Text("No tradable items found in your inventory.")
        end
    end
    imgui.End()
end

-- Initialize inventory lists safely
populate_inventory()

-- Bind explicit text matching event logs straight to your callback configurations
mq.event("FactionAlly",   "#1# regards you as an ally#*#", faction_ally)
mq.event("FactionWarmly", "#1# views you warmly#*#", faction_warmly)
mq.event("FactionKindly", "#1# looks upon you kindly#*#", faction_kindly)
mq.event("FactionAmiable","#1# judges you amiably#*#", faction_amiable)
mq.event("FactionIndiff", "#1# regards you indifferently#*#", faction_indiff)
mq.event("FactionAppre",  "#1# glares at you apprehensively#*#", faction_appre)
mq.event("FactionDubious", "#1# looks upon you dubiously#*#", faction_dubious)
mq.event("FactionThreat", "#1# looks at you threateningly#*#", faction_threat)
mq.event("FactionScowls", "#1# scowls with ready anger#*#", faction_scowls)

-- Main Script Loop
mq.imgui.init('HandInGui', draw_gui)
while open_gui do
    mq.doevents()
    
    if should_execute then
        process_handin_routine()
    end
    
    mq.delay(10) 
end
