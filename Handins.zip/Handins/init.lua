--[[
================================================================================
 MQ Item Hand-In Assistant
================================================================================

DESCRIPTION
    A MacroQuest Lua script with an ImGui interface that automates handing
    items or coin to an NPC or PC via the in-game trade/give window. Useful
    for turn-in quests, donation runs, faction grinding, or repeatedly
    trading stacks of an item (or amounts of coin) to a target.

INSTALLATION
    1. Save this file as "handin.lua" in your MacroQuest "lua" folder
       (e.g. <MQ Install Folder>/lua/handin.lua).
    2. In-game, run it with:
           /lua run handin
    3. To stop the script entirely, close the GUI window (click the X) or
       run:
           /lua stop handin

REQUIREMENTS
    - MacroQuest with Lua and ImGui support enabled.
    - The mq and ImGui Lua modules (bundled with MacroQuest).
    - Optional: the MQ2Nav plugin. If loaded, the script uses "/nav" to
      approach a distant target; otherwise it falls back to "/moveto".

HOW IT WORKS
    1. On load, the script scans your top-level inventory bags (slots
       pack1-pack12) for tradable (non No-Drop) items and lists them in
       the GUI, along with their current quantity.
    2. Choose an automation focus via the radio buttons:
         - "Quantity": Select an item, then keep handing it in until your
           inventory no longer has enough of it to satisfy the configured
           amount.
         - "Faction" (NPC targets only): Select an item, then keep handing
           it in until the targeted NPC's faction toward you reaches ALLY
           (detected via the "/consider" command and faction message
           events). Faction is only checked/detected while this focus mode
           is active, to avoid unnecessary "/consider" spam.
         - "Coin": Instead of an item, choose a coin denomination
           (Platinum/Gold/Silver/Copper) and an amount, and hand that
           amount in for a chosen number of repeats.
    3. For Quantity/Faction focus: select an item from the dropdown, then
       configure:
         - How many of that item to include per hand-in "stack" (limited
           by the item's max stack size and your current count).
         - How many stacks/turn-ins to perform per loop pass (max 4,
           matching the number of trade window slots available).
       For Coin focus: select a coin type, then configure:
         - "Amount to hand in", via a slider (snaps to multiples of 5) or
           the "Fine tune amount" +/- buttons (adjust by exactly 1). Capped
           at how much of that coin type you currently have on hand.
         - "Repeat X times", via +/- buttons. This is automatically capped
           so that (amount x repeats) can never exceed your on-hand total
           for the selected coin type.
    4. Target a valid NPC or PC, then click the action button ("Hand in
       ALL items" / "Hand in until ALLY" / "Hand in Coin") to begin the
       automated loop. While running, an "Emergency Stop" button is
       available to immediately halt the loop.
    5. Before each hand-in attempt (item or coin), the script checks your
       distance to the target. If you're farther than 10 units away, it
       automatically moves you closer (via "/nav" if MQ2Nav is loaded,
       otherwise "/moveto") before attempting the trade.
    6. After every successful hand-in attempt, if anything is left on your
       cursor it is automatically cleared via "/autoinventory" (with a
       5-second timeout, in case bags are full and it can't be cleared).

GUI CONTROLS
    - Refresh Inventory : Re-scans your bags for tradable items and
                           updates the dropdown list.
    - Sorted: A-Z / Z-A : Located next to Refresh Inventory. Toggles the
                           sort order of the item dropdown list between
                           ascending and descending alphabetical order
                           (click again to reverse). The first item in
                           the newly sorted list becomes the selected
                           item.
    - (Partial) Search Items field : Located below the Refresh
                           Inventory / Sort buttons, directly above the
                           item dropdown. Type any part of an item's
                           name to filter the dropdown list to matching
                           items (partial, case-insensitive match). As
                           you type, the first item matching the search
                           text is automatically selected. Leave empty
                           to show all items. Not shown in Coin focus.
    - Item dropdown     : Select which item to hand in. The dropdown width
                           automatically adjusts to fit the longest item
                           name currently in the list. After every
                           inventory refresh or sort-order change, the
                           selection automatically resets to the first
                           item in the currently displayed (sorted) list.
                           A separator line follows the dropdown. Not
                           shown in Coin focus.
    - "Items per stack" slider : How many of the selected item to place
                           into a single trade slot (capped by max stack
                           size and available quantity). Quantity/Faction
                           focus only.
    - "Number of stacks/turns" slider : How many trade slots to fill per
                           loop iteration (capped at 4). Quantity/Faction
                           focus only.
    - Quantity / Faction / Coin radio buttons : Selects the automation
                           focus mode (see HOW IT WORKS above). "Faction"
                           is disabled when targeting a PC.
    - Select Coin dropdown : Coin focus only. Choose which denomination
                           (Platinum/Gold/Silver/Copper) to hand in.
    - "Amount to hand in" slider + "Fine tune amount" +/- buttons :
                           Coin focus only. Sets how much of the selected
                           coin type to hand in per pass. The slider snaps
                           to multiples of 5; the +/- buttons adjust by 1.
                           Both are capped at your current on-hand amount.
    - "Repeat X times" +/- buttons : Coin focus only. How many times to
                           repeat the coin hand-in. Automatically capped
                           so (amount x repeats) never exceeds your
                           on-hand total for the selected coin type.
    - Hand-in button    : Starts the automated hand-in loop using the
                           current settings.
    - Emergency Stop    : Immediately stops an in-progress automation
                           loop.

NOTES / LIMITATIONS
    - Only items in your main inventory bags (pack1-pack12) are scanned;
      bank, cursor, and worn/equipped slots are not included.
    - No-Drop items are excluded, since they cannot be traded.
    - Faction detection relies on parsing chat messages produced by
      "/consider" and may briefly show "Fetching..." or time out to
      "INDIFFERENT (TIMEOUT)" if no faction message is received within
      1.5 seconds. It is only active while "Faction" focus is selected.
    - Coin hand-in interacts with the Inventory window's money fields
      (IW_Money0-3 for Platinum/Gold/Silver/Copper) and the Trade window's
      confirm button (TRDW_Trade_Button). The script will try to
      auto-open your Inventory window (via "/keypress INVENTORY") if it
      isn't already open.
    - The proximity check moves you to within 10 units of your target
      before each hand-in attempt; if it cannot get you in range within
      15 seconds, the loop stops with an error.
    - The automation loop performs in-game actions (clicking items,
      opening quantity windows, confirming trades) with short delays
      between steps; avoid moving your character or changing windows
      while a loop is active.

================================================================================
--]]

-- Save this script as handin.lua in your MacroQuest lua folder
-- Run it ingame using: /lua run handin

local mq = require('mq')
local imgui = require('ImGui')

-- Script State
local open_gui = true
local inventory_items = {}
local item_names = {}
local selected_idx = 1
local items_per_handin = 1
local total_handins = 1

-- Toggle radio button states (1 = Quantity, 2 = Faction, 3 = Coin)
local current_radio_mode = 1

-- Coin hand-in mode: available coin denominations, currently selected
-- denomination, and the amount of that coin to hand in per turn-in
local coin_types = { "Platinum", "Gold", "Silver", "Copper" }
local selected_coin_idx = 1
local coin_amount = 1
local coin_repeat_count = 1

-- Maps each coin denomination to the corresponding GiveWnd edit box control
-- name (control names sourced from the actual EQ Inventory/Give windows).
local coin_edit_controls = {
    Platinum = "IW_Money0",
    Gold     = "IW_Money1",
    Silver   = "IW_Money2",
    Copper   = "IW_Money3",
}

-- Sort direction for item list (true = ascending, false = descending)
local sort_ascending = true

-- Cached pixel width for the item selection combo box, sized to fit the
-- longest item label so names are not truncated
local combo_width = 200

-- Uniform pixel width applied to sliders and the search input so they line
-- up symmetrically instead of each auto-sizing to the window's full width
local FIELD_WIDTH = 220

-- Text entered by the user to filter the item dropdown list (partial,
-- case-insensitive match against item names)
local search_filter = ""

-- Execution & Interaction States
local should_execute = false
local last_target_id = 0
local faction_standing_text = "None"
local fx_r, fx_g, fx_b = 1.0, 1.0, 1.0
local fetch_timer = 0

-- Human-readable "transactions remaining" text, updated live during an
-- active hand-in loop and shown in the LOOP ACTIVE panel of the GUI
local remaining_transactions_text = ""

-- Clean and explicit event callbacks to isolate faction matches instantly
local function faction_ally()      faction_standing_text = "ALLY";         fx_r, fx_g, fx_b = 0.0, 1.0, 0.0 end
local function faction_warmly()    faction_standing_text = "WARMLY";       fx_r, fx_g, fx_b = 0.3, 0.9, 0.3 end
local function faction_kindly()    faction_standing_text = "KINDLY";       fx_r, fx_g, fx_b = 0.5, 0.9, 0.5 end
local function faction_amiable()   faction_standing_text = "AMIABLE";      fx_r, fx_g, fx_b = 0.6, 1.0, 0.6 end
local function faction_indiff()    faction_standing_text = "INDIFFERENT";   fx_r, fx_g, fx_b = 1.0, 1.0, 1.0 end
local function faction_appre()     faction_standing_text = "APPREHENSIVE";  fx_r, fx_g, fx_b = 1.0, 0.6, 0.0 end
local function faction_dubious()   faction_standing_text = "DUBIOUS";       fx_r, fx_g, fx_b = 0.9, 0.4, 0.0 end
local function faction_threat()    faction_standing_text = "THREATENING";   fx_r, fx_g, fx_b = 1.0, 0.2, 0.2 end
local function faction_scowls()    faction_standing_text = "SCOWLS (KOS)";  fx_r, fx_g, fx_b = 1.0, 0.0, 0.0 end

-- Resolves the true absolute maximum stack size using safe string macro parsing
local function get_max_stack_size(item_name)
    if not item_name or item_name == "" then return 20 end
    
    local query = string.format("${FindItem[=%s].StackSize}", item_name)
    local result = mq.parse(query)
    
    if not result or result == "" or result == "NULL" then
        return 20
    end
    
    local parsed_max = tonumber(result)
    if parsed_max and parsed_max > 0 then
        return parsed_max
    end
    
    return 20
end

-- Sorts inventory_items (and the parallel item_names list) by item name,
-- respecting the current sort_ascending direction
local function sort_inventory_items()
    -- Build a combined list so item_names stays in sync with inventory_items
    local combined = {}
    for i, item in ipairs(inventory_items) do
        table.insert(combined, { item = item, label = item_names[i] })
    end

    table.sort(combined, function(a, b)
        local name_a = a.item.name:lower()
        local name_b = b.item.name:lower()
        if sort_ascending then
            return name_a < name_b
        else
            return name_a > name_b
        end
    end)

    inventory_items = {}
    item_names = {}
    for _, entry in ipairs(combined) do
        table.insert(inventory_items, entry.item)
        table.insert(item_names, entry.label)
    end
end

-- Safely scan inventory using top-level InvSlot alias structures
local function populate_inventory()
    inventory_items = {}
    item_names = {}
    
    for pack_num = 1, 12 do
        local slot_name = string.format("pack%d", pack_num)
        local container_item = mq.TLO.InvSlot(slot_name).Item
        
        if container_item and container_item() and (container_item.ID() or 0) > 0 then
            local container_slots = container_item.Container() or 0
            
            if container_slots > 0 then
                for pack_slot = 1, container_slots do
                    local inner_item = container_item.Item(pack_slot)
                    
                    if inner_item and inner_item() and (inner_item.ID() or 0) > 0 then
                        if not inner_item.NoDrop() then
                            local qty = inner_item.Stack() or inner_item.Count() or 1
                            local item_name = inner_item.Name()
                            
                            local max_stack_rule = get_max_stack_size(item_name)
                            local allowed_max = math.min(max_stack_rule, qty)
                            
                            table.insert(inventory_items, {
                                name = item_name,
                                inv_slot = pack_num + 22,
                                bag_slot = pack_slot,
                                count = qty,
                                max_stack = allowed_max
                            })
                            table.insert(item_names, string.format("%s (Qty: %d)", item_name, qty))
                        end
                    end
                end
            else
                if not container_item.NoDrop() then
                    local qty = container_item.Stack() or container_item.Count() or 1
                    local item_name = container_item.Name()
                    
                    local max_stack_rule = get_max_stack_size(item_name)
                    local allowed_max = math.min(max_stack_rule, qty)
                    
                    table.insert(inventory_items, {
                        name = item_name,
                        inv_slot = pack_num + 22,
                        bag_slot = -1,
                        count = qty,
                        max_stack = allowed_max
                    })
                    table.insert(item_names, string.format("%s (Qty: %d)", container_item.Name(), qty))
                end
            end
        end
    end
    
    sort_inventory_items()

    -- Always default to the first item in the currently sorted list,
    -- regardless of sort direction or any prior selection
    selected_idx = 1

    -- Recalculate the combo box width so the longest item name fits without
    -- being truncated. Add padding for the dropdown arrow and item border.
    combo_width = 200
    for _, label in ipairs(item_names) do
        local text_w, _ = imgui.CalcTextSize(label)
        if type(text_w) == "table" then
            text_w = text_w.x
        end
        local needed_w = (text_w or 0) + 40
        if needed_w > combo_width then
            combo_width = needed_w
        end
    end

    -- Ensure the per-stack amount is valid for the newly selected (first) item
    local new_selected = inventory_items[selected_idx]
    if new_selected and items_per_handin > new_selected.max_stack then
        items_per_handin = new_selected.max_stack
    end
end

-- Helper logic to determine if the script loop should terminate based on conditions
local function check_automation_termination(item_name)
    -- Refresh available items tracking data fields
    populate_inventory() 
    local total_available_items = 0
    
    for _, item in ipairs(inventory_items) do
        if item.name == item_name then
            total_available_items = total_available_items + item.count
        end
    end

    local total_items_needed_per_turn = total_handins * items_per_handin

    -- Termination Condition 1: Check if inventory items fell underneath requirements threshold
    if total_available_items < total_items_needed_per_turn then
        print(string.format("\ar[HandIn Assistant] Not enough items remaining (%d/%d needed). Stopping loop.\ax", total_available_items, total_items_needed_per_turn))
        return true
    end

    -- Termination Condition 2: Faction mode validation loops (Ignored if PC target)
    if current_radio_mode == 2 then
        local target = mq.TLO.Target
        if target() and target.Type() == "NPC" then
            faction_standing_text = "Updating Faction..."
            mq.cmd("/consider")
            
            local wait_start = os.clock()
            while faction_standing_text == "Updating Faction..." and (os.clock() - wait_start) < 1.0 do
                mq.doevents()
                mq.delay(20)
            end
            
            if faction_standing_text == "ALLY" then
                print("\ay[HandIn Assistant] Target NPC faction is verified ALLY! Stopping loop.\ax")
                return true
            end
        end
    end

    return false
end

-- Returns how much of the given coin denomination the character currently
-- has on-hand (not bank), used to cap the "Amount to hand in" slider.
local function get_coin_on_hand(coin_name)
    if coin_name == "Platinum" then return mq.TLO.Me.Platinum() or 0
    elseif coin_name == "Gold" then return mq.TLO.Me.Gold() or 0
    elseif coin_name == "Silver" then return mq.TLO.Me.Silver() or 0
    elseif coin_name == "Copper" then return mq.TLO.Me.Copper() or 0
    else return 0 end
end

-- Coin hand-in routine used when "Coin" focus mode is active. Repeats the
-- selected coin type/amount hand-in for a total of coin_repeat_count passes,
-- stopping early if funds run out or Emergency Stop is pressed.
-- Maximum allowed distance from target before a hand-in pass is attempted
local HANDIN_MAX_DISTANCE = 10

-- Ensures the character is within max_dist of the current target, moving
-- closer first if needed. Uses /nav (MQ2Nav) if the plugin is loaded,
-- otherwise falls back to /moveto. Returns true if in range, false if it
-- could not get close enough within the timeout.
local function ensure_within_range(max_dist)
    local target = mq.TLO.Target
    if not target() then return false end

    local dist = target.Distance3D() or 9999
    if dist <= max_dist then return true end

    local target_id = target.ID()
    print(string.format("\ay[HandIn Assistant] Target is %.1f away (need <= %d). Moving closer...\ax", dist, max_dist))

    local nav_loaded = mq.TLO.Plugin("MQ2Nav")() ~= nil

    if nav_loaded then
        mq.cmdf("/nav id %d", target_id)
        local wait_start = os.clock()
        while mq.TLO.Nav.Active() and (os.clock() - wait_start) < 15 do
            mq.doevents()
            mq.delay(100)
            if not should_execute then break end
        end
    else
        mq.cmdf("/moveto id %d", target_id)
        local wait_start = os.clock()
        while (mq.TLO.Target.Distance3D() or 9999) > max_dist and (os.clock() - wait_start) < 15 do
            mq.doevents()
            mq.delay(100)
            if not should_execute then break end
        end
        mq.cmd("/moveto off")
    end

    dist = mq.TLO.Target.Distance3D() or 9999
    if dist > max_dist then
        print(string.format("\ar[HandIn Assistant] Could not get within range of target (still %.1f away). Stopping.\ax", dist))
        return false
    end

    return true
end

local function process_coin_handin_routine()
    local target = mq.TLO.Target
    if not target() or (target.Type() ~= "NPC" and target.Type() ~= "PC") then
        print("\ar[HandIn Error] You must target a valid PC or NPC first!\ax")
        should_execute = false
        return
    end

    local coin_name = coin_types[selected_coin_idx]
    local control = coin_edit_controls[coin_name]
    local repeats_requested = coin_repeat_count

    for pass = 1, repeats_requested do
        if not should_execute then break end

        remaining_transactions_text = string.format("Transactions remaining: %d / %d", repeats_requested - pass + 1, repeats_requested)

        if get_coin_on_hand(coin_name) < coin_amount then
            print(string.format("\ar[HandIn Assistant] Not enough %s remaining. Stopping after %d/%d.\ax", coin_name, pass - 1, repeats_requested))
            break
        end

        if not control then
            print(string.format("\ar[HandIn Assistant] No control mapped for %s. Stopping.\ax", coin_name))
            break
        end

        if not ensure_within_range(HANDIN_MAX_DISTANCE) then
            should_execute = false
            break
        end

        -- The coin fields (IW_Money0-3) live on the Inventory window, not
        -- the Give window -- open it via the game's actual inventory
        -- keybind if it isn't already on-screen.
        local inv_win = mq.TLO.Window("InventoryWindow")
        if not inv_win.Open() then
            mq.cmd("/keypress INVENTORY")
            mq.delay(300)
        end

        if not inv_win.Open() then
            print("\ar[HandIn Assistant] Could not open your Inventory window (tried /keypress INVENTORY). Open it manually and try again.\ax")
            break
        end

        -- Clicking a coin field (IW_Money0-3) opens the same QuantityWnd
        -- stack-split dialog used for item stacks -- drive it the same way
        -- the item hand-in flow already does.
        mq.cmd("/notify InventoryWindow " .. control .. " leftmouseup")
        mq.delay(250)

        if mq.TLO.Window("QuantityWnd").Open() then
            mq.cmdf("/notify QuantityWnd QTYW_Slider newvalue %d", coin_amount)
            mq.delay(100)
            mq.cmd("/notify QuantityWnd QTYW_Accept_Button leftmouseup")
            mq.delay(250)
        else
            print("\ar[HandIn Assistant] Quantity window did not open for coin selection. Stopping.\ax")
            break
        end

        -- The coin is now on the cursor -- give/place it onto the target
        -- (drops it into the trade/give window) before confirming.
        mq.cmd("/click left target")
        mq.delay(300)

        -- Finalize the coin hand-in by clicking the Trade window's confirm
        -- button (this is the actual "Give"/"Trade" button for coin, as
        -- opposed to GVW_Give_Button used for item hand-ins).
        mq.cmd("/notify TradeWnd TRDW_Trade_Button leftmouseup")
        mq.delay(500)

        if mq.TLO.Cursor() then
            local clear_start = os.clock()
            while mq.TLO.Cursor() and (os.clock() - clear_start) < 5 do
                mq.cmd("/autoinventory")
                mq.delay(200)
            end
            if mq.TLO.Cursor() then
                print("\ar[HandIn Assistant] Could not clear cursor via /autoinventory (bags full?). Stopping.\ax")
                should_execute = false
                break
            end
        end

        print(string.format("\ay[HandIn Assistant] Handed in %d %s. (%d/%d)\ax", coin_amount, coin_name, pass, repeats_requested))

        if pass < repeats_requested then
            mq.delay(300)
        end
    end

    remaining_transactions_text = ""
    should_execute = false
end

-- Asynchronous loop automation runner
local function process_handin_routine()
    local selected_item = inventory_items[selected_idx]
    if not selected_item then 
        should_execute = false
        return 
    end
    
    local target = mq.TLO.Target
    if not target() or (target.Type() ~= "NPC" and target.Type() ~= "PC") then
        -- MODIFIED: Changed color prefix formatting string from \ay to \ar (red warning text style)
        print("\ar[HandIn Error] You must target a valid PC or NPC first!\ax")
        should_execute = false
        return
    end
    
    local preserved_item_name = selected_item.name

    -- Primary structural loop runner layer
    while should_execute do
        local active_item = nil
        for _, item in ipairs(inventory_items) do
            if item.name == preserved_item_name then
                active_item = item
                break
            end
        end

        if not active_item then break end

        if current_radio_mode == 2 then
            remaining_transactions_text = "Transactions remaining: Unknown (until ALLY)"
        else
            local per_transaction = math.max(1, items_per_handin * math.min(total_handins, 4))
            local est_remaining = math.floor(active_item.count / per_transaction)
            remaining_transactions_text = string.format("Transactions remaining: ~%d", est_remaining)
        end

        if not ensure_within_range(HANDIN_MAX_DISTANCE) then
            should_execute = false
            break
        end

        local execution_stacks = math.min(total_handins, 4)
        local final_handin_qty = math.min(items_per_handin, active_item.count)
        
        mq.cmd("/autoinventory")
        mq.delay(200) 
        
        -- Click loop targeting up to trade space slots cap matching choice stacks
        for slot_idx = 1, execution_stacks do
            if active_item.bag_slot ~= -1 then
                local pack_num = active_item.inv_slot - 22
                mq.cmdf("/itemnotify in pack%d %d leftmouseup", pack_num, active_item.bag_slot)
            else
                mq.cmdf("/itemnotify %d leftmouseup", active_item.inv_slot)
            end
            mq.delay(250) 
            
            if mq.TLO.Window("QuantityWnd").Open() then
                mq.cmdf("/notify QuantityWnd QTYW_Slider newvalue %d", final_handin_qty)
                mq.delay(100)
                mq.cmd("/notify QuantityWnd QTYW_Accept_Button leftmouseup")
                mq.delay(250) 
            end
            
            mq.cmdf("/click left target trade %d", slot_idx)
            mq.delay(300)
        end
        
        mq.cmd("/notify GiveWnd GVW_Give_Button leftmouseup")
        mq.delay(500)
        
        if mq.TLO.Cursor() then
            local clear_start = os.clock()
            while mq.TLO.Cursor() and (os.clock() - clear_start) < 5 do
                mq.cmd("/autoinventory")
                mq.delay(200)
            end
            if mq.TLO.Cursor() then
                print("\ar[HandIn Assistant] Could not clear cursor via /autoinventory (bags full?). Stopping.\ax")
                should_execute = false
                break
            end
        end
        
        -- Evaluate termination conditions based on your radio toggle rules
        if check_automation_termination(preserved_item_name) then
            break
        end

        mq.delay(300) 
    end

    remaining_transactions_text = ""
    should_execute = false 
end

-- Draw ImGui Interface
local function draw_gui()
    if not open_gui then return end
    
    local open, draw = imgui.Begin("MQ Item Hand-In Assistant", true, 0)
    if not open then
        open_gui = false
        imgui.End()
        return
    end
    
    if draw then
        if should_execute then
            imgui.TextColored(1, 1, 0, 1, "LOOP ACTIVE: Processing repeat hand-ins...")
            if remaining_transactions_text ~= "" then
                imgui.TextColored(1, 1, 1, 1, remaining_transactions_text)
            end
            if imgui.Button("Emergency Stop") then
                should_execute = false
            end
            imgui.End()
            return
        end

        -- Target Display Information
        local target = mq.TLO.Target
        if target() and (target.Type() == "NPC" or target.Type() == "PC") then
            if target.ID() ~= last_target_id then
                last_target_id = target.ID()
                if target.Type() == "PC" then
                    faction_standing_text = "ALLY (PLAYER)"
                    fx_r, fx_g, fx_b = 0.3, 0.6, 1.0
                    fetch_timer = 0
                    current_radio_mode = 1 
                else
                    faction_standing_text = "None"
                    fx_r, fx_g, fx_b = 1.0, 1.0, 1.0
                    fetch_timer = 0
                    if current_radio_mode == 2 then
                        faction_standing_text = "Fetching..."
                        fetch_timer = os.clock()
                        mq.cmd("/consider")
                    end
                end
            elseif current_radio_mode == 2 and target.Type() == "NPC" and faction_standing_text == "None" then
                -- Faction mode was just switched on for an already-targeted NPC
                -- that hasn't had its faction fetched yet.
                faction_standing_text = "Fetching..."
                fx_r, fx_g, fx_b = 1.0, 1.0, 1.0
                fetch_timer = os.clock()
                mq.cmd("/consider")
            end

            if faction_standing_text == "Fetching..." and fetch_timer > 0 and (os.clock() - fetch_timer) > 1.5 then
                faction_standing_text = "INDIFFERENT (TIMEOUT)"
                fx_r, fx_g, fx_b = 1.0, 1.0, 1.0
                fetch_timer = 0
            end

            local r, g, b = 0.3, 0.9, 0.3
            if target.Type() == "PC" then r, g, b = 0.3, 0.6, 1.0 end
            imgui.Text("Target Unit:")
            imgui.SameLine()
            imgui.TextColored(r, g, b, 1, string.format("%s (%s)", target.CleanName(), target.Type()))
            
            if current_radio_mode == 2 then
                imgui.Text("Target Faction:")
                imgui.SameLine()
                imgui.TextColored(fx_r, fx_g, fx_b, 1.0, faction_standing_text)
            end
        else
            last_target_id = 0
            faction_standing_text = "None"
            imgui.Text("Target Unit:")
            imgui.SameLine()
            imgui.TextColored(1, 0.2, 0.2, 1, "None (Select a PC or NPC)")
        end
        
        imgui.Separator()
        
        -- MODE SELECTION: Radio Buttons block logic
        imgui.Text("Automation Hand-In Focus:")
        
        if imgui.RadioButton("Quantity", current_radio_mode == 1) then
            current_radio_mode = 1
        end
        imgui.SameLine()
        
        local disable_faction_radio = (target() and target.Type() == "PC")
        if disable_faction_radio then imgui.BeginDisabled() end
        
        if imgui.RadioButton("Faction", current_radio_mode == 2) then
            current_radio_mode = 2
        end
        
        if disable_faction_radio then imgui.EndDisabled() end
        imgui.SameLine()

        if imgui.RadioButton("Coin", current_radio_mode == 3) then
            current_radio_mode = 3
        end
        
        imgui.Separator()
        
        if current_radio_mode == 3 then
            -- COIN FOCUS MODE: no item search/list -- just a coin type
            -- dropdown and the amount of that coin to hand in.
            imgui.Text("Coin Type:")
            imgui.SetNextItemWidth(combo_width)
            if imgui.BeginCombo("Select Coin", coin_types[selected_coin_idx] or "") then
                for i, name in ipairs(coin_types) do
                    local is_selected = (selected_coin_idx == i)
                    if imgui.Selectable(name, is_selected) then
                        selected_coin_idx = i
                    end
                end
                imgui.EndCombo()
            end
            imgui.Separator()

            local coin_max = get_coin_on_hand(coin_types[selected_coin_idx])
            if coin_amount > coin_max then
                coin_amount = coin_max
            end

            local pre_slider_amount = coin_amount
            imgui.Text(string.format("Amount to hand in (Max Available: %d)", coin_max))
            imgui.SetNextItemWidth(FIELD_WIDTH)
            coin_amount = imgui.SliderInt("##coin_amount_slider", coin_amount, 0, coin_max)

            if coin_amount ~= pre_slider_amount then
                -- Snap to the nearest multiple of 5, clamped back within range.
                -- Only applied when the slider itself changed the value, so the
                -- +/- buttons below can adjust by exactly 1 independently.
                coin_amount = math.floor((coin_amount / 5) + 0.5) * 5
                if coin_amount > coin_max then coin_amount = coin_max end
                if coin_amount < 0 then coin_amount = 0 end
            end

            imgui.Text("Fine tune amount:")
            imgui.SameLine()
            if imgui.Button("-##amount_dec") then
                coin_amount = math.max(0, coin_amount - 1)
            end
            imgui.SameLine()
            imgui.Text(tostring(coin_amount))
            imgui.SameLine()
            if imgui.Button("+##amount_inc") then
                coin_amount = math.min(coin_max, coin_amount + 1)
            end

            imgui.Separator()

            -- Repeat count can never let (amount * repeats) exceed how much
            -- of this coin type is actually on hand.
            local max_repeats_for_amount = coin_amount > 0 and math.floor(coin_max / coin_amount) or 50
            if max_repeats_for_amount < 1 then max_repeats_for_amount = 1 end
            if coin_repeat_count > max_repeats_for_amount then
                coin_repeat_count = max_repeats_for_amount
            end

            imgui.Text(string.format("Repeat X times: (Max %d)", max_repeats_for_amount))
            imgui.SameLine()
            if imgui.Button("-##repeat_dec") then
                coin_repeat_count = math.max(1, coin_repeat_count - 1)
            end
            imgui.SameLine()
            imgui.Text(tostring(coin_repeat_count))
            imgui.SameLine()
            if imgui.Button("+##repeat_inc") then
                coin_repeat_count = math.min(max_repeats_for_amount, coin_repeat_count + 1)
            end

            local total_needed = coin_amount * coin_repeat_count
            imgui.TextColored(0.7, 0.7, 0.7, 1, string.format("Total this run: %d / %d available", total_needed, coin_max))

            imgui.Separator()

            imgui.TextColored(0.7, 0.7, 0.7, 1, "Note: The script will try to auto-open your Inventory")
            imgui.TextColored(0.7, 0.7, 0.7, 1, "window (/keypress INVENTORY) if it isn't already open.")

            imgui.Separator()

            if target() and (target.Type() == "NPC" or target.Type() == "PC") then
                if coin_amount <= 0 then
                    imgui.TextColored(1, 0.6, 0, 1, "Set an amount greater than 0 to hand in.")
                else
                    if imgui.Button("Hand in Coin") then
                        should_execute = true
                    end
                end
            else
                imgui.TextColored(1, 0, 0, 1, "Hand-in locked: Invalid or empty target.")
            end
        elseif #item_names > 0 then
            if imgui.Button("Refresh Inventory") then
                populate_inventory()
            end
            imgui.SameLine()
            local sort_label = sort_ascending and "Sorted: A-Z" or "Sorted: Z-A"
            if imgui.Button(sort_label) then
                sort_ascending = not sort_ascending
                populate_inventory()
            end

            imgui.SetNextItemWidth(FIELD_WIDTH)
            local new_search_filter = imgui.InputText("(Partial) Search Items", search_filter)

            if new_search_filter ~= search_filter then
                search_filter = new_search_filter
                local filter_lower = search_filter:lower()

                if filter_lower ~= "" then
                    for i, name in ipairs(item_names) do
                        if name:lower():find(filter_lower, 1, true) then
                            selected_idx = i
                            if items_per_handin > inventory_items[selected_idx].max_stack then
                                items_per_handin = inventory_items[selected_idx].max_stack
                            end
                            break
                        end
                    end
                end
            end

            imgui.SetNextItemWidth(combo_width)
            if imgui.BeginCombo("Select Item", item_names[selected_idx] or "") then
                local filter_lower = search_filter:lower()
                for i, name in ipairs(item_names) do
                    if filter_lower == "" or name:lower():find(filter_lower, 1, true) then
                        local is_selected = (selected_idx == i)
                        if imgui.Selectable(name, is_selected) then
                            selected_idx = i
                            if items_per_handin > inventory_items[selected_idx].max_stack then
                                items_per_handin = inventory_items[selected_idx].max_stack
                            end
                        end
                    end
                end
                imgui.EndCombo()
            end
            imgui.Separator()

            local current_item = inventory_items[selected_idx]
            local max_allowed_stack = current_item and current_item.max_stack or 1
            
            imgui.SetNextItemWidth(FIELD_WIDTH)
            items_per_handin = imgui.SliderInt(string.format("Items per stack (Max Allowed: %d)", max_allowed_stack), items_per_handin, 1, max_allowed_stack)
            imgui.SetNextItemWidth(FIELD_WIDTH)
            total_handins = imgui.SliderInt("Number of stacks/turns (Max 4)", total_handins, 1, 4)
            
            imgui.Separator()
            
            if target() and (target.Type() == "NPC" or target.Type() == "PC") then
                local btn_text = current_radio_mode == 2 and "Hand in until ALLY" or "Hand in ALL items"
                if imgui.Button(btn_text) then
                    should_execute = true
                end
            else
                imgui.TextColored(1, 0, 0, 1, "Hand-in locked: Invalid or empty target.")
            end
        else
            imgui.Text("No tradable items found in your inventory.")
            if imgui.Button("Refresh Inventory") then
                populate_inventory()
            end
        end
    end
    imgui.End()
end

-- Initialize inventory lists safely
populate_inventory()

-- Bind explicit text matching event logs straight to your callback configurations
mq.event("FactionAlly",   "#1# regards you as an ally#*#", faction_ally)
mq.event("FactionWarmly", "#1# views you warmly#*#", faction_warmly)
mq.event("FactionKindly", "#1# looks upon you kindly#*#", faction_kindly)
mq.event("FactionAmiable","#1# judges you amiably#*#", faction_amiable)
mq.event("FactionIndiff", "#1# regards you indifferently#*#", faction_indiff)
mq.event("FactionAppre",  "#1# glares at you apprehensively#*#", faction_appre)
mq.event("FactionDubious", "#1# looks upon you dubiously#*#", faction_dubious)
mq.event("FactionThreat", "#1# looks at you threateningly#*#", faction_threat)
mq.event("FactionScowls", "#1# scowls with ready anger#*#", faction_scowls)

-- Main Script Loop
mq.imgui.init('HandInGui', draw_gui)
while open_gui do
    mq.doevents()
    
    if should_execute then
        if current_radio_mode == 3 then
            process_coin_handin_routine()
        else
            process_handin_routine()
        end
    end
    
    mq.delay(10) 
end
