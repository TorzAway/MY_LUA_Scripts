--[[
chase.lua 1.3.0 -- aquietone

=============================================================================
 OVERVIEW
=============================================================================
 A MacroQuest Lua chase script. It keeps your character following a chosen
 person around the zone by issuing MQ2Nav (/nav) commands whenever you fall
 outside a configurable distance from your chase target.

 The chase target can be:
   * a free-typed PC name,
   * a raid member selected from an in-zone dropdown (see UI below), or
   * a group/raid role (main assist, main tank, leader, raid assist 1-3).

=============================================================================
 REQUIREMENTS
=============================================================================
   * MacroQuest with the Lua and ImGui runtimes.
   * MQ2Nav loaded, with a mesh available for the current zone. If no nav
     path exists to the target, the script simply does nothing.

=============================================================================
 USAGE
=============================================================================
 Run the script from the MQ console:
     /lua run chase

 You may pass a single startup argument that is either a role name or a PC
 name to chase immediately:
     /lua run chase ma            -- chase the group main assist
     /lua run chase Somedude      -- chase the PC named Somedude

=============================================================================
 SLASH COMMANDS  (/luachase)
=============================================================================
 /luachase pause on|1|true          -- pause chasing
 /luachase pause off|0|false        -- resume chasing
 /luachase pause                    -- print the current paused state
 /luachase target                   -- chase your current target (must be a PC)
 /luachase name somedude            -- set the chase target to "somedude"
 /luachase name                     -- print the current chase target
 /luachase role ma|mt|leader|raid1|raid2|raid3
                                    -- chase the PC filling the given role
 /luachase role                     -- print the role being chased
 /luachase distance 30              -- set the chase (start) distance
 /luachase distance                 -- print the current chase distance
 /luachase stopdistance 10          -- set the stop distance (nav dist=# param)
 /luachase stopdistance             -- print the current stop distance
 /luachase show                     -- show the UI window
 /luachase hide                     -- hide the UI window
 /luachase [help]                   -- print the help output

 Distance rules:
   * Chase distance must be between 15 and 300.
   * Stop distance must be between 0 and (chase distance - 1).

=============================================================================
 USER INTERFACE
=============================================================================
 A small ImGui window titled "Chase v<version>" provides:
   * Lock chevron           -- lock/unlock the window's on-screen position.
   * Pause / Resume button   -- yellow (with black text) while running, red
     while paused. Only shown once a valid chase is defined.
   * Exit button (red)       -- stop chasing and terminate the script.
   * Chase Role combo        -- pick a group/raid role, or "none" for a named PC.
   * Chase Target input       -- (role "none" only) free-type a PC name.
   * Clear Chase Target       -- (role "none", non-empty target only) clear the
     typed target name.
   * Raid Members (in zone)  -- (role "none" only) dropdown listing raid members
     who are currently in your zone. Your own group members and yourself are
     excluded from this list.
   * Chase Distance / Stop Distance inputs.

 The window auto-resizes to fit its widest element.

=============================================================================
 CHASE BEHAVIOR / SAFETY GUARDS
=============================================================================
 The script will NOT chase (and will stop any active nav) while you are:
   * paused,
   * in combat (Me.Combat or CombatState == "COMBAT"),
   * looting -- the loot window is open, a corpse loot is in progress, or the
     TurboLoot macro is running.

 It will also skip chasing while you are hovering (dead), auto-firing,
 casting (except Bards), or actively /stick'd to something.

=============================================================================
 TOP-LEVEL OBJECT (TLO)
=============================================================================
 ${Chase}                -- ToString: "Chase Running = true|false"
 ${Chase.Role}           -- string: current role being chased
 ${Chase.Paused}         -- bool:   whether chasing is paused
 ${Chase.ChaseDistance}  -- int:    current chase (start) distance
 ${Chase.StopDistance}   -- int:    current stop distance
 ${Chase.Target}         -- string: current chase target name

=============================================================================
 CHANGELOG
=============================================================================
 1.3.0 -- Added Clear Chase Target button (shown only with a typed target);
          red Exit button that stops chasing and cleanly terminates the
          script; lock chevron to lock/unlock the window position; window now
          auto-resizes to fit its widest element; widened the Raid Members
          combo; Pause/Resume button hidden until a valid chase is defined.
 1.2.0 -- Raid Members (in zone) selector (excludes self and own group);
          combat/loot guards now actively stop nav; TurboLoot macro treated
          as looting; colored Pause/Resume button; version shown in title bar;
          fixed stopdistance command (was checking an undefined variable);
          full documentation added.
 1.1.0 -- Prior release.

 Author: aquietone
]]--

local mq = require('mq')
require('ImGui')
local icons = require('mq.icons')

local VERSION = '1.3.0'

local PREFIX = '\aw[\agCHASE\aw] \ay'
local PAUSED = false
local TERMINATE = false
local LOCKED = true
local CHASE = ''
local DISTANCE = 30
local STOP_DISTANCE = 10

local open_gui = true
local should_draw_gui = true

local ROLES = {[1]='none',none=1,[2]='ma',ma=1,[3]='mt',mt=1,[4]='leader',leader=1,[5]='raid1',raid1=1,[6]='raid2',raid2=1,[7]='raid3',raid3=1}
local ROLE = 'none'

-- Cache for the list of raid members currently in zone so we don't hammer the
-- TLOs every single ImGui frame. Refreshed at most once per second.
local raid_in_zone_cache = {}
local raid_in_zone_last_refresh = 0

local function init_tlo()
    local ChaseType

    local function ChaseTLO(index)
        return ChaseType, {}
    end

    local tlomembers = {
        Paused = function() return 'bool', PAUSED end,
        Role = function(val, index) return 'string', ROLE end,
        Target = function(val, index) return 'string', CHASE end,
        ChaseDistance = function(val, index) return 'int', DISTANCE end,
        StopDistance = function(val, index) return 'int', STOP_DISTANCE end,
    }

    ChaseType = mq.DataType.new('ChaseType', {
        Members = tlomembers
    })
    function ChaseType.ToString()
        return ('Chase Running = %s'):format(not PAUSED)
    end

    mq.AddTopLevelObject('Chase', ChaseTLO)
end

local function validate_distance(distance)
    return distance >= 15 and distance <= 300
end

local function validate_stop_distance(distance)
    return distance >= 0 and distance < DISTANCE
end

local function check_distance(x1, y1, x2, y2)
    return (x2 - x1) ^ 2 + (y2 - y1) ^ 2
end

local function validate_chase_role(role)
    return ROLES[role] ~= nil
end

-- Build a list of raid members who are currently in the same zone as you.
-- A raid member is considered "in zone" if a matching PC spawn exists.
-- Yourself is excluded since chasing yourself makes no sense.
local function get_raid_members_in_zone()
    local now = os.time()
    if now - raid_in_zone_last_refresh < 1 then
        return raid_in_zone_cache
    end
    raid_in_zone_last_refresh = now

    local members = {}
    local me = mq.TLO.Me.CleanName()

    -- Build a set of my own group members (raid subgroup) so we can exclude
    -- them. Group.Member(0) is me; 1..Members() are the rest of my group.
    local group_set = {}
    local gcount = mq.TLO.Group.Members() or 0
    for i = 0, gcount do
        local gm = mq.TLO.Group.Member(i)
        local gname = gm and gm.Name()
        if gname then group_set[gname] = true end
    end

    local count = mq.TLO.Raid.Members() or 0
    for i = 1, count do
        local member = mq.TLO.Raid.Member(i)
        local name = member and member.Name()
        if name and name ~= me and not group_set[name] then
            -- Spawn('pc =name') only returns a valid spawn if they are in zone
            local spawn = mq.TLO.Spawn('pc ='..name)
            local id = spawn and spawn.ID()
            if id and id > 0 then
                table.insert(members, name)
            end
        end
    end
    table.sort(members)
    raid_in_zone_cache = members
    return members
end

local function get_spawn_for_role()
    local spawn = nil
    if ROLE == 'none' then
        spawn = mq.TLO.Spawn('pc ='..CHASE)
    elseif ROLE == 'ma' then
        spawn = mq.TLO.Group.MainAssist
    elseif ROLE == 'mt' then
        spawn = mq.TLO.Group.MainTank
    elseif ROLE == 'leader' then
        spawn = mq.TLO.Group.Leader
    elseif ROLE == 'raid1' then
        spawn = mq.TLO.Raid.MainAssist(1)
    elseif ROLE == 'raid2' then
        spawn = mq.TLO.Raid.MainAssist(2)
    elseif ROLE == 'raid3' then
        spawn = mq.TLO.Raid.MainAssist(3)
    end
    return spawn
end

local function is_looting()
    -- Loot window open, loot-in-progress flag set, or the TurboLoot macro running.
    if mq.TLO.Window('LootWnd').Open() or mq.TLO.Corpse.Open() then return true end
    local macro = mq.TLO.Macro.Name()
    if macro and macro:lower():find('turboloot') then return true end
    return false
end

local function is_in_combat()
    -- Me.Combat() = melee/attack active; CombatState()=='COMBAT' catches the
    -- broader "actively engaged" case (e.g. casters standing back).
    return mq.TLO.Me.Combat() or mq.TLO.Me.CombatState() == 'COMBAT'
end

local function do_chase()
    if PAUSED then return end
    if is_in_combat() or is_looting() then
        -- Don't chase while fighting/looting, and cancel any nav already running.
        if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
        return
    end
    if mq.TLO.Me.Hovering() or mq.TLO.Me.AutoFire() or (mq.TLO.Me.Casting() and mq.TLO.Me.Class.ShortName() ~= 'BRD') or mq.TLO.Stick.Active() then return end
    local chase_spawn = get_spawn_for_role()
    local me_x = mq.TLO.Me.X()
    local me_y = mq.TLO.Me.Y()
    local chase_x = chase_spawn.X()
    local chase_y = chase_spawn.Y()
    if not chase_x or not chase_y then return end
    if check_distance(me_x, me_y, chase_x, chase_y) > DISTANCE^2 then
        if not mq.TLO.Nav.Active() and mq.TLO.Navigation.PathExists(string.format('spawn pc =%s', chase_spawn.CleanName())) then
            mq.cmdf('/nav spawn pc =%s | dist=%s log=off', chase_spawn.CleanName(), STOP_DISTANCE)
        end
    end
end

local function helpMarker(desc)
    if ImGui.IsItemHovered() then
        ImGui.BeginTooltip()
        ImGui.PushTextWrapPos(ImGui.GetFontSize() * 35.0)
        ImGui.Text(desc)
        ImGui.PopTextWrapPos()
        ImGui.EndTooltip()
    end
end

local function draw_combo_box(resultvar, options)
    if ImGui.BeginCombo('Chase Role', resultvar) then
        for _,j in ipairs(options) do
            if ImGui.Selectable(j, j == resultvar) then
                resultvar = j
            end
        end
        ImGui.EndCombo()
    end
    helpMarker('Assign the group or raid role to chase')
    return resultvar
end

-- Combo box that lets you pick a chase target from the raid members currently
-- in your zone. Returns the (possibly updated) chase target name.
local function draw_raid_combo_box(current)
    local members = get_raid_members_in_zone()
    local preview = current ~= '' and current or '<select raid member>'
    -- The outer PushItemWidth(100) is too narrow for this combo's preview text,
    -- so give it its own wider width for this one item.
    ImGui.SetNextItemWidth(200)
    if ImGui.BeginCombo('Raid Members (in zone)', preview) then
        if #members == 0 then
            ImGui.TextDisabled('No raid members in zone')
        else
            for _, name in ipairs(members) do
                if ImGui.Selectable(name, name == current) then
                    current = name
                end
            end
        end
        ImGui.EndCombo()
    end
    helpMarker('Pick a raid member who is currently in your zone')
    return current
end

-- A chase is "valid" (and thus pausable) when a role other than 'none' is
-- selected, or when the role is 'none' and a non-empty target name is set.
local function has_valid_chase()
    if ROLE ~= 'none' then return true end
    return CHASE ~= nil and CHASE ~= ''
end

local function chase_ui()
    if not open_gui or mq.TLO.MacroQuest.GameState() ~= 'INGAME' then return end
    local flags = ImGuiWindowFlags.AlwaysAutoResize
    if LOCKED then flags = flags + ImGuiWindowFlags.NoMove end
    open_gui, should_draw_gui = ImGui.Begin('Chase v'..VERSION, open_gui, flags)
    if should_draw_gui then
        -- Lock chevron: toggles whether the window can be dragged.
        local lock_icon = LOCKED and icons.FA_LOCK or icons.FA_UNLOCK
        if ImGui.Button(lock_icon) then
            LOCKED = not LOCKED
        end
        helpMarker(LOCKED and 'Window position locked -- click to unlock' or 'Click to lock the window position')
        ImGui.SameLine()
        local rendered_pause = false
        if has_valid_chase() then
            if PAUSED then
                -- Red while actively paused.
                ImGui.PushStyleColor(ImGuiCol.Button, 0.7, 0.1, 0.1, 1.0)
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.8, 0.2, 0.2, 1.0)
                ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0.9, 0.3, 0.3, 1.0)
                if ImGui.Button('Resume') then
                    PAUSED = false
                end
                ImGui.PopStyleColor(3)
            else
                -- Yellow while running, with black text for contrast.
                ImGui.PushStyleColor(ImGuiCol.Button, 0.7, 0.7, 0.1, 1.0)
                ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.8, 0.8, 0.2, 1.0)
                ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0.9, 0.9, 0.3, 1.0)
                ImGui.PushStyleColor(ImGuiCol.Text, 0.0, 0.0, 0.0, 1.0)
                if ImGui.Button('Pause') then
                    PAUSED = true
                    mq.cmd('/squelch /nav stop')
                end
                ImGui.PopStyleColor(4)
            end
            helpMarker('Pause or resume chasing')
            rendered_pause = true
        end
        -- Red Exit button, on the same line as Pause/Resume when it is shown.
        if rendered_pause then ImGui.SameLine() end
        ImGui.PushStyleColor(ImGuiCol.Button, 0.7, 0.1, 0.1, 1.0)
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.8, 0.2, 0.2, 1.0)
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, 0.9, 0.3, 0.3, 1.0)
        if ImGui.Button('Exit') then
            mq.cmd('/squelch /nav stop')
            TERMINATE = true
        end
        ImGui.PopStyleColor(3)
        helpMarker('Stop chasing and exit the script')
        ImGui.PushItemWidth(100)
        ROLE = draw_combo_box(ROLE, ROLES)
        if ROLE == 'none' then
            -- Free-form typed target...
            CHASE = ImGui.InputText('Chase Target', CHASE)
            helpMarker('Type a PC spawn name to chase')
            if CHASE ~= nil and CHASE ~= '' then
                ImGui.SameLine()
                if ImGui.Button('Clear Chase Target') then
                    CHASE = ''
                end
                helpMarker('Clear the chase target name')
            end
            -- ...or pick one from the raid members in zone.
            CHASE = draw_raid_combo_box(CHASE)
        end
        local tmp_distance = ImGui.InputInt('Chase Distance', DISTANCE)
        helpMarker('Set the distance to begin chasing at. Min=15, Max=300')
        if validate_distance(tmp_distance) then
            DISTANCE = tmp_distance
        end
        tmp_distance = ImGui.InputInt('Stop Distance', STOP_DISTANCE)
        helpMarker('Set the distance to stop chasing at. Min=0, Max='..(DISTANCE-1))
        ImGui.PopItemWidth()
        if validate_stop_distance(tmp_distance) then
            STOP_DISTANCE = tmp_distance
        end
    end
    ImGui.End()
end
mq.imgui.init('Chase', chase_ui)

local function print_help()
    print('\ayLua Chase '..VERSION..' -- \awAvailable Commands:')
    print('\ay\t/luachase role ma|mt|leader|raid1|raid2|raid3\n\t/luachase target\n\t/luachase name [pc_name_to_chase]\n\t/luachase distance [10,300]\n\t/luachase stopdistance [0,chase_distance-1]\n\t/luachase pause on|1|true\n\t/luachase pause off|0|false\n\t/luachase show\n\t/luachase hide')
end

local function bind_chase(...)
    local args = {...}
    local key = args[1]
    local value = args[2]
    if not key or key == 'help' then
        print_help()
    elseif key == 'target' then
        if not mq.TLO.Target() or mq.TLO.Target.Type() ~= 'PC' then
            return
        end
        CHASE = mq.TLO.Target.CleanName()
    elseif key == 'name' then
        if value then
            CHASE = value
        else
            printf('%sChase Target: \aw%s', PREFIX, CHASE)
        end
    elseif key == 'role' then
        if value and validate_chase_role(value) then
            ROLE = value
        else
            printf('%sChase Role: \aw%s', PREFIX, ROLE)
        end
    elseif key == 'distance' then
        if tonumber(value) then
            local tmp_distance = tonumber(value)
            if validate_distance(tmp_distance) then
                DISTANCE = tmp_distance
            end
        else
            printf('%sChase Distance: \aw%s', PREFIX, DISTANCE)
        end
    elseif key == 'stopdistance' then
        if tonumber(value) then
            local tmp_distance = tonumber(value)
            if validate_stop_distance(tmp_distance) then
                STOP_DISTANCE = tmp_distance
            end
        else
            printf('%sStop Distance: \aw%s', PREFIX, STOP_DISTANCE)
        end
    elseif key == 'pause' then
        if value == 'on' or value == '1' or value == 'true' then
            PAUSED = true
            mq.cmd('/squelch /nav stop')
        elseif value == 'off' or value == '0' or value == 'false' then
            PAUSED = false
        else
            printf('%sPaused: \aw%s', PREFIX, PAUSED)
        end
    elseif key == 'show' then
        open_gui = true
    elseif key == 'hide' then
        open_gui = false
    end
end
mq.bind('/luachase', bind_chase)
init_tlo()

local args = {...}
if args[1] then
    if validate_chase_role(args[1]) then
        ROLE = args[1]
    else
        CHASE=args[1]
    end
end

while not TERMINATE do
    if mq.TLO.MacroQuest.GameState() == 'INGAME' then
        do_chase()
    end
    mq.delay(50)
end

-- Clean up on exit: make sure we aren't leaving a nav running.
if mq.TLO.Nav.Active() then mq.cmd('/squelch /nav stop') end
