--[[
================================================================================
 MobMonitor.lua
================================================================================

 OVERVIEW
 --------
 A MacroQuest Lua/ImGui tool that watches your current zone for a specific
 PC or NPC by name. While the named spawn has not yet appeared in zone, the
 script idles quietly and keeps scanning in the background. The moment it
 spawns, the script:

   1. Captures and freezes its initial spawn coordinates (Y, X, Z) and the
      time/zone it was first seen in.
   2. Appends that spawn event as a line to a persistent log file so you
      build up a history of spawn locations/times over multiple sessions.
   3. Continues to display the spawn's live "current" location (separate
      from the frozen initial-spawn coordinates) for as long as it remains
      in zone, so you can tell if/how far it has wandered from its spawn
      point.

 If the spawn despawns (dies, zones, etc.) and later appears again, this
 counts as a new spawn event: the initial-spawn coordinates are recaptured
 and a new line is appended to the log file. This makes the tool useful for
 tracking rare/named spawn points and rough respawn timing.


 REQUIREMENTS
 ------------
   - MacroQuest (with Lua scripting support enabled)
   - The ImGui Lua bindings that ship with MacroQuest (require('ImGui'))


 INSTALLATION
 ------------
   1. Copy this file into your MacroQuest "lua" folder, e.g.:
        <MQ Root>\lua\MobMonitor.lua
   2. In-game, run it with:
        /lua run MobMonitor


 USAGE
 -----
   1. Launch the script (/lua run MobMonitor). A "Spawn Monitor" ImGui
      window will appear.
   2. Type the name of the PC or NPC you want to watch for into the name
      field.
   3. (Optional) Adjust the search options:
        - Include PCs / Include NPCs  : restrict which spawn types count
                                         as a match (both checked = no
                                         type restriction).
        - Exact name match            : when checked, requires an exact
                                         (clean) name match. Uncheck this
                                         to allow partial/substring name
                                         matches (useful for names you're
                                         not 100% sure of, or internal
                                         names like "a_certain_named").
        - Log spawn events to file    : toggles whether spawn events get
                                         written to NPC_Spawn_Log.txt.
   4. Click "Start Monitoring". The script will continuously scan
      (~4 times per second) for a matching spawn in your current zone.
   5. While idle (no match found), the window shows a yellow status
      message and an amber "not in zone - watching..." notice.
   6. As soon as a match appears, the window turns green, displays the
      frozen "Initial Spawn Location" and the live "Current Location",
      and a log entry is written automatically.
   7. Click "Stop Monitoring" at any time to pause scanning, "Clear" to
      reset the name field and all captured data, or "Exit Script" to
      close the window and immediately terminate the script (no
      confirmation prompt).


 GUI CONTROLS
 ------------
   Start Monitoring / Stop Monitoring : begins/halts the background scan
                                         loop for the currently entered
                                         name.
   Clear                              : clears the name field and all
                                         captured spawn data, stops
                                         monitoring.
   Exit Script (red button)           : immediately closes the window and
                                         ends the script. No confirmation
                                         is asked - this is intentional.
   Echo Location to Console           : (shown once a spawn is found)
                                         prints the spawn's current Y/X/Z
                                         to the MQ console window.


 COLOR LEGEND
 ------------
   Yellow   : the current status line (idle / watching / found).
   Cyan     : the configured log file path.
   Green    : "NOT LOGGED YET" - no spawn event has been written to the
              log file yet for the current monitoring session.
   Orange   : "LOGGED TO FILE" - the most recent spawn event was
              successfully written to the log file.
   Red      : a log file write error occurred (see the message text for
              details), or the Exit Script button.
   Bright
   green    : "FOUND" banner once the monitored spawn is located in zone.
   Amber    : "Not currently in zone - watching..." notice while idle.
   Blue     : "Initial Spawn Location" section header.


 LOG FILE
 --------
   Location : <MacroQuest Config Folder>\NPC_Spawn_Log.txt
              (the resolved path is also shown in the GUI window)

   Format   : one line per spawn event, pipe-delimited, e.g.:

       Timestamp | Name | Type | Zone | Location | Heading
       2026-06-21 14:32:05 | Bristlebane | NPC | qeynos2 | Y=[123.45] X=[-678.90] Z=[12.34] | Heading: [90.0]

   A header row is written automatically the first time the file is
   created. Subsequent runs/spawn events are appended, so the file
   accumulates a running history rather than being overwritten.


 NOTES & LIMITATIONS
 --------------------
   - Only the current zone is scanned; the script does not track spawns
     across zones simultaneously.
   - If multiple spawns match the search criteria (e.g. a very common
     partial-match name), MacroQuest's Spawn TLO will resolve to a single
     (typically nearest) match - not all matches.
   - "Initial Spawn Location" reflects the moment the script detected the
     spawn, which may be a tick or two after it actually became visible,
     depending on the scan interval (default 250ms).
   - Logging can be disabled at any time via the "Log spawn events to
     file" checkbox without stopping monitoring.
================================================================================
]]

local mq    = require('mq')
local ImGui = require('ImGui')

----------------------------------------------------------------
-- State
----------------------------------------------------------------
local isOpen      = true   -- window open flag (tied to the title-bar X)
local shouldDraw  = true

local inputBuffer = 'Reaver' -- raw text currently in the input box
local targetName  = ''     -- name actively being monitored
local monitoring  = false  -- true once "Start Monitoring" is clicked

local exactMatch  = true   -- exact vs. partial (substring) name match
local includePC   = true
local includeNPC  = true
local loggingOn   = true   -- whether to write spawn events to the log file

local found       = false
local foundName   = ''
local foundType   = ''
local spawnID     = 0

-- live / current location (updates continuously while in zone)
local locY, locX, locZ = 0, 0, 0
local heading     = 0
local distance3D  = 0

-- initial spawn location (captured once per spawn event, then frozen)
local spawnedY, spawnedX, spawnedZ = 0, 0, 0
local spawnedTime  = ''
local spawnedZone  = ''
local hasSpawnRecord = false

local currentZone = mq.TLO.Zone.ShortName() or ''
local statusMsg   = 'Idle - enter a name and click Start Monitoring.'
local lastLogMsg  = 'NOT LOGGED YET'
local logState    = 'none' -- 'none' | 'logged' | 'error'

----------------------------------------------------------------
-- Log file helpers
----------------------------------------------------------------
local function GetLogFilePath()
    local dir = mq.configDir or '.'
    local lastChar = dir:sub(-1)
    if lastChar ~= '\\' and lastChar ~= '/' then
        dir = dir .. '\\'
    end
    return dir .. 'NPC_Spawn_Log.txt'
end

local LOG_FILE_PATH = GetLogFilePath()

local function WriteSpawnLog(name, spType, zone, y, x, z, hdg)
    if not loggingOn then return end

    local ok, err = pcall(function()
        -- Write a header line the first time the file is created
        local existing = io.open(LOG_FILE_PATH, 'r')
        local isNewFile = existing == nil
        if existing then existing:close() end

        local f = io.open(LOG_FILE_PATH, 'a')
        if not f then error('could not open file for writing') end

        if isNewFile then
            f:write('Timestamp | Name | Type | Zone | Location | Heading\n')
        end

        f:write(string.format('%s | %s | %s | %s | Y=[%.2f] X=[%.2f] Z=[%.2f] | Heading: [%.1f]\n',
            os.date('%Y-%m-%d %H:%M:%S'), name, spType, zone, y, x, z, hdg))

        f:close()
    end)

    if ok then
        logState   = 'logged'
        lastLogMsg = 'LOGGED TO FILE'
        print(string.format('[MobMonitor] Spawn location logged to %s', LOG_FILE_PATH))
    else
        logState   = 'error'
        lastLogMsg = 'ERROR writing log file: ' .. tostring(err)
        print('[MobMonitor] ' .. lastLogMsg)
    end
end

----------------------------------------------------------------
-- Search helpers
----------------------------------------------------------------
local function BuildSearchString(name)
    -- Builds a MacroQuest spawn search string.
    -- A leading '=' on the name token forces an exact (clean) name match.
    local parts = {}

    if includePC and not includeNPC then
        table.insert(parts, 'pc')
    elseif includeNPC and not includePC then
        table.insert(parts, 'npc')
    end
    -- if both (or neither) are checked, no type filter is applied

    if exactMatch then
        table.insert(parts, '=' .. name)
    else
        table.insert(parts, name)
    end

    return table.concat(parts, ' ')
end

local function ResetLive()
    found, foundName, foundType, spawnID = false, '', '', 0
    locY, locX, locZ, heading, distance3D = 0, 0, 0, 0, 0
end

local function UpdateMonitor()
    if not monitoring or targetName == '' then return end

    -- Detect zone changes so stale data doesn't linger
    local zoneNow = mq.TLO.Zone.ShortName() or ''
    if zoneNow ~= currentZone then
        currentZone = zoneNow
        if found then
            print(string.format("[MobMonitor] Zoned - '%s' is no longer tracked.", targetName))
        end
        ResetLive()
    end

    local spawn = mq.TLO.Spawn(BuildSearchString(targetName))
    local id = spawn.ID() or 0

    if id > 0 then
        local newlySpawned = not found

        found       = true
        foundName   = spawn.CleanName() or spawn.Name() or targetName
        foundType   = spawn.Type() or '?'
        spawnID     = id
        locY        = spawn.Y() or 0
        locX        = spawn.X() or 0
        locZ        = spawn.Z() or 0
        heading     = (spawn.Heading and spawn.Heading.Degrees and spawn.Heading.Degrees()) or 0
        distance3D  = spawn.Distance3D() or 0
        statusMsg   = string.format("Monitoring '%s' - FOUND in zone", targetName)

        if newlySpawned then
            -- This is the moment it appeared: freeze these as the "initial spawn" coords
            spawnedY, spawnedX, spawnedZ = locY, locX, locZ
            spawnedTime   = os.date('%Y-%m-%d %H:%M:%S')
            spawnedZone   = currentZone
            hasSpawnRecord = true

            print(string.format("[MobMonitor] '%s' has spawned! (%s, ID %d) at Y=%.2f X=%.2f Z=%.2f",
                foundName, foundType, id, locY, locX, locZ))

            WriteSpawnLog(foundName, foundType, spawnedZone, spawnedY, spawnedX, spawnedZ, heading)
        end
    else
        if found then
            print(string.format("[MobMonitor] '%s' is no longer in zone.", targetName))
        end
        ResetLive()
        statusMsg = string.format("Monitoring '%s' - not in zone, watching...", targetName)
    end
end

----------------------------------------------------------------
-- ImGui Render
----------------------------------------------------------------
local function RenderGUI()
    ImGui.SetNextWindowSize(400, 480, ImGuiCond.FirstUseEver)
    shouldDraw, isOpen = ImGui.Begin('Spawn Monitor', isOpen)

    if shouldDraw then
        ImGui.Text('Mob / PC name to monitor:')
        inputBuffer = ImGui.InputText('##nameinput', inputBuffer)

        ImGui.Spacing()
        includePC  = ImGui.Checkbox('Include PCs', includePC)
        ImGui.SameLine()
        includeNPC = ImGui.Checkbox('Include NPCs', includeNPC)
        exactMatch = ImGui.Checkbox('Exact name match (uncheck for partial match)', exactMatch)
        loggingOn  = ImGui.Checkbox('Log spawn events to file', loggingOn)

        ImGui.Spacing()

        if not monitoring then
            if ImGui.Button('Start Monitoring', 150, 0) then
                if inputBuffer ~= '' then
                    targetName  = inputBuffer
                    monitoring  = true
                    currentZone = mq.TLO.Zone.ShortName() or ''
                    ResetLive()
                    hasSpawnRecord = false
                    logState   = 'none'
                    lastLogMsg = 'NOT LOGGED YET'
                    statusMsg = string.format("Monitoring '%s' - not in zone, watching...", targetName)
                    print(string.format("[MobMonitor] Now monitoring for '%s'.", targetName))
                end
            end
        else
            if ImGui.Button('Stop Monitoring', 150, 0) then
                monitoring = false
                statusMsg  = 'Idle - enter a name and click Start Monitoring.'
                print('[MobMonitor] Monitoring stopped.')
                ResetLive()
            end
        end

        ImGui.SameLine()
        if ImGui.Button('Clear', 80, 0) then
            inputBuffer = ''
            targetName  = ''
            monitoring  = false
            ResetLive()
            hasSpawnRecord = false
            logState   = 'none'
            lastLogMsg = 'NOT LOGGED YET'
            statusMsg = 'Idle - enter a name and click Start Monitoring.'
        end

        ImGui.Spacing()
        ImGui.PushStyleColor(ImGuiCol.Button, ImVec4(0.7, 0.15, 0.15, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonHovered, ImVec4(0.85, 0.2, 0.2, 1.0))
        ImGui.PushStyleColor(ImGuiCol.ButtonActive, ImVec4(0.6, 0.1, 0.1, 1.0))
        if ImGui.Button('Exit Script', -1, 0) then
            isOpen = false
            mq.exit()
        end
        ImGui.PopStyleColor(3)

        ImGui.Separator()
        ImGui.PushStyleColor(ImGuiCol.Text, ImVec4(1.0, 0.9, 0.2, 1.0))
        ImGui.TextWrapped('Status: ' .. statusMsg)
        ImGui.PopStyleColor()

        ImGui.PushStyleColor(ImGuiCol.Text, ImVec4(0.2, 0.9, 0.95, 1.0))
        ImGui.TextWrapped('Log file: ' .. LOG_FILE_PATH)
        ImGui.PopStyleColor()

        local logColor
        if logState == 'logged' then
            logColor = ImVec4(1.0, 0.6, 0.1, 1.0)   -- orange
        elseif logState == 'error' then
            logColor = ImVec4(1.0, 0.3, 0.3, 1.0)   -- red
        else
            logColor = ImVec4(0.3, 0.9, 0.3, 1.0)   -- green
        end
        ImGui.PushStyleColor(ImGuiCol.Text, logColor)
        ImGui.TextWrapped(lastLogMsg)
        ImGui.PopStyleColor()
        ImGui.Separator()

        if monitoring then
            if hasSpawnRecord then
                ImGui.TextColored(ImVec4(0.4, 0.8, 1.0, 1.0), 'Initial Spawn Location (logged):')
                ImGui.Text(string.format('  Time: %s', spawnedTime))
                ImGui.Text(string.format('  Zone: %s', spawnedZone))
                ImGui.Text(string.format('  Y: %.2f', spawnedY))
                ImGui.Text(string.format('  X: %.2f', spawnedX))
                ImGui.Text(string.format('  Z: %.2f', spawnedZ))
                ImGui.Spacing()
                ImGui.Separator()
                ImGui.Spacing()
            end

            if found then
                ImGui.TextColored(ImVec4(0.2, 1.0, 0.2, 1.0),
                    string.format('FOUND: %s (%s)', foundName, foundType))
                ImGui.Text(string.format('Spawn ID: %d', spawnID))
                ImGui.Spacing()
                ImGui.Text('Current Location:')
                ImGui.Text(string.format('  Y: %.2f', locY))
                ImGui.Text(string.format('  X: %.2f', locX))
                ImGui.Text(string.format('  Z: %.2f', locZ))
                ImGui.Spacing()
                ImGui.Text(string.format('Heading: %.1f', heading))
                ImGui.Text(string.format('Distance from you: %.1f', distance3D))
            else
                ImGui.TextColored(ImVec4(1.0, 0.85, 0.2, 1.0), 'Not currently in zone - watching...')
            end
        end
    end

    ImGui.End()
end

mq.imgui.init('SpawnMonitorGUI', RenderGUI)

----------------------------------------------------------------
-- Main loop
----------------------------------------------------------------
print('[MobMonitor] Script loaded. Enter a name in the window and click Start Monitoring.')
print('[MobMonitor] Spawn events will be logged to: ' .. LOG_FILE_PATH)

while isOpen do
    UpdateMonitor()
    mq.delay(250) -- scan ~4x/sec; raise this number to reduce CPU usage
end

print('[MobMonitor] Window closed - script ending.')
