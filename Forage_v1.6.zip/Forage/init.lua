--[[
================================================================================
  AutoForage  (autoforage.lua / init.lua)                      Version 1.6
  A MacroQuest Lua take on MQ2AutoForage, with an ImGui window.
================================================================================

  PURPOSE
    Automatically uses the Forage ability and decides what to do with each item
    that lands on your cursor: KEEP it (/autoinventory) or DESTROY it (/destroy),
    according to rules stored in MQ2AutoForage.ini.

  INSTALL / RUN
    Place this file as  <MacroQuest>/lua/autoforage/init.lua
    Start with:  /lua run autoforage        Stop with:  /autoforage quit
    The window title shows the script version (the VERSION constant below).

  FILES
    <MacroQuest config folder>/MQ2AutoForage.ini   rules + general settings.
    The INI is read on load, on zone change, on "Reload INI" (or /autoforage
    reload), and when you change the "Add to" scope. It is written whenever a rule
    is added/changed/removed or a setting is toggled. Comments, blank lines and
    other sections are preserved. Whenever a NEW rule is added, that rule section
    ([Global] or a zone) is re-sorted alphabetically (case-insensitive), so any
    entries that were out of order move into place at that time. [General] is
    never re-sorted.

--------------------------------------------------------------------------------
  HOW IT WORKS (main loop, runs every 250 ms)
--------------------------------------------------------------------------------
    1. If you changed zones, the INI rules are reloaded.
    2. If an item is on the cursor, the keep/destroy rules are applied to it
       (see "CURSOR HANDLING").
    3. If foraging is started and every condition below is met, the script sends
       /doability Forage and waits for the result.

  Foraging ALWAYS starts PAUSED when the script loads. Press Start in the window
  or use /autoforage start.

  Foraging is held off (the status line tells you why) when any of these apply:
    Paused | waiting for the previous forage result | not in a zone |
    no Forage skill | in combat | casting | stunned | feigning | dead | moving |
    an item is already on the cursor | spellbook, loot, trade, merchant,
    bank or give window open | Forage ability on cooldown |
    a mob in an Auto Hater extended-target slot (can be switched off with the
    "Pause while mobs are on XTarget" checkbox).
  Sitting does NOT block foraging: when everything else is ready and you are
  sitting, the script sends /stand (waiting up to 1 s) and then forages. If you
  are on a mount it is treated as standing and no /stand is sent.

--------------------------------------------------------------------------------
  CURSOR HANDLING
--------------------------------------------------------------------------------
    * A forage result is detected from the chat message "You have scrounged up".
      For FORAGE_WINDOW (15) seconds afterwards, cursor items are processed; the
      window is extended 5 s after each item so multi-item forages are caught.
    * "Only process foraged items" (checkbox, ON by default): only items that
      arrive inside that forage window are touched. Turn it OFF to apply the rules
      to ANY item that appears on your cursor, even when foraging is stopped.
    * The item must sit on the cursor for ~0.5 s before it is processed.
    * Processing is skipped while a merchant, bank, trade, give or loot window is
      open, so the script never destroys something you are handling by hand.
    * The cursor is drained item by item (up to 15 per pass), applying the rules
      to EACH item.
    * If the same item cannot be cleared after 3 attempts (e.g. inventory full),
      the script reports it and retries that item after 10 seconds.

--------------------------------------------------------------------------------
  RULES: KEEP / DESTROY
--------------------------------------------------------------------------------
    Item names are matched case-insensitively against the INI keys.

    Rules come from ONE section only, chosen with the "Add to" option
    (window radio buttons, or /autoforage scope):
      Global -> only the [Global] section is loaded and written
      Zone   -> only the section named after the zone's LONG name is loaded and
                written, e.g. [Misty Thicket] or [Plane of Knowledge]
    The other section is not used to decide keep/destroy (it is only touched when
    AutoAddAll mirrors a new rule into it, see AutoAddAll below). The script
    starts on Global. Rules reload when you change zones or change the option.

    Decision for each cursor item (first match wins):
      1. AutoKeepAll is ON            -> KEEP. NOTE: in this version AutoKeepAll
                                         overrides every rule, including DESTROY
                                         rules. Turn it OFF for rules to apply.
      2. A rule exists in the loaded section -> that rule (keep / destroy).
      3. No rule (a "new" item)       -> the "new item" default: KEEP or DESTROY
                                         (radio buttons / /autoforage default).
                                         It ALWAYS starts as KEEP when the
                                         script loads; any Default= line in the
                                         INI is recognised but ignored.

    Accepted rule values in the INI:
      keep    : keep, 1, true, yes, on
      destroy : destroy, delete, 0, false, no, off
    Lines whose value is not one of these are not treated as rules.

--------------------------------------------------------------------------------
  INI FORMAT
--------------------------------------------------------------------------------
    [General]                     (a [Settings] section or any section holding
    AutoAddAll=on                  the known keys is also accepted)
    AutoKeepAll=off
    ForageOn=on                   <- ignored entirely by this script

    [Global]
    Roots=keep
    Fruit=destroy

    [Misty Thicket]               <- zone LONG name (what /echo ${Zone.Name} shows)
    Vegetables=destroy

    General settings (booleans; on/off, yes/no, true/false or 1/0 -- the style
    already used in your INI is preserved when the script rewrites a value):
      AutoAddAll   When ON, every item that has no rule in the selected
                   "Add to" section gets a rule written to the INI using the
                   "New items" KEEP/DESTROY default. The rule is written to BOTH
                   [Global] and the current zone's section (each kept in
                   alphabetical order). If the section you are NOT using already
                   has an entry for the item, that entry is updated to match the
                   new rule. Rules you add or change by hand (buttons, commands)
                   only affect the selected section.
      AutoKeepAll  When ON, everything is kept (see decision order above).
      ForageOn     Ignored.
    Keys named Enabled/Enable/On/Active/AutoForage, Default/DefaultAction/
    Unlisted/Unknown/DefaultItem, and the general keys above are never treated
    as item rules, even if found inside [Global] or a zone section.

--------------------------------------------------------------------------------
  WINDOW (title: "AutoForage v<version>")
--------------------------------------------------------------------------------
    Top (always visible)
               Start / Stop foraging and Exit (quits the script); Status line
               (why it is or isn't foraging); "Next forage" timer; AutoAddAll and
               AutoKeepAll ON/OFF buttons; "New items (no rule)" Keep/Destroy
               default; the "Pause while mobs are on XTarget" and "Only process
               foraged items" checkboxes.
    Activity   Statistics (forage attempts, found, misses, kept, destroyed).
               "In inventory" list: directly below the Kept / Destroyed line, a
               table of every item that has a KEEP rule in the rules section in
               use (Global or Zone, chosen with "Add to"), with the number of
               that item currently in your inventory. Items with a DESTROY rule
               are not listed. Counts are exact-name matches, add up stacks, cover
               bags and worn slots only (the bank is NOT counted) and refresh
               about once a second. A count of 0 is shown in grey. The list
               follows the "Add to" selection and the current zone.
               Then "Reset stats" and "Clear log" buttons and a scrolling
               colour-coded log: green = kept, red = destroyed.
    Rules      Current zone and number of rules loaded; "Add to" Global/Zone
               selector; a box to add a Keep or Destroy rule for a typed item
               name (the "Use cursor item" button fills it from your cursor);
               a Filter box; a table of the loaded rules with a Keep/Destroy
               toggle and an X to remove.
    Bottom     "Reload INI" button and a "Sections:" line showing which INI
               sections are loaded.

--------------------------------------------------------------------------------
  COMMANDS
--------------------------------------------------------------------------------
    /autoforage                       show one-line status
    /autoforage show | hide | gui     show / hide / toggle the window
    /autoforage start                 start foraging        (also: on)
    /autoforage stop                  stop foraging         (also: off, pause)
    /autoforage toggle                start/stop foraging
    /autoforage scope global|zone     choose the section that is loaded/written
                                      (same as the "Add to" option)
    /autoforage keep <item>           always keep this item    (selected section)
    /autoforage destroy <item>        always destroy this item (selected section)
    /autoforage remove <item>         delete the item's rule   (selected section)
    /autoforage default keep|destroy  action for NEW items that have no rule yet
    /autoforage list                  print the active rules in chat
    /autoforage reload                re-read the INI
    /autoforage dump                  show how the INI was parsed (troubleshooting)
    /autoforage quit                  stop the script         (also: exit)

--------------------------------------------------------------------------------
  TROUBLESHOOTING
--------------------------------------------------------------------------------
    * An item is kept although its rule says destroy:
        - AutoKeepAll is ON (it overrides rules in this version), or
        - the rule is in a section that is not selected: check the "Add to"
          selector -- a zone rule is only used when "Zone" is selected, and the
          section name must match the zone LONG name exactly (case-insensitive).
        - Use /autoforage dump to see the zone name and the sections loaded.
    * Nothing happens: foraging starts paused -- press Start. Check the status
      line for the blocking condition.
    * Status "Could not stand up": /stand did not take effect within 1 s (e.g.
      you are rooted/stunned or something is forcing you to sit); it retries.
    * A rule appeared in both [Global] and the zone section: that is AutoAddAll
      (the activity log marks the second write "(mirrored)").
    * Entries moved around in the INI: rule sections are re-sorted when a new
      rule is added (see FILES).
    * An item is missing from the "In inventory" list: only KEEP rules in the
      selected "Add to" section are listed (check the Global/Zone selection).
    * An "In inventory" count looks too low: the bank is not counted, and the
      item name in the rule must match the real item name exactly (case-insensitive).
    * "Cannot write MQ2AutoForage.ini": the config folder is not writable.
    * "INI not found": the file is created the first time a rule is added.

--------------------------------------------------------------------------------
  CHANGE LOG
--------------------------------------------------------------------------------
    1.6   Activity tab: new "In inventory" list under Kept / Destroyed showing, for each item
          that has a KEEP rule in the rules section in use (Global or Zone), how many you
          currently carry (exact name, stack-aware, bags only, refreshed ~1 s). Destroy-rule
          items are not listed. Header documentation and troubleshooting notes updated.
    1.5   Documentation update: corrected layout, sorting, AutoAddAll and standing notes.
    1.4   Stands up before foraging if sitting (a mounted character counts as standing).
    1.3   AutoAddAll writes a new rule to both [Global] and the zone section; an existing
          entry in the section not in use is updated to match.
    1.2   New rules are written into [Global] / the zone section in alphabetical order
          (the whole section is kept sorted, case-insensitive).
    1.1   Removed the "Foraged this session" list from the Rules tab.
    1.0   Version number added to the window title; full header documentation.
================================================================================
]]

local mq = require('mq')

local VERSION = '1.6'   -- bump this (and the header + change log) when you change the script

local iniPath = mq.configDir .. '/MQ2AutoForage.ini'

-- rules.global / rules.zone: [lowername] = { action = 'keep'|'destroy', display = 'Name' }
local config = { enabled = true, global = {}, zone = {} }
local secNames = { global = 'Global', zone = nil }   -- actual INI section names to write to
local general = { section = 'General', found = false, full = false, entries = {} }  -- entries: { key=, value= }
local running = true   -- script main loop
local paused = true    -- foraging starts paused every time the script loads
local checkXTarget = true  -- hold off while an Auto Hater extended target slot holds a mob
local forage = { pending = false, windowEnd = 0 }  -- a forage attempt whose result we are waiting to process
local FORAGE_WINDOW = 15   -- seconds a forage result may take to land on the cursor
local newItemAction = 'keep'  -- KEEP/DESTROY for new items (no rule); always starts as KEEP on load
local onlyForaged = true   -- true (default): only apply the rules to forage results; false: ANY item on the cursor
local cursorTicks = 0      -- consecutive loops the same cursor item has been seen (settle time)
local retryName, retryAt = nil, 0   -- item we failed to clear, and when to try again

-- GUI / runtime state
local showGUI = true
local state = { reason = 'Starting...', ok = false, zoneShort = '', zoneLong = '', loaded = {} }
local stats = { attempts = 0, found = 0, kept = 0, destroyed = 0, misses = 0 }
local log = {}             -- { time =, text =, kind = }
local ui = { newItem = '', filter = '', scope = 'global' }

---------------------------------------------------------------------
-- Logging
---------------------------------------------------------------------
local function say(fmt, ...) printf('\ag[AutoForage]\ax ' .. fmt, ...) end

local function addLog(text, kind)
    table.insert(log, 1, { time = os.date('%H:%M:%S'), text = text, kind = kind or 'info' })
    while #log > 100 do table.remove(log) end
end

---------------------------------------------------------------------
-- INI helpers
---------------------------------------------------------------------
local function trim(s) return (s:gsub('^%s+', ''):gsub('%s+$', '')) end

local function readLines()
    local lines = {}
    local f = io.open(iniPath, 'r')
    if not f then return lines end
    for line in f:lines() do lines[#lines + 1] = (line:gsub('\r$', '')) end
    f:close()
    return lines
end

local function writeLines(lines)
    local f, err = io.open(iniPath, 'w')
    if not f then printf('\ar[AutoForage]\ax Cannot write %s: %s', iniPath, tostring(err)); return false end
    f:write(table.concat(lines, '\n'), '\n')
    f:close()
    return true
end

local function parseKV(line)
    if line:match('^%s*[;#]') then return nil end
    local k, v = line:match('^%s*([^=]-)%s*=%s*(.-)%s*$')
    if k and k ~= '' then return k, v end
end

local function parseSection(line)
    local s = line:match('^%s*%[(.-)%]%s*$')
    return s and trim(s) or nil
end

-- set (or delete when value == nil) key in section, preserving everything else
local function iniSet(section, key, value, sortKeys)
    local lines = readLines()
    local curSec, secStart, secEnd
    for i, line in ipairs(lines) do
        local s = parseSection(line)
        if s then
            if secStart and not secEnd then secEnd = i - 1 end
            curSec = s
            if s:lower() == section:lower() then secStart = i; secEnd = nil end
        elseif curSec and curSec:lower() == section:lower() then
            local k = parseKV(line)
            if k and k:lower() == key:lower() then
                if value == nil then table.remove(lines, i) else lines[i] = key .. '=' .. value end
                return writeLines(lines)
            end
        end
    end
    if value == nil then return true end
    if secStart then
        secEnd = secEnd or #lines
        while secEnd > secStart and trim(lines[secEnd]) == '' do secEnd = secEnd - 1 end
        table.insert(lines, secEnd + 1, key .. '=' .. value)
        if sortKeys then
            -- keep the rules alphabetical: put the new entry in, then sort every key=value line of the
            -- section (case-insensitive) within the same line slots, so comments/blank lines stay where they are
            local slots, kvs = {}, {}
            for i = secStart + 1, secEnd + 1 do
                local k = parseKV(lines[i])
                if k then
                    slots[#slots + 1] = i
                    kvs[#kvs + 1] = { line = lines[i], lk = k:lower(), n = #kvs + 1 }
                end
            end
            table.sort(kvs, function(x, y)
                if x.lk ~= y.lk then return x.lk < y.lk end
                return x.n < y.n
            end)
            for j, slot in ipairs(slots) do lines[slot] = kvs[j].line end
        end
    else
        if #lines > 0 and trim(lines[#lines]) ~= '' then lines[#lines + 1] = '' end
        lines[#lines + 1] = '[' .. section .. ']'
        lines[#lines + 1] = key .. '=' .. value
    end
    return writeLines(lines)
end

---------------------------------------------------------------------
-- Interpreting the INI (only [Global] + current zone)
---------------------------------------------------------------------
local ENABLE_KEYS  = { enabled = true, enable = true, on = true, active = true, autoforage = true }
local DEFAULT_KEYS = { default = true, defaultaction = true, unlisted = true, unknown = true, defaultitem = true }

local function toAction(v)
    v = (v or ''):lower()
    if v == 'keep' or v == '1' or v == 'true' or v == 'yes' or v == 'on' then return 'keep' end
    if v == 'destroy' or v == 'delete' or v == '0' or v == 'false' or v == 'no' or v == 'off' then return 'destroy' end
end

local function currentZone()
    local short = mq.TLO.Zone.ShortName()
    local long  = mq.TLO.Zone.Name()
    if short == 'NULL' then short = nil end
    if long == 'NULL' then long = nil end
    return short, long
end

-- settings the script knows about (never treated as item rules). ForageON is ignored entirely.
local KNOWN_SETTINGS = { autoaddall = true, autokeepall = true, forageon = true }

local BOOL_WORDS = { ['1'] = true, ['0'] = false, ['true'] = true, ['false'] = false,
                     ['yes'] = true, ['no'] = false, ['on'] = true, ['off'] = false }

local function isBoolValue(v) return BOOL_WORDS[(v or ''):lower()] ~= nil end
local function toBool(v) return BOOL_WORDS[(v or ''):lower()] == true end

local function loadGeneral(lines)
    general = { section = 'General', found = false, full = false, entries = {} }
    local secs, cur, firstKnown = {}, nil, nil
    for _, line in ipairs(lines) do
        local sname = parseSection(line)
        if sname then
            cur = { name = sname, kvs = {} }
            secs[#secs + 1] = cur
        elseif cur then
            local k, v = parseKV(line)
            if k then
                table.insert(cur.kvs, { k, v })
                if KNOWN_SETTINGS[k:lower()] and not firstKnown then firstKnown = cur end
            end
        end
    end
    local pick
    for _, want in ipairs({ 'general', 'settings' }) do
        for _, sec in ipairs(secs) do
            if sec.name:lower() == want then pick = sec; break end
        end
        if pick then general.full = true; break end
    end
    pick = pick or firstKnown     -- fall back to wherever the known keys live
    if not pick then return end
    general.section, general.found = pick.name, true
    for _, kv in ipairs(pick.kvs) do
        local lk = kv[1]:lower()
        if lk ~= 'forageon' and (general.full or KNOWN_SETTINGS[lk]) then
            table.insert(general.entries, { key = kv[1], value = kv[2] })
        end
    end
end

local function findGeneral(name)
    for _, e in ipairs(general.entries) do
        if e.key:lower() == name:lower() then return e end
    end
end

local function generalOn(name)
    local e = findGeneral(name)
    return e ~= nil and toBool(e.value)
end

local function fmtBoolLike(sample, on)
    local sl = (sample or ''):lower()
    if sl == 'true' or sl == 'false' then return on and 'true' or 'false' end
    if sl == 'yes' or sl == 'no' then return on and 'yes' or 'no' end
    if sl == 'on' or sl == 'off' then return on and 'on' or 'off' end
    return on and '1' or '0'
end

local function setGeneral(name, on)
    local e = findGeneral(name)
    local sample = e and e.value
    if not sample then
        for _, x in ipairs(general.entries) do
            if isBoolValue(x.value) then sample = x.value; break end
        end
    end
    local val = fmtBoolLike(sample, on)
    local key = e and e.key or name
    if e then e.value = val else table.insert(general.entries, { key = key, value = val }) end
    general.found = true
    iniSet(general.section, key, val)
    addLog(('Setting %s = %s'):format(key, on and 'ON' or 'OFF'))
end

local function loadConfig()
    config = { enabled = true, global = {}, zone = {} }
    local short, long = currentZone()
    state.zoneShort, state.zoneLong = short or '', long or ''
    state.loaded = {}
    secNames = { global = 'Global', zone = (long and long ~= '') and long or nil }

    local lines = readLines()
    loadGeneral(lines)
    if #lines == 0 then return false end

    local entries = { global = {}, zone = {} }
    local which = nil

    for _, line in ipairs(lines) do
        local s = parseSection(line)
        if s then
            local ls = s:lower()
            if ls == 'global' then
                which = 'global'; secNames.global = s
                if ui.scope == 'global' then table.insert(state.loaded, s) end
            elseif long and ls == long:lower() then
                which = 'zone'; secNames.zone = s     -- zone sections are always the zone LONG name
                if ui.scope == 'zone' then table.insert(state.loaded, s) end
            else
                which = nil
            end
        elseif which then
            local k, v = parseKV(line)
            if k then table.insert(entries[which], { k, v }) end
        end
    end

    -- only the section selected in "Add to" is loaded; the other is ignored
    for _, scope in ipairs({ ui.scope }) do
        for _, kv in ipairs(entries[scope]) do
            local k, v = kv[1], kv[2]
            local lk = k:lower()
            local act = toAction(v)
            if KNOWN_SETTINGS[lk] then
                -- general setting that happens to sit in a rules section: never an item rule
            elseif ENABLE_KEYS[lk] and act then
                -- INI Enabled key is recognised (so it isn't treated as an item) but ignored: the script always starts paused
            elseif DEFAULT_KEYS[lk] and act then
                -- a Default= line is recognised (so it isn't an item rule) but ignored: the KEEP/DESTROY
                -- option always starts as KEEP when the script loads
            elseif act then
                config[scope][lk] = { action = act, display = k }
            end
        end
    end

    if general.found then
        local dup = false
        for _, n in ipairs(state.loaded) do
            if n:lower() == general.section:lower() then dup = true end
        end
        if not dup then table.insert(state.loaded, general.section) end
    end
    return true
end

local function findRule(lkey)
    return config.zone[lkey] or config.global[lkey]
end

---------------------------------------------------------------------
-- Config mutators (used by both chat commands and the GUI)
---------------------------------------------------------------------
local function setPaused(v)
    paused = v
    addLog(v and 'Foraging stopped' or 'Foraging started')
end

local function setRule(name, action, scope)
    name = trim(name or '')
    if name == '' then return end
    scope = scope or 'zone'
    local section = secNames[scope]
    if not section then
        say('\arNo zone detected, cannot write a zone rule.')
        return
    end
    local lkey = name:lower()
    local old = config[scope][lkey]
    local keyName = old and old.display or name
    config[scope][lkey] = { action = action, display = keyName }
    iniSet(section, keyName, action, true)   -- true: keep the section alphabetical
    addLog(('Rule [%s]: %s -> %s'):format(section, keyName, action))
end

-- Writes the rule to the selected section (via setRule) AND to the opposite section (Global <-> current zone).
-- If the opposite section already has an entry for the item it is updated to the same action,
-- otherwise the entry is added (alphabetically). The opposite section is only written to the INI:
-- it is not loaded in memory, because only the "Add to" section is ever loaded.
local function setRuleBoth(name, action, scope)
    setRule(name, action, scope)
    local other = scope == 'global' and 'zone' or 'global'
    local section = secNames[other]
    if not section then return end          -- no zone detected: nothing to mirror to
    name = trim(name or '')
    local lkey = name:lower()
    local old = config[scope][lkey]
    iniSet(section, old and old.display or name, action, true)
    addLog(('Rule [%s]: %s -> %s (mirrored)'):format(section, old and old.display or name, action))
end

local function removeRule(lkey, scope)
    local old = config[scope][lkey]
    if not old then return false end
    config[scope][lkey] = nil
    if secNames[scope] then iniSet(secNames[scope], old.display, nil) end
    addLog(('Removed rule [%s]: %s'):format(secNames[scope] or scope, old.display))
    return true
end

local function setDefault(action)
    newItemAction = action   -- session setting only, not written to the INI
    addLog('Default action for unlisted items: ' .. action)
end

---------------------------------------------------------------------
-- Forage logic
---------------------------------------------------------------------
-- seconds until the Forage ability is ready again (0 when ready)
local function forageSecondsLeft()
    local me = mq.TLO.Me
    if me.AbilityReady('Forage')() then return 0 end
    local t = me.AbilityTimer('Forage')
    if not t then return 0 end
    local secs = t.TotalSeconds()
    if secs == nil then
        local v = t.Value()          -- fallback: milliseconds
        secs = v and (v / 1000) or 0
    end
    return secs
end

local function fmtTime(secs)
    secs = math.ceil(secs)
    if secs >= 60 then return ('%d:%02d'):format(math.floor(secs / 60), secs % 60) end
    return ('%ds'):format(secs)
end

local function checkForage()
    local me = mq.TLO.Me
    if paused then return false, 'Paused' end
    if forage.pending then return false, 'Waiting for forage result' end
    if mq.TLO.Zone.ID() == nil then return false, 'Not in a zone' end
    if (me.Skill('Forage')() or 0) == 0 then return false, 'No Forage skill' end
    if me.Combat() or me.CombatState() == 'COMBAT' then return false, 'In combat' end
    if me.Casting.ID() then return false, 'Casting' end
    if me.Stunned() then return false, 'Stunned' end
    if me.Feigning() then return false, 'Feigning' end
    if me.Dead() then return false, 'Dead' end
    if me.Moving() then return false, 'Moving' end
    if mq.TLO.Cursor.ID() then return false, 'Item on cursor' end
    for _, w in ipairs({ 'SpellBookWnd', 'LootWnd', 'TradeWnd', 'MerchantWnd', 'BigBankWnd', 'GiveWnd' }) do
        if mq.TLO.Window(w).Open() then return false, 'Window open: ' .. w end
    end
    if checkXTarget then
        -- an empty slot has ID 0 (truthy in Lua), so require a real spawn ID in an Auto Hater slot
        local slots = me.XTargetSlots() or 13
        for i = 1, slots do
            local xt = me.XTarget(i)
            if xt and (xt.ID() or 0) > 0 and xt.TargetType() == 'Auto Hater' and xt.Type() ~= 'Corpse' then
                return false, 'Aggro on XTarget: ' .. (xt.CleanName() or '?')
            end
        end
    end
    if not me.AbilityReady('Forage')() then
        return false, 'Forage on cooldown (' .. fmtTime(forageSecondsLeft()) .. ')'
    end
    -- Everything else is OK and a forage is about to be attempted: if sitting, stand up first.
    -- Sitting on a mount counts as standing, so a mounted character is left alone.
    if me.Sitting() and (me.Mount.ID() or 0) == 0 then
        mq.cmd('/stand')
        mq.delay(1000, function() return not mq.TLO.Me.Sitting() end)
        if mq.TLO.Me.Sitting() then return false, 'Could not stand up' end
        addLog('Stood up to forage')
    end
    return true, 'Ready'
end

-- Applies the rules to the item currently on the cursor and sends the keep/destroy command.
-- first = false for repeat attempts on an identical item (no extra stats or log).
local function applyRules(first, name)
    name = name or mq.TLO.Cursor.Name() or ''
    if name == '' then return end
    local lkey = name:lower()
    local rule = findRule(lkey)
    local keepAll = generalOn('AutoKeepAll')

    -- AutoKeepAll ignores all rules and keeps everything.
    -- Otherwise an existing rule decides; the KEEP/DESTROY default only applies to NEW items (no rule).
    local action, source
    if keepAll then
        action, source = 'keep', 'AutoKeepAll'
    elseif rule then
        action = rule.action
        source = config.zone[lkey] and 'zone rule' or 'global rule'
    else
        action, source = newItemAction, 'new item, default ' .. newItemAction
    end

    -- AutoAddAll: for an item with no rule in the section chosen in "Add to" (Global or Zone), write the
    -- rule to BOTH [Global] and the current zone's section. An entry that already exists in the other
    -- section is updated to match the new rule. The action is the KEEP/DESTROY default for new items.
    if generalOn('AutoAddAll') then
        local scope = ui.scope
        if not config[scope][lkey] and (scope == 'global' or secNames.zone) then
            local value = rule and rule.action or newItemAction
            setRuleBoth(name, value, scope)
            source = source .. (', rule added to %s: %s'):format(secNames.zone and 'Global + Zone' or 'Global', value)
        end
    end

    if first then
        stats.found = stats.found + 1
        if action == 'destroy' then
            stats.destroyed = stats.destroyed + 1
            say('Destroying \ar%s\ax (%s)', name, source)
            addLog(('Destroyed %s (%s)'):format(name, source), 'destroy')
        else
            stats.kept = stats.kept + 1
            say('Keeping \ag%s\ax (%s)', name, source)
            addLog(('Kept %s (%s)'):format(name, source), 'keep')
        end
    end

    mq.cmd(action == 'destroy' and '/destroy' or '/autoinventory')
end

-- Drains the cursor: handles the item on it, then keeps going for as long as another item
-- (a second foraged item / queued cursor item) turns up, applying the rules to EACH one.
local function handleCursor()
    local prevId, prevName, runs = nil, nil, 0
    for _ = 1, 15 do
        local id = mq.TLO.Cursor.ID()
        if not id then
            -- cursor is empty: give a further foraged item a moment to arrive
            mq.delay(800, function() return mq.TLO.Cursor.ID() ~= nil end)
            id = mq.TLO.Cursor.ID()
            if not id then retryName = nil; return end
        end

        -- the same item ID several times in a row is either duplicates or a stuck item
        local name = mq.TLO.Cursor.Name() or ''
        if id == prevId and name == prevName then runs = runs + 1 else runs = 1 end
        prevId, prevName = id, name

        if runs > 3 then
            say('\ayCould not clear %s from the cursor (inventory full?) - will retry in 10s', name)
            addLog('Could not clear ' .. name .. ' from cursor (inventory full?)')
            retryName, retryAt = name, os.time() + 10
            return
        end

        applyRules(runs == 1 and name ~= retryName, name)
        -- wait until this item is gone: cursor empty, or a different item in its place
        mq.delay(1500, function()
            local c = mq.TLO.Cursor.ID()
            return c == nil or c ~= id or (mq.TLO.Cursor.Name() or '') ~= name
        end)
    end
end

local HANDS_ON_WINDOWS = { 'MerchantWnd', 'BigBankWnd', 'TradeWnd', 'GiveWnd', 'LootWnd' }

-- Called every loop: ANY item on the cursor gets the keep/destroy rules applied,
-- whether or not foraging is started. Skipped only while you are dealing with a
-- merchant, bank, trade, give or loot window, or when "only foraged items" is on.
local function processCursor()
    if not mq.TLO.Cursor.ID() then
        cursorTicks = 0
        retryName = nil
        return
    end
    cursorTicks = cursorTicks + 1
    if cursorTicks < 2 then return end                       -- let the item settle (~0.5s)
    if retryName and mq.TLO.Cursor.Name() == retryName and os.time() < retryAt then return end  -- that item failed to clear recently
    if onlyForaged and os.time() > forage.windowEnd then return end   -- not a forage result
    for _, w in ipairs(HANDS_ON_WINDOWS) do
        if mq.TLO.Window(w).Open() then return end
    end
    forage.pending = false
    handleCursor()
    -- a forage can yield more than one item: keep accepting results for a few more seconds
    forage.windowEnd = math.max(forage.windowEnd, os.time() + 5)
end

-- Forage attempt that never produced an item
local function processForageResult()
    if forage.pending and not mq.TLO.Cursor.ID() and os.time() > forage.windowEnd then
        forage.pending = false
        stats.misses = stats.misses + 1
        addLog('Forage found nothing')
    end
end

---------------------------------------------------------------------
-- ImGui
---------------------------------------------------------------------
local GREEN  = { 0.4, 1.0, 0.4, 1.0 }
local RED    = { 1.0, 0.4, 0.4, 1.0 }
local YELLOW = { 1.0, 0.85, 0.3, 1.0 }
local GREY   = { 0.7, 0.7, 0.7, 1.0 }

local function colored(c, text) ImGui.TextColored(c[1], c[2], c[3], c[4], text) end

local function countRules()
    local g, z = 0, 0
    for _ in pairs(config.global) do g = g + 1 end
    for _ in pairs(config.zone) do z = z + 1 end
    return g, z
end

-- combined, sorted list of { key=, scope=, rule= }
local function ruleRows()
    local rows = {}
    for k, r in pairs(config.zone) do rows[#rows + 1] = { key = k, scope = 'zone', rule = r } end
    for k, r in pairs(config.global) do rows[#rows + 1] = { key = k, scope = 'global', rule = r } end
    table.sort(rows, function(a, b)
        if a.key ~= b.key then return a.key < b.key end
        return a.scope < b.scope
    end)
    return rows
end

local function pushButtonColors(r, g, b)
    ImGui.PushStyleColor(ImGuiCol.Button, r, g, b, 1.0)
    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, math.min(r + 0.1, 1.0), math.min(g + 0.1, 1.0), math.min(b + 0.1, 1.0), 1.0)
    ImGui.PushStyleColor(ImGuiCol.ButtonActive, math.max(r - 0.1, 0.0), math.max(g - 0.1, 0.0), math.max(b - 0.1, 0.0), 1.0)
    ImGui.PushStyleColor(ImGuiCol.Text, 0.0, 0.0, 0.0, 1.0)
end

local function popButtonColors() ImGui.PopStyleColor(4) end

-- ON/OFF status button for a general setting; click to toggle (writes to the INI)
local function settingButton(name)
    local on = generalOn(name)
    if on then pushButtonColors(0.30, 0.80, 0.30) else pushButtonColors(0.80, 0.30, 0.30) end
    if ImGui.Button((on and 'ON' or 'OFF') .. '##' .. name, 50, 0) then setGeneral(name, not on) end
    popButtonColors()
end

local function drawHeader()
    if paused then
        pushButtonColors(0.30, 0.80, 0.30)
        if ImGui.Button('Start', 70, 0) then setPaused(false) end
        popButtonColors()
    else
        pushButtonColors(0.95, 0.70, 0.20)
        if ImGui.Button('Stop', 70, 0) then setPaused(true) end
        popButtonColors()
    end

    ImGui.SameLine()
    pushButtonColors(0.85, 0.10, 0.10)   -- red background, black text
    if ImGui.Button('Exit', 70, 0) then running = false end
    popButtonColors()

    ImGui.SameLine()
    ImGui.Text('Status:')
    ImGui.SameLine()
    local c = YELLOW
    if state.ok then c = GREEN end
    colored(c, state.reason)

    ImGui.Text('Next forage:')
    ImGui.SameLine()
    if paused then
        colored(GREY, '(stopped)')
    else
        local left = forageSecondsLeft()
        if left > 0 then colored(YELLOW, fmtTime(left)) else colored(GREEN, 'Ready') end
    end
    ImGui.Separator()

    ImGui.Text('AutoAddAll:')
    ImGui.SameLine()
    settingButton('AutoAddAll')
    ImGui.SameLine()
    ImGui.Text('   AutoKeepAll:')
    ImGui.SameLine()
    settingButton('AutoKeepAll')

    ImGui.Text('New items (no rule):')
    ImGui.SameLine()
    if ImGui.RadioButton('Keep##def', newItemAction == 'keep') then setDefault('keep') end
    ImGui.SameLine()
    if ImGui.RadioButton('Destroy##def', newItemAction == 'destroy') then setDefault('destroy') end

    local xtVal, xtPressed = ImGui.Checkbox('Pause while mobs are on XTarget (Auto Hater)', checkXTarget)
    if xtPressed then checkXTarget = xtVal end

    local ofVal, ofPressed = ImGui.Checkbox('Only process foraged items (otherwise ANY cursor item)', onlyForaged)
    if ofPressed then onlyForaged = ofVal end
    ImGui.Separator()
end

-- Number of an item currently in your inventory (bags + worn, stack-aware; bank is not counted).
-- Counts are cached and refreshed about once a second so the window doesn't query MQ every frame.
local invCache = { at = 0, counts = {} }

local function inventoryCount(lkey, name)
    local now = os.clock()
    if now - invCache.at >= 1 then
        invCache = { at = now, counts = {} }
    end
    local n = invCache.counts[lkey]
    if n == nil then
        -- '=' makes FindItemCount match the exact item name instead of a partial name
        n = mq.TLO.FindItemCount('=' .. name)() or 0
        invCache.counts[lkey] = n
    end
    return n
end

local function drawActivity()
    ImGui.Text(('Forage attempts: %d'):format(stats.attempts))
    ImGui.SameLine()
    ImGui.Text(('   Found: %d   Misses: %d'):format(stats.found, stats.misses))
    ImGui.Text('Kept: ')
    ImGui.SameLine(); colored(GREEN, tostring(stats.kept))
    ImGui.SameLine(); ImGui.Text('   Destroyed: ')
    ImGui.SameLine(); colored(RED, tostring(stats.destroyed))

    -- items from the rules section in use (Global or Zone) and how many are in your inventory right now
    ImGui.Separator()
    ImGui.Text(('In inventory (%s rules)'):format(ui.scope == 'global' and 'Global' or 'Zone'))
    local invRows = {}
    for lkey, r in pairs(config[ui.scope]) do
        if r.action == 'keep' then invRows[#invRows + 1] = { lkey = lkey, rule = r } end
    end
    table.sort(invRows, function(a, b) return a.lkey < b.lkey end)
    if #invRows == 0 then
        colored(GREY, '(no keep rules in this section)')
    elseif ImGui.BeginTable('afInv', 2, ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.ScrollY, 0, 130) then
        ImGui.TableSetupColumn('Item', ImGuiTableColumnFlags.WidthStretch)
        ImGui.TableSetupColumn('Count', ImGuiTableColumnFlags.WidthFixed, 55)
        ImGui.TableHeadersRow()
        for _, row in ipairs(invRows) do
            local n = inventoryCount(row.lkey, row.rule.display)
            ImGui.TableNextRow()
            ImGui.TableNextColumn()
            ImGui.Text(row.rule.display)
            ImGui.TableNextColumn()
            if n > 0 then colored(GREEN, tostring(n)) else colored(GREY, '0') end
        end
        ImGui.EndTable()
    end
    ImGui.Separator()

    if ImGui.Button('Reset stats') then
        stats = { attempts = 0, found = 0, kept = 0, destroyed = 0, misses = 0 }
    end
    ImGui.SameLine()
    if ImGui.Button('Clear log') then log = {} end

    ImGui.Separator()
    ImGui.Text('Recent activity')
    if #log == 0 then colored(GREY, '(nothing yet)') end
    for i = 1, math.min(#log, 15) do
        local e = log[i]
        local c = GREY
        if e.kind == 'keep' then c = GREEN elseif e.kind == 'destroy' then c = RED end
        colored(c, ('[%s] %s'):format(e.time, e.text))
    end
end

local function drawRules()
    local g, z = countRules()
    ImGui.Text('Zone: ')
    ImGui.SameLine()
    colored(YELLOW, state.zoneLong ~= '' and state.zoneLong or '(unknown)')
    ImGui.SameLine()
    colored(GREY, ('  %s rules loaded: %d'):format(ui.scope == 'global' and 'Global' or 'Zone', ui.scope == 'global' and g or z))

    -- scope for new rules
    ImGui.Text('Add to:')
    ImGui.SameLine()
    if ImGui.RadioButton('Global##scope', ui.scope == 'global') and ui.scope ~= 'global' then
        ui.scope = 'global'; loadConfig(); addLog('Using the [Global] section only')
    end
    ImGui.SameLine()
    if ImGui.RadioButton('Zone##scope', ui.scope == 'zone') and ui.scope ~= 'zone' then
        ui.scope = 'zone'; loadConfig(); addLog('Using the zone section only')
    end
    ImGui.SameLine()
    colored(GREY, '(only this section is loaded and written)')

    ui.newItem = ImGui.InputText('##newitem', ui.newItem)
    ImGui.SameLine()
    if ImGui.Button('Keep##add') then setRule(ui.newItem, 'keep', ui.scope); ui.newItem = '' end
    ImGui.SameLine()
    if ImGui.Button('Destroy##add') then setRule(ui.newItem, 'destroy', ui.scope); ui.newItem = '' end

    local cursorName = mq.TLO.Cursor.Name()
    if cursorName then
        if ImGui.SmallButton('Use cursor item: ' .. cursorName) then ui.newItem = cursorName end
    end

    ImGui.Separator()
    ImGui.Text('Filter:')
    ImGui.SameLine()
    ui.filter = ImGui.InputText('##filter', ui.filter)

    local flags = ImGuiTableFlags.RowBg + ImGuiTableFlags.Borders + ImGuiTableFlags.ScrollY
    if ImGui.BeginTable('afRules', 4, flags, 0, 200) then
        ImGui.TableSetupColumn('Item', ImGuiTableColumnFlags.WidthStretch)
        ImGui.TableSetupColumn('Scope', ImGuiTableColumnFlags.WidthFixed, 55)
        ImGui.TableSetupColumn('Action', ImGuiTableColumnFlags.WidthFixed, 80)
        ImGui.TableSetupColumn('', ImGuiTableColumnFlags.WidthFixed, 30)
        ImGui.TableHeadersRow()

        local f = ui.filter:lower()
        for _, row in ipairs(ruleRows()) do
            local r, key, scope = row.rule, row.key, row.scope
            if f == '' or key:find(f, 1, true) then
                local id = key .. scope
                ImGui.TableNextRow()
                ImGui.TableNextColumn()
                ImGui.Text(r.display)
                ImGui.TableNextColumn()
                colored(scope == 'zone' and YELLOW or GREY, scope == 'zone' and 'Zone' or 'Global')
                ImGui.TableNextColumn()
                if r.action == 'keep' then
                    if ImGui.SmallButton('Keep##' .. id) then setRule(r.display, 'destroy', scope) end
                else
                    if ImGui.SmallButton('Destroy##' .. id) then setRule(r.display, 'keep', scope) end
                end
                ImGui.TableNextColumn()
                if ImGui.SmallButton('X##' .. id) then removeRule(key, scope) end
            end
        end
        ImGui.EndTable()
    end

    ImGui.Separator()
    if ImGui.Button('Reload INI') then loadConfig(); addLog('Reloaded INI') end
    ImGui.SameLine()
    colored(GREY, 'Sections: ' .. (#state.loaded > 0 and table.concat(state.loaded, ', ') or '(none found)'))
end

local function drawGUI()
    if not showGUI then return end
    ImGui.SetNextWindowSize(500, 480, ImGuiCond.FirstUseEver)
    local open, draw = ImGui.Begin(('AutoForage v%s##autoforage'):format(VERSION), showGUI)
    showGUI = open
    if draw then
        drawHeader()
        if ImGui.BeginTabBar('afTabs') then
            if ImGui.BeginTabItem('Activity') then
                drawActivity()
                ImGui.EndTabItem()
            end
            if ImGui.BeginTabItem('Rules') then
                drawRules()
                ImGui.EndTabItem()
            end
            ImGui.EndTabBar()
        end
    end
    ImGui.End()
end

---------------------------------------------------------------------
-- Chat commands
---------------------------------------------------------------------
local function listRules()
    say('Zone: %s | default action: %s', state.zoneLong, newItemAction)
    for _, row in ipairs(ruleRows()) do
        local r = row.rule
        printf('   %s%s\ax = %s (%s)', r.action == 'keep' and '\ag' or '\ar', r.display, r.action, row.scope)
    end
end

local function dump()
    say('INI: %s', iniPath)
    if #readLines() == 0 then say('File not found or empty.'); return end
    local g, z = countRules()
    say('Zone: %s (short name: %s)', state.zoneLong, state.zoneShort)
    say('Sections loaded: %s', #state.loaded > 0 and table.concat(state.loaded, ', ') or '(none)')
    say('Using the %s section only | rules loaded: %d | default=%s', ui.scope, ui.scope == 'global' and g or z, newItemAction)
    say('General settings: [%s] AutoAddAll=%s AutoKeepAll=%s', general.section, tostring(generalOn('AutoAddAll')), tostring(generalOn('AutoKeepAll')))
    say('Rules are written to [%s]', tostring(secNames[ui.scope]))
end

local function onCommand(...)
    local args = { ... }
    local sub = (args[1] or ''):lower()
    local item = trim(table.concat(args, ' ', 2))
    local scope = ui.scope          -- chat commands always use the section selected in "Add to"
    local lkey = item:lower()

    if sub == '' or sub == 'status' then
        local g, z = countRules()
        say('%s | %s | zone: %s | default: %s | %s section only, %d rules',
            paused and 'STOPPED' or 'RUNNING', state.reason, state.zoneLong, newItemAction,
            ui.scope, ui.scope == 'global' and g or z)
    elseif sub == 'show' then showGUI = true
    elseif sub == 'hide' then showGUI = false
    elseif sub == 'gui' or sub == 'ui' then showGUI = not showGUI
    elseif sub == 'start' or sub == 'on' then setPaused(false); say('Foraging started')
    elseif sub == 'stop' or sub == 'off' or sub == 'pause' then setPaused(true); say('Foraging stopped')
    elseif sub == 'toggle' then setPaused(not paused); say(paused and 'Foraging stopped' or 'Foraging started')
    elseif (sub == 'keep' or sub == 'destroy') and item ~= '' then
        setRule(item, sub, scope); say('Will %s: %s (%s)', sub, item, scope)
    elseif sub == 'remove' and item ~= '' then
        if removeRule(lkey, scope) then say('Removed: %s (%s)', item, scope)
        else say('No %s rule for: %s', scope, item) end
    elseif sub == 'default' and (lkey == 'keep' or lkey == 'destroy') then
        setDefault(lkey); say('Default action: %s', lkey)
    elseif sub == 'scope' and (lkey == 'global' or lkey == 'zone') then
        ui.scope = lkey; loadConfig(); say('Using the %s section only', lkey)
    elseif sub == 'list' then listRules()
    elseif sub == 'reload' then loadConfig(); say('Reloaded %s', iniPath)
    elseif sub == 'dump' then dump()
    elseif sub == 'quit' or sub == 'exit' or sub == 'stop' then running = false
    else
        say('Usage: /autoforage [show|hide|gui|start|stop|toggle|scope global|zone|keep <item>|destroy <item>|remove <item>|default keep|destroy|list|reload|dump|quit]')
    end
end

---------------------------------------------------------------------
-- Main
---------------------------------------------------------------------
if not loadConfig() then
    say('\ayMQ2AutoForage.ini not found at %s, using defaults (it will be created when you add rules).', iniPath)
end
local lastZone = state.zoneShort
mq.bind('/autoforage', onCommand)
mq.event('af_scrounge', 'You have scrounged up#*#', function()
    forage.pending = true; forage.windowEnd = os.time() + FORAGE_WINDOW
end)
mq.imgui.init('AutoForage', drawGUI)
say('Loaded. Foraging is \ayPAUSED\ax - press Start in the window or use /autoforage start. Window: /autoforage gui')
addLog(('Script started in %s'):format(state.zoneLong ~= '' and state.zoneLong or 'unknown zone'))

while running do
    -- reload rules whenever the zone changes
    local zs = currentZone()
    if zs and zs ~= lastZone then
        lastZone = zs
        loadConfig()
        addLog('Zone changed to ' .. (state.zoneLong ~= '' and state.zoneLong or zs) .. ', rules reloaded')
    end

    mq.doevents()
    processCursor()
    processForageResult()

    local ok, reason = checkForage()
    state.ok, state.reason = ok, reason
    if ok then
        state.reason = 'Foraging...'
        stats.attempts = stats.attempts + 1
        forage.pending = true
        forage.windowEnd = os.time() + FORAGE_WINDOW
        mq.cmd('/doability Forage')
    end
    mq.delay(250)
end

pcall(function() mq.imgui.destroy('AutoForage') end)
pcall(function() mq.unevent('af_scrounge') end)
mq.unbind('/autoforage')
say('Stopped.')
