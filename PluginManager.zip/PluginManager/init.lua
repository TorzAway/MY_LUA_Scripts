-----------------------------------------------------------
-- PluginManager.lua
-- MacroQuest ImGui-based plugin toggle window
--
-- Shows ALL plugins found in the MacroQuest plugins\ folder
-- (loaded or not) and lets you load/unload them on the fly.
--
-- Usage:
--   /lua run PluginManager
--   /lua stop PluginManager
--   /pluginmgr          <- toggle window visibility
-----------------------------------------------------------

local mq    = require('mq')
local imgui = require('ImGui')

-----------------------------------------------------------
-- ImGui integer constants
-----------------------------------------------------------
local ImGuiCond_FirstUseEver = 8
local ImGuiCol_Button        = 21
local ImGuiCol_ButtonHovered = 22
local ImGuiCol_ButtonActive  = 23

-----------------------------------------------------------
-- State
-----------------------------------------------------------
local open         = true
local firstDraw    = true
local plugins      = {}   -- array of { name, loaded, toggling }
local lastRefresh  = 0
local REFRESH_SEC  = 3
local searchFilter = ''

-- Queue: set to an entry table when the main loop should toggle it.
-- The draw callback NEVER blocks -- it only sets this.
local pendingToggle = nil

-----------------------------------------------------------
-- Helpers
-----------------------------------------------------------

local function getLoadedSet()
    local set = {}
    local i = 1
    while true do
        local p = mq.TLO.Plugin(i)
        if not p or not p.Name() then break end
        set[p.Name():lower()] = true
        i = i + 1
    end
    return set
end

local function getMQRoot()
    local path = mq.TLO.MacroQuest.Path()
    if path and path ~= '' then
        return path:gsub('\\', '/')
    end
    local scriptDir = mq.luaDir or '.'
    local root = scriptDir:match('^(.+)[/\\]lua') or scriptDir
    return root:gsub('\\', '/')
end

local function scanPlugins()
    local loadedSet = getLoadedSet()
    local seen      = {}
    local result    = {}

    local pluginDir = getMQRoot() .. '/plugins'
    local winDir    = pluginDir:gsub('/', '\\')

    local pipe = io.popen(string.format('dir /b "%s\\*.dll" 2>nul', winDir))
    if pipe then
        for filename in pipe:lines() do
            local name = filename:match('^(.+)%.dll$')
            if name then
                local key = name:lower()
                if not seen[key] then
                    seen[key] = true
                    result[#result + 1] = {
                        name     = name,
                        loaded   = loadedSet[key] or false,
                        toggling = false,
                    }
                end
            end
        end
        pipe:close()
    end

    -- Include loaded plugins not found on disk
    local i = 1
    while true do
        local p = mq.TLO.Plugin(i)
        if not p or not p.Name() then break end
        local name = p.Name()
        local key  = name:lower()
        if not seen[key] then
            seen[key] = true
            result[#result + 1] = {
                name     = name,
                loaded   = true,
                toggling = false,
            }
        end
        i = i + 1
    end

    table.sort(result, function(a, b)
        return a.name:lower() < b.name:lower()
    end)
    return result
end

local function refreshPlugins()
    local fresh    = scanPlugins()
    local existing = {}
    for _, v in ipairs(plugins) do
        existing[v.name:lower()] = v
    end

    local merged = {}
    for _, f in ipairs(fresh) do
        local e = existing[f.name:lower()]
        if e then
            e.loaded = f.loaded
            merged[#merged + 1] = e
        else
            merged[#merged + 1] = f
        end
    end
    plugins = merged
end

-----------------------------------------------------------
-- ImGui render callback  (NO blocking calls allowed here)
-----------------------------------------------------------
local function drawUI()
    if not open then return end

    if firstDraw then
        imgui.SetNextWindowSize(420, 540, ImGuiCond_FirstUseEver)
        firstDraw = false
    end

    open = imgui.Begin('Macroquest Plugin Manager##PlugMgr', open, 0)

    if open then
        -- Toolbar
        if imgui.Button('Refresh') then
            refreshPlugins()
        end
        imgui.SameLine()
        imgui.SetNextItemWidth(-1)
        searchFilter = imgui.InputText('##search', searchFilter, 128)
        imgui.Separator()

        -- Stats
        local loadedCount = 0
        for _, p in ipairs(plugins) do
            if p.loaded then loadedCount = loadedCount + 1 end
        end
        imgui.TextDisabled(
            string.format('%d plugins found  |  %d loaded', #plugins, loadedCount)
        )
        imgui.Separator()

        -- Scrollable list
        local footerH = imgui.GetTextLineHeightWithSpacing() + 6
        imgui.BeginChild('##pluglist', 0, -footerH, false)

        local filter = searchFilter:lower()
        for _, entry in ipairs(plugins) do
            if filter == '' or entry.name:lower():find(filter, 1, true) then

                if entry.loaded then
                    imgui.TextColored(0.2, 0.9, 0.3, 1.0, '[ON] ')
                else
                    imgui.TextColored(0.5, 0.5, 0.5, 1.0, '[--] ')
                end
                imgui.SameLine()

                imgui.Text(entry.name)
                imgui.SameLine()

                local btnW   = 68
                imgui.SetCursorPosX(imgui.GetContentRegionMax() - btnW)

                if entry.toggling then
                    imgui.BeginDisabled()
                    imgui.Button('Wait##' .. entry.name, btnW, 0)
                    imgui.EndDisabled()
                else
                    if entry.loaded then
                        imgui.PushStyleColor(ImGuiCol_Button,        0.65, 0.12, 0.12, 1.0)
                        imgui.PushStyleColor(ImGuiCol_ButtonHovered, 0.85, 0.22, 0.22, 1.0)
                        imgui.PushStyleColor(ImGuiCol_ButtonActive,  0.45, 0.06, 0.06, 1.0)
                        if imgui.Button('Unload##' .. entry.name, btnW, 0) then
                            -- Queue the toggle; do NOT block here
                            pendingToggle = entry
                            entry.toggling = true
                        end
                    else
                        imgui.PushStyleColor(ImGuiCol_Button,        0.12, 0.52, 0.12, 1.0)
                        imgui.PushStyleColor(ImGuiCol_ButtonHovered, 0.22, 0.72, 0.22, 1.0)
                        imgui.PushStyleColor(ImGuiCol_ButtonActive,  0.06, 0.36, 0.06, 1.0)
                        if imgui.Button('Load##' .. entry.name, btnW, 0) then
                            pendingToggle = entry
                            entry.toggling = true
                        end
                    end
                    imgui.PopStyleColor(3)
                end

                imgui.Separator()
            end
        end

        imgui.EndChild()  -- always reached; no yields above

        -- Footer
        imgui.TextDisabled('Filter above  |  /pluginmgr to toggle  |  /lua stop PluginManager to quit')
    end

    imgui.End()

    if not open then
        mq.exit()
    end
end

-----------------------------------------------------------
-- Slash command
-----------------------------------------------------------
mq.bind('/pluginmgr', function()
    open = not open
end)

-----------------------------------------------------------
-- Main loop  (blocking work happens here, outside ImGui frames)
-----------------------------------------------------------
refreshPlugins()
mq.imgui.init('PluginManager', drawUI)

while true do
    -- Process any queued toggle OUTSIDE the draw callback
    if pendingToggle then
        local entry = pendingToggle
        pendingToggle = nil

        if entry.loaded then
            mq.cmdf('/plugin %s unload noauto', entry.name)
        else
            mq.cmdf('/plugin %s noauto', entry.name)
        end

        mq.delay(800)       -- safe to block here; we are not inside ImGui
        refreshPlugins()
        entry.toggling = false
    end

    -- Periodic background refresh
    local now = os.time()
    if now - lastRefresh >= REFRESH_SEC then
        refreshPlugins()
        lastRefresh = now
    end

    mq.doevents()
    mq.delay(100)
end
