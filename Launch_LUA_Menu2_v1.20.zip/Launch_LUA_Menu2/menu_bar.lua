-- ============================================================
--  menu_bar.lua  -  MacroQuest LUA Script Launcher
--  Version : 1.20
--  Author  : Kroaking DaKnightsAway
--
--  CHANGELOG
--  ---------
--  1.20 — Setup tab section headings.  The two sections now have clearly
--        labelled headings: "ADD LUA BUTTON" (bold yellow) above the Add
--        Script text and button, and "EDIT EXISTING LUA BUTTON" (bold red)
--        above the "Move / reorder / delete a button" controls.  (Bold is
--        simulated by drawing the text twice, 1 pixel apart, because
--        MacroQuest's ImGui has no bold font.)
--  1.19 — Delete a button.  The Setup tab's Move section (retitled "Move /
--        reorder / delete a button") has a red DELETE LUA BUTTON next to Move.
--        It acts on the button chosen in the Button box and opens a "Delete
--        LUA Button" confirmation window asking "Do you really want to delete
--        this LUA button?".  Yes removes that button's line from
--        menu_config.lua (and a "-- Row N" header left with nothing under it);
--        No or the X cancels with no change.  Same safety as Add / Move: the
--        result is verified, menu_config.lua.bak keeps the previous file, and
--        the buttons reload immediately.  The entry must be alone on its own
--        line, otherwise you get a message to delete it by hand.
--  1.18 — Arguments in the Add Script window.  A new "Arguments" section has
--        one box per argument ("+ Add argument" adds a box, X removes or
--        clears one).  On Add, the arguments are joined with spaces after
--        the .lua file name and written as a single `script` string, e.g.
--        `script = "aaparty/init.lua driver 2"`, and a live "Will be saved
--        as" preview shows exactly what will be written.  Each argument
--        must be one word (no spaces) and may not contain quote characters;
--        arguments typed after the file name in the Script box are still
--        accepted and combined with the boxes.  Backslashes in arguments
--        are written escaped and Move / re-order now matches such entries.
--  1.17 — Fixed script ids for upper/mixed-case extensions.  scriptID()
--        stripped only a lowercase ".lua", so "Foo.LUA" produced the id
--        "foo.lua" (never matching the running script's name) and the
--        button never lit up.  The name is now lowercased before the
--        extension is stripped.
--  1.16 — Script arguments.  Anything after the .lua file name in a config
--        entry's `script` field is now passed to the script, e.g.
--        `script = "aaparty/init.lua driver"` starts it with
--        `/lua run aaparty driver`.  Previously the text was ignored for
--        folder scripts and broke detection for single-file scripts.  The
--        script's id (used for the running-state check and /lua stop) is
--        always taken from the file part only.  Picking a file with
--        Browse... keeps any arguments already typed in the Script box.
--        Note: two buttons that run the same script with different
--        arguments share one id, so they light up and stop together.
--  1.15 — Re-ordering now updates the whole row.  When a button is moved or
--        re-ordered, every button in the target row is rewritten with an
--        explicit `order = N` matching its new position (1, 2, 3 ...), so
--        the row's order is stored for all of its buttons rather than being
--        implied by file position.  This also means rows that already use
--        `order` values can now be re-ordered (the 1.14 limitation).  A
--        button added to a row that uses `order` values is given the next
--        number so it lands at the end.
--  1.14 — Button order.  The Setup tab's Move section now has a Position
--        dropdown: choose where in the target row the button goes (1st, 2nd,
--        ... or the end), and it also works within the button's current row
--        to simply re-order it.  The button's line is placed in menu_config.lua
--        directly before the button it should precede, so the order is stored
--        in the file itself.  The result is verified by rebuilding the layout
--        before saving.  (A row whose entries use `order` values can't be
--        re-ordered this way - you get a message instead of a bad edit.)
--        Also: entries with no `row` field are now recognised as row 1 when
--        the editor looks for a row to add to.
--  1.13 — Setup tab: "Move a button to another row" section (below a
--        separator, after the script-count / config-path line).  Pick any
--        configured button and a target row (existing or new) and click
--        Move.  The button's own line in menu_config.lua is relocated into
--        the target row's group with its `row` value rewritten - any other
--        fields (oneshot, order, trailing comments) are kept.  Same safety
--        checks and .bak backup as Add Script.
--  1.12 — Two-tab window: "LUA" and "Setup".  The LUA tab is the existing
--        button launcher, unchanged.  The new Setup tab adds scripts to
--        menu_config.lua without hand-editing it: "Add Script..." opens a
--        pop-up window with a label box, a script path box, a fully working
--        Browse... file picker (folder navigation, Up / Lua Folder / Refresh,
--        name filter, double-click to pick) and a row selector (any existing
--        row, or a new row).  The config is edited as text so all comments
--        and formatting are preserved; the edit is verified (valid Lua, entry
--        present) before saving, the previous file is kept as
--        menu_config.lua.bak, and the new button appears immediately - no
--        restart.  Also added a Reload Config button, and the config is now
--        read fresh from disk (not through require's cache).
--  1.11 — Replaced PID detection entirely. Every prior version of this
--        (hardcoded 1-100 range, then a "walk from 1 and guess when the
--        sequence has ended" miss-streak heuristic, then attempts to
--        patch that heuristic's gap-handling) was working around MQ's
--        actual PID assignment instead of asking MQ for it. MQ exposes
--        mq.TLO.Lua.PIDs directly: a comma-delimited string of the exact
--        PIDs it currently has info for. Detection now parses that list
--        and checks only those PIDs - no range, no cap, no gap-tolerance
--        heuristic, nothing to tune or get wrong. A script is detected
--        the instant MQ reports its PID, regardless of what number it is.
--  1.10 — Fixed missed detection once many scripts have been launched.
--        MQ's Lua PIDs are assigned like OS process IDs: every /lua run
--        (any script, including repeat runs and restarts during testing)
--        consumes a new, ever-increasing number for the whole MQ session -
--        they are never recycled. Detection previously scanned a hardcoded
--        PID range of 1-100, so once cumulative launches pushed a script's
--        assigned PID past 100 it silently stopped being detected: its
--        button never lit up even while running, and launching it reported
--        "Failed to start" even on a clean launch. The scan now follows
--        PIDs upward from 1 and only stops after a run of consecutive
--        unassigned PIDs long enough to be sure it has reached the end of
--        the sequence (PID_SCAN_MISS_STREAK), so it keeps working no matter
--        how many scripts have been run in the session.
--  1.9 — Reliable detection of short-lived scripts.  Some scripts
--        start, perform one action and terminate on their own.  The
--        old verify-after-run logic issued the run, waited a fixed
--        500 ms, then scanned the PID table ONCE — by which point such
--        a script had already exited, so it was wrongly reported as
--        "Failed to start" and its button never lit up.  Launch
--        verification now POLLS across a window (waitForStart) and
--        counts the script as started the instant it is seen running
--        even once, so transient scripts are detected while briefly
--        alive and persistent ones are confirmed faster (it returns
--        as soon as the script appears instead of always waiting the
--        full delay).  Scripts that finish faster than any poll can
--        sample can be marked `oneshot = true` (alias `transient =
--        true`) in menu_config.lua: those report "Launched" instead
--        of "Failed to start" when no running state is observed.
--  1.8 — Table-based button grid.  Buttons are now rendered inside an
--        ImGui table whose columns all share the same fixed width (the
--        widest button across every row and state).  This guarantees a
--        perfectly symmetric grid regardless of label lengths or how
--        buttons are distributed across rows.  The window auto-sizes
--        to the table: WIN_PAD_X margin + maxCols×colWidth + margins.
--  1.7 — Multi-row button layout.  Buttons can now be split across
--        rows from menu_config.lua via an optional `row` field (and
--        optional `order` for position within a row); a nested
--        `rows` layout is also accepted.  The window auto-sizes to
--        the widest row and left-aligns shorter ones.  Omitting these
--        fields keeps the previous single-row behaviour.
--  1.6 — Minimise-to-icon.  Clicking the title-bar chevron now hides
--        the toolbar and shows a small clickable image representing
--        the minimised launcher; drag the image to move it, or click
--        it to restore the toolbar.  Image is loaded with mq.CreateTexture and drawn as
--        an ImGui.ImageButton (same approach as the BIS tracker).
--        Because ImGui's native collapse only hides content (it can't
--        show an image), the chevron click is intercepted and turned
--        into a custom "minimised" mode that draws a separate
--        borderless icon window; the toolbar's collapsed flag is
--        cleared on restore so it reopens expanded.  Configure the
--        image via the ICON_* constants (see MINIMISE-TO-ICON below);
--        falls back to a small "Menu" button if no image loads.
--  1.5 — Even left/right margins.  The toolbar's side spacing no
--        longer relies on ImGui's WindowPadding, which rendered a
--        gap before the first button but none after the last on a
--        force-sized window.  WIN_PAD_X is now applied manually as
--        an equal left inset (SetCursorPosX) and a matching trailing
--        spacer (Dummy), so both edges have an identical margin.
--  1.4 — Renamed to "LUA Script Launcher" and added the version
--        to the ImGui window title (now "LUA Script Launcher v1.4").
--        Console notification prefix renamed to match.
--  1.1 — Added console notification system (see CONSOLE
--        NOTIFICATIONS below): a startup scan summary plus
--        verified Started/Stopped messages on each button toggle.
--  1.0 — Initial release.
--
--  OVERVIEW
--  --------
--  A MacroQuest Lua launcher window built with ImGui.  It has two tabs:
--
--    LUA    A grid of buttons, one per script listed in menu_config.lua.
--           Click a grey button to start its script; click a green button
--           to stop it.  Every button shows the live running state of its
--           script: green with an [ACTIVE] suffix when running, grey when
--           stopped.
--    Setup  Add a script to menu_config.lua, move / re-order buttons, and
--           reload the config - all from inside the game, no hand-editing.
--
--  The window can be minimised to a small draggable icon (see
--  MINIMISE-TO-ICON).  Closing the window with its X ends the launcher.
--
--  REQUIREMENTS
--  ------------
--  • MacroQuest with Lua and ImGui support.  Active-state detection uses the
--    mq.TLO.Lua.PIDs member.
--  • menu_config.lua, loadable from the lua folder (see CONFIG FILE).
--  • Optional: LuaFileSystem (`lfs`, normally bundled with MacroQuest).  It
--    powers the Browse... file picker.  Without it the picker shows a
--    message and you type the script path instead; everything else works.
--  • Optional: menu_bar_icon.png next to this script, for the minimised view.
--
--  INSTALLATION
--  ------------
--  1. Place menu_bar.lua    in MacroQuest/lua/
--  2. Place menu_config.lua in MacroQuest/lua/
--     (It is located with package.searchpath on package.path; if that
--     finds nothing, the folder containing menu_bar.lua is used.  This is
--     also the file the Setup tab edits.)
--  3. Optional: drop menu_bar_icon.png beside menu_bar.lua.
--  4. Start with:  /lua run menu_bar
--  5. Stop  with:  /lua stop menu_bar   (or close the window with its X)
--
--  CONFIG FILE  (menu_config.lua)
--  ------------------------------
--  menu_config.lua is a Lua file that returns a table.  It is read fresh
--  from disk with loadfile (NOT through require's cache), so edits take
--  effect as soon as the config is reloaded - see RELOADING below.
--
--  Flat layout (recommended; the only layout the Setup tab can edit):
--
--    return {
--        apps = {
--            -- Row 1
--            { label = "Tracker", script = "tracker.lua",           row = 1 },
--            { label = "Bank",    script = "GuildBankMaint/init.lua", row = 1 },
--            { label = "Driver",  script = "aaparty/init.lua driver", row = 1 },
--            -- Row 2
--            { label = "Buffer",  script = "buffer.lua", row = 2, oneshot = true },
--        },
--    }
--
--  Fields of each entry in `apps`:
--
--    label    Text on the button (keep it short).  Defaults to "App<N>".
--    script   Path relative to MacroQuest/lua/.  Required.
--               • Single-file script  → "myscript.lua"
--               • Folder script       → "FolderName/init.lua"
--             Only these two file shapes work: the launcher starts a script
--             with `/lua run <id>`, where <id> is the top-level folder name
--             (or the file name without its ".lua" extension - any letter
--             case, e.g. ".LUA" - lowercased).
--             ARGUMENTS: anything after the ".lua" file name is passed to
--             the script, e.g. script = "aaparty/init.lua driver" runs
--             `/lua run aaparty driver`.  The id (state detection, stop)
--             uses the file part only, so two buttons running the same
--             script with different arguments share one id: they light up
--             and stop together.  Arguments are separated by spaces, so each
--             must be a single word; avoid quote characters in them (the
--             Setup tab refuses them - see its limitations).  The Setup
--             tab's Add Script window has a separate box per argument and
--             writes them into this field for you.
--    row      Which row the button sits on (1 = top, 2 = next, ...).
--             Omit it and the button is on row 1.  The number of rows shown
--             is just the number of distinct row numbers in use.
--    order    Optional.  Position within the row (lower = further left).
--    oneshot  Optional (alias: transient).  Set `true` for scripts that
--             start, do one thing and exit on their own - see BUTTON
--             BEHAVIOUR.
--
--  Nested layout (accepted for display, but NOT editable from the Setup tab):
--
--    return {
--        rows = {
--            { { label = "A", script = "a.lua" }, { label = "B", script = "b.lua" } },
--            { { label = "C", script = "c.lua" } },
--        },
--    }
--
--  Each inner table is one row, top to bottom, with its buttons left to
--  right.  If `rows` is present it takes precedence and `apps` is ignored.
--
--  ROWS & ORDERING
--  ---------------
--  • Rows are drawn in ascending row-number order.
--  • Within a row, buttons are sorted by `order`.  A button with no `order`
--    uses its position in the file as its sort key, and file position also
--    breaks ties.  Mixing buttons with and without `order` in one row can
--    therefore interleave unexpectedly - give every button in a row an
--    `order`, or none of them.  (The Setup tab always writes `order` for
--    every button in a row it re-orders.)
--  • The window is as wide as the widest row; shorter rows are left-aligned.
--    Every button cell is the same width (see WINDOW SIZING).
--
--  ADDING / REMOVING / RELOADING
--  -----------------------------
--  • Add     Setup tab → Add Script...  (or edit menu_config.lua by hand).
--  • Move    Setup tab → Move / reorder a button.
--  • Remove  Setup tab → DELETE LUA BUTTON (asks for confirmation), or
--            delete the button's line from menu_config.lua by hand.
--  • Reload  After a manual edit, click "Reload Config" on the Setup tab.
--            No restart is needed.  Setup-tab edits reload automatically.
--  If the config cannot be loaded or has an error, the Setup tab reports it
--  and the console shows "Config reload failed"; the previous buttons stay.
--
--  BUTTON BEHAVIOUR
--  ----------------
--  • Clicking a grey  button runs   the script  (/lua run <id> [arguments]).
--  • Clicking a green button stops  the script  (/lua stop <id>).
--  • Active state comes from MQ's own Lua.PIDs list (the exact set of PIDs
--    MQ currently tracks - not a guessed range).  For each PID the script's
--    reported Name() is compared with the button's derived id, and the
--    script counts as active only if its Status() is "running".
--  • State is re-synced every 2 seconds, and immediately after any run or
--    stop action.
--  • START VERIFICATION: after issuing /lua run, the launcher polls (every
--    25 ms, for up to 1500 ms) until the script is seen running, so a
--    persistent script is confirmed as soon as it appears and a short-lived
--    one is caught while briefly alive.
--  • ONE-SHOT SCRIPTS: a script that starts, acts and exits faster than the
--    poll can sample would look like a failed start.  Mark it
--    `oneshot = true` in the config: it is polled for a shorter window
--    (500 ms) and, if never seen running, is reported as "Launched" rather
--    than "Failed to start".
--  • STOP VERIFICATION: after /lua stop, the launcher waits 200 ms, rescans,
--    and reports whether the script really stopped.
--  • The run/stop/add/move/delete/reload work is done in the main loop, not in the
--    render callback; the buttons only queue a request.
--
--  TABS
--  ----
--  LUA tab    The button grid described above.  With no scripts configured
--             it shows a hint to use the Setup tab.
--  Setup tab  See below.
--
--  SETUP TAB
--  ---------
--  Contents, top to bottom:
--    • A bold yellow "ADD LUA BUTTON" heading, then the Add Script text.
--    • "Add Script..." button (hidden for a nested `rows` config) and a
--      "Reload Config" button.
--    • A status line (green = success, red = failure) with the result of
--      the last Add / Reload.
--    • A summary line: "<N> scripts in <M> rows - <path to menu_config.lua>".
--    • After a separator, a bold red "EDIT EXISTING LUA BUTTON" heading and
--      the Move / reorder / delete section (flat layout
--      only, and only when at least one button exists).
--  If menu_config.lua uses the nested `rows` layout, an orange notice
--  explains that Add Script, Move and Delete are unavailable; Reload Config still
--  works.  To use them, convert the config to the flat `apps` layout.
--
--  ADD SCRIPT  (Setup tab → "Add Script...")
--  Opens the "Add Script to Menu" window:
--    Label   Button text.  Auto-suggested when a file is picked (folder name
--            for Folder/init.lua, otherwise the file name without .lua)
--            unless you have typed your own.
--    Script  Path relative to the lua folder, typed or filled by Browse...
--            Absolute paths inside the lua folder are converted to relative
--            ones; backslashes in the path become forward slashes.
--            Arguments typed after the .lua file name are still accepted
--            (and kept when Browse... fills in the file), but the Arguments
--            boxes below are the intended way to enter them.
--    Arguments  One box per argument.  "+ Add argument" adds another box;
--            X removes a box (or clears the last remaining one).  Empty
--            boxes are ignored.  Each argument must be a single word (no
--            spaces - /lua run splits on whitespace) and may not contain a
--            quote character (" or ').  On Add they are joined with single
--            spaces after the .lua file name and written as ONE `script`
--            string, e.g. boxes "driver" and "2" give
--            script = "aaparty/init.lua driver 2".  A grey "Will be saved
--            as" line under the form previews the exact string (or shows an
--            orange message if an argument isn't allowed).
--    Row     Any existing row (shown with its button count) or the next new
--            row.
--  A live warning appears if the path is an unsupported shape.  "Add to Menu"
--  checks, in order: label not empty; script not empty; a row chosen; path
--  points to a .lua file; no ".." in the path; supported shape (top-level
--  .lua or Folder/init.lua); the file exists under the lua folder; the
--  arguments are valid (see above); no existing button already uses that
--  script (compared case-insensitively as the whole final string,
--  arguments included).  The path, shape and file-exists checks apply to
--  the .lua file part only.  On success
--  the window closes and the button appears at once; on failure the reason
--  is shown in red in the window and printed to the console.
--  Placement: the new line goes after the last entry of the chosen row (an
--  entry with no `row` field counts as row 1), or as a new "-- Row N" group
--  at the end of the `apps` table.  If other buttons in that row already
--  carry `order` values, the new button is given the next number so it
--  lands at the end of the row.
--
--  BROWSE...  (inside the Add Script window → "Select Lua Script" window)
--    • Confined to the MacroQuest lua folder (scripts elsewhere can't be
--      started with /lua run).  The window shows the current folder as
--      "[lua]/<subfolder>".
--    • Buttons: Up, Lua Folder (both hidden at the lua folder itself) and
--      Refresh.  A "[..] Up one level" row also appears in the list.
--    • Filter box: case-insensitive "contains" match on file/folder names.
--    • The list shows folders ("[DIR]", marked "(has init.lua)" when they
--      are folder scripts) followed by .lua files, each sorted by name.
--      Entries starting with "." are hidden.  Click a folder to open it.
--    • Click a .lua file to select it; double-click it, or press Select, to
--      confirm.  A file in an unsupported location can be selected but is
--      flagged and cannot be confirmed.  For a folder script, open the
--      folder and pick its init.lua.
--    • Reopening Browse starts in the last folder used, or in the folder of
--      the path already typed (with that file pre-selected).
--    • Closing the Add Script window also closes the browser.
--
--  MOVE / REORDER  (Setup tab, below the separator)
--    Button    Any configured button (listed as "label (row N)").
--    To row    Any existing row, or the next new row.
--    Position  1st, 2nd, ... or the end of the target row, labelled with the
--              button each choice goes in front of.  Defaults to the
--              button's current slot when staying in its row, otherwise the
--              end of the new row.  Choosing the button's own row simply
--              re-orders it.
--  "Move" relocates the button's own line in menu_config.lua into the
--  target row's group directly before the button it should precede, with
--  its `row` value rewritten (or added).  Every other field and any
--  trailing comment on that line are kept.  Then every button in the target
--  row is rewritten with an explicit `order = N` matching its new position
--  (1, 2, 3, ...), so the row's order is stored for all of its buttons.
--  The source row's remaining buttons are left as they were.  Moving a
--  button to the slot it already occupies reports a message and changes
--  nothing.
--
--  DELETE LUA BUTTON  (Setup tab, red button next to Move)
--  Deletes the button currently chosen in the Button box.  Clicking it does
--  not delete anything yet: it opens the "Delete LUA Button" window showing
--  the button's label, row and script and asking "Do you really want to
--  delete this LUA button?".
--    Yes   removes that button's line from the `apps` table of
--          menu_config.lua and reloads the buttons.  If the line was the
--          only entry under a "-- Row N" header, the header is removed too.
--          The result is reported in green/red under the Move button and in
--          the console.
--    No / X   closes the window; nothing changes.
--  The entry must be alone on its own line (only the entry, a comma and an
--  optional comment); otherwise nothing is changed and you are told to
--  delete it by hand.  Other buttons' `order` values are not renumbered, so
--  the remaining buttons keep their relative order.  menu_config.lua.bak
--  holds the file as it was just before the delete.
--
--  HOW SETUP-TAB EDITS ARE MADE (Add, Move and Delete)
--  • menu_config.lua is edited as TEXT, so all comments and formatting are
--    preserved.  The `apps = { ... }` table is located by a scanner that
--    ignores braces/words inside comments and strings.
--  • Before anything is saved the edited text must compile as Lua, return a
--    table with an `apps` table, and contain the expected result (for Add,
--    the new entry; for Move, the same number of entries and a layout that,
--    when rebuilt exactly as the launcher does, matches the intended order;
--    for Delete, exactly one entry fewer, and that one script gone).
--    If any check fails nothing is written.
--  • The previous contents are saved as menu_config.lua.bak first.  Only
--    the most recent edit is kept (one-step undo).
--  • The file is then written and the buttons are rebuilt immediately.
--  Limitations:
--    - flat `apps` layout only;
--    - Move / order / Delete need each affected entry to sit on a single
--      line (otherwise you get a message to edit it by hand);
--    - only top-level .lua files and Folder/init.lua can be added;
--    - Move / re-order locates an entry by its quoted `script` string, so a
--      hand-written entry whose script text contains a quote character
--      can't be found and must be edited by hand.  (Add refuses quotes in
--      arguments for this reason.  Backslashes are fine: they are written
--      doubled and un-doubled again when matching.)
--
--  CONSOLE NOTIFICATIONS
--  ---------------------
--  Plain print statements to the MacroQuest console (the MQ chat window) -
--  NOT the ImGui window.  Every line is prefixed with [LUA Script Launcher]
--  and colour-coded with MQ colour codes.
--  Startup:
--    • One "ACTIVE on startup: <label>" line per configured script already
--      running, then "<N> configured script(s) already active." - or a
--      single "No configured scripts detected active on startup." line.
--    • "Minimise icon loaded: <path>", or "No minimise icon at <path>" plus a
--      hint that the minimised view will show a "Menu" button.
--  Button toggles (the message reflects the real state after a re-scan, not
--  just the command that was issued):
--    run  → "Started: <label>"
--           "Launched: <label> (one-shot; exited too quickly to confirm)"
--           "Failed to start: <label>"
--    stop → "Stopped: <label>"  or  "Still running: <label>"
--  Setup tab:
--    • "Added menu button: <label> (<script>, row <N>)"
--    • "Could not add script: <reason>"
--    • "Moved <label> to row <N>, position <P>"
--    • "Could not move: <reason>"
--    • "Deleted menu button: <label> (<script>)"
--    • "Could not delete: <reason>"
--    • "Config reloaded: <N> script(s) in <M> row(s)."
--    • "Config reload failed: <reason>"
--
--  WINDOW SIZING
--  -------------
--  Buttons are drawn in a single ImGui table whose columns are all the same
--  fixed width.  That width (colWidth) is the widest button across every row
--  - measured with ImGui.CalcTextSize on "<label> [ACTIVE]" plus the
--  button's frame padding - so a button never changes size when it toggles
--  between active and inactive.  The number of columns (maxCols) is the
--  button count of the longest row.  Window width is calculated every frame:
--
--      WIN_PAD_X*2 + maxCols*colWidth + (maxCols-1)*ITEM_SPC_X
--
--  taken as the larger of that and an estimate of the title-bar width (so
--  the title, name + version, is never clipped when the buttons are
--  narrower).  Height is left at 0 so ImGui auto-fits it.  The window is
--  non-resizable.  The result fits its contents with no blank space and no
--  clipping, and it tracks label changes immediately.
--
--  STARTUP SEQUENCING
--  ------------------
--  Phase 1  Load menu_config.lua (loadfile; falls back to require so a
--           broken config surfaces the usual error), build the button grid,
--           and load the minimise icon texture.
--  Phase 2  Resolve every button's active state BEFORE ImGui is touched,
--           then mq.delay(1) to yield one MQ frame so TLO state settles.
--           This prevents any first-frame flash of active scripts looking
--           inactive.  The startup console report is printed here.
--  Phase 3  Register the render callback with mq.imgui.init('ScriptLauncher',
--           renderUI), then enter the main loop.
--  renderUI also returns immediately until the initial sync is done, as a
--  safety net.
--
--  MAIN LOOP
--  ---------
--  Runs at about 10 Hz (mq.delay(100)) until the window is closed.  Each
--  tick it handles any queued request - run, stop, add, move, delete, reload - and
--  every 2 seconds re-syncs the active states.  Work that waits or writes
--  files lives here rather than in the render callback.
--
--  STYLE CONSTANTS  (top of script, easy to tune)
--  ---------------
--  WIN_PAD_X    Symmetric left & right side margin in pixels.  Applied
--               manually (SetCursorPosX plus a matching trailing spacer),
--               NOT via ImGui WindowPadding, which is forced to 0 on x.
--  FRAME_PAD_X  Horizontal padding inside each button.
--  ITEM_SPC_X   Total gap between adjacent buttons (applied as table
--               CellPadding x, split across both sides of each cell).
--  ICON_PATH    Image shown while minimised (see below).
--  ICON_W/H     Size the minimised image is drawn at (pixels).
--  ICON_PAD     Window padding around the minimised image.
--  FRAME_PAD_X and ITEM_SPC_X must match the values pushed in
--  renderToolbar() / renderLuaTab() so the text-width geometry stays exact.
--  Button colours are inline in renderLuaTab() as RGBA 0-1 floats (green
--  when active, grey when stopped); status/warning text colours are inline
--  in the Setup-tab and pop-up render functions.
--
--  MINIMISE-TO-ICON
--  ----------------
--  Click the title-bar chevron to minimise the toolbar to a small image
--  (the chevron click is intercepted: ImGui's native collapse can only hide
--  content, so it is turned into a custom "minimised" mode that shows a
--  separate borderless, backgroundless icon window with no title bar).
--  While minimised:
--    • drag the image to reposition it;
--    • click it (press and release with no drag) to restore the toolbar.
--  Hovering shows a tooltip.  The image is drawn with ImGui.Image (not a
--  button) so ImGui lets the window be dragged by it; clicks are detected
--  separately.  On restore the toolbar's collapsed flag is cleared so it
--  reopens expanded.  The Setup-tab pop-up windows stay open while
--  minimised.
--  Icon file:  by default <dir containing menu_bar.lua>/menu_bar_icon.png
--  (resolved from debug.getinfo, so it works wherever the script lives).
--  Drop a PNG named menu_bar_icon.png next to menu_bar.lua, or set ICON_PATH
--  to any absolute path.  The file is checked for existence and loaded once
--  at startup via mq.CreateTexture; a startup console line reports whether
--  it was found.  If it is missing or fails to load, the minimised view
--  falls back to a small "Menu" button so the launcher still works.
--
--  CODE MAP  (top to bottom)
--  --------
--  Identity ............ VERSION, APP_NAME, WIN_TITLE  (bump VERSION here)
--  State ............... buttons, rows, pending* requests, form/browse state
--  Style constants ..... WIN_PAD_X, FRAME_PAD_X, ITEM_SPC_X, ICON_*
--  Helpers ............. notify, splitScript (file + arguments), scriptID,
--                        PID scan (getAllPIDs, getRunningScripts,
--                        isRunning, waitForStart), syncActiveStates,
--                        table geometry
--  Layout .............. buildRowsSpec, buildButtons, reloadConfig
--  Paths ............... LUA_ROOT, CONFIG_PATH, path/script normalisation
--  Config editing ...... collectArgs, text scanners, placeEntryLine,
--                        insertAppEntry, setEntryOrder, moveAppEntry,
--                        removeAppEntry,
--                        saveConfigEdit, performAdd, performMove,
--                        performDelete
--  File browser ........ refreshBrowse, browseTo/Up, openBrowse, chooseFile
--  Startup ............. phase 2 sync + console report
--  Render .............. renderIcon, UI helpers (selectable, coloredText,
--                        boldHeading), renderLuaTab, renderSetupTab (+ Move
--                        section), renderAddWindow, renderBrowseWindow,
--                        renderDeleteWindow,
--                        renderToolbar, renderUI
--  Main loop ........... deferred run / stop / add / move / delete / reload + re-sync
--
--  TROUBLESHOOTING
--  ---------------
--  • A button never turns green:  its id (folder name, or file name without
--    .lua in any case, lowercased) must equal the name MQ reports for the running
--    script.  Check the `script` path.
--  • Arguments seem ignored:  they must come after the ".lua" file name in
--    the `script` field, separated by a space (e.g. "aaparty/init.lua driver").
--    In the Add Script window use one Arguments box per argument.
--  • "Argument N contains a space":  split it into separate boxes - each
--    argument is a single word.  Quote characters aren't allowed.
--  • "Failed to start" on a script that does run briefly:  add
--    `oneshot = true` to its entry.
--  • Setup tab says the config uses the nested layout:  switch menu_config.lua
--    to the flat `apps` list.
--  • Browse... shows an lfs message:  type the path into the Script box.
--  • A Setup edit went wrong:  menu_config.lua.bak holds the file as it was
--    before the last edit.
-- ============================================================

mq     = require('mq')
require 'ImGui'
local lfsOK, lfs = pcall(require, 'lfs')   -- file browser (Setup tab)

-- ============================================================
--  Identity
--  Single source of truth for the app name and version.  APP_NAME
--  is used as the console notification prefix; WIN_TITLE (name +
--  version) is the ImGui window title.  Bump VERSION here only.
-- ============================================================

local VERSION   = '1.20'
local APP_NAME  = 'LUA Script Launcher'
local WIN_TITLE = APP_NAME .. ' v' .. VERSION   -- "LUA Script Launcher v1.20"

-- ============================================================
--  State
-- ============================================================

local buttons     = {}   -- flat list of every button (used for state sync and
                         -- startup reporting); each entry:
                         --   .id        (int)    stable unique index (for ImGui IDs)
                         --   .label     (string) display name
                         --   .script    (string) config path
                         --   .active    (bool)   live running state
                         --   .row       (int)    row number from the config (default 1)
                         --   .transient (bool)   one-shot script (`oneshot`/`transient`)
local rows        = {}   -- layout: array of rows (top→bottom); each row is an
                         -- array of references to the button objects above,
                         -- left→right.  Built from menu_config (see Phase 1).

local open        = true   -- false when the window X is clicked → exits main loop
local pendingRun  = nil    -- {id,label,transient,args} queued to start on next main-loop tick
local pendingStop = nil    -- {id,label} queued to stop  on next main-loop tick

-- Minimise-to-icon state.
local minimized   = false  -- true → show the icon instead of the toolbar
local forceExpand = false  -- one-shot: un-collapse the toolbar window when
                           -- restoring, clearing the collapsed flag ImGui set
                           -- on the chevron click (else it would re-minimise).
local iconPressed = false  -- mouse button is down having pressed on the icon
local iconDragged = false  -- that press has moved → treat as a window drag,
                           -- not a click, so it moves instead of restoring.

-- Render callback is registered after the initial sync completes.
-- This flag prevents renderUI from touching ImGui before that point.
local initialSyncDone = false

-- Config / Setup-tab state.
local cfg           = nil    -- table returned by menu_config.lua (reloaded after edits)
local cfgNested     = false  -- true if the config uses the nested `rows` layout
                             -- (the Setup tab can only edit the flat `apps` layout)
local rowInfo       = {}     -- { {num=, count=}, ... } distinct rows in a flat config
local pendingAdd    = nil    -- {label,script,row,args} queued by the Add Script window
local pendingReload = false  -- Reload Config clicked
local pendingMove   = nil    -- {script,row,pos} queued by the Move section
local moveForm      = { script = nil, row = 1, pos = 1, key = nil }   -- Move section selections
local moveStatus    = nil    -- {ok=bool, text=string} last Move / Delete result
local pendingDelete = nil    -- {script} queued once the user confirms a delete
local deleteConfirm = nil    -- {script,label,row} while the confirmation window is open
local setupStatus   = nil    -- {ok=bool, text=string} last result, shown on Setup tab
local addOpen       = false  -- Add Script window visible
local addForm       = { label = '', script = '', autoLabel = '', row = 1, error = nil,
                        args = { '' } }   -- args: one string per argument box
local browse        = { open = false, dir = '', entries = nil, err = nil,
                        selected = nil, filter = '' }   -- file picker window

-- ============================================================
--  Style constants
--  FRAME_PAD_X and ITEM_SPC_X must match the values used in
--  renderToolbar() / renderLuaTab() so the CalcTextSize-based geometry
--  stays accurate.
--  WIN_PAD_X is NOT a PushStyleVar — it is the outer left/right margin
--  applied via SetCursorPosX before the table.  ITEM_SPC_X is used as
--  the total gap between columns (split evenly as CellPadding x on each
--  side of a cell).
-- ============================================================

local WIN_PAD_X   = 4   -- Symmetric left & right side margin (pixels).
                       -- NOTE: this is applied MANUALLY, not via ImGui's
                       -- WindowPadding (which is forced to 0 in renderUI).
                       -- ImGui's WindowPadding renders the left inset but, on
                       -- a force-sized window, lets the last button sit flush
                       -- against the right border — producing a lopsided look.
                       -- Instead we inset the first button by WIN_PAD_X from
                       -- the left and add a matching WIN_PAD_X spacer after the
                       -- last button, so both edges have an identical margin.
                       -- calcWindowWidth() reserves WIN_PAD_X * 2 for exactly
                       -- these two margins, so no width change is needed.
local FRAME_PAD_X = 6   -- ImGuiStyleVar.FramePadding  x  (inside each button)
local ITEM_SPC_X  = 4   -- ImGuiStyleVar.ItemSpacing   x  (gap between buttons)

-- ============================================================
--  Minimise-to-icon constants  (see MINIMISE-TO-ICON in header)
-- ============================================================

-- Image shown while minimised.  Looked for as menu_bar_icon.png in THIS
-- script's own directory, resolved from debug.getinfo so it works no matter
-- where menu_bar.lua is placed (lua root or a subfolder).  SCRIPT_DIR keeps
-- the trailing path separator.  Set ICON_PATH to an absolute path instead if
-- you prefer a different location.
local SCRIPT_DIR = (debug.getinfo(1, 'S').short_src or ''):match('^(.*[/\\])')
                   or ((mq.luaDir or '.') .. '/')
local ICON_PATH  = SCRIPT_DIR .. 'menu_bar_icon.png'
local ICON_W     = 48   -- drawn image width  (pixels)
local ICON_H     = 48   -- drawn image height (pixels)
local ICON_PAD   = 0    -- window padding around the minimised image
                        -- (0 = the window hugs the image with no surrounding box)

-- Load the icon texture once (same call the BIS tracker uses).  We first
-- confirm the file actually exists, because mq.CreateTexture can return a
-- non-nil but blank texture for a missing path — which would show an empty
-- box instead of cleanly falling back.  If the file is absent (or the build
-- lacks mq.CreateTexture), iconImg stays nil and the minimised view uses a
-- small "Menu" button instead.  A startup console line (below) reports which.
local iconImg     = nil
local iconLoaded  = false
do
    local f = io.open(ICON_PATH, 'rb')
    if f then
        f:close()
        local ok, tex = pcall(mq.CreateTexture, ICON_PATH)
        if ok and tex then
            iconImg    = tex
            iconLoaded = true
        end
    end
end

-- ============================================================
--  Helpers
-- ============================================================

-- Prints a prefixed, colour-coded line to the MacroQuest console
-- (MQ chat window), NOT to the ImGui window.  Prefix is APP_NAME.
-- Uses MQ colour codes:
--   \ay yellow  \ag green  \ar red  \aw white  \ax reset
-- If a given MQ build does not expose printf as a global, replace
-- the body with: print(string.format('[' .. APP_NAME .. '] ' .. fmt, ...))
local function notify(fmt, ...)
    printf('\aw[\ay' .. APP_NAME .. '\aw]\ax ' .. fmt, ...)
end

-- Splits a config `script` string into the script file and its arguments:
--   "aaparty/init.lua driver" -> "aaparty/init.lua", "driver"
--   "myscript.lua"            -> "myscript.lua",     ""
-- If no ".lua" is found the whole string is returned as the file, no args.
local function splitScript(script)
    script = tostring(script or '')
    local file = script:match('^(.-%.[Ll][Uu][Aa])')
    if not file then return script, '' end
    local args = script:sub(#file + 1):match('^%s+(.-)%s*$') or ''
    return file, args
end

-- Derives the key MacroQuest uses to identify a running script.
-- For folder-based scripts ("GuildBankMaint/init.lua") MQ reports
-- the folder name ("GuildBankMaint"), so that is used as the key.
-- For flat scripts ("myscript.lua") the extension is stripped.
-- Result is always lowercased for case-insensitive comparison, and the
-- ".lua" extension is stripped whatever its case (".LUA", ".Lua", ...).
-- Any arguments after the .lua file name are ignored here: they are passed
-- on `/lua run` but are not part of the script's name.
local function scriptID(script)
    script = splitScript(script)
    local dir = script:match('^([^/\\]+)[/\\]')
    if dir then return dir:lower() end
    local base = script:match('([^/\\]+)$') or script
    return (base:lower():gsub('%.lua$', ''))   -- lowercase first so ".LUA" is stripped too
end

-- MacroQuest actually exposes the exact set of Lua PIDs it knows about:
-- mq.TLO.Lua.PIDs is a comma-delimited string of every PID that currently
-- has info to access - no range, no cap, no gaps to guess around. This
-- replaces every previous version of this file's approach (a hardcoded
-- 1-100 range, then a "walk from 1 and guess when to stop" heuristic with
-- various patches): all of those were reverse-engineering something MQ
-- already tells us directly. Splits that string into a plain array of
-- integer PIDs.
local function getAllPIDs()
    local pidsStr = mq.TLO.Lua.PIDs()
    local pids = {}
    if pidsStr and pidsStr ~= '' then
        for numStr in pidsStr:gmatch('%d+') do
            pids[#pids + 1] = tonumber(numStr)
        end
    end
    return pids
end

-- Returns a set (table keyed by lowercase script name) of every script
-- currently in the "running" state, built from the real PID list above -
-- every entry is a PID MQ has confirmed exists, so there is nothing to
-- miss and nothing to over-scan.
local function getRunningScripts()
    local running = {}
    for _, pid in ipairs(getAllPIDs()) do
        local s    = mq.TLO.Lua.Script(pid)
        local name = s and s.Name()
        if name and name ~= '' then
            local status = s.Status()
            if status and status:lower() == 'running' then
                running[name:lower()] = true
            end
        end
    end
    return running
end

-- Updates every button's .active field against the current set of
-- running scripts.  Accepts an optional precomputed running set to
-- avoid a redundant PID scan; returns the set used either way.
local function syncActiveStates(running)
    running = running or getRunningScripts()
    for _, btn in ipairs(buttons) do
        btn.active = running[scriptID(btn.script)] == true
    end
    return running
end

-- Returns true if a single script `id` is currently in the "running"
-- state.  Lighter than getRunningScripts when only one id matters (used by
-- the launch poll below): it stops at the first matching PID.
local function isRunning(id)
    for _, pid in ipairs(getAllPIDs()) do
        local s    = mq.TLO.Lua.Script(pid)
        local name = s and s.Name()
        if name and name:lower() == id then
            local status = s.Status()
            return status ~= nil and status:lower() == 'running'
        end
    end
    return false
end

-- Polls for up to timeoutMs (default 1500) for `id` to appear running,
-- returning true the instant it is first seen.  This is what makes
-- short-lived scripts detectable: a script that starts, performs its
-- action and exits on its own would already be gone by the time of a
-- single post-run scan, so the previous fixed-delay check misreported it
-- as "Failed to start".  By sampling across the whole window we catch it
-- while it is briefly alive.  It returns early on success, so a normal
-- persistent script is confirmed as soon as it appears rather than after
-- a full fixed wait.
local function waitForStart(id, timeoutMs)
    local deadline = mq.gettime() + (timeoutMs or 1500)
    repeat
        if isRunning(id) then return true end
        mq.delay(25)
    until mq.gettime() >= deadline
    return isRunning(id)
end

-- Returns the pixel width that a button will occupy for a given label.
--   button width = text width + 2 × FramePadding.x
local function buttonWidth(label)
    return ImGui.CalcTextSize(label) + FRAME_PAD_X * 2
end

-- ============================================================
--  Table-layout geometry
--
--  Buttons are rendered inside an ImGui table whose columns all
--  have the same width (the widest button across every row and
--  state).  This makes the grid perfectly symmetric regardless
--  of how many buttons are on each row or how their labels differ.
--
--  colWidth  — width of every column  (widest button + ACTIVE suffix)
--  maxCols   — number of columns      (largest row in the config)
--  Window width = WIN_PAD_X×2 + maxCols×colWidth + (maxCols-1)×ITEM_SPC_X
-- ============================================================

-- Recomputed each frame so [ACTIVE] label changes are reflected instantly.
local function calcTableGeometry()
    local maxCols  = 0
    local colWidth = 0
    for _, row in ipairs(rows) do
        if #row > maxCols then maxCols = #row end
        for _, btn in ipairs(row) do
            local w = buttonWidth(btn.label .. ' [ACTIVE]')  -- worst-case width
            if w > colWidth then colWidth = w end
        end
    end
    return maxCols, colWidth
end

local function calcWindowWidth()
    local maxCols, colWidth = calcTableGeometry()
    local btnArea = maxCols * colWidth
                  + math.max(0, maxCols - 1) * ITEM_SPC_X

    -- Title-bar width estimate: padding + title text + the two title-bar
    -- widgets (collapse arrow, close button) + inter-widget spacing.
    local font     = ImGui.GetFontSize()
    local titleBar = WIN_PAD_X * 2
                   + ImGui.CalcTextSize(WIN_TITLE)
                   + font * 2
                   + ITEM_SPC_X * 2 + FRAME_PAD_X * 2

    return math.max(WIN_PAD_X * 2 + btnArea, titleBar)
end

local function buildRowsSpec(c)
    -- Already-nested rows format.
    if type(c.rows) == 'table' then
        return c.rows
    end

    -- Flat apps format → group by `row`, order within row.
    local apps  = c.apps or {}
    local byRow = {}     -- rowNumber → { {app=, seq=}, ... }
    local order = {}     -- distinct row numbers, in first-seen order

    for seq, app in ipairs(apps) do
        local r = tonumber(app.row) or 1
        if not byRow[r] then
            byRow[r]            = {}
            order[#order + 1]   = r
        end
        table.insert(byRow[r], { app = app, seq = seq })
    end

    table.sort(order)    -- rows render in ascending row-number order

    local spec = {}
    for _, r in ipairs(order) do
        local entries = byRow[r]
        -- Within a row: sort by `order` if given, else by list position;
        -- list position breaks ties so the sort stays stable.
        table.sort(entries, function(a, b)
            local ao = tonumber(a.app.order) or a.seq
            local bo = tonumber(b.app.order) or b.seq
            if ao == bo then return a.seq < b.seq end
            return ao < bo
        end)
        local row = {}
        for _, e in ipairs(entries) do row[#row + 1] = e.app end
        spec[#spec + 1] = row
    end
    return spec
end

-- ------------------------------------------------------------
--  Paths
--  LUA_ROOT   : MacroQuest's lua folder (forward slashes, no trailing '/').
--               /lua run only loads scripts from here, so the Setup tab's
--               file browser is confined to it.
--  CONFIG_PATH: the menu_config.lua file the Setup tab edits.
-- ------------------------------------------------------------

local function normPath(p)
    p = tostring(p or ''):gsub('\\', '/')
    p = p:gsub('/+$', '')
    return p
end

local LUA_ROOT = normPath(mq.luaDir)
if LUA_ROOT == '' then
    local ok, v = pcall(function() return mq.TLO.MacroQuest.Path('lua')() end)
    if ok and v then LUA_ROOT = normPath(v) end
end
if LUA_ROOT == '' then LUA_ROOT = normPath(SCRIPT_DIR) end

local function findConfigPath()
    if package.searchpath then
        local p = package.searchpath('menu_config', package.path)
        if p then return p end
    end
    return SCRIPT_DIR .. 'menu_config.lua'
end
local CONFIG_PATH = findConfigPath()

-- Returns the path of `full` relative to LUA_ROOT ('' for the root itself),
-- or nil if `full` is not inside LUA_ROOT.
local function toRelative(full)
    full = normPath(full)
    local root, f = LUA_ROOT:lower(), full:lower()
    if f == root then return '' end
    if f:sub(1, #root + 1) == root .. '/' then return full:sub(#root + 2) end
    return nil
end

-- Cleans up a script path typed/pasted by the user: trims, forward slashes,
-- and converts an absolute path inside the lua folder to a relative one.
local function normalizeScript(s)
    s = tostring(s or ''):match('^%s*(.-)%s*$')
    s = s:gsub('\\', '/')
    local rel = toRelative(s)
    if rel and rel ~= '' then s = rel end
    s = s:gsub('^%./', '')
    s = s:gsub('^/+', '')
    return s
end

-- The ".lua" file portion of a config script string, ignoring any arguments
-- after it (e.g. "aaparty/init.lua driver" -> "aaparty/init.lua").  See
-- splitScript() for the file + arguments pair.
local function scriptFilePart(s)
    return (s or ''):match('^(.-%.[Ll][Uu][Aa])')
end

-- The launcher starts a script with `/lua run <scriptID>`, and scriptID is the
-- top-level folder name (or the filename).  That only resolves correctly for a
-- top-level .lua file or a "Folder/init.lua".  Returns a message if `file`
-- is anything else (it would add a button that could never start properly).
local function supportProblem(file)
    local segs = {}
    for seg in tostring(file):gsub('\\', '/'):gmatch('[^/]+') do
        segs[#segs + 1] = seg
    end
    if #segs <= 1 then return nil end
    if #segs == 2 and segs[2]:lower() == 'init.lua' then return nil end
    return 'Unsupported location: the launcher runs folder scripts by folder name, '
        .. 'so only top-level .lua files and Folder/init.lua can be added.'
end

-- Builds the argument string for a new entry from (a) any arguments typed
-- after the .lua file name in the Script box (`typed`, whitespace-separated)
-- and (b) the Add Script window's separate argument boxes (`list`, one
-- argument per box, empty boxes ignored).  Each argument must be a single
-- token: /lua run splits on whitespace, so an argument containing a space
-- would arrive as two.  Quote characters are rejected because they cannot
-- be written to / matched in menu_config.lua reliably.
-- Returns the space-joined string ('' if none), or nil + a message.
local function collectArgs(typed, list)
    local out = {}
    for tok in tostring(typed or ''):gmatch('%S+') do out[#out + 1] = tok end
    for i, a in ipairs(list or {}) do
        a = tostring(a or ''):match('^%s*(.-)%s*$')
        if a ~= '' then
            if a:find('%s') then
                return nil, string.format('Argument %d contains a space - put each '
                    .. 'argument in its own box.', i)
            end
            out[#out + 1] = a
        end
    end
    for _, a in ipairs(out) do
        if a:find('["\']') then
            return nil, 'Arguments cannot contain quote characters (" or \').'
        end
        if a:find('%c') then
            return nil, 'Arguments cannot contain control characters.'
        end
    end
    return table.concat(out, ' ')
end

-- ------------------------------------------------------------
--  Config loading / (re)building the button grid
-- ------------------------------------------------------------

-- Loads menu_config.lua fresh from disk (bypassing require's cache so edits
-- made by the Setup tab show up immediately).  Returns table, or nil + error.
local function loadConfig()
    local chunk, err = loadfile(CONFIG_PATH)
    if not chunk then return nil, tostring(err) end
    local ok, res = pcall(chunk)
    if not ok then return nil, tostring(res) end
    if type(res) ~= 'table' then return nil, 'menu_config.lua did not return a table' end
    return res
end

-- ============================================================
--  Initialisation — Phase 1: build the button grid from config
--
--  Two config layouts are accepted (see menu_config.lua):
--    • Flat `apps` list with an optional per-app `row` (default 1)
--      and optional `order` (default = list position).  Buttons are
--      grouped by row (ascending) and sorted within each row.
--    • Nested `rows` list: each inner table is a row, top→bottom,
--      with buttons in left→right order.
--  buildRowsSpec() (above) turns either into an array of rows.
--  buildButtons() is re-runnable: it clears and rebuilds `buttons`,
--  `rows` and `rowInfo`, so the Setup tab can add a script and have
--  the new button appear without restarting the launcher.
-- ============================================================

local function buildButtons(c)
    for i = #buttons, 1, -1 do buttons[i] = nil end
    for i = #rows,    1, -1 do rows[i]    = nil end

    cfgNested = type(c.rows) == 'table'

    -- Summary of the row numbers used by a flat config (for the Setup tab's
    -- row picker): distinct row numbers ascending, with a button count each.
    local counts, nums = {}, {}
    if not cfgNested then
        for _, app in ipairs(c.apps or {}) do
            local r = math.floor(tonumber(app.row) or 1)
            if not counts[r] then counts[r] = 0; nums[#nums + 1] = r end
            counts[r] = counts[r] + 1
        end
    end
    table.sort(nums)
    rowInfo = {}
    for _, r in ipairs(nums) do rowInfo[#rowInfo + 1] = { num = r, count = counts[r] } end

    local rowsSpec = buildRowsSpec(c)
    local idx = 0
    for _, rowSpec in ipairs(rowsSpec) do
        local row = {}
        for _, app in ipairs(rowSpec) do
            idx = idx + 1
            local btn = {
                id     = idx,
                label  = app.label  or ('App' .. idx),
                script = app.script or '',
                active = false,
                row    = math.floor(tonumber(app.row) or 1),
                -- One-shot scripts (start → act → exit on their own) that
                -- finish faster than the launch poll can sample.  When set,
                -- an unobserved running state after a run reports "Launched"
                -- rather than "Failed to start".  Accepts `oneshot` or the
                -- alias `transient` in menu_config.lua.
                transient = (app.oneshot or app.transient) == true,
            }
            buttons[idx] = btn          -- flat list (for sync/reporting)
            row[#row + 1] = btn         -- this row's left→right order
        end
        if #row > 0 then rows[#rows + 1] = row end
    end
end

local function reloadConfig()
    local c, err = loadConfig()
    if not c then return false, err end
    cfg = c
    buildButtons(c)
    syncActiveStates()
    return true
end

-- Initial load.  Falls back to require() so a broken config surfaces the same
-- error it always did.
cfg = loadConfig() or require('menu_config')
buildButtons(cfg)

-- ============================================================
--  Config file editing  (used by the Setup tab)
--
--  The file is edited as TEXT, not regenerated, so every comment and all
--  existing formatting in menu_config.lua are preserved.  A single new
--  line is inserted into the `apps = { ... }` table:
--    • after the last existing entry of the same row, if that row exists;
--    • otherwise as a new "-- Row N" group at the end of the table.
--  Before saving, the edited text is compiled and checked to make sure it
--  is valid Lua and really contains the new entry; the previous contents
--  are kept in menu_config.lua.bak.
-- ============================================================

-- If text[i] begins a comment or a quoted string, returns the index just past
-- it; otherwise nil.  Lets the scanners below ignore braces/words that sit
-- inside comments and strings (menu_config.lua's header is full of both).
local function skipNonCode(text, i)
    local c = text:sub(i, i)
    if c == '-' and text:sub(i + 1, i + 1) == '-' then
        local eq = text:match('^%-%-%[(=*)%[', i)
        if eq then
            local _, e = text:find(']' .. eq .. ']', i, true)
            return (e or #text) + 1
        end
        local e = text:find('\n', i, true)
        return (e or #text) + 1
    elseif c == '"' or c == "'" then
        local j = i + 1
        while j <= #text do
            local d = text:sub(j, j)
            if d == '\\' then
                j = j + 2
            elseif d == c or d == '\n' then
                break
            else
                j = j + 1
            end
        end
        return j + 1
    end
    return nil
end

-- Locates the `apps = { ... }` table in the config text.
-- Returns openPos (the '{'), closePos (its matching '}'), lastCode (index of
-- the last real code character before the closing brace), or nil.
local function findAppsBlock(text)
    local n, i, openPos = #text, 1, nil
    while i <= n do
        local skip = skipNonCode(text, i)
        if skip then
            i = skip
        else
            local s, e = text:find('^apps%s*=%s*{', i)
            if s and (i == 1 or not text:sub(i - 1, i - 1):match('[%w_]')) then
                openPos = e
                break
            end
            i = i + 1
        end
    end
    if not openPos then return nil end

    local depth, lastCode = 0, openPos
    i = openPos
    while i <= n do
        local skip = skipNonCode(text, i)
        if skip then
            local c = text:sub(i, i)
            if c == '"' or c == "'" then lastCode = skip - 1 end
            i = skip
        else
            local c = text:sub(i, i)
            if c == '{' then
                depth = depth + 1
                lastCode = i
            elseif c == '}' then
                depth = depth - 1
                if depth == 0 then return openPos, i, lastCode end
                lastCode = i
            elseif not c:match('%s') then
                lastCode = i
            end
            i = i + 1
        end
    end
    return nil
end

local function escapeLua(s)
    s = tostring(s):gsub('\\', '\\\\')
    s = s:gsub('"', '\\"')
    return s
end

-- Finds the line inside the apps block holding the entry whose script is
-- `script`.  Returns lineStart, lineEnd (index of its '\n'), line - or nil.
local function findEntryLine(text, openPos, closePos, script)
    local nl0 = text:find('\n', openPos, true)
    local pos = nl0 and nl0 + 1
    while pos and pos < closePos do
        local nl = text:find('\n', pos, true)
        if not nl or nl > closePos then break end
        local l = text:sub(pos, nl - 1)
        if l:match('^%s*(.-)%s*$'):sub(1, 2) ~= '--' then
            local s = l:match('script%s*=%s*["\']([^"\']-)["\']')
            -- Entries are written with backslashes doubled (escapeLua), so
            -- undo that before comparing with the plain script string.
            if s then s = s:gsub('\\\\', '\\') end
            if s == script then return pos, nl, l end
        end
        pos = nl + 1
    end
    return nil
end

-- Inserts one ready-made entry string (no indentation) into the `apps` table
-- of `text`: after the last existing line of row `rowNum`, or as a new
-- "-- Row N" group at the end.  If `beforeScript` is given and its entry is
-- found, the new line goes directly before that entry instead (this is what
-- sets a button's position within its row).  Returns the new text, or nil + error.
local function placeEntryLine(text, entry, rowNum, beforeScript)
    local eol = text:find('\r\n', 1, true) and '\r\n' or '\n'

    local openPos, closePos, lastCode = findAppsBlock(text)
    if not openPos then
        return nil, 'Could not find an `apps = { ... }` table in menu_config.lua.'
    end

    -- Make sure the last existing entry ends with a comma so the new line
    -- can follow it.
    local lastChar = text:sub(lastCode, lastCode)
    if lastCode > openPos and lastChar ~= ',' and lastChar ~= ';' then
        text = text:sub(1, lastCode) .. ',' .. text:sub(lastCode + 1)
        openPos, closePos = findAppsBlock(text)
        if not openPos then return nil, 'Internal error while editing menu_config.lua.' end
    end

    -- Start of the line holding the closing '}'.
    local closeLineStart, pos = 1, 1
    while true do
        local nl = text:find('\n', pos, true)
        if not nl or nl >= closePos then break end
        closeLineStart = nl + 1
        pos = nl + 1
    end

    -- Unusual layout (closing brace not alone on its line): insert inline.
    local closeOnOwnLine = closeLineStart > openPos
        and text:sub(closeLineStart, closePos - 1):match('^%s*$') ~= nil
    if not closeOnOwnLine then
        return text:sub(1, closePos - 1) .. ' ' .. entry .. ' ' .. text:sub(closePos)
    end

    -- Positioned insert: go directly before the entry that should follow us.
    if beforeScript then
        local ls = findEntryLine(text, openPos, closePos, beforeScript)
        if ls then
            local ind = text:match('^([ \t]*)', ls)
            return text:sub(1, ls - 1) .. ind .. entry .. eol .. text:sub(ls)
        end
    end

    -- Walk the entry lines: remember the indentation and the last line that
    -- belongs to the target row.
    local indent, anchorEnd, anchorIndent
    local nl0 = text:find('\n', openPos, true)
    pos = nl0 and nl0 + 1
    while pos and pos < closeLineStart do
        local nl   = text:find('\n', pos, true)
        local line = text:sub(pos, nl and nl - 1 or #text)
        local trimmed = line:match('^%s*(.-)%s*$')
        if trimmed ~= '' and trimmed:sub(1, 2) ~= '--' then
            indent = indent or line:match('^(%s*)')
            local r   -- an entry with no `row` field is on row 1
            if line:find('script%s*=') then
                r = tonumber(line:match('%f[%w_]row%s*=%s*(%d+)')) or 1
            end
            if r == rowNum then
                anchorEnd    = nl           -- index of this line's '\n'
                anchorIndent = line:match('^(%s*)')
            end
        end
        pos = nl and nl + 1
    end
    indent = anchorIndent or indent or '        '

    -- Row already exists → add right after its last entry.
    if anchorEnd then
        return text:sub(1, anchorEnd) .. indent .. entry .. eol .. text:sub(anchorEnd + 1)
    end

    -- New row → append a "-- Row N" group just before the closing brace.
    local before    = text:sub(1, closeLineStart - 1)
    local needBlank = not before:match('\n[ \t]*\r?\n$')
    return before
        .. (needBlank and eol or '')
        .. indent .. '-- Row ' .. rowNum .. eol
        .. indent .. entry .. eol
        .. text:sub(closeLineStart)
end

-- Returns the config text with one new entry inserted, or nil + error.
local function insertAppEntry(text, label, script, rowNum)
    local entry = string.format('{ label = "%s", script = "%s", row = %d },',
                                escapeLua(label), escapeLua(script), rowNum)
    return placeEntryLine(text, entry, rowNum)
end

-- Finds the { ... } entry on a single config line.  Returns its first and
-- last character positions in `line`, or nil if the entry isn't fully on it.
local function isolateEntry(line)
    local o = line:find('{', 1, true)
    if not o then return nil end
    local depth, i = 0, o
    while i <= #line do
        local skip = skipNonCode(line, i)
        if skip then
            i = skip
        else
            local ch = line:sub(i, i)
            if ch == '{' then
                depth = depth + 1
            elseif ch == '}' then
                depth = depth - 1
                if depth == 0 then return o, i end
            end
            i = i + 1
        end
    end
    return nil
end

-- Sets `order = n` on the entry whose script is `script` (rewriting an
-- existing order value, or adding the field).  Everything else on the line,
-- including a trailing comment, is left alone.  Returns the new text, or
-- nil + error.
local function setEntryOrder(text, script, n)
    local openPos, closePos = findAppsBlock(text)
    if not openPos then
        return nil, 'Could not find an `apps = { ... }` table in menu_config.lua.'
    end
    local ls, le, line = findEntryLine(text, openPos, closePos, script)
    if not ls then
        return nil, 'Could not find "' .. script .. '" in menu_config.lua.'
    end
    local o, cpos = isolateEntry(line)
    if not cpos then
        return nil, 'The entry for "' .. script .. '" spans several lines, so its order '
                 .. 'can\'t be updated automatically. Put it on one line first.'
    end
    local entry = line:sub(o, cpos)
    if entry:find('%f[%w_]order%s*=%s*[%-%d%.]+') then
        entry = entry:gsub('(%f[%w_]order%s*=%s*)[%-%d%.]+', function(pre) return pre .. n end, 1)
    else
        local body = entry:sub(1, -2):gsub('[%s,]+$', '')
        entry = body .. ', order = ' .. n .. ' }'
    end
    return text:sub(1, ls - 1) .. line:sub(1, o - 1) .. entry .. line:sub(cpos + 1) .. text:sub(le)
end

-- Moves the existing entry whose script is `script` to row `rowNum`:
-- the entry's own line is cut out, its `row` value rewritten (or added if it
-- had none), and the line re-inserted into the target row's group.  Every
-- other field and any trailing comment on the line is preserved.
-- Returns the new text, or nil + error.
local function moveAppEntry(text, script, rowNum, beforeScript)
    local openPos, closePos = findAppsBlock(text)
    if not openPos then
        return nil, 'Could not find an `apps = { ... }` table in menu_config.lua.'
    end

    -- Find the line holding this script's entry.
    local lineStart, lineEnd, line = findEntryLine(text, openPos, closePos, script)
    if not line then
        return nil, 'Could not find that button on its own line in menu_config.lua. '
                 .. 'Edit its row by hand.'
    end

    -- Isolate the { ... } entry on that line.
    local o, cpos = isolateEntry(line)
    if not (o and cpos) then
        return nil, 'That button\'s entry spans several lines. Edit its row by hand.'
    end

    local entry   = line:sub(o, cpos)
    local comment = line:sub(cpos + 1):match('(%-%-.*)$')
    if comment then comment = comment:gsub('%s+$', '') end

    if entry:find('%f[%w_]row%s*=%s*%d+') then
        entry = entry:gsub('(%f[%w_]row%s*=%s*)%d+', function(pre) return pre .. rowNum end, 1)
    else
        local body = entry:sub(1, -2):gsub('[%s,]+$', '')
        entry = body .. ', row = ' .. rowNum .. ' }'
    end
    entry = entry .. ',' .. (comment and (' ' .. comment) or '')

    -- Cut the old line out, then place the rewritten one.
    text = text:sub(1, lineStart - 1) .. text:sub(lineEnd + 1)
    return placeEntryLine(text, entry, rowNum, beforeScript)
end

-- Removes the entry whose script is `script` from the `apps` table: its own
-- line is cut out of the text.  Refuses (with a message) unless the entry is
-- alone on its line, so no other config text can be lost.  If that leaves a
-- generated "-- Row N" header with nothing under it, the header is removed
-- too.  Returns the new text, or nil + error.
local function removeAppEntry(text, script)
    local openPos, closePos = findAppsBlock(text)
    if not openPos then
        return nil, 'Could not find an `apps = { ... }` table in menu_config.lua.'
    end
    local lineStart, lineEnd, line = findEntryLine(text, openPos, closePos, script)
    if not line then
        return nil, 'Could not find that button on its own line in menu_config.lua. '
                 .. 'Delete it by hand.'
    end
    local o, cpos = isolateEntry(line)
    if not (o and cpos) then
        return nil, 'That button\'s entry spans several lines. Delete it by hand.'
    end
    -- Only the entry (plus a comma and/or comment) may be on the line.
    local _, nEntries = line:gsub('script%s*=', '')
    local rest = line:sub(cpos + 1):gsub('%-%-.*$', '')
    if nEntries ~= 1 or line:sub(1, o - 1):match('%S') or rest:match('[^%s,;]') then
        return nil, 'That line holds more than just this button. Delete it by hand.'
    end

    local before = text:sub(1, lineStart - 1)
    local after  = text:sub(lineEnd + 1)

    -- Drop a now-empty "-- Row N" header directly above the removed line.
    local prevLine = before:match('([^\n]*)\n$')
    if prevLine and prevLine:match('^%s*%-%-%s*[Rr][Oo][Ww]%s+%d+%s*\r?$') then
        local nextLine = after:match('^([^\n]*)') or ''
        if nextLine:match('^%s*\r?$')
           or nextLine:match('^%s*%-%-%s*[Rr][Oo][Ww]%s+%d+')
           or nextLine:match('^%s*}') then
            before = before:sub(1, #before - #prevLine - 1)
        end
    end
    return before .. after
end

local function readFile(path)
    local f, err = io.open(path, 'rb')
    if not f then return nil, err end
    local data = f:read('*a')
    f:close()
    return data
end

local function writeFile(path, data)
    local f, err = io.open(path, 'wb')
    if not f then return false, err end
    f:write(data)
    f:close()
    return true
end

-- Shared save step for every Setup-tab edit: the edited text must compile and
-- pass `check(apps)`; the previous file is kept as menu_config.lua.bak; then
-- the file is written and the button grid reloaded.  Returns true, or false +
-- a message.
local function saveConfigEdit(oldText, newText, check)
    local loader = loadstring or load
    local chunk, cerr = loader(newText, '=menu_config')
    if not chunk then
        return false, 'Not saved - the edit would have produced invalid Lua: ' .. tostring(cerr)
    end
    local ok, res = pcall(chunk)
    local good, why = false, nil
    if ok and type(res) == 'table' and type(res.apps) == 'table' then
        good, why = check(res.apps, res)
    end
    if not good then
        return false, why or 'Not saved - could not verify the edited config.'
    end
    writeFile(CONFIG_PATH .. '.bak', oldText)          -- one-step undo
    local wok, werr = writeFile(CONFIG_PATH, newText)
    if not wok then return false, 'Could not write menu_config.lua: ' .. tostring(werr) end
    local rok, rerr = reloadConfig()
    if not rok then return false, 'Saved, but reloading failed: ' .. tostring(rerr) end
    return true
end

-- Validates a request from the Add Script window and, if everything checks
-- out, saves it into menu_config.lua and reloads the button grid.
-- Returns true, or false + a message for the user.
local function performAdd(req)
    if cfgNested then
        return false, 'menu_config.lua uses the nested `rows` layout. The Setup tab '
            .. 'can only add to the flat `apps` layout.'
    end

    local label = tostring(req.label or ''):gsub('%c', ' ')
    label = label:match('^%s*(.-)%s*$')
    local script = normalizeScript(req.script)
    local rowNum = math.floor(tonumber(req.row) or 0)

    if label == '' then return false, 'Enter a label for the button.' end
    if script == '' then return false, 'Choose a script with Browse, or type its path.' end
    if rowNum < 1 then return false, 'Pick a row.' end

    local file = scriptFilePart(script)
    if not file then return false, 'The script path must point to a .lua file.' end
    if file:find('^%.%./') or file:find('/%.%./') then
        return false, 'The script path cannot contain "..".'
    end
    local problem = supportProblem(file)
    if problem then return false, problem end

    -- Arguments: anything typed after the file name in the Script box, plus
    -- the separate argument boxes.  The final entry is "<file> <arg> <arg>...".
    -- (Typed arguments are taken from the raw text so backslashes survive.)
    local typedRaw = tostring(req.script or ''):match('^%s*(.-)%s*$')
    local argStr, aerr = collectArgs(select(2, splitScript(typedRaw)), req.args)
    if not argStr then return false, aerr end
    script = file .. (argStr ~= '' and (' ' .. argStr) or '')

    local fh = io.open(LUA_ROOT .. '/' .. file, 'rb')
    if not fh then
        return false, 'File not found in the lua folder: ' .. file
    end
    fh:close()

    for _, b in ipairs(buttons) do
        if b.script:lower() == script:lower() then
            return false, string.format('"%s" already uses that script.', b.label)
        end
    end

    local text, rerr = readFile(CONFIG_PATH)
    if not text then return false, 'Cannot read menu_config.lua: ' .. tostring(rerr) end

    local newText, ierr = insertAppEntry(text, label, script, rowNum)
    if not newText then return false, ierr end

    -- If other buttons in this row carry explicit `order` values, file position
    -- alone won't place the new one - give it the next number so it lands last.
    do
        local chunk = (loadstring or load)(newText, '=menu_config')
        local okc, res = false, nil
        if chunk then okc, res = pcall(chunk) end
        if okc and type(res) == 'table' and type(res.apps) == 'table' then
            local hasOrder, maxOrder = false, 0
            for _, a in ipairs(res.apps) do
                if math.floor(tonumber(a.row) or 1) == rowNum and tonumber(a.order) then
                    hasOrder = true
                    maxOrder = math.max(maxOrder, tonumber(a.order))
                end
            end
            if hasOrder then
                local t = setEntryOrder(newText, script, math.floor(maxOrder) + 1)
                if t then newText = t end
            end
        end
    end

    local ok, err = saveConfigEdit(text, newText, function(apps)
        for _, a in ipairs(apps) do
            if a.script == script and a.label == label then return true end
        end
        return false
    end)
    if not ok then return false, err end
    return true, label, script, rowNum
end

-- The buttons currently displayed in row number `num`, left to right.
local function buttonsInRow(num)
    for _, r in ipairs(rows) do
        if r[1] and r[1].row == num then return r end
    end
    return {}
end

-- Moves an existing button to another row and/or position within a row
-- (Setup tab → Move section).  `req.pos` is the 1-based position the button
-- should end up at in the target row.
-- Returns true, label, row, pos  or  false, message.
local function performMove(req)
    if cfgNested then
        return false, 'menu_config.lua uses the nested `rows` layout. The Setup tab '
            .. 'can only edit the flat `apps` layout.'
    end
    local rowNum = math.floor(tonumber(req.row) or 0)
    if rowNum < 1 then return false, 'Pick a row.' end

    local btn
    for _, b in ipairs(buttons) do
        if b.script == req.script then btn = b; break end
    end
    if not btn then return false, 'Pick a button to move.' end

    -- Buttons already in the target row, not counting the one being moved.
    local others, curPos = {}, nil
    for i, b in ipairs(buttonsInRow(rowNum)) do
        if b.script == btn.script then curPos = i else others[#others + 1] = b end
    end
    local pos = math.floor(tonumber(req.pos) or (#others + 1))
    pos = math.max(1, math.min(pos, #others + 1))

    if btn.row == rowNum and curPos == pos then
        return false, string.format('"%s" is already in position %d of row %d.',
                                    btn.label, pos, rowNum)
    end

    local text, rerr = readFile(CONFIG_PATH)
    if not text then return false, 'Cannot read menu_config.lua: ' .. tostring(rerr) end

    local before = others[pos] and others[pos].script or nil   -- the button we go in front of
    local newText, merr = moveAppEntry(text, btn.script, rowNum, before)
    if not newText then return false, merr end

    -- What the layout must look like afterwards.
    local wantTarget = {}
    for _, b in ipairs(others) do wantTarget[#wantTarget + 1] = b.script end
    table.insert(wantTarget, pos, btn.script)

    -- Update every button in the target row: each gets `order` = its new
    -- position, so the whole row's order is explicit, not just the moved one.
    for i, s in ipairs(wantTarget) do
        local t, oerr = setEntryOrder(newText, s, i)
        if not t then return false, oerr end
        newText = t
    end
    local wantSource
    if btn.row ~= rowNum then
        wantSource = {}
        for _, b in ipairs(buttonsInRow(btn.row)) do
            if b.script ~= btn.script then wantSource[#wantSource + 1] = b.script end
        end
    end
    local expected = #buttons

    local function rowScripts(spec, n)
        for _, r in ipairs(spec) do
            local first = r[1]
            if first and math.floor(tonumber(first.row) or 1) == n then
                local t = {}
                for _, a in ipairs(r) do t[#t + 1] = a.script end
                return t
            end
        end
        return {}
    end
    local function same(x, y)
        if #x ~= #y then return false end
        for i = 1, #x do if x[i] ~= y[i] then return false end end
        return true
    end

    local ok, err = saveConfigEdit(text, newText, function(apps, res)
        if #apps ~= expected then return false end
        -- Rebuild the layout exactly as the launcher would and compare.
        local spec = buildRowsSpec(res)
        if not same(rowScripts(spec, rowNum), wantTarget)
           or (wantSource and not same(rowScripts(spec, btn.row), wantSource)) then
            return false, 'Not saved - the new order did not verify against the rebuilt layout.'
        end
        return true
    end)
    if not ok then return false, err end
    return true, btn.label, rowNum, pos
end

-- Deletes an existing button's entry from menu_config.lua (Setup tab →
-- DELETE LUA BUTTON, after the user confirms).  Same safety net as Add / Move:
-- the result is verified, menu_config.lua.bak keeps the previous file, and the
-- button grid is rebuilt.  Returns true, label, script  or  false, message.
local function performDelete(req)
    if cfgNested then
        return false, 'menu_config.lua uses the nested `rows` layout. The Setup tab '
            .. 'can only edit the flat `apps` layout.'
    end

    local btn
    for _, b in ipairs(buttons) do
        if b.script == req.script then btn = b; break end
    end
    if not btn then return false, 'That button no longer exists. Try Reload Config.' end

    local text, rerr = readFile(CONFIG_PATH)
    if not text then return false, 'Cannot read menu_config.lua: ' .. tostring(rerr) end

    local newText, derr = removeAppEntry(text, btn.script)
    if not newText then return false, derr end

    local same = 0
    for _, b in ipairs(buttons) do
        if b.script == btn.script then same = same + 1 end
    end
    local expected = #buttons - 1

    local ok, err = saveConfigEdit(text, newText, function(apps)
        local left = 0
        for _, a in ipairs(apps) do
            if a.script == btn.script then left = left + 1 end
        end
        if #apps ~= expected or left ~= same - 1 then
            return false, 'Not saved - the edited config did not verify '
                       .. '(was menu_config.lua changed on disk? Try Reload Config).'
        end
        return true
    end)
    if not ok then return false, err end
    return true, btn.label, btn.script
end

-- ------------------------------------------------------------
--  File browser (Setup tab → Add Script → Browse...)
--  Uses LuaFileSystem (lfs), which ships with MacroQuest.  Confined to
--  LUA_ROOT: scripts outside it cannot be started with /lua run.
-- ------------------------------------------------------------

local function refreshBrowse()
    browse.entries, browse.err = nil, nil
    if not lfsOK then
        browse.err = 'LuaFileSystem (lfs) is not available in this MacroQuest build. '
                  .. 'Type the script path into the Script box instead.'
        return
    end

    local dirs, files = {}, {}
    local ok, err = pcall(function()
        for name in lfs.dir(browse.dir) do
            if name:sub(1, 1) ~= '.' then
                local full = browse.dir .. '/' .. name
                local mode = lfs.attributes(full, 'mode')
                if mode == 'directory' then
                    dirs[#dirs + 1] = {
                        name    = name,
                        isDir   = true,
                        hasInit = lfs.attributes(full .. '/init.lua', 'mode') == 'file',
                    }
                elseif mode == 'file' and name:lower():match('%.lua$') then
                    files[#files + 1] = { name = name }
                end
            end
        end
    end)
    if not ok then
        browse.err = 'Cannot read folder: ' .. tostring(err)
        return
    end

    local function byName(a, b) return a.name:lower() < b.name:lower() end
    table.sort(dirs, byName)
    table.sort(files, byName)

    local list = {}
    for _, d in ipairs(dirs)  do list[#list + 1] = d end
    for _, f in ipairs(files) do list[#list + 1] = f end
    browse.entries = list
end

local function browseTo(dir)
    browse.dir = dir
    refreshBrowse()
end

local function browseUp()
    if browse.dir:lower() == LUA_ROOT:lower() then return end
    local parent = browse.dir:match('^(.*)/[^/]*$')
    if not parent or #parent < #LUA_ROOT then parent = LUA_ROOT end
    browseTo(parent)
end

local function openBrowse()
    browse.filter, browse.selected = '', nil
    local startDir = (browse.dir ~= '' and browse.dir) or LUA_ROOT

    -- If a script path is already in the box, open its folder with it selected.
    local file = scriptFilePart(normalizeScript(addForm.script))
    if file and not file:find('%.%.') then
        local sub = file:match('^(.*)/[^/]*$')
        local candidate = sub and (LUA_ROOT .. '/' .. sub) or LUA_ROOT
        if lfsOK and lfs.attributes(candidate, 'mode') == 'directory' then
            startDir = candidate
        end
        browse.selected = file
    end

    browse.dir = startDir
    refreshBrowse()
    browse.open = true
end

-- Called when a file is chosen in the browser: fills the Add Script form and
-- suggests a button label (the folder name for Folder/init.lua, otherwise the
-- file name) unless the user has already typed their own.  Arguments already
-- typed in the Script box are preserved.
local function chooseFile(rel)
    -- Keep any arguments already typed after the file name.
    local _, args = splitScript(tostring(addForm.script or ''):match('^%s*(.-)%s*$'))
    addForm.script = rel .. (args ~= '' and (' ' .. args) or '')
    addForm.error  = nil
    local dir  = rel:match('^([^/]+)/')
    local base = rel:match('([^/]+)$') or rel
    local name = (base:lower() == 'init.lua' and dir) or (base:gsub('%.[Ll][Uu][Aa]$', ''))
    if addForm.label == '' or addForm.label == addForm.autoLabel then
        addForm.label, addForm.autoLabel = name, name
    end
end

local function nextNewRow()
    local last = rowInfo[#rowInfo]
    return (last and last.num or 0) + 1
end

local function rowLabelFor(num)
    for _, ri in ipairs(rowInfo) do
        if ri.num == num then
            return string.format('Row %d  (%d button%s)', num, ri.count, ri.count == 1 and '' or 's')
        end
    end
    return string.format('Row %d  (new row)', num)
end

local function openAddWindow()
    addForm.label, addForm.autoLabel, addForm.script, addForm.error = '', '', '', nil
    addForm.args = { '' }
    local last = rowInfo[#rowInfo]
    addForm.row = last and last.num or 1
    setupStatus = nil
    addOpen = true
end

-- ============================================================
--  Initialisation — Phase 2: blocking pre-render state sync
--  Resolves the active flag for every button before ImGui is
--  touched, preventing any first-frame flash of wrong state.
-- ============================================================

syncActiveStates()
mq.delay(1)          -- yield one MQ frame so TLO state settles
initialSyncDone = true

-- Report which configured scripts were already running at startup.
-- This is console output only; the ImGui window is unaffected.
do
    local activeCount = 0
    for _, btn in ipairs(buttons) do
        if btn.active then
            notify('\agACTIVE\ax on startup: %s', btn.label)
            activeCount = activeCount + 1
        end
    end
    if activeCount == 0 then
        notify('No configured scripts detected active on startup.')
    else
        notify('%d configured script(s) already active.', activeCount)
    end
end

-- Report whether the minimise icon was found, so its absence is obvious
-- rather than silently showing the text-button fallback.
if iconLoaded then
    notify('Minimise icon loaded: \ag%s\ax', ICON_PATH)
else
    notify('\arNo minimise icon\ax at %s', ICON_PATH)
    notify('  → minimised view will show a "Menu" button. Drop a PNG there to use an image.')
end

-- ============================================================
--  Render callback
--  Registered after the pre-render sync; gated by initialSyncDone
--  as a safety net against any edge-case early fire.
-- ============================================================

-- Minimised view: a small borderless, auto-sized window (no title bar, no
-- background) whose only content is the icon drawn with ImGui.Image, or a
-- "Menu" button if no icon loaded.  Drag the image to move the window; a
-- click (press + release with no drag) restores the toolbar.  Uses its own
-- window id so it is independent of the toolbar window.
local MIN_FLAGS = bit32.bor(ImGuiWindowFlags.AlwaysAutoResize,
                            ImGuiWindowFlags.NoResize,
                            ImGuiWindowFlags.NoScrollbar,
                            ImGuiWindowFlags.NoTitleBar,
                            (ImGuiWindowFlags.NoBackground or 0))  -- no panel/border box

local function renderIcon()
    ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, ICON_PAD, ICON_PAD)

    local visible
    open, visible = ImGui.Begin(APP_NAME .. ' Icon###LauncherMini', open, MIN_FLAGS)
    if visible then
        local restore = false

        if iconImg then
            -- Draw the icon as a plain image (not a button).  A plain image is
            -- non-interactive, so ImGui lets the borderless window be dragged by
            -- it — giving us "drag the image to move" for free.  Restoring is
            -- handled below by detecting a click (press + release with no drag).
            local ok = pcall(function()
                ImGui.Image(iconImg:GetTextureID(), ImVec2(ICON_W, ICON_H))
            end)

            if ok then
                local hovered = ImGui.IsItemHovered()
                if hovered and not iconPressed then
                    ImGui.SetTooltip(APP_NAME .. ' — drag to move, click to restore')
                end

                -- Press started on the icon → begin tracking a potential click.
                if hovered and ImGui.IsMouseClicked(0) then
                    iconPressed = true
                    iconDragged = false
                end
                -- Any movement while held turns it into a drag (window move),
                -- which must NOT restore.
                if iconPressed and ImGui.IsMouseDragging(0) then
                    iconDragged = true
                end
                -- Release: a press that never became a drag is a click → restore.
                if ImGui.IsMouseReleased(0) then
                    if iconPressed and not iconDragged then
                        restore = true
                    end
                    iconPressed = false
                    iconDragged = false
                end
            else
                iconImg = nil
            end
        end

        if not iconImg then
            if ImGui.Button('Menu##restore') then restore = true end
        end

        if restore then
            minimized   = false
            forceExpand = true   -- un-collapse the toolbar window next frame
        end
    end

    ImGui.End()
    ImGui.PopStyleVar()
end

-- ------------------------------------------------------------
--  UI helpers
-- ------------------------------------------------------------

-- ImGui.Selectable returns just `pressed` in some MQ builds and
-- `(selected, pressed)` in others; this normalises both to a single boolean.
local function selectable(label, selected, flags)
    local a, b
    if flags then
        a, b = ImGui.Selectable(label, selected, flags)
    else
        a, b = ImGui.Selectable(label, selected)
    end
    if b ~= nil then return b end
    return a
end

-- Positions the next window near the centre of the screen when it first
-- appears (best effort - silently skipped if this build lacks the calls).
local function centerNextWindow(w, h, dx, dy)
    local ok, sw, sh = pcall(function()
        local d = ImGui.GetIO().DisplaySize
        return d.x, d.y
    end)
    if not (ok and sw and sh and sw > 0) then return end
    local x, y = (sw - w) / 2 + (dx or 0), (sh - h) / 3 + (dy or 0)
    if not pcall(ImGui.SetNextWindowPos, x, y, ImGuiCond.Appearing) then
        pcall(ImGui.SetNextWindowPos, ImVec2(x, y), ImGuiCond.Appearing)
    end
end

local function coloredText(r, g, b, text)
    ImGui.PushStyleColor(ImGuiCol.Text, r, g, b, 1)
    ImGui.Text(text)
    ImGui.PopStyleColor()
end

-- Bold, coloured section heading.  MacroQuest's ImGui has no bold font, so
-- the text is drawn twice, 1 pixel apart, which gives a convincing bold.  The
-- cursor ends up on the next line exactly as after a normal ImGui.Text.  If
-- this build lacks the cursor calls it falls back to a single plain draw.
local function boldHeading(r, g, b, text)
    ImGui.PushStyleColor(ImGuiCol.Text, r, g, b, 1)
    local ok = pcall(function()
        local x, y = ImGui.GetCursorPosX(), ImGui.GetCursorPosY()
        ImGui.SetCursorPosX(x + 1)
        ImGui.Text(text)
        ImGui.SetCursorPosX(x)
        ImGui.SetCursorPosY(y)
        ImGui.Text(text)
    end)
    if not ok then ImGui.Text(text) end
    ImGui.PopStyleColor()
end

-- Section heading colours (Setup tab).
local HEAD_ADD_COLOR  = { 1.0, 0.9,  0.1,  }   -- bold yellow: ADD LUA BUTTON
local HEAD_EDIT_COLOR = { 1.0, 0.25, 0.25, }   -- bold red:    EDIT EXISTING LUA BUTTON

-- ------------------------------------------------------------
--  LUA tab  (the original button grid)
-- ------------------------------------------------------------

local function renderLuaTab()
    local maxCols, colWidth = calcTableGeometry()

    if maxCols == 0 then
        ImGui.SetCursorPosX(WIN_PAD_X)
        ImGui.PushTextWrapPos(calcWindowWidth() - WIN_PAD_X)
        ImGui.Text('No scripts are configured yet. Use the Setup tab to add one.')
        ImGui.PopTextWrapPos()
        return
    end

    -- One ImGui table, maxCols columns, all the same width (colWidth).
    -- CellPadding x = ITEM_SPC_X/2 so adjacent cells are separated by
    -- ITEM_SPC_X total.  The outer left/right margins come from the
    -- table's x offset: we position it at WIN_PAD_X from the window edge.
    ImGui.PushStyleVar(ImGuiStyleVar.CellPadding, ITEM_SPC_X / 2, 2)
    ImGui.SetCursorPosX(WIN_PAD_X)

    local tblFlags = ImGuiTableFlags.SizingFixedSame
    if ImGui.BeginTable('##btns', maxCols, tblFlags) then

        -- Set every column to the same fixed width.
        for c = 1, maxCols do
            ImGui.TableSetupColumn('', ImGuiTableColumnFlags.WidthFixed, colWidth)
        end

        for _, row in ipairs(rows) do
            ImGui.TableNextRow()
            for i, btn in ipairs(row) do
                ImGui.TableSetColumnIndex(i - 1)

                -- Button fills the full column width so every cell is
                -- the same size regardless of label length.
                if btn.active then
                    ImGui.PushStyleColor(ImGuiCol.Button,        0.1,  0.55, 0.1,  1)
                    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.15, 0.65, 0.15, 1)
                    ImGui.PushStyleColor(ImGuiCol.ButtonActive,  0.05, 0.45, 0.05, 1)
                    ImGui.PushStyleColor(ImGuiCol.Text,          1,    1,    0.4,  1)
                    if ImGui.Button(btn.label .. ' [ACTIVE]##' .. btn.id, colWidth, 0) then
                        pendingStop = { id = scriptID(btn.script), label = btn.label }
                    end
                    ImGui.PopStyleColor(4)
                else
                    ImGui.PushStyleColor(ImGuiCol.Button,        0.2,  0.2,  0.2,  1)
                    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.35, 0.35, 0.35, 1)
                    ImGui.PushStyleColor(ImGuiCol.ButtonActive,  0.15, 0.15, 0.15, 1)
                    ImGui.PushStyleColor(ImGuiCol.Text,          0.9,  0.9,  0.9,  1)
                    if ImGui.Button(btn.label .. '##' .. btn.id, colWidth, 0) then
                        pendingRun = { id = scriptID(btn.script), label = btn.label, transient = btn.transient,
                                       args = select(2, splitScript(btn.script)) }
                    end
                    ImGui.PopStyleColor(4)
                end
            end
        end

        ImGui.EndTable()
    end

    ImGui.PopStyleVar()   -- CellPadding
end

-- ------------------------------------------------------------
--  Setup tab
-- ------------------------------------------------------------

-- Setup tab → "Move / reorder a button" (below the separator).
local function renderMoveSection(wrapX)
    local sel
    for _, b in ipairs(buttons) do
        if b.script == moveForm.script then sel = b; break end
    end
    if not sel then
        sel = buttons[1]
        moveForm.script, moveForm.row = sel.script, sel.row
    end

    -- Other buttons in the chosen target row (the moved button excluded), and
    -- the moved button's current slot if that row is its own.
    local others, curPos = {}, nil
    for i, b in ipairs(buttonsInRow(moveForm.row)) do
        if b.script == sel.script then curPos = i else others[#others + 1] = b end
    end
    -- Whenever the button or target row changes, reset the position: its
    -- current slot when staying in the row, otherwise the end of the new row.
    local key = sel.script .. '|' .. moveForm.row
    if moveForm.key ~= key then
        moveForm.key = key
        moveForm.pos = curPos or (#others + 1)
    end
    moveForm.pos = math.max(1, math.min(moveForm.pos, #others + 1))

    local function posLabel(i)
        local nxt = others[i]
        if nxt then return string.format('%d   (before %s)', i, nxt.label) end
        if #others == 0 then return string.format('%d   (only button in row)', i) end
        return string.format('%d   (end of row)', i)
    end

    ImGui.SetCursorPosX(WIN_PAD_X)
    boldHeading(HEAD_EDIT_COLOR[1], HEAD_EDIT_COLOR[2], HEAD_EDIT_COLOR[3],
                'EDIT EXISTING LUA BUTTON')
    ImGui.Spacing()
    ImGui.SetCursorPosX(WIN_PAD_X)
    ImGui.Text('Move / reorder / delete a button')
    ImGui.Spacing()

    local offX  = WIN_PAD_X + 60
    local itemW = wrapX - offX

    ImGui.SetCursorPosX(WIN_PAD_X)
    ImGui.Text('Button')
    ImGui.SameLine(offX)
    ImGui.SetNextItemWidth(itemW)
    if ImGui.BeginCombo('##moveBtn', string.format('%s  (row %d)', sel.label, sel.row)) then
        for _, row in ipairs(rows) do
            for _, b in ipairs(row) do
                if selectable(string.format('%s  (row %d)##mv%d', b.label, b.row, b.id),
                              b.script == moveForm.script) then
                    moveForm.script, moveForm.row = b.script, b.row
                end
            end
        end
        ImGui.EndCombo()
    end

    ImGui.SetCursorPosX(WIN_PAD_X)
    ImGui.Text('To row')
    ImGui.SameLine(offX)
    ImGui.SetNextItemWidth(itemW)
    if ImGui.BeginCombo('##moveRow', rowLabelFor(moveForm.row)) then
        for _, ri in ipairs(rowInfo) do
            if selectable(rowLabelFor(ri.num) .. '##mrow' .. ri.num, moveForm.row == ri.num) then
                moveForm.row = ri.num
            end
        end
        local newNum = nextNewRow()
        if selectable(rowLabelFor(newNum) .. '##mrowNew', moveForm.row == newNum) then
            moveForm.row = newNum
        end
        ImGui.EndCombo()
    end

    ImGui.SetCursorPosX(WIN_PAD_X)
    ImGui.Text('Position')
    ImGui.SameLine(offX)
    ImGui.SetNextItemWidth(itemW)
    if ImGui.BeginCombo('##movePos', posLabel(moveForm.pos)) then
        for i = 1, #others + 1 do
            if selectable(posLabel(i) .. '##mpos' .. i, moveForm.pos == i) then
                moveForm.pos = i
            end
        end
        ImGui.EndCombo()
    end

    ImGui.Spacing()
    ImGui.SetCursorPosX(WIN_PAD_X)
    if ImGui.Button('Move##setupMove') then
        moveStatus  = nil
        pendingMove = { script = moveForm.script, row = moveForm.row, pos = moveForm.pos }
    end

    -- Deletes the button chosen in the Button box.  Nothing is deleted here:
    -- this only opens the confirmation window (renderDeleteWindow).
    ImGui.SameLine()
    ImGui.PushStyleColor(ImGuiCol.Button,        0.6,  0.15, 0.15, 1)
    ImGui.PushStyleColor(ImGuiCol.ButtonHovered, 0.75, 0.2,  0.2,  1)
    ImGui.PushStyleColor(ImGuiCol.ButtonActive,  0.5,  0.1,  0.1,  1)
    if ImGui.Button('DELETE LUA BUTTON##setupDelete') then
        moveStatus    = nil
        deleteConfirm = { script = sel.script, label = sel.label, row = sel.row }
    end
    ImGui.PopStyleColor(3)

    if moveStatus then
        ImGui.Spacing()
        ImGui.SetCursorPosX(WIN_PAD_X)
        if moveStatus.ok then
            ImGui.PushStyleColor(ImGuiCol.Text, 0.4, 0.9, 0.4, 1)
        else
            ImGui.PushStyleColor(ImGuiCol.Text, 1, 0.4, 0.4, 1)
        end
        ImGui.PushTextWrapPos(wrapX)
        ImGui.Text(moveStatus.text)
        ImGui.PopTextWrapPos()
        ImGui.PopStyleColor()
    end
end

local function renderSetupTab()
    local wrapX = calcWindowWidth() - WIN_PAD_X

    ImGui.Spacing()
    ImGui.SetCursorPosX(WIN_PAD_X)
    boldHeading(HEAD_ADD_COLOR[1], HEAD_ADD_COLOR[2], HEAD_ADD_COLOR[3], 'ADD LUA BUTTON')
    ImGui.Spacing()
    ImGui.SetCursorPosX(WIN_PAD_X)
    ImGui.PushTextWrapPos(wrapX)
    ImGui.Text('Add a Lua script to the launcher. It is saved into menu_config.lua '
            .. 'and its button appears on the LUA tab straight away.')
    ImGui.PopTextWrapPos()
    ImGui.Spacing()

    if cfgNested then
        ImGui.SetCursorPosX(WIN_PAD_X)
        ImGui.PushStyleColor(ImGuiCol.Text, 1, 0.55, 0.3, 1)
        ImGui.PushTextWrapPos(wrapX)
        ImGui.Text('menu_config.lua uses the nested `rows` layout, which this tab '
                .. 'cannot edit. Switch it to the flat `apps` layout to use Add Script.')
        ImGui.PopTextWrapPos()
        ImGui.PopStyleColor()
        ImGui.SetCursorPosX(WIN_PAD_X)
    else
        ImGui.SetCursorPosX(WIN_PAD_X)
        if ImGui.Button('Add Script...##setupAdd') then openAddWindow() end
        ImGui.SameLine()
    end
    if ImGui.Button('Reload Config##setupReload') then pendingReload = true end

    if setupStatus then
        ImGui.Spacing()
        ImGui.SetCursorPosX(WIN_PAD_X)
        if setupStatus.ok then
            ImGui.PushStyleColor(ImGuiCol.Text, 0.4, 0.9, 0.4, 1)
        else
            ImGui.PushStyleColor(ImGuiCol.Text, 1, 0.4, 0.4, 1)
        end
        ImGui.PushTextWrapPos(wrapX)
        ImGui.Text(setupStatus.text)
        ImGui.PopTextWrapPos()
        ImGui.PopStyleColor()
    end

    ImGui.Spacing()
    ImGui.SetCursorPosX(WIN_PAD_X)
    ImGui.PushStyleColor(ImGuiCol.Text, 0.6, 0.6, 0.6, 1)
    ImGui.PushTextWrapPos(wrapX)
    ImGui.Text(string.format('%d script%s in %d row%s  -  %s',
        #buttons, #buttons == 1 and '' or 's',
        #rows,    #rows    == 1 and '' or 's',
        CONFIG_PATH))
    ImGui.PopTextWrapPos()
    ImGui.PopStyleColor()

    if not cfgNested and #buttons > 0 then
        ImGui.Spacing()
        ImGui.Separator()
        ImGui.Spacing()
        renderMoveSection(wrapX)
    end
    ImGui.Spacing()
end

-- ------------------------------------------------------------
--  Add Script window  (pop-up opened from the Setup tab)
-- ------------------------------------------------------------

local function renderAddWindow()
    if not addOpen then return end

    local w, h = 520, 360
    centerNextWindow(w, h)
    ImGui.SetNextWindowSize(w, h, ImGuiCond.FirstUseEver)

    local visible
    addOpen, visible = ImGui.Begin('Add Script to Menu###LauncherAddScript', addOpen,
                                   ImGuiWindowFlags.NoCollapse)
    if visible then
        local v

        ImGui.Text('Label')
        ImGui.SameLine(80)
        ImGui.SetNextItemWidth(-1)
        v = ImGui.InputText('##addLabel', addForm.label)
        if type(v) == 'string' then addForm.label = v end

        ImGui.Text('Script')
        ImGui.SameLine(80)
        ImGui.SetNextItemWidth(-90)
        v = ImGui.InputText('##addScript', addForm.script)
        if type(v) == 'string' then addForm.script = v end
        ImGui.SameLine()
        if ImGui.Button('Browse...##addBrowse', 80, 0) then openBrowse() end

        -- Arguments: one box per argument.  Joined with spaces after the file
        -- name when saved.  X clears/removes a box; "+ Add argument" appends one.
        ImGui.Text('Arguments')
        ImGui.SameLine(80)
        local delIdx
        for i = 1, #addForm.args do
            if i > 1 then ImGui.SetCursorPosX(80) end
            ImGui.SetNextItemWidth(-40)
            v = ImGui.InputText('##addArg' .. i, addForm.args[i])
            if type(v) == 'string' then addForm.args[i] = v end
            ImGui.SameLine()
            if ImGui.Button('X##addArgDel' .. i, 26, 0) then delIdx = i end
        end
        if delIdx then
            if #addForm.args > 1 then
                table.remove(addForm.args, delIdx)
            else
                addForm.args[1] = ''
            end
        end
        ImGui.SetCursorPosX(80)
        if ImGui.Button('+ Add argument##addArgAdd') then
            addForm.args[#addForm.args + 1] = ''
        end

        ImGui.Text('Row')
        ImGui.SameLine(80)
        ImGui.SetNextItemWidth(-1)
        if ImGui.BeginCombo('##addRow', rowLabelFor(addForm.row)) then
            for _, ri in ipairs(rowInfo) do
                if selectable(rowLabelFor(ri.num) .. '##row' .. ri.num, addForm.row == ri.num) then
                    addForm.row = ri.num
                end
            end
            local newNum = nextNewRow()
            if selectable(rowLabelFor(newNum) .. '##rowNew', addForm.row == newNum) then
                addForm.row = newNum
            end
            ImGui.EndCombo()
        end

        ImGui.Spacing()
        ImGui.PushStyleColor(ImGuiCol.Text, 0.6, 0.6, 0.6, 1)
        ImGui.TextWrapped('Scripts must live inside the MacroQuest lua folder. Use Browse... '
                       .. 'to pick the .lua file (for a folder script choose its init.lua), '
                       .. 'or type the path relative to the lua folder. Put each argument '
                       .. 'for the script in its own Arguments box (one word per box).')
        ImGui.PopStyleColor()

        -- Live check of the typed/selected path (string checks only).
        local file = scriptFilePart(normalizeScript(addForm.script))
        local problem = file and supportProblem(file)
        if problem then
            ImGui.Spacing()
            ImGui.PushStyleColor(ImGuiCol.Text, 1, 0.55, 0.3, 1)
            ImGui.TextWrapped(problem)
            ImGui.PopStyleColor()
        end

        -- Live preview of the script string that will be written, or the
        -- reason the arguments can't be used.
        if file and not problem then
            local typedRaw = tostring(addForm.script or ''):match('^%s*(.-)%s*$')
            local argStr, aerr = collectArgs(select(2, splitScript(typedRaw)), addForm.args)
            ImGui.Spacing()
            if argStr then
                ImGui.PushStyleColor(ImGuiCol.Text, 0.6, 0.6, 0.6, 1)
                ImGui.TextWrapped('Will be saved as:  script = "'
                    .. escapeLua(file .. (argStr ~= '' and (' ' .. argStr) or '')) .. '"')
            else
                ImGui.PushStyleColor(ImGuiCol.Text, 1, 0.55, 0.3, 1)
                ImGui.TextWrapped(aerr)
            end
            ImGui.PopStyleColor()
        end

        if addForm.error then
            ImGui.Spacing()
            ImGui.PushStyleColor(ImGuiCol.Text, 1, 0.4, 0.4, 1)
            ImGui.TextWrapped(addForm.error)
            ImGui.PopStyleColor()
        end

        ImGui.Spacing()
        ImGui.Separator()
        ImGui.Spacing()
        if ImGui.Button('Add to Menu##addGo', 130, 0) then
            addForm.error = nil
            local argsCopy = {}
            for i, a in ipairs(addForm.args) do argsCopy[i] = a end
            pendingAdd = { label = addForm.label, script = addForm.script, row = addForm.row,
                           args = argsCopy }
        end
        ImGui.SameLine()
        if ImGui.Button('Cancel##addCancel', 90, 0) then
            addOpen = false
            browse.open = false
        end
    end
    ImGui.End()

    -- Closing the Add window (X or Cancel) also closes the browser.
    if not addOpen then browse.open = false end
end

-- ------------------------------------------------------------
--  Browse window  (file picker opened from the Add Script window)
-- ------------------------------------------------------------

local function renderBrowseWindow()
    if not browse.open then return end

    local w, h = 540, 460
    centerNextWindow(w, h, 40, 30)
    ImGui.SetNextWindowSize(w, h, ImGuiCond.FirstUseEver)

    local visible
    browse.open, visible = ImGui.Begin('Select Lua Script###LauncherBrowse', browse.open,
                                       ImGuiWindowFlags.NoCollapse)
    if visible then
        local atRoot = browse.dir:lower() == LUA_ROOT:lower()

        -- Navigation row.
        if not atRoot then
            if ImGui.Button('Up##bUp') then browseUp() end
            ImGui.SameLine()
            if ImGui.Button('Lua Folder##bRoot') then browseTo(LUA_ROOT) end
            ImGui.SameLine()
        end
        if ImGui.Button('Refresh##bRefresh') then refreshBrowse() end

        local rel = toRelative(browse.dir) or ''
        ImGui.Text('Folder:  [lua]/' .. rel)

        ImGui.Text('Filter')
        ImGui.SameLine(60)
        ImGui.SetNextItemWidth(220)
        local v = ImGui.InputText('##bFilter', browse.filter)
        if type(v) == 'string' then browse.filter = v end

        -- Selection summary and the confirm / cancel buttons.
        local sel     = browse.selected
        local problem = sel and supportProblem(sel)
        if sel then
            ImGui.Text('Selected:  ' .. sel)
            if problem then
                ImGui.PushStyleColor(ImGuiCol.Text, 1, 0.55, 0.3, 1)
                ImGui.TextWrapped(problem)
                ImGui.PopStyleColor()
            end
        else
            ImGui.PushStyleColor(ImGuiCol.Text, 0.6, 0.6, 0.6, 1)
            ImGui.Text('Click a .lua file to select it (double-click to confirm).')
            ImGui.PopStyleColor()
        end

        local confirm = false
        if sel and not problem then
            if ImGui.Button('Select##bSelect', 100, 0) then confirm = true end
            ImGui.SameLine()
        end
        if ImGui.Button('Cancel##bCancel', 100, 0) then browse.open = false end

        ImGui.Separator()

        -- File / folder list.  Navigation is applied after the loop so the
        -- list being iterated is never replaced mid-iteration.
        local navTo
        if browse.err then
            ImGui.PushStyleColor(ImGuiCol.Text, 1, 0.4, 0.4, 1)
            ImGui.TextWrapped(browse.err)
            ImGui.PopStyleColor()
        elseif browse.entries then
            local flt = browse.filter:lower()
            local dblFlag = ImGuiSelectableFlags and ImGuiSelectableFlags.AllowDoubleClick or nil

            if not atRoot then
                if selectable('[..]   Up one level##bUpRow', false) then navTo = 'UP' end
            end

            local shown = 0
            for i, e in ipairs(browse.entries) do
                if flt == '' or e.name:lower():find(flt, 1, true) then
                    shown = shown + 1
                    if e.isDir then
                        local lbl = '[DIR]   ' .. e.name
                                 .. (e.hasInit and '     (has init.lua)' or '') .. '##d' .. i
                        if selectable(lbl, false) then navTo = browse.dir .. '/' .. e.name end
                    else
                        local fileRel = toRelative(browse.dir .. '/' .. e.name)
                        if selectable(e.name .. '##f' .. i, browse.selected == fileRel, dblFlag) then
                            browse.selected = fileRel
                            if ImGui.IsMouseDoubleClicked(0) then confirm = true end
                        end
                    end
                end
            end
            if shown == 0 then
                ImGui.PushStyleColor(ImGuiCol.Text, 0.6, 0.6, 0.6, 1)
                ImGui.Text(flt ~= '' and 'Nothing matches the filter.'
                                     or 'No folders or .lua files here.')
                ImGui.PopStyleColor()
            end
        end

        if navTo == 'UP' then
            browseUp()
        elseif navTo then
            browseTo(navTo)
        end

        if confirm and browse.selected and not supportProblem(browse.selected) then
            chooseFile(browse.selected)
            browse.open = false
        end
    end
    ImGui.End()
end

-- ------------------------------------------------------------
--  Delete confirmation window  (opened by DELETE LUA BUTTON on the Setup tab)
--  Yes queues the delete (done in the main loop); No / the X just closes it.
-- ------------------------------------------------------------

local function renderDeleteWindow()
    if not deleteConfirm then return end

    local w, h = 440, 170
    centerNextWindow(w, h, 20, 20)
    ImGui.SetNextWindowSize(w, h, ImGuiCond.FirstUseEver)

    local keep, visible = ImGui.Begin('Delete LUA Button###LauncherDeleteConfirm', true,
                                      ImGuiWindowFlags.NoCollapse)
    if visible then
        ImGui.TextWrapped('Do you really want to delete this LUA button?')
        ImGui.Spacing()
        ImGui.PushStyleColor(ImGuiCol.Text, 1, 1, 0.4, 1)
        ImGui.TextWrapped(string.format('%s   (row %d)', deleteConfirm.label, deleteConfirm.row))
        ImGui.PopStyleColor()
        ImGui.PushStyleColor(ImGuiCol.Text, 0.6, 0.6, 0.6, 1)
        ImGui.TextWrapped(deleteConfirm.script)
        ImGui.TextWrapped('It will be removed from menu_config.lua. The previous file is '
                       .. 'kept as menu_config.lua.bak.')
        ImGui.PopStyleColor()

        ImGui.Spacing()
        ImGui.Separator()
        ImGui.Spacing()
        if ImGui.Button('Yes##delYes', 100, 0) then
            pendingDelete = { script = deleteConfirm.script }
            deleteConfirm = nil
        end
        ImGui.SameLine()
        if deleteConfirm and ImGui.Button('No##delNo', 100, 0) then
            deleteConfirm = nil
        end
    end
    ImGui.End()

    if keep == false then deleteConfirm = nil end    -- closed with the X
end

-- Expanded toolbar (tab bar with the LUA and Setup tabs).  When the user
-- clicks the title-bar chevron, ImGui.IsWindowCollapsed() turns true; that is
-- the cue to switch into minimised/icon mode instead of showing a bare
-- title bar.
local function renderToolbar()
    -- Clear any collapsed flag left over from the chevron click so the
    -- toolbar reopens expanded rather than immediately re-minimising.
    if forceExpand then
        ImGui.SetNextWindowCollapsed(false, ImGuiCond.Always)
        forceExpand = false
    end

    -- Push WindowPadding.x to 0 BEFORE Begin so the content area starts at
    -- the window's true left edge.  SetCursorPosX(WIN_PAD_X) then places
    -- each row at exactly WIN_PAD_X pixels from the edge — no offset from
    -- ImGui's default padding sneaking in.  WindowPadding.y stays at 4 for
    -- vertical breathing room below the title bar.
    ImGui.PushStyleVar(ImGuiStyleVar.WindowPadding, 0, 4)

    -- Force the window to exactly the width needed for the current
    -- set of labels.  ImGuiCond.Always reapplies every frame so the
    -- window tracks label changes (e.g. [ACTIVE] suffix toggling).
    -- Height 0 lets ImGui auto-fit vertically.
    ImGui.SetNextWindowSize(calcWindowWidth(), 0, ImGuiCond.Always)

    local visible
    open, visible = ImGui.Begin(WIN_TITLE, open, ImGuiWindowFlags.NoResize)

    -- Detect the chevron click via the window's collapsed state directly.
    -- This is more reliable than Begin's second return value, which does not
    -- flag a collapse consistently across MQ/ImGui builds.
    if ImGui.IsWindowCollapsed() then
        -- Chevron clicked → minimise to the icon instead of a bare title bar.
        minimized = true
    elseif visible then
        ImGui.PushStyleVar(ImGuiStyleVar.FramePadding, FRAME_PAD_X, 3)

        -- Two tabs: LUA (the launcher buttons) and Setup (add scripts).
        -- The tab bar is inset by WIN_PAD_X like everything else.
        ImGui.SetCursorPosX(WIN_PAD_X)
        if ImGui.BeginTabBar('##launcherTabs') then
            if ImGui.BeginTabItem('LUA') then
                renderLuaTab()
                ImGui.EndTabItem()
            end
            if ImGui.BeginTabItem('Setup') then
                renderSetupTab()
                ImGui.EndTabItem()
            end
            ImGui.EndTabBar()
        end

        ImGui.PopStyleVar()   -- FramePadding
    end

    ImGui.End()
    ImGui.PopStyleVar()        -- WindowPadding (pushed before Begin)
end

local function renderUI()
    if not initialSyncDone then return end

    if minimized then
        renderIcon()
    else
        renderToolbar()
    end

    -- Setup-tab pop-ups (independent windows; they stay open while minimised).
    renderAddWindow()
    renderBrowseWindow()
    renderDeleteWindow()
end

-- ============================================================
--  Initialisation — Phase 3: register ImGui callback
--  Done last, after all state is ready.
-- ============================================================

mq.imgui.init('ScriptLauncher', renderUI)

-- ============================================================
--  Main loop
--  Runs at ~10 Hz.  Handles deferred run / stop / add / move / delete / reload
--  requests queued by the render callback, and re-syncs the active
--  states every 2 seconds.
-- ============================================================

local lastSync = mq.gettime()

while open do
    mq.delay(100)

    if pendingRun then
        -- Issue the run, then poll across a window for the script to appear
        -- running.  waitForStart returns true the moment it is seen, so a
        -- short-lived script that starts, acts and exits on its own is still
        -- caught while briefly alive instead of being missed by a single
        -- late scan.  A `transient`-flagged script that is never observed is
        -- assumed to have completed too fast to sample (reported "Launched"),
        -- not failed.
        local id, label, transient = pendingRun.id, pendingRun.label, pendingRun.transient
        local args = pendingRun.args
        if args and args ~= '' then
            mq.cmdf('/lua run %s %s', id, args)    -- script arguments
        else
            mq.cmdf('/lua run %s', id)
        end
        pendingRun = nil
        if waitForStart(id, transient and 500 or 1500) then
            notify('\agStarted\ax: %s', label)
        elseif transient then
            notify('\agLaunched\ax: %s \aw(one-shot; exited too quickly to confirm)\ax', label)
        else
            notify('\arFailed to start\ax: %s', label)
        end
        syncActiveStates()   -- refresh button colours against current state
    end

    if pendingStop then
        -- Issue the stop, wait for it to exit, re-scan, then report
        -- the actual result (running[id] still set ⇒ it did not stop).
        local id, label = pendingStop.id, pendingStop.label
        mq.cmdf('/lua stop %s', id)
        pendingStop = nil
        mq.delay(200)      -- allow the script time to exit before re-scanning
        local running = syncActiveStates()
        if running[id] then
            notify('\arStill running\ax: %s', label)
        else
            notify('\arStopped\ax: %s', label)
        end
    end

    if pendingAdd then
        -- Save the new entry into menu_config.lua and rebuild the buttons.
        -- (Done here, not in the render callback, like run/stop above.)
        local req = pendingAdd
        pendingAdd = nil
        local ok, a, b, c = performAdd(req)
        if ok then
            notify('\agAdded\ax menu button: %s \aw(%s, row %s)\ax', a, b, c)
            setupStatus = { ok = true, text = string.format('Added "%s" (%s) to row %s.', a, b, c) }
            addOpen = false
            browse.open = false
        else
            addForm.error = a
            notify('\arCould not add script\ax: %s', tostring(a))
        end
    end

    if pendingMove then
        local req = pendingMove
        pendingMove = nil
        local ok, a, b, c = performMove(req)
        if ok then
            notify('\agMoved\ax %s to row %s, position %s', a, b, c)
            moveStatus = { ok = true,
                           text = string.format('Moved "%s" to row %s, position %s.', a, b, c) }
            moveForm.row = b      -- keep the Move section pointed at this button
            moveForm.pos = c
        else
            notify('\arCould not move\ax: %s', tostring(a))
            moveStatus = { ok = false, text = tostring(a) }
        end
    end

    if pendingDelete then
        local req = pendingDelete
        pendingDelete = nil
        local ok, a, b = performDelete(req)
        if ok then
            notify('\agDeleted\ax menu button: %s \aw(%s)\ax', a, b)
            moveStatus = { ok = true, text = string.format('Deleted "%s" (%s).', a, b) }
            moveForm.script, moveForm.key = nil, nil   -- re-pick a valid button
        else
            notify('\arCould not delete\ax: %s', tostring(a))
            moveStatus = { ok = false, text = tostring(a) }
        end
    end

    if pendingReload then
        pendingReload = false
        local ok, err = reloadConfig()
        if ok then
            notify('Config reloaded: %d script(s) in %d row(s).', #buttons, #rows)
            setupStatus = { ok = true, text = 'Config reloaded.' }
        else
            notify('\arConfig reload failed\ax: %s', tostring(err))
            setupStatus = { ok = false, text = 'Reload failed: ' .. tostring(err) }
        end
    end

    local now = mq.gettime()
    if now - lastSync >= 2000 then
        syncActiveStates()
        lastSync = now
    end
end
