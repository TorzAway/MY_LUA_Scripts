-- raidassist_picker.lua
-- MacroQuest Lua script:
-- 1) Builds a combo list of current raid member names
-- 2) Lets you select one
-- 3) Sets a TLO variable named RaidAssist once
-- 4) Announces selection in /rs
-- 5) Exits

local mq = require('mq')
local ImGui = require('ImGui')
local open = true
local selectedIndex = 1
local names = {}
local done = false

local function loadRaidNames()
    names = {}
    local raid = mq.TLO.Raid
    local members = raid.Members() or 0
    for i = 1, members do
        local member = raid.Member(i)
        if member and member.Name() then
            table.insert(names, member.Name())
        end
    end
    table.sort(names, function(a, b) return a:lower() < b:lower() end)
    if #names == 0 then
        selectedIndex = 1
    elseif selectedIndex > #names then
        selectedIndex = 1
    end
end

local function ensureRaidAssistDeclared()
    -- Create RaidAssist if it does not already exist
    if mq.parse('${Defined[RaidAssist]}') ~= 'TRUE' then
        mq.cmd('/declare RaidAssist string outer')
    end
end

local function setRaidAssistAndExit()
    if #names == 0 then
        mq.cmd('/echo No raid members found.')
        done = true
        return
    end
    local picked = names[selectedIndex]
    if not picked or picked == '' then
        mq.cmd('/echo Invalid selection.')
        done = true
        return
    end

    -- Set TLO variable once
	ensureRaidAssistDeclared()
	
    -- (MQ command style variable: /e3varset RaidAssist <name>)
    mq.cmdf('/e3varset RaidAssist %s', picked)	
	
    -- (MQ command style variable: /varset RaidAssist <name>)
    mq.cmdf('/varset RaidAssist %s', picked)	
	
    -- Announce in raid say
    mq.cmdf('/rs FYI: I have just set my ~[RaidAssist]~ to: *[%s]* !!!', picked)
    done = true
end

local function drawUI()
    if not open then
        done = true
        return
    end
    local shouldDraw, newOpen = ImGui.Begin('RaidAssist Picker', open, ImGuiWindowFlags.AlwaysAutoResize)
    open = newOpen
    if shouldDraw then
        ImGui.Text('Select a raid member to set as RaidAssist:')
        ImGui.Separator()
        if ImGui.Button('Refresh Raid List') then
            loadRaidNames()
        end
        if #names == 0 then
            ImGui.TextColored(1, 0.5, 0.5, 1, 'No raid members found.')
        else
            local preview = names[selectedIndex] or 'Select...'
            if ImGui.BeginCombo('##RaidMemberCombo', preview) then
                for i = 1, #names do
                    local isSelected = (i == selectedIndex)
                    if ImGui.Selectable(names[i], isSelected) then
                        selectedIndex = i
                    end
                    if isSelected then
                        ImGui.SetItemDefaultFocus()
                    end
                end
                ImGui.EndCombo()
            end
        end
        ImGui.Separator()
        if ImGui.Button('Set RaidAssist') then
            setRaidAssistAndExit()
        end
        ImGui.SameLine()
        if ImGui.Button('Cancel') then
            done = true
        end
    end
    ImGui.End()
end

-- Initial load
loadRaidNames()
-- Main loop
mq.imgui.init('RaidAssistPickerUI', drawUI)

while not done do
    mq.delay(10)
end

mq.imgui.destroy('RaidAssistPickerUI')
