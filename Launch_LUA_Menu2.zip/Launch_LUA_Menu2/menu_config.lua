-- ============================================================
--  menu_config.lua  -  Add your scripts here
--
--  Each entry:
--    label  : text shown on the button (keep it short)
--    script : filename without .lua, OR "FolderName/init.lua",
--             relative to MacroQuest/lua/
--
--  LAYOUT (rows & order)
--  ---------------------
--    row    : (optional) which row the button is on.
--             1 = top row, 2 = next, and so on.
--             Omit it and the button goes on row 1.
--             The number of rows shown = how many distinct row
--             numbers you use.
--    order  : (optional) position within its row; lower = further
--             left.  If omitted, buttons keep the order they are
--             listed in below.
--
--  ONE-SHOT / SHORT-LIVED SCRIPTS
--  ------------------------------
--    oneshot : (optional) set `oneshot = true` for a script that
--              starts, performs one action, then terminates on its
--              own.  The launcher verifies a normal start by polling
--              for the script to appear running, which already catches
--              most short-lived scripts.  But one that finishes faster
--              than the poll can sample would otherwise be reported as
--              "Failed to start"; flagging it as oneshot makes that
--              case report "Launched" instead.  (`transient = true`
--              works as an alias.)  Example:
--                { label = "Handins", script = "handins/init.lua",
--                  row = 3, oneshot = true }
--
--  So below: rows 1, 2 and 3 are shown.  Within each row the
--  buttons appear left-to-right in listed order.  Move a button to
--  a different row by changing its `row`; reorder within a row by
--  reordering the lines (or by setting `order`).
-- ============================================================

return {
    apps = {
        -- Row 1
        { label = "Button-M",      script = "buttonmaster/init.lua",   row = 1 },
		{ label = "GLD-Bank-Mgr", script = "GuildBankMaint/init.lua",  row = 1 },
		{ label = "AAParty",       script = "aaparty/init.lua driver", row = 1 },
		
        -- Row 2
		{ label = "Raid-Bot",     script = "RaidAssistBot/init.lua",  row = 2 },
		{ label = "BRD-Kite",     script = "BardKite/init.lua",       row = 2 },
		{ label = "Handins",      script = "handins/init.lua",        row = 2 },
		
        -- Row 3
        { label = "Gambler",      script = "Gambler/init.lua",        row = 3 },    
		{ label = "Symbols",     script = "Symbol_Handin/init.lua",   row = 3 },        
		{ label = "XTarget",     script = "xtargetx/init.lua",        row = 3 },
		
		-- Row 4
		{ label = "TurboLoot",     script = "Turbo/init.lua",        row = 4 },
		{ label = "NPCSpawnLog",   script = "NPCSpawnLog/init.lua",  row = 4 },
		{ label = "Merch-Buy",    script = "MerchantBuyer/init.lua", row = 4 },

		-- Row 5
		{ label = "MyChat",     script = "MyChat/init.lua",          row = 5 },		
		{ label = "BoxHud",     script = "boxhud/init.lua",          row = 5 },	
		{ label = "Lazcraft",     script = "lazcraft/init.lua",      row = 5 },
		
		-- Row 6
		{ label = "LuaChase",     script = "luachase/init.lua",      row = 6 },
    }
}

-- ============================================================
--  ALTERNATIVE LAYOUT (nested rows)
--  --------------------------------
--  If you'd rather have the config visually mirror the screen,
--  you can instead return a `rows` table.  Each inner table is a
--  row (top→bottom); buttons appear left→right in listed order.
--  Delete the `return` block above and use this style instead:
--
--  return {
--      rows = {
--          {   -- row 1
--              { label = "GLD-Bank-Mgr", script = "GuildBankMaint/init.lua" },
--              { label = "Merch-Buy",    script = "MerchantBuyer/init.lua" },
--          },
--          {   -- row 2
--              { label = "Raid-Bot", script = "RaidAssistBot/init.lua" },
--              { label = "BRD-Kite", script = "BardKite/init.lua" },
--          },
--          {   -- row 3
--              { label = "Gambler", script = "Gambler/init.lua" },
--          },
--      }
--  }
-- ============================================================
